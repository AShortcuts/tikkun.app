const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["../chunks/4sasMrN8.js","../chunks/BKyGW8e_.js","../chunks/HclGiUj8.js","../chunks/Ccw47rD8.js","../chunks/Bi-iJBTs.js","../chunks/xihTtKlq.js","../chunks/BMudkHWd.js","../chunks/DKx5_7NX.js","../chunks/CNzCO5PF.js","../chunks/CygPNIQN.js","../chunks/D0QugGjg.js","../chunks/C95F8--H.js","../chunks/CT4bspt6.js","../chunks/lUv01tge.js","../assets/UpdatePrompt.BIPq9Q8g.css","../chunks/CS2xXTzO.js","../chunks/pQ1g9p7j.js","../chunks/Bp8nYgQN.js","../chunks/BM-H3AMm.js","../chunks/DOdgCi89.js","../chunks/CfgJk93m.js","../chunks/Dd7cfVUm.js","../chunks/BKYQXYn7.js","../chunks/C8_FwxZz.js","../chunks/mkujADwL.js","../chunks/CYDxUvyN.js","../chunks/9TVex-1-.js","../chunks/DYadnLiy.js","../chunks/BgwmKRfG.js","../chunks/0BKoAcky.js","../chunks/BdJKXlo7.js","../chunks/CLuianmQ.js","../chunks/C_sG4J_C.js"])))=>i.map(i=>d[i]);
import{B as e,D as t,Et as n,F as r,L as i,S as a,Tt as o,U as s,Y as c,Z as l,_t as u,a as d,ct as f,et as p,f as m,it as h,j as g,nt as _,o as v,ot as y,r as b,rt as x,tt as S,ut as C,vt as w,yt as T,z as E}from"../chunks/BKyGW8e_.js";import{l as D,n as O,r as k}from"../chunks/DKx5_7NX.js";import{t as A}from"../chunks/HclGiUj8.js";import"../chunks/xihTtKlq.js";import{a as j,t as M}from"../chunks/BMudkHWd.js";import{n as N}from"../chunks/D0QugGjg.js";import{i as P,r as F}from"../chunks/pQ1g9p7j.js";import{n as I,r as L}from"../chunks/BM-H3AMm.js";import"../chunks/D4pwonf0.js";/* empty css                */import{i as R,r as z}from"../chunks/BdJKXlo7.js";var B=`@layer reset, tokens, shell, reader, feature, responsive, overrides;

@layer tokens {
  :root {
    color-scheme: light;
    --paper-color: oklch(98.5% 0 0);
    --page-ink-color: oklch(0% 0 0 / 0.8);
    --annotations-toggle-active-color: black;
    --verses-color: oklch(0% 0 0 / 0.35);
    --light-accent-color: oklch(0% 0 0 / 0.05);
    --medium-accent-color: oklch(0% 0 0 / 0.1);
    --heavy-accent-color: oklch(0% 0 0 / 0.2);
    --text-color: oklch(0% 0 0 / 0.7);
    --light-text-color: oklch(0% 0 0 / 0.5);
    --reader-custom-background-color: #eee6d6;
    --reader-custom-text-color: #3b3026;
  }

  html[data-reader-theme='sepia'] {
    --paper-color: oklch(90% 17% 90deg);
  }

  html[data-reader-theme='dark'] {
    color-scheme: dark;
    --paper-color: oklch(25% 0 0);
    --page-ink-color: oklch(100% 0 0 / 0.8);
    --annotations-toggle-active-color: oklch(100% 0 0 / 0.8);
    --verses-color: oklch(100% 0 0 / 0.35);
    --light-accent-color: oklch(100% 0 0 / 0.05);
    --medium-accent-color: oklch(100% 0 0 / 0.1);
    --heavy-accent-color: oklch(100% 0 0 / 0.2);
    --text-color: oklch(100% 0 0 / 0.7);
    --light-text-color: oklch(100% 0 0 / 0.5);
  }

  html[data-reader-theme='custom'] {
    --paper-color: var(--reader-custom-background-color);
    --page-ink-color: var(--reader-custom-text-color);
    --annotations-toggle-active-color: var(--reader-custom-text-color);
    --verses-color: color-mix(in srgb, var(--reader-custom-text-color) 42%, transparent);
    --light-accent-color: color-mix(in srgb, var(--reader-custom-text-color) 6%, transparent);
    --medium-accent-color: color-mix(in srgb, var(--reader-custom-text-color) 12%, transparent);
    --heavy-accent-color: color-mix(in srgb, var(--reader-custom-text-color) 22%, transparent);
    --text-color: var(--reader-custom-text-color);
    --light-text-color: color-mix(in srgb, var(--reader-custom-text-color) 68%, transparent);
  }

  @media (prefers-color-scheme: dark) {
    html[data-reader-theme='automatic'] {
      color-scheme: dark;
      --paper-color: oklch(25% 0 0);
      --page-ink-color: oklch(100% 0 0 / 0.8);
      --annotations-toggle-active-color: oklch(100% 0 0 / 0.8);
      --verses-color: oklch(100% 0 0 / 0.35);
      --light-accent-color: oklch(100% 0 0 / 0.05);
      --medium-accent-color: oklch(100% 0 0 / 0.1);
      --heavy-accent-color: oklch(100% 0 0 / 0.2);
      --text-color: oklch(100% 0 0 / 0.7);
      --light-text-color: oklch(100% 0 0 / 0.5);
    }
  }
}

@layer shell {
  html,
  body {
    background-color: var(--paper-color);
    color: var(--text-color);
  }
}
`,V=i(`<!> <meta id="reader-theme-color" name="theme-color"/>`,1),H=i(`<p class="svelte-9j1inu">Opening Reader…</p>`),U=i(`<div class="reader-boot-panel svelte-9j1inu"><h1 class="svelte-9j1inu">Reader couldn’t start</h1> <p class="svelte-9j1inu">Try again, or continue from the reading index.</p> <div class="reader-boot-actions svelte-9j1inu"><button type="button" class="svelte-9j1inu">Try again</button> <a class="svelte-9j1inu">Reading index</a> <a class="svelte-9j1inu">About</a></div></div>`),W=i(`<section class="reader-boot-state svelte-9j1inu" data-target-id="reader-boot-state"><!></section>`),G=i(`<div class="app" data-target-id="app-root"><div data-target-id="reader-shell-anchor" hidden=""></div> <div data-target-id="cue-authoring-panel-root"></div> <div data-target-id="cue-authoring-access-dialog-root"></div> <div data-target-id="command-palette-root"></div> <div data-target-id="recording-issue-dialog-root"></div> <div class="reader-issue-toast u-hidden" data-target-id="reader-issue-toast" role="status" aria-live="polite"></div> <div class="reader-issue-toast u-hidden" data-target-id="persistence-toast" role="status" aria-live="polite"></div> <div data-target-id="cue-authoring-export-sheet-root"></div> <audio data-target-id="reader-audio"></audio> <div id="debug" class="u-hidden"><button type="button" data-target-id="debug-focal-measure-toggle">Toggle focal measure</button></div> <div class="app-offline-prompt u-hidden" data-target-id="app-offline-prompt" role="status" aria-live="polite"><span>This recording isn't available offline. It will retry when your connection
      returns.</span> <button class="app-update-dismiss" data-target-id="app-offline-dismiss" type="button" aria-label="Dismiss offline recording prompt">OK</button></div> <!></div>`);function K(i,o){T(o,!0);let c=`<style data-reader-theme-critical>${B}</style>`,p=()=>A(()=>import(`../chunks/4sasMrN8.js`).then(e=>e.t),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32]),import.meta.url),v=u(M),C=u(j),E=d(o,`loadApp`,3,p),I=d(o,`reloadPage`,3,()=>window.location.reload()),L=f(`loading`),K=f(h(typeof document>`u`?``:getComputedStyle(document.documentElement).getPropertyValue(`--paper-color`).trim())),q=!1,J=0,Y=null,X=!1;k(({from:e,to:t})=>{e?.route.id!==t?.route.id&&(J+=1,Y?.(),Y=null)});function Z(){X?I()():Q()}async function Q(){let e=++J;y(L,`loading`),X=!1;let t=null;try{if(await C?.ready,await P(),q||e!==J||(t=await E()(),q||e!==J))return;let n=t.startApp({downloadOwner:v,openAbout:()=>O(o.aboutHref)});if(q||e!==J){t.stopApp();return}if(Y=()=>t?.stopApp(),X=!0,await n.ready,q||e!==J)return;y(L,`ready`),F(),R()}catch(n){if(q||e!==J)return;if(t)try{t.stopApp()}catch(e){console.error(`Failed to clean up the Reader after startup`,e)}Y=null,console.error(`Failed to start the Reader`,n),y(L,`failed`)}}b(()=>{if(!N()&&window.location.hash.split(`?`,1)[0]===`#/about`){window.location.replace(o.aboutHref);return}let e=document.documentElement,t=window.matchMedia(`(prefers-color-scheme: dark)`),n=()=>{let e=getComputedStyle(document.body).getPropertyValue(`--paper-color`).trim();y(K,e||`oklch(98.5% 0 0)`,!0)},r=new MutationObserver(n);r.observe(e,{attributes:!0,attributeFilter:[`data-reader-theme`,`style`]}),t.addEventListener(`change`,n),n(),Q();let i=()=>{s(L)===`ready`&&document.visibilityState===`visible`&&z()};return window.addEventListener(`online`,i),document.addEventListener(`visibilitychange`,i),()=>{q=!0,window.removeEventListener(`online`,i),document.removeEventListener(`visibilitychange`,i),J+=1,r.disconnect(),t.removeEventListener(`change`,n),Y?.(),Y=null}});var $=G();a(`9j1inu`,e=>{var n=V(),i=_(n);t(i,()=>c);var a=x(i,2);l(()=>m(a,`content`,s(K))),r(e,n)});var ee=x(S($),22),te=t=>{var i=W(),a=S(i),o=e=>{var t=H();r(e,t)},c=t=>{var i=U(),a=x(S(i),4),o=S(a),s=x(o,2),c=x(s,2);n(a),n(i),l((e,t)=>{m(s,`href`,e),m(c,`href`,t)},[()=>D(`/readings/`),()=>D(`/about/`)]),e(`click`,o,Z),r(t,i)};g(a,e=>{s(L)===`loading`?e(o):e(c,-1)}),n(i),l(()=>{m(i,`data-state`,s(L)),m(i,`role`,s(L)===`failed`?`alert`:`status`),m(i,`aria-live`,s(L)===`failed`?`assertive`:`polite`)}),r(t,i)};g(ee,e=>{s(L)!==`ready`&&e(te)}),n($),l(()=>{m($,`data-about-href`,o.aboutHref),m($,`data-reader-boot-state`,s(L)),m($,`aria-busy`,s(L)===`loading`)}),r(i,$),w()}E([`click`]);var q=i(`<meta name="apple-itunes-app"/> <meta name="description" content="Practice Torah reading with Tikkun Reader."/>`,1);function J(e,t){T(t,!1),b(()=>L(document,window.location)),v(),a(`brg3ig`,e=>{var t=q(),n=_(t);o(2),l(()=>m(n,`content`,I)),c(()=>{p.title=`Reader — Tikkun Reader`}),r(e,t)});{let t=C(()=>D(`/`));K(e,{get aboutHref(){return s(t)}})}w()}export{J as component};