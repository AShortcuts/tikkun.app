import{t as e}from"./C95F8--H.js";import{i as t,n,o as r}from"./CT4bspt6.js";import{t as i}from"./CygPNIQN.js";import{_ as a,g as o,h as s}from"./pQ1g9p7j.js";import{a as c,i as l,n as u}from"./Dd7cfVUm.js";import{i as d,l as f}from"./C8_FwxZz.js";import{t as p}from"./CYDxUvyN.js";var m=e=>e.length?e.length===1?e[0]:[e[0],e[e.length-1]].join(`-`):``,h={asVersesRange:e=>m(e.map(e=>{let t=[];return e.v===1&&t.push(e.c),t.push(e.v),t.map(e=>c(e)).join(`:`)}))},g=`tikkun.last-reading`;function _(e,t){return f(e.leining,t)??d(e,t)}function v(e,n){if(!e||typeof e!=`object`)return!1;let r=e;return typeof r.hash==`string`&&i(r.hash)&&typeof r.parshaName==`string`&&r.parshaName.trim().length>0&&(r.aliyahLabel===void 0||typeof r.aliyahLabel==`string`)&&t(r.savedAt,{now:n})}function y(e,t,r=i){return n({storage:e,key:g,validate:e=>v(e,t)&&r(e.hash)})}function b(t,n,a=Date.now()){if(!i(n.hash))return;let o=n.parshaName.trim();if(!o)return;let s={hash:n.hash,parshaName:o,aliyahLabel:n.aliyahLabel?.trim()||void 0,savedAt:a};try{let n=y(t,a),i=n.read();if(i.status===`unavailable`)throw i.error;r(n.write(s,i.revision)),e({reading:s})}catch(e){throw new C(e)}}function x(e,t=Date.now(),n=i){let r=y(e,t,n),a=r.read();return a.status===`unavailable`?(console.error(`Failed to read the last-reading checkpoint`,a.error),null):a.status===`invalid`?(a.reason===`invalid-json`?console.error(`Failed to parse the last-reading checkpoint`,a.error):console.error(`Invalid last-reading checkpoint`),null):a.status===`missing`?null:t-a.value.savedAt>1728e5?(S(r,a.revision),null):a.value}function S(e,t){try{let n=e.remove(t);if(n.status===`unavailable`)throw n.error}catch(e){console.error(`Failed to remove an expired last-reading checkpoint`,e)}}var C=class extends Error{constructor(e){super(`Failed to save the last-reading checkpoint`),this.name=`LastReadingStorageError`,this.cause=e}},w={schemaVersion:1,tradition:`contemporary-ashkenazi-sephardi`,entries:[{id:`genesis-2-4-small-he`,verse:{book:1,chapter:2,verse:4},word:{text:`בהבראם`,occurrence:1},letter:{text:`ה`,position:2},form:{type:`small`}},{id:`genesis-23-2-small-kaf`,verse:{book:1,chapter:23,verse:2},word:{text:`ולבכתה`,occurrence:1},letter:{text:`כ`,position:4},form:{type:`small`}},{id:`genesis-27-46-small-qof`,verse:{book:1,chapter:27,verse:46},word:{text:`קצתי`,occurrence:1},letter:{text:`ק`,position:1},form:{type:`small`}},{id:`leviticus-1-1-small-alef`,verse:{book:3,chapter:1,verse:1},word:{text:`ויקרא`,occurrence:1},letter:{text:`א`,position:5},form:{type:`small`}},{id:`leviticus-6-2-small-mem`,verse:{book:3,chapter:6,verse:2},word:{text:`מוקדה`,occurrence:1},letter:{text:`מ`,position:1},form:{type:`small`}},{id:`numbers-10-35-inverted-nun`,verse:{book:4,chapter:10,verse:35},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-10-36-inverted-nun`,verse:{book:4,chapter:10,verse:36},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-25-11-small-yod`,verse:{book:4,chapter:25,verse:11},word:{text:`פינחס`,occurrence:1},letter:{text:`י`,position:2},form:{type:`small`}},{id:`deuteronomy-32-18-small-yod`,verse:{book:5,chapter:32,verse:18},word:{text:`תשי`,occurrence:1},letter:{text:`י`,position:3},form:{type:`small`}}]},T=e=>!!e&&typeof e==`object`&&!Array.isArray(e),E=e=>Number.isSafeInteger(e)&&Number(e)>0,D=e=>typeof e==`string`&&/^[א-ת]$/u.test(e),O=e=>e.match(/[א-ת\u05c6]/gu)?.join(``)??``,k=(e,t)=>{let n=`Special-letter entry ${t+1}`;if(!T(e))throw Error(`${n} must be an object`);let{id:r,verse:i,word:a,letter:o,form:s}=e;if(typeof r!=`string`||!/^[a-z0-9-]+$/.test(r))throw Error(`${n} has an invalid id`);if(!T(i)||!E(i.book)||!E(i.chapter)||!E(i.verse))throw Error(`${n} has an invalid verse`);if(!T(a)||typeof a.text!=`string`||O(a.text)!==a.text||!E(a.occurrence))throw Error(`${n} has an invalid word target`);if(!T(o)||!(D(o.text)||o.text===`׆`)||!E(o.position)||Array.from(a.text)[o.position-1]!==o.text)throw Error(`${n} has an invalid letter target`);if(!T(s)||s.type!==`small`&&s.type!==`inverted`)throw Error(`${n} has an unsupported form`);if(s.type===`inverted`?a.text!==`׆`||o.text!==`׆`:!D(o.text))throw Error(`${n} has an invalid target for its form`);return{id:r,verse:{book:i.book,chapter:i.chapter,verse:i.verse},word:{text:a.text,occurrence:a.occurrence},letter:{text:o.text,position:o.position},form:{type:s.type}}},A=(e=>{if(!T(e)||e.schemaVersion!==1)throw Error(`Special-letter catalog has an unsupported schema version`);if(typeof e.tradition!=`string`||!e.tradition.trim())throw Error(`Special-letter catalog must name its tradition`);if(!Array.isArray(e.entries))throw Error(`Special-letter catalog entries must be an array`);let t=e.entries.map(k),n=new Set,r=new Set;for(let e of t){if(n.has(e.id))throw Error(`Duplicate special-letter id: ${e.id}`);n.add(e.id);let t=[e.verse.book,e.verse.chapter,e.verse.verse,e.word.text,e.word.occurrence,e.letter.position].join(`:`);if(r.has(t))throw Error(`Duplicate special-letter target: ${t}`);r.add(t)}return{schemaVersion:1,tradition:e.tradition,entries:t}})(w),ee=({b:e,c:t,v:n})=>`${e}:${t}:${n}`,te=({verse:e})=>`${e.book}:${e.chapter}:${e.verse}`,j=A.entries.reduce((e,t)=>{let n=te(t);return e.set(n,[...e.get(n)??[],t]),e},new Map),ne=(e,t)=>`<span
  class="special-letter mod-${t.form.type}"
  data-special-letter-id="${t.id}"
  data-special-letter-form="${t.form.type}"
  data-special-letter-position="${t.letter.position}"
>${e}</span>`,re=(e,t)=>{let n=new Map(t.map(e=>[e.letter.position,e])),r=0;return(e.match(/.\p{Mark}*/gu)??[]).map(e=>{let t=e.match(/[א-ת\u05c6]/u)?.[0];if(!t)return e;r+=1;let i=n.get(r);return!i||i.letter.text!==t?e:ne(e,i)}).join(``)},M=e=>{let t=[...new Set(e.filter(e=>!!e).map(ee))].flatMap(e=>j.get(e)??[]),n=new Map;return e=>{let r=O(e),i=t.filter(e=>e.word.text===r);if(!i.length)return e;let a=(n.get(r)??0)+1;n.set(r,a);let o=i.filter(e=>e.word.occurrence===a);return o.length?re(e,o):e}};function ie(e,t){let n=(t,n)=>e[t]?.[n]??0,r=Math.max(n(`fragments-3`,0),n(`fragments-3`,2),n(`closing`,0)),i=n(`fragments-3`,1),a=Math.max(...e[`fragments-2`]??[],n(`extended-left`,0),n(`penultimate`,1)),o=n(`extended-left`,1),s=n(`penultimate`,0);return{required:Math.max(n(`opening`,0),2*r+i+2*t,2*a+t,a+o+t,s+a+t,r+n(`closing`,1)+t),outer:r,middle:i,half:a,extendedLeft:o,penultimateRight:s}}var ae=`opening.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.extended-left.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.penultimate.closing`.split(`.`);function N(e,t){if(e!==78)return null;let n=ae[t-5];return n?{pattern:n}:null}var oe=[`reading`,`match`],se=[`one`,`two`],ce=[`tikkun-right`,`torah-right`],P={layout:`match`,sides:`one`},le=e=>typeof e==`string`&&oe.some(t=>t===e),ue=e=>typeof e==`string`&&se.some(t=>t===e),de=e=>typeof e==`string`&&ce.some(t=>t===e);function fe(e,t){return e===`two`&&!t?`two`:`one`}var pe=e=>e?`mod-petucha`:``,me=e=>e.length>1?`mod-setuma`:``,F=e=>e.replace(/&/g,`&amp;`).replace(/"/g,`&quot;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),I=e=>e.normalize(`NFD`).replace(/\p{M}/gu,``),L=({annotatedText:e,unannotatedText:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,fragmentIndex:s,renderAnnotatedSpecialLetters:c,renderUnannotatedSpecialLetters:l,readingLayout:u})=>{let d=a(e),f=a(t),p=Math.max(d.length,f.length);return Array.from({length:p},(e,t)=>{let a=d[t],p=f[t],m=a?c(a.text):``,h=p?l(p.text):``,g=n?a:p,_=n?m:h,v=n?h:m,y=`${r}:${i}:${s}:${t}`,b=!!a?.text.includes(`׃`);return`<span
        class="word ${g?.isKri?`ktiv-kri`:``}${b?` mod-sof-pasuk`:``}"
        ${o(a?.text??``)?``:`data-token-key="${y}"`}
        data-page-number="${r}"
        data-line-index="${i}"
        data-fragment-index="${s}"
        data-word-index="${t}"
        data-annotations-mode="${n?`on`:`off`}"
        data-annotations-alternate="${F(v)}"
        data-annotations-on-text="${F(a?.text??``)}"
        data-annotations-on-present="${!!a}"
        data-annotations-off-present="${!!p}"
        data-annotations-on-kri="${!!a?.isKri}"
        data-annotations-off-kri="${!!p?.isKri}"
        ${g?``:`hidden`}
      >${_}</span>${u&&b?`<br class="reader-pasuk-break" aria-hidden="true">`:``}`}).join(` `)},R=e=>e.replace(/([־-])/g,`$1<wbr>`),z=e=>e?.leining.date.title.he.replace(/^פרשת /,``)??e?.leining.date.title.en.replace(/^Parshat\s+/i,``)??``,B=new Map([[1,`ראשון`],[2,`שני`],[3,`שלישי`],[4,`רביעי`],[5,`חמישי`],[6,`ששי`],[7,`שביעי`],[`Maftir`,`מפטיר`]]),he=e=>e.map(e=>B.get(e.index)).filter(Boolean).join(`, `),ge=e=>e.map(e=>l(e)).join(`, `),V=(e,t,n,r)=>`
  <span
    class="aliyah-badge${n?.index?` mod-with-audio`:``}"
    ${n?.index?`data-aliyah-marker="true"`:``}
    ${t?`data-run-id="${t}"`:``}
    ${n?.index?`data-aliyah-index="${n.index}"`:``}
    ${n?.index?`data-aliyah-start-label="${F(B.get(n.index)??e)}" data-aliyah-start-verse="${F(l(n))}"`:``}
  >
    ${n?.index?`<button
            type="button"
            class="aliyah-audio-button"
            data-audio-button="true"
            data-run-id="${t}"
            data-aliyah-index="${n.index}"
            aria-label="Play ${e}"
          >${p(`play`)}</button>`:``}
    <span class="aliyah-label-text">${R(e)}</span>
    ${_e(e,r,n)}
  </span>
`,_e=(e,t,n)=>!t||!n?.start?``:`
    <button
      type="button"
      class="aliyah-link"
      data-aliyah-link="true"
      data-aliyah-url="${F(_(t,n.start))}"
      aria-label="Copy link to ${F(e)}"
      title="Copy link to ${F(e)}"
    ><span data-aliyah-link-icon="link">${p(`link`)}</span><span data-aliyah-link-icon="check" hidden>${p(`check`)}</span></button>
  `,H=(e,t,n,r)=>{let i=t?.b===2&&N(n,r);return i?{kind:`sea`,pattern:i.pattern}:t&&t.b===5&&t.c===32&&t.v>=1&&t.v<=43&&e.length===2?{kind:`haazinu`,pattern:`columns-2`}:null},U=({text:e,references:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,presentation:a,surface:o})=>{let c=o===`tikkun`||o!==`torah`&&null,l=c??n,u=M(t),d=M(t);return`<div
    class="reader-text-side mod-${o}"
    data-reader-canonical="${o!==`torah`}"
    ${c===null?``:`data-reader-annotations="${l?`on`:`off`}"`}
    ${o===`torah`?`aria-hidden="true"`:``}
  >
    <div class="reader-text-flow">
      ${e.map((e,t)=>`
        <div class="column">
          ${e.map((n,o)=>{let c=s({text:n,annotated:!0}),f=a.layout===`reading`&&a.sides===`two`?I(c):s({text:n,annotated:!1});return`
            <span class="fragment ${me(e)}">${L({annotatedText:c,unannotatedText:f,annotationsEnabled:l,pageNumber:r,lineIndex:i,fragmentIndex:t*100+o,renderAnnotatedSpecialLetters:u,renderUnannotatedSpecialLetters:d,readingLayout:a.layout===`reading`})}</span>
          `}).join(``)}
        </div>
      `).join(``)}
    </div>
  </div>`},ve=({pageNumber:e,lineIndex:t,run:n,aliyahStarts:r,startTitle:i,startLabel:a,startVerse:o,mirror:s})=>`
    data-line-index="${t}"
    data-page-number="${e}"
    ${s?`data-reader-mirror="true"`:`data-class="line"`}
    ${n?`data-run-id="${n.id}"`:``}
    ${!s&&r.length?`data-aliyah-starts="${r.map(e=>e.index).join(`,`)}"`:``}
    ${!s&&r.length&&i?`data-aliyah-start-title="${F(i)}"`:``}
    ${!s&&r.length&&a?`data-aliyah-start-label="${F(a)}"`:``}
    ${!s&&r.length&&o?`data-aliyah-start-verse="${F(o)}"`:``}
  `,W=({pageNumber:e,text:t,verses:n,focalRef:r,isPetucha:i,labels:a,aliyahStarts:o,run:s,lineIndex:c,annotationsEnabled:l=!0,presentation:u=P,surface:d=`single`,mirror:f=!1,renderVerseGutter:p=!0,pageReference:m})=>{let g=he(o),_=z(s),v=ge(o),y=[r,...n],b=n[0]??r??m,x=u.layout===`match`?H(t,b,e,c):null,S=u.layout===`match`?t.length>1||x!==null:!1,C=ve({pageNumber:e,lineIndex:c,run:s,aliyahStarts:o,startTitle:_,startLabel:g,startVerse:v,mirror:f}),w=u.sides===`two`&&d===`single`?[`tikkun`,`torah`].map(n=>U({text:t,references:y,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:n})).join(``):U({text:t,references:y,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:d});return u.layout===`reading`?`
      <div
        class="${f?`reader-mirror-line`:`line`} mod-reading-line${S?` mod-shirah`:``}"
        ${C}
      >
        <div class="line-content">${w}</div>
        ${p?`<div class="line-gutter mod-verses">
                <span class="location-indicator mod-verses">${h.asVersesRange(n)}</span>
              </div>`:``}
        ${f?``:`<div class="line-gutter mod-aliyot">
                <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>V(e,s?.id,o[t],s)).join(``)}</span>
              </div>`}
      </div>
    `:`
  <tr
    class="${S?`mod-shirah`:``}"
    ${C}
    ${x?`data-shirah-kind="${x.kind}" data-shirah-pattern="${x.pattern}"`:``}
  >
    <td class="line ${pe(i)}">
      <div class="line-content">${w}</div>
      <div class="line-gutter mod-verses">
        <span class="location-indicator mod-verses">${h.asVersesRange(n)}</span>
      </div>
      <div class="line-gutter mod-aliyot">
        <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>V(e,s?.id,o[t],s)).join(``)}</span>
      </div>
    </td>
  </tr>
`},ye=(e,{annotationsEnabled:t=!0,presentation:n=P}={})=>{let r=e.lines.find(e=>e.verses.length)?.verses[0];if(n.layout===`reading`){let r=({surface:r=`single`,mirror:i=!1}={})=>e.lines.map((a,o)=>W({pageNumber:e.pageNumber,lineIndex:o,annotationsEnabled:t,presentation:n,surface:r,mirror:i,...a})).join(``);return`
      <div
        class="reader-reading-page mod-${n.sides}-side"
        data-page-number="${e.pageNumber}"
      >
        <span class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</span>
        ${n.sides===`two`?`<div class="reader-reading-page-side mod-tikkun">${r({surface:`tikkun`})}</div>
               <div class="reader-reading-page-side mod-torah" aria-hidden="true">${r({surface:`torah`,mirror:!0})}</div>`:`<div class="reader-reading-page-side mod-single">${r()}</div>`}
      </div>
    `}return`
  <table data-page-number="${e.pageNumber}" data-reader-sides="${n.sides}">
    <caption class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</caption>
    ${e.lines.map((i,a)=>W({pageNumber:e.pageNumber,lineIndex:a,annotationsEnabled:t,presentation:n,pageReference:r,...i})).join(``)}
  </table>
`},be=e=>e?.dataset.annotationsOnText??e?.textContent??``;function G({currentLineWords:e,previousLineWords:t,verseOrdinal:n}){return u({currentLineWords:e.map(K),previousLineWords:t.map(K),verseOrdinal:n})}var K=e=>({tokenKey:e.dataset.tokenKey??``,annotatedText:be(e)}),xe=e=>{let t=[...e.querySelectorAll(`[data-reader-canonical="true"] .fragment .word`)];return(t.length?t:[...e.querySelectorAll(`.fragment .word`)]).filter(e=>e.dataset.annotationsOnPresent!==`false`&&!!e.dataset.tokenKey)};function Se({book:e,startLine:t,startVerseOrdinal:n}){let r=[...e.querySelectorAll(`[data-class="line"]`)],i=r.indexOf(t);if(i<0||n<0)return null;let a=r.map(xe);return{lines:r,startLineIndex:i,startWordIndex:G({currentLineWords:a[i],previousLineWords:a[i-1]??[],verseOrdinal:n}),wordsByLine:a}}function Ce({book:e,startLine:t,startVerseOrdinal:n}){let r=Se({book:e,startLine:t,startVerseOrdinal:n});return r?.wordsByLine[r.startLineIndex][r.startWordIndex]?.dataset.tokenKey??null}var we=`.word[data-annotations-mode][data-annotations-alternate]`;function q(e,t){e.querySelectorAll(we).forEach(e=>{let n=e.closest(`[data-reader-annotations]`)?.dataset.readerAnnotations,r=n===`on`||n!==`off`&&t,i=r?`on`:`off`,a=(r?e.dataset.annotationsOnPresent:e.dataset.annotationsOffPresent)!==`false`,o=(r?e.dataset.annotationsOnKri:e.dataset.annotationsOffKri)===`true`;if(e.hidden=!a,e.classList.toggle(`ktiv-kri`,a&&o),e.dataset.annotationsMode===i)return;let s=e.innerHTML,c=e.dataset.annotationsAlternate??``;e.dataset.annotationsAlternate=s,e.innerHTML=a?c:``,e.dataset.annotationsMode=i})}var Te=`[
  {
    "text": [
      [
        "הַבָּאִ֥ים אַחֲרֵיהֶ֖ם בַּיָּ֑ם לֹֽא־נִשְׁאַ֥ר בָּהֶ֖ם עַד־אֶחָֽד׃ וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בַיַּבָּשָׁ֖ה בְּת֣וֹךְ הַיָּ֑ם וְהַמַּ֤יִם לָהֶם֙ חֹמָ֔ה מִֽימִינָ֖ם וּמִשְּׂמֹאלָֽם׃ וַיּ֨וֹשַׁע"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֜ה בַּיּ֥וֹם הַה֛וּא אֶת־יִשְׂרָאֵ֖ל מִיַּ֣ד מִצְרָ֑יִם וַיַּ֤רְא יִשְׂרָאֵל֙ אֶת־מִצְרַ֔יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מֵ֖ת עַל־שְׂפַ֥ת הַיָּֽם׃ וַיַּ֨רְא יִשְׂרָאֵ֜ל אֶת־הַיָּ֣ד הַגְּדֹלָ֗ה אֲשֶׁ֨ר עָשָׂ֤ה יְהֹוָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּמִצְרַ֔יִם וַיִּֽירְא֥וּ הָעָ֖ם אֶת־יְהֹוָ֑ה וַיַּֽאֲמִ֙ינוּ֙ בַּֽיהֹוָ֔ה וּבְמֹשֶׁ֖ה עַבְדּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        "אָ֣ז יָשִֽׁיר־מֹשֶׁה֩ וּבְנֵ֨י יִשְׂרָאֵ֜ל אֶת־הַשִּׁירָ֤ה הַזֹּאת֙ לַֽיהֹוָ֔ה וַיֹּאמְר֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 1
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֵאמֹ֑ר",
        " אָשִׁ֤ירָה לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה",
        " ס֥וּס"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " עָזִּ֤י וְזִמְרָת֙ יָ֔הּ וַֽיְהִי־לִ֖י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לִֽישׁוּעָ֑ה",
        " זֶ֤ה אֵלִי֙ וְאַנְוֵ֔הוּ",
        " אֱלֹהֵ֥י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָבִ֖י וַאֲרֹמְמֶֽנְהוּ׃",
        " יְהֹוָ֖ה אִ֣ישׁ מִלְחָמָ֑ה יְהֹוָ֖ה"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁמֽוֹ׃",
        " מַרְכְּבֹ֥ת פַּרְעֹ֛ה וְחֵיל֖וֹ יָרָ֣ה בַיָּ֑ם",
        " וּמִבְחַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָֽׁלִשָׁ֖יו טֻבְּע֥וּ בְיַם־סֽוּף׃",
        " תְּהֹמֹ֖ת יְכַסְיֻ֑מוּ יָרְד֥וּ בִמְצוֹלֹ֖ת כְּמוֹ־"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָֽבֶן׃",
        " יְמִֽינְךָ֣ יְהֹוָ֔ה נֶאְדָּרִ֖י בַּכֹּ֑חַ",
        " יְמִֽינְךָ֥"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה תִּרְעַ֥ץ אוֹיֵֽב׃",
        " וּבְרֹ֥ב גְּאוֹנְךָ֖ תַּהֲרֹ֣ס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 7
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָמֶ֑יךָ",
        " תְּשַׁלַּח֙ חֲרֹ֣נְךָ֔ יֹאכְלֵ֖מוֹ כַּקַּֽשׁ׃",
        " וּבְר֤וּחַ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַפֶּ֙יךָ֙ נֶ֣עֶרְמוּ מַ֔יִם",
        " נִצְּב֥וּ כְמוֹ־נֵ֖ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נֹזְלִ֑ים",
        " קָֽפְא֥וּ תְהֹמֹ֖ת בְּלֶב־יָֽם׃",
        " אָמַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אוֹיֵ֛ב אֶרְדֹּ֥ף אַשִּׂ֖יג",
        " אֲחַלֵּ֣ק שָׁלָ֑ל תִּמְלָאֵ֣מוֹ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נַפְשִׁ֔י",
        " אָרִ֣יק חַרְבִּ֔י תּוֹרִישֵׁ֖מוֹ יָדִֽי׃",
        " נָשַׁ֥פְתָּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְרוּחֲךָ֖ כִּסָּ֣מוֹ יָ֑ם",
        " צָֽלְלוּ֙ כַּֽעוֹפֶ֔רֶת בְּמַ֖יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַדִּירִֽים׃",
        " מִֽי־כָמֹ֤כָה בָּֽאֵלִם֙ יְהֹוָ֔ה",
        " מִ֥י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כָּמֹ֖כָה נֶאְדָּ֣ר בַּקֹּ֑דֶשׁ",
        " נוֹרָ֥א תְהִלֹּ֖ת עֹ֥שֵׂה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶֽלֶא׃",
        " נָטִ֙יתָ֙ יְמִ֣ינְךָ֔ תִּבְלָעֵ֖מוֹ אָֽרֶץ׃",
        " נָחִ֥יתָ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 12
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 13
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְחַסְדְּךָ֖ עַם־ז֣וּ גָּאָ֑לְתָּ",
        " נֵהַ֥לְתָּ בְעׇזְּךָ֖ אֶל־נְוֵ֥ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קׇדְשֶֽׁךָ׃",
        " שָֽׁמְע֥וּ עַמִּ֖ים יִרְגָּז֑וּן",
        " חִ֣יל"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָחַ֔ז יֹשְׁבֵ֖י פְּלָֽשֶׁת׃",
        " אָ֤ז נִבְהֲלוּ֙ אַלּוּפֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱד֔וֹם",
        " אֵילֵ֣י מוֹאָ֔ב יֹֽאחֲזֵ֖מוֹ רָ֑עַד",
        " נָמֹ֕גוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כֹּ֖ל יֹשְׁבֵ֥י כְנָֽעַן׃",
        " תִּפֹּ֨ל עֲלֵיהֶ֤ם אֵימָ֙תָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וָפַ֔חַד",
        " בִּגְדֹ֥ל זְרוֹעֲךָ֖ יִדְּמ֣וּ כָּאָ֑בֶן",
        " עַד־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲבֹ֤ר עַמְּךָ֙ יְהֹוָ֔ה",
        " עַֽד־יַעֲבֹ֖ר עַם־ז֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָנִֽיתָ׃",
        " תְּבִאֵ֗מוֹ וְתִטָּעֵ֙מוֹ֙ בְּהַ֣ר נַחֲלָֽתְךָ֔",
        " מָכ֧וֹן"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְשִׁבְתְּךָ֛ פָּעַ֖לְתָּ יְהֹוָ֑ה",
        " מִקְּדָ֕שׁ אֲדֹנָ֖י כּוֹנְנ֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָדֶֽיךָ׃",
        " יְהֹוָ֥ה ׀ יִמְלֹ֖ךְ לְעֹלָ֥ם וָעֶֽד׃",
        " כִּ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 18
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 19
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָא֩ ס֨וּס פַּרְעֹ֜ה בְּרִכְבּ֤וֹ וּבְפָרָשָׁיו֙ בַּיָּ֔ם",
        " וַיָּ֧שֶׁב יְהֹוָ֛ה עֲלֵהֶ֖ם אֶת־מֵ֣י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַיָּ֑ם",
        " וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ בַיַּבָּשָׁ֖ה בְּת֥וֹךְ הַיָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּקַּח֩ מִרְיָ֨ם הַנְּבִיאָ֜ה אֲח֧וֹת אַהֲרֹ֛ן אֶת־הַתֹּ֖ף בְּיָדָ֑הּ וַתֵּצֶ֤אןָ כׇֽל־הַנָּשִׁים֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֶ֔יהָ בְּתֻפִּ֖ים וּבִמְחֹלֹֽת׃ וַתַּ֥עַן לָהֶ֖ם מִרְיָ֑ם שִׁ֤ירוּ לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה ס֥וּס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " וַיַּסַּ֨ע מֹשֶׁ֤ה אֶת־יִשְׂרָאֵל֙ מִיַּם־ס֔וּף וַיֵּצְא֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶל־מִדְבַּר־שׁ֑וּר וַיֵּלְכ֧וּ שְׁלֹֽשֶׁת־יָמִ֛ים בַּמִּדְבָּ֖ר וְלֹא־מָ֥צְאוּ מָֽיִם׃ וַיָּבֹ֣אוּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָרָ֔תָה וְלֹ֣א יָֽכְל֗וּ לִשְׁתֹּ֥ת מַ֙יִם֙ מִמָּרָ֔ה כִּ֥י מָרִ֖ים הֵ֑ם עַל־כֵּ֥ן קָרָֽא־שְׁמָ֖הּ מָרָֽה׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  }
]`,Ee=`[
  {
    "text": [
      [
        "וְאָעִ֣ידָה בָּ֔ם אֶת־הַשָּׁמַ֖יִם וְאֶת־הָאָֽרֶץ׃ כִּ֣י יָדַ֗עְתִּי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֵ֤י מוֹתִי֙ כִּֽי־הַשְׁחֵ֣ת תַּשְׁחִת֔וּן וְסַרְתֶּ֣ם מִן־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדֶּ֔רֶךְ אֲשֶׁ֥ר צִוִּ֖יתִי אֶתְכֶ֑ם וְקָרָ֨את אֶתְכֶ֤ם הָרָעָה֙"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּאַחֲרִ֣ית הַיָּמִ֔ים כִּֽי־תַעֲשׂ֤וּ אֶת־הָרַע֙ בְּעֵינֵ֣י יְהֹוָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְהַכְעִיס֖וֹ בְּמַעֲשֵׂ֥ה יְדֵיכֶֽם׃ וַיְדַבֵּ֣ר מֹשֶׁ֗ה בְּאׇזְנֵי֙ כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קְהַ֣ל יִשְׂרָאֵ֔ל אֶת־דִּבְרֵ֥י הַשִּׁירָ֖ה הַזֹּ֑את עַ֖ד תֻּמָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַאֲזִ֥ינוּ הַשָּׁמַ֖יִם וַאֲדַבֵּ֑רָה"
      ],
      [
        "וְתִשְׁמַ֥ע הָאָ֖רֶץ אִמְרֵי־פִֽי׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 1
      }
    ],
    "aliyot": [
      {
        "standard": 1
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲרֹ֤ף כַּמָּטָר֙ לִקְחִ֔י"
      ],
      [
        "תִּזַּ֥ל כַּטַּ֖ל אִמְרָתִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּשְׂעִירִ֣ם עֲלֵי־דֶ֔שֶׁא"
      ],
      [
        "וְכִרְבִיבִ֖ים עֲלֵי־עֵֽשֶׂב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י שֵׁ֥ם יְהֹוָ֖ה אֶקְרָ֑א"
      ],
      [
        "הָב֥וּ גֹ֖דֶל לֵאלֹהֵֽינוּ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַצּוּר֙ תָּמִ֣ים פׇּֽעֳל֔וֹ"
      ],
      [
        "כִּ֥י כׇל־דְּרָכָ֖יו מִשְׁפָּ֑ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֵ֤ל אֱמוּנָה֙ וְאֵ֣ין עָ֔וֶל"
      ],
      [
        "צַדִּ֥יק וְיָשָׁ֖ר הֽוּא׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שִׁחֵ֥ת ל֛וֹ לֹ֖א בָּנָ֣יו מוּמָ֑ם"
      ],
      [
        "דּ֥וֹר עִקֵּ֖שׁ וּפְתַלְתֹּֽל׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַ לְיְהֹוָה֙ תִּגְמְלוּ־זֹ֔את"
      ],
      [
        "עַ֥ם נָבָ֖ל וְלֹ֣א חָכָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הֲלוֹא־הוּא֙ אָבִ֣יךָ קָּנֶ֔ךָ"
      ],
      [
        "ה֥וּא עָשְׂךָ֖ וַֽיְכֹנְנֶֽךָ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "זְכֹר֙ יְמ֣וֹת עוֹלָ֔ם"
      ],
      [
        "בִּ֖ינוּ שְׁנ֣וֹת דֹּר־וָדֹ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 7
      }
    ],
    "aliyot": [
      {
        "standard": 2
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁאַ֤ל אָבִ֙יךָ֙ וְיַגֵּ֔דְךָ"
      ],
      [
        "זְקֵנֶ֖יךָ וְיֹ֥אמְרוּ לָֽךְ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּהַנְחֵ֤ל עֶלְיוֹן֙ גּוֹיִ֔ם"
      ],
      [
        "בְּהַפְרִיד֖וֹ בְּנֵ֣י אָדָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַצֵּב֙ גְּבֻלֹ֣ת עַמִּ֔ים"
      ],
      [
        "לְמִסְפַּ֖ר בְּנֵ֥י יִשְׂרָאֵֽל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י חֵ֥לֶק יְהֹוָ֖ה עַמּ֑וֹ"
      ],
      [
        "יַעֲקֹ֖ב חֶ֥בֶל נַחֲלָתֽוֹ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִמְצָאֵ֙הוּ֙ בְּאֶ֣רֶץ מִדְבָּ֔ר"
      ],
      [
        "וּבְתֹ֖הוּ יְלֵ֣ל יְשִׁמֹ֑ן"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְסֹבְבֶ֙נְהוּ֙ יְב֣וֹנְנֵ֔הוּ"
      ],
      [
        "יִצְּרֶ֖נְהוּ כְּאִישׁ֥וֹן עֵינֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כְּנֶ֙שֶׁר֙ יָעִ֣יר קִנּ֔וֹ"
      ],
      [
        "עַל־גּוֹזָלָ֖יו יְרַחֵ֑ף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִפְרֹ֤שׂ כְּנָפָיו֙ יִקָּחֵ֔הוּ"
      ],
      [
        "יִשָּׂאֵ֖הוּ עַל־אֶבְרָתֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה בָּדָ֣ד יַנְחֶ֑נּוּ"
      ],
      [
        "וְאֵ֥ין עִמּ֖וֹ אֵ֥ל נֵכָֽר׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 12
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַרְכִּבֵ֙הוּ֙ עַל־במותי#[בָּ֣מֳתֵי] אָ֔רֶץ"
      ],
      [
        "וַיֹּאכַ֖ל תְּנוּבֹ֣ת שָׂדָ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 13
      }
    ],
    "aliyot": [
      {
        "standard": 3
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיֵּנִקֵ֤הֽוּ דְבַשׁ֙ מִסֶּ֔לַע"
      ],
      [
        "וְשֶׁ֖מֶן מֵחַלְמִ֥ישׁ צֽוּר׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חֶמְאַ֨ת בָּקָ֜ר וַחֲלֵ֣ב צֹ֗אן"
      ],
      [
        "עִם־חֵ֨לֶב כָּרִ֜ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵילִ֤ים בְּנֵֽי־בָשָׁן֙ וְעַתּוּדִ֔ים"
      ],
      [
        "עִם־חֵ֖לֶב כִּלְי֣וֹת חִטָּ֑ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְדַם־עֵנָ֖ב תִּשְׁתֶּה־חָֽמֶר׃"
      ],
      [
        "וַיִּשְׁמַ֤ן יְשֻׁרוּן֙ וַיִּבְעָ֔ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָׁמַ֖נְתָּ עָבִ֣יתָ כָּשִׂ֑יתָ"
      ],
      [
        "וַיִּטֹּשׁ֙ אֱל֣וֹהַּ עָשָׂ֔הוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיְנַבֵּ֖ל צ֥וּר יְשֻׁעָתֽוֹ׃"
      ],
      [
        "יַקְנִאֻ֖הוּ בְּזָרִ֑ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּתוֹעֵבֹ֖ת יַכְעִיסֻֽהוּ׃"
      ],
      [
        "יִזְבְּח֗וּ לַשֵּׁדִים֙ לֹ֣א אֱלֹ֔הַּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱלֹהִ֖ים לֹ֣א יְדָע֑וּם"
      ],
      [
        "חֲדָשִׁים֙ מִקָּרֹ֣ב בָּ֔אוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֹ֥א שְׂעָר֖וּם אֲבֹתֵיכֶֽם׃"
      ],
      [
        "צ֥וּר יְלָדְךָ֖ תֶּ֑שִׁי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 18
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּשְׁכַּ֖ח אֵ֥ל מְחֹלְלֶֽךָ׃"
      ],
      [
        "וַיַּ֥רְא יְהֹוָ֖ה וַיִּנְאָ֑ץ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 19
      }
    ],
    "aliyot": [
      {
        "standard": 4
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִכַּ֥עַס בָּנָ֖יו וּבְנֹתָֽיו׃"
      ],
      [
        "וַיֹּ֗אמֶר אַסְתִּ֤ירָה פָנַי֙ מֵהֶ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶרְאֶ֖ה מָ֣ה אַחֲרִיתָ֑ם"
      ],
      [
        "כִּ֣י ד֤וֹר תַּהְפֻּכֹת֙ הֵ֔מָּה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָּנִ֖ים לֹא־אֵמֻ֥ן בָּֽם׃"
      ],
      [
        "הֵ֚ם קִנְא֣וּנִי בְלֹא־אֵ֔ל"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּעֲס֖וּנִי בְּהַבְלֵיהֶ֑ם"
      ],
      [
        "וַאֲנִי֙ אַקְנִיאֵ֣ם בְּלֹא־עָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּג֥וֹי נָבָ֖ל אַכְעִיסֵֽם׃"
      ],
      [
        "כִּי־אֵשׁ֙ קָדְחָ֣ה בְאַפִּ֔י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,De=`[
  {
    "text": [
      [
        "וַתִּיקַ֖ד עַד־שְׁא֣וֹל תַּחְתִּ֑ית"
      ],
      [
        "וַתֹּ֤אכַל אֶ֙רֶץ֙ וִֽיבֻלָ֔הּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתְּלַהֵ֖ט מוֹסְדֵ֥י הָרִֽים׃"
      ],
      [
        "אַסְפֶּ֥ה עָלֵ֖ימוֹ רָע֑וֹת"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חִצַּ֖י אֲכַלֶּה־בָּֽם׃"
      ],
      [
        "מְזֵ֥י רָעָ֛ב וּלְחֻ֥מֵי רֶ֖שֶׁף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 24
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְקֶ֣טֶב מְרִירִ֑י"
      ],
      [
        "וְשֶׁן־בְּהֵמֹת֙ אֲשַׁלַּח־בָּ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "עִם־חֲמַ֖ת זֹחֲלֵ֥י עָפָֽר׃"
      ],
      [
        "מִחוּץ֙ תְּשַׁכֶּל־חֶ֔רֶב"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 25
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמֵחֲדָרִ֖ים אֵימָ֑ה"
      ],
      [
        "גַּם־בָּחוּר֙ גַּם־בְּתוּלָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יוֹנֵ֖ק עִם־אִ֥ישׁ שֵׂיבָֽה׃"
      ],
      [
        "אָמַ֖רְתִּי אַפְאֵיהֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 26
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁבִּ֥יתָה מֵאֱנ֖וֹשׁ זִכְרָֽם׃"
      ],
      [
        "לוּלֵ֗י כַּ֤עַס אוֹיֵב֙ אָג֔וּר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 27
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶּֽן־יְנַכְּר֖וּ צָרֵ֑ימוֹ"
      ],
      [
        "פֶּן־יֹֽאמְרוּ֙ יָדֵ֣נוּ רָ֔מָה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְלֹ֥א יְהֹוָ֖ה פָּעַ֥ל כׇּל־זֹֽאת׃"
      ],
      [
        "כִּי־ג֛וֹי אֹבַ֥ד עֵצ֖וֹת הֵ֑מָּה"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 28
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין בָּהֶ֖ם תְּבוּנָֽה׃"
      ],
      [
        "ל֥וּ חָכְמ֖וּ יַשְׂכִּ֣ילוּ זֹ֑את"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 29
      }
    ],
    "aliyot": [
      {
        "standard": 5
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָבִ֖ינוּ לְאַחֲרִיתָֽם׃"
      ],
      [
        "אֵיכָ֞ה יִרְדֹּ֤ף אֶחָד֙ אֶ֔לֶף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּשְׁנַ֖יִם יָנִ֣יסוּ רְבָבָ֑ה"
      ],
      [
        "אִם־לֹא֙ כִּי־צוּרָ֣ם מְכָרָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַֽיהֹוָ֖ה הִסְגִּירָֽם׃"
      ],
      [
        "כִּ֛י לֹ֥א כְצוּרֵ֖נוּ צוּרָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֹיְבֵ֖ינוּ פְּלִילִֽים׃"
      ],
      [
        "כִּֽי־מִגֶּ֤פֶן סְדֹם֙ גַּפְנָ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 32
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמִשַּׁדְמֹ֖ת עֲמֹרָ֑ה"
      ],
      [
        "עֲנָבֵ֙מוֹ֙ עִנְּבֵי־ר֔וֹשׁ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכְּלֹ֥ת מְרֹרֹ֖ת לָֽמוֹ׃"
      ],
      [
        "חֲמַ֥ת תַּנִּינִ֖ם יֵינָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 33
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹ֥אשׁ פְּתָנִ֖ים אַכְזָֽר׃"
      ],
      [
        "הֲלֹא־ה֖וּא כָּמֻ֣ס עִמָּדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 34
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חָת֖וּם בְּאוֹצְרֹתָֽי׃"
      ],
      [
        "לִ֤י נָקָם֙ וְשִׁלֵּ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 35
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְעֵ֖ת תָּמ֣וּט רַגְלָ֑ם"
      ],
      [
        "כִּ֤י קָרוֹב֙ י֣וֹם אֵידָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְחָ֖שׁ עֲתִדֹ֥ת לָֽמוֹ׃"
      ],
      [
        "כִּֽי־יָדִ֤ין יְהֹוָה֙ עַמּ֔וֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 36
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְעַל־עֲבָדָ֖יו יִתְנֶחָ֑ם"
      ],
      [
        "כִּ֤י יִרְאֶה֙ כִּֽי־אָ֣זְלַת יָ֔ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֶ֖פֶס עָצ֥וּר וְעָזֽוּב׃"
      ],
      [
        "וְאָמַ֖ר אֵ֣י אֱלֹהֵ֑ימוֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 37
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "צ֖וּר חָסָ֥יוּ בֽוֹ׃"
      ],
      [
        "אֲשֶׁ֨ר חֵ֤לֶב זְבָחֵ֙ימוֹ֙ יֹאכֵ֔לוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 38
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִשְׁתּ֖וּ יֵ֣ין נְסִיכָ֑ם"
      ],
      [
        "יָק֙וּמוּ֙ וְיַעְזְרֻכֶ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהִ֥י עֲלֵיכֶ֖ם סִתְרָֽה׃"
      ],
      [
        "רְא֣וּ ׀ עַתָּ֗ה כִּ֣י אֲנִ֤י אֲנִי֙ ה֔וּא"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 39
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין אֱלֹהִ֖ים עִמָּדִ֑י"
      ],
      [
        "אֲנִ֧י אָמִ֣ית וַאֲחַיֶּ֗ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָחַ֙צְתִּי֙ וַאֲנִ֣י אֶרְפָּ֔א"
      ],
      [
        "וְאֵ֥ין מִיָּדִ֖י מַצִּֽיל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּֽי־אֶשָּׂ֥א אֶל־שָׁמַ֖יִם יָדִ֑י"
      ],
      [
        "וְאָמַ֕רְתִּי חַ֥י אָנֹכִ֖י לְעֹלָֽם׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 40
      }
    ],
    "aliyot": [
      {
        "standard": 6
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אִם־שַׁנּוֹתִי֙ בְּרַ֣ק חַרְבִּ֔י"
      ],
      [
        "וְתֹאחֵ֥ז בְּמִשְׁפָּ֖ט יָדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 41
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָשִׁ֤יב נָקָם֙ לְצָרָ֔י"
      ],
      [
        "וְלִמְשַׂנְאַ֖י אֲשַׁלֵּֽם׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכִּ֤יר חִצַּי֙ מִדָּ֔ם"
      ],
      [
        "וְחַרְבִּ֖י תֹּאכַ֣ל בָּשָׂ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 42
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִדַּ֤ם חָלָל֙ וְשִׁבְיָ֔ה"
      ],
      [
        "מֵרֹ֖אשׁ פַּרְע֥וֹת אוֹיֵֽב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַרְנִ֤ינוּ גוֹיִם֙ עַמּ֔וֹ"
      ],
      [
        "כִּ֥י דַם־עֲבָדָ֖יו יִקּ֑וֹם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 43
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְנָקָם֙ יָשִׁ֣יב לְצָרָ֔יו"
      ],
      [
        "וְכִפֶּ֥ר אַדְמָת֖וֹ עַמּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיָּבֹ֣א מֹשֶׁ֗ה וַיְדַבֵּ֛ר אֶת־כׇּל־דִּבְרֵ֥י הַשִּׁירָֽה־הַזֹּ֖את בְּאׇזְנֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 44
      }
    ],
    "aliyot": [
      {
        "standard": 7
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הָעָ֑ם ה֖וּא וְהוֹשֵׁ֥עַ בִּן־נֽוּן׃ וַיְכַ֣ל מֹשֶׁ֗ה לְדַבֵּ֛ר אֶת־כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 45
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדְּבָרִ֥ים הָאֵ֖לֶּה אֶל־כׇּל־יִשְׂרָאֵֽל׃ וַיֹּ֤אמֶר אֲלֵהֶם֙ שִׂ֣ימוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 46
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְבַבְכֶ֔ם לְכׇ֨ל־הַדְּבָרִ֔ים אֲשֶׁ֧ר אָנֹכִ֛י מֵעִ֥יד בָּכֶ֖ם הַיּ֑וֹם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֲשֶׁ֤ר תְּצַוֻּם֙ אֶת־בְּנֵיכֶ֔ם לִשְׁמֹ֣ר לַעֲשׂ֔וֹת אֶת־כׇּל־דִּבְרֵ֖י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַתּוֹרָ֥ה הַזֹּֽאת׃ כִּ֠י לֹֽא־דָבָ֨ר רֵ֥ק הוּא֙ מִכֶּ֔ם כִּי־ה֖וּא חַיֵּיכֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 47
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,Oe=JSON.parse(Te),ke=JSON.parse(Ee),Ae=JSON.parse(De);function je(e){return(e===`sea`?[{pageNumber:78,lines:Oe}]:[{pageNumber:242,lines:ke},{pageNumber:243,lines:Ae}]).flatMap(({pageNumber:t,lines:n})=>{let r,i=n.find(e=>e.verses.length)?.verses[0],a=i?{b:i.book,c:i.chapter,v:i.verse}:void 0;return n.flatMap((n,i)=>{let o=n.verses.map(({book:e,chapter:t,verse:n})=>({b:e,c:t,v:n})),s=r??o[0];return r=o.at(-1)??r,H(n.text,o[0]??s??a,t,i)?.kind===e?[{pageNumber:t,lineIndex:i,markup:U({text:n.text,references:[s,...o],annotationsEnabled:!0,pageNumber:t,lineIndex:i,presentation:{layout:`match`,sides:`one`},surface:`single`})}]:[]})})}var J=(e,t)=>[...e.querySelectorAll(t)].filter(e=>!e.hidden&&e.getClientRects().length>0);function Y(e){e.querySelectorAll(`.word[data-token-key]`).forEach(e=>e.style.removeProperty(`--reader-paired-word-width`))}var X=new WeakMap,Z=new WeakMap;function Q(e){let t=getComputedStyle(e);return`${t.fontStyle} ${t.fontWeight} ${t.fontSize}/${t.lineHeight} ${t.fontFamily}`}function Me(e){let t=[...e.querySelectorAll(`tr:not([data-shirah-kind]) [data-reader-canonical="true"] .reader-text-flow`)];if(!t.length)return[];let n=Q(e),r=Z.get(t[0]);if(r?.font===n&&document.fonts.check(n,`אשר`))return r.widths;let i=document.createElement(`div`);i.className=`match-shirah-measure`,i.style.font=n,i.setAttribute(`aria-hidden`,`true`);let a=t.map(e=>e.cloneNode(!0));i.append(...a),document.body.append(i);let o=[];for(let e of[!0,!1]){q(i,e);for(let e of a){let t=[...e.querySelectorAll(`.ktiv-kri:not([hidden])`)].reduce((e,t)=>{let n=getComputedStyle(t);return e+Number.parseFloat(n.paddingLeft)+Number.parseFloat(n.paddingRight)+Number.parseFloat(n.borderLeftWidth)+Number.parseFloat(n.borderRightWidth)},0);o.push({width:e.getBoundingClientRect().width,fixedInsets:t})}}return i.remove(),document.fonts.check(n,`אשר`)&&Z.set(t[0],{font:n,widths:o}),o}function Ne(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind])`),r=e.closest(`.tikkun-book`),i=e.querySelector(`table`);if(!n||!r||!i||r.clientWidth===0)return;let a=Me(e),o=Math.max(...a.map(e=>e.width))+2,s=n.querySelector(`.line-content`),c=s.getBoundingClientRect(),l=t===`two`?1+2*Number.parseFloat(getComputedStyle(s).columnGap):0,u=t===`two`?2:1,d=u*o+l;if(d<=c.width)return;let f=r.getBoundingClientRect(),p=getComputedStyle(n.querySelector(`.line`)).gridTemplateColumns.split(` `).map(Number.parseFloat),m=p[2]+p[3],h=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),g=(c.left+c.right)/2,_=t===`two`?2*Math.min(g-f.left-h,f.right-m-h-g):f.width-m-2*h,v=Math.max(c.width,Math.min(d,_)),y=t===`two`?g+v/2:Math.min(g+v/2,f.right-m-h);i.style.width=getComputedStyle(i).width,e.classList.add(`mod-match-fitted`),e.style.setProperty(`--match-ordinary-inline-size`,`${v}px`),e.style.setProperty(`--match-ordinary-inline-offset`,`${y-c.right}px`);let b=(v-l)/u,x=Math.min(1,...a.map(e=>(b-e.fixedInsets)/(e.width-e.fixedInsets+2)));e.style.setProperty(`--match-text-scale`,`${x}em`)}function $(e){e.classList.remove(`mod-match-song-frame`);for(let t of[`inline-size`,`inline-offset`,`gutter-inline-offset`,`ordinary-flow-size`,`shirah-flow-size`])e.style.removeProperty(`--match-page-${t}`)}function Pe(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind]) .line-content`),r=e.querySelector(`tr[data-shirah-kind] .line-content`),i=e.closest(`.tikkun-book`);if(!n||!r||!i)return;let a=n.getBoundingClientRect(),o=r.getBoundingClientRect(),s=a.width>o.width?a:o,c=getComputedStyle(r).transform,l=o.right-(c===`none`?0:new DOMMatrixReadOnly(c).m41),u=e.querySelector(`table`);u.style.width=getComputedStyle(u).width,e.style.setProperty(`--match-page-ordinary-flow-size`,`${n.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-shirah-flow-size`,`${r.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-inline-size`,`${s.width}px`),e.style.setProperty(`--match-page-inline-offset`,`${s.right-l}px`),e.classList.add(`mod-match-song-frame`);let d=i.getBoundingClientRect().right,f=[...e.querySelectorAll(`.location-indicator.mod-verses`)],p=Math.max(0,...f.map(e=>e.getBoundingClientRect().right-d+1));e.style.setProperty(`--match-page-gutter-inline-offset`,`${s.right-l-p}px`)}function Fe(e,t){let n=e.closest(`.tikkun-book`);if(!n||n.clientWidth===0)return;let r=e.querySelector(`tr[data-shirah-kind]`)?.dataset.shirahKind;if(r!==`sea`&&r!==`haazinu`||r!==`haazinu`&&t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let i=[...n.querySelectorAll(`tr[data-shirah-kind="${r}"]`)],a=[...new Set(i.map(e=>e.closest(`.tikkun-page`)))];for(let e of a)$(e),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-haazinu-gap`);let o=Q(e),s=X.get(n)??new Map;X.set(n,s);let c=`${r}:${o}`,l=s.get(c)??{half:0,gap:0,trailingSpace:0,sea:{},pageFirstSpanWidths:new Map},u=document.createElement(`div`);u.className=`match-shirah-measure`,u.style.font=o,u.setAttribute(`aria-hidden`,`true`);let d=document.createElement(`span`);d.className=`fragment`,d.textContent=`אשר אשר אשר`;let f=document.createElement(`span`);f.textContent=`\xA0`,u.append(d,f);let p=l.gap?[]:je(r).map(({pageNumber:e,lineIndex:t,markup:n})=>{let r=document.createElement(`div`);r.innerHTML=n;let i=[...r.querySelectorAll(`.fragment`)];return u.append(...i),{pageNumber:e,seaLayout:N(e,t),fragments:i}});(p.length||!l.gap)&&document.body.append(u),l.gap||(l.gap=d.getBoundingClientRect().width,l.trailingSpace=f.getBoundingClientRect().width);for(let e of[!0,!1]){q(u,e);for(let{pageNumber:e,seaLayout:t,fragments:n}of p){let r=n.map(e=>e.getBoundingClientRect().width);if(t){let e=l.sea[t.pattern]??[];r.forEach((t,n)=>{e[n]=Math.max(e[n]??0,t+1)}),l.sea[t.pattern]=e}else l.half=Math.max(l.half,...r),l.pageFirstSpanWidths.set(e,Math.max(l.pageFirstSpanWidths.get(e)??0,r[0]))}}u.remove(),document.fonts.check(o,`אשר`)&&s.set(c,l);let m=r===`sea`?ie(l.sea,l.gap):null;if(m){let t=Number.parseFloat(getComputedStyle(e).fontSize);a.forEach(e=>{e.style.setProperty(`--match-sea-outer`,`${m.outer/t}em`),e.style.setProperty(`--match-sea-middle`,`${m.middle/t}em`),e.style.setProperty(`--match-sea-half`,`${m.half/t}em`),e.style.setProperty(`--match-sea-extended-left`,`${m.extendedLeft/t}em`),e.style.setProperty(`--match-sea-penultimate-right`,`${m.penultimateRight/t}em`),e.style.setProperty(`--match-sea-gap`,`${l.gap/t}em`)})}r===`haazinu`&&t===`one`&&a.forEach(e=>e.style.setProperty(`--match-haazinu-page-first-span-width`,`${(l.pageFirstSpanWidths.get(Number(e.querySelector(`table`)?.dataset.pageNumber))??0)+l.trailingSpace}px`));let h=a.map(e=>e.querySelector(`tr[data-shirah-kind="${r}"] .line-content`).getBoundingClientRect()),g=i[0].querySelector(r===`haazinu`?`.reader-text-flow`:`.column`),_=r===`haazinu`?l.gap:Number.parseFloat(getComputedStyle(g).columnGap),v=n.getBoundingClientRect(),y=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),b=m?.required??2*l.half+_,x=r===`haazinu`||i.some(e=>e.querySelector(`.line-gutter.mod-aliyot`)?.textContent?.trim()),S=i[0].querySelector(`.line`),C=getComputedStyle(S).gridTemplateColumns.split(` `).map(Number.parseFloat),w=x&&(C[3]??0)>0,T=C[2]+(w?C[3]:0);if(r===`haazinu`||t===`two`){T=Math.max(T,...i.map(e=>{let t=e.querySelector(`.location-indicator.mod-verses`),n=e.querySelector(`.line-content`);return t?t.getBoundingClientRect().right-n.getBoundingClientRect().right:0}));let n=t===`two`?2:1,r=i[0].querySelector(`.line-content`),o=t===`two`?1+2*Number.parseFloat(getComputedStyle(r).columnGap):0,s=n*(b+2),c=Math.ceil(s+o),l=Math.min(y,Math.max(2,(v.width-T-c)/2)),u=t===`two`?(h[0].left+h[0].right)/2:(v.left+v.right)/2,d=t===`two`?2*Math.min(u-v.left-l,v.right-T-l-u):v.width-T-2*l,f=Math.min(1,(d-o)/s),p=t===`two`?s*f+o:Math.min(c,d),m=t===`two`?u+p/2:Math.min(u+p/2,v.right-T-l),g=Number.parseFloat(getComputedStyle(e).fontSize);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${p}px`),e.style.setProperty(`--match-shirah-inline-offset`,`${m-h[t].right}px`),e.style.setProperty(`--match-shirah-text-scale`,`${f}em`),e.style.setProperty(`--match-haazinu-gap`,`${_/g}em`),e.style.setProperty(`--match-shirah-aliyah-display`,w?`flex`:`none`)}),a}let E=Math.ceil(b+1),D=y,O=Math.min(y,Math.max(2,v.width-T-D-E)),k=Math.min(E,v.width-T-D-O),A=Math.min((v.left+v.right+k)/2,v.right-T-O);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${k}px`),e.style.setProperty(`--match-shirah-text-scale`,`${Math.min(1,k/E)}em`),e.style.setProperty(`--match-shirah-inline-offset`,`${A-h[t].right}px`),e.style.setProperty(`--match-shirah-aliyah-display`,x?`flex`:`none`)}),a}function Ie(e){Y(e);let t=new Map,n=[];for(let n of J(e,`.reader-reading-page-side.mod-torah .word[data-token-key]`)){let e=n.dataset.tokenKey;e&&t.set(e,n)}for(let r of J(e,`.reader-reading-page-side.mod-tikkun .word[data-token-key]`)){let e=r.dataset.tokenKey,i=e?t.get(e):void 0;if(!i)continue;let a=Number.parseFloat(getComputedStyle(r).fontSize),o=Number.parseFloat(getComputedStyle(i).fontSize),s=Math.max(a,o);if(!Number.isFinite(s)||s<=0)continue;let c=`${(Math.max(r.getBoundingClientRect().width,i.getBoundingClientRect().width)/s).toFixed(4)}em`;n.push({torah:i,tikkun:r,width:c})}for(let{torah:e,tikkun:t,width:r}of n)t.style.setProperty(`--reader-paired-word-width`,r),e.style.setProperty(`--reader-paired-word-width`,r)}function Le(e){let t=e.querySelector(`.reader-reading-page`),n=e.closest(`.tikkun-book`);if(!t||!n)return;let r=t.getBoundingClientRect();for(let t of e.querySelectorAll(`.reader-reading-page-side`)){let e=t.classList.contains(`mod-torah`)?`mod-torah`:`mod-tikkun`,i=[...n.querySelectorAll(`.reader-reading-page-side.${e} .mod-reading-line`)];for(let e of t.querySelectorAll(`.mod-reading-line`)){let t=e.querySelector(`.line-gutter.mod-verses`);if(!t?.textContent?.trim())continue;let n=i.indexOf(e),a=J(e,`.word[data-token-key]`),o=a[G({currentLineWords:a,previousLineWords:n>0?J(i[n-1],`.word[data-token-key]`):[],verseOrdinal:0})]??a[0];o&&t.style.setProperty(`--reading-verse-gutter-top`,`${o.getBoundingClientRect().top-r.top}px`)}}}function Re(e){let t=e.closest(`.tikkun-book`);if(!t)return;let n=t.getBoundingClientRect(),r=[...t.querySelectorAll(`.mod-reading-line[data-class="line"]`)];for(let i of e.querySelectorAll(`.mod-reading-line[data-class="line"]`)){let e=i.querySelector(`.line-gutter.mod-verses`);if(!e?.textContent?.trim())continue;let a=r.indexOf(i),o=J(i,`[data-reader-canonical="true"] .word[data-token-key]`),s=o[G({currentLineWords:o,previousLineWords:a>0?J(r[a-1],`[data-reader-canonical="true"] .word[data-token-key]`):[],verseOrdinal:0})]??o[0];s&&e.style.setProperty(`--reading-verse-gutter-top`,`${s.getBoundingClientRect().top-n.top+t.scrollTop}px`)}}function ze(e,t){if($(e),e.style.removeProperty(`--reading-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-expansion`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-aliyah-display`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-text-scale`),e.style.removeProperty(`--match-haazinu-gap`),e.style.removeProperty(`--match-ordinary-inline-size`),e.style.removeProperty(`--match-ordinary-inline-offset`),e.classList.remove(`mod-match-fitted`),e.querySelector(`table`)?.style.removeProperty(`width`),Y(e),t.layout===`match`){let n=Fe(e,t.sides);Ne(e,t.sides),n?.forEach(e=>Pe(e,t.sides));return}t.sides===`two`?(Ie(e),Le(e)):Re(e)}export{ye as a,ue as c,_ as d,x as f,Ce as i,de as l,Q as n,P as o,b as p,q as r,fe as s,ze as t,le as u};