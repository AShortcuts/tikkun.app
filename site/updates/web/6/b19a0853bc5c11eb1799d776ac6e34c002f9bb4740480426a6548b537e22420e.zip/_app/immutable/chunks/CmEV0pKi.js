const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./BoyJLsD7.js","./CJLdMZ-j.js","./xihTtKlq.js","./CDkMCuS0.js","./DT_-59oX.js","./KkKzNkus.js","./HclGiUj8.js","./CGTliPwN.js","./BguZM7hk.js","./DEKaBRFm.js","./CT4bspt6.js","./CkaUEpHg.js","./DHpTsjPm.js","./D0YNzAQW.js","./C_qCsIQy.js","./CvqNZxHV.js","./C_sG4J_C.js","./dgLhgZvB.js","./B55PeGk9.js","./yVxVdJXI.js","./CN4PYbqv.js","../assets/SupportDiagnosticsActions.DJCwcTri.css","./BrPuoNd_.js","../assets/reader-settings.CDE9aU7P.css","./Ft8YMWpR.js","./CxkbxRrs.js","../assets/CueAnalyticsPage.BQ5Mq9ep.css","./DKcmOp2B.js","./CjV3nxOM.js","../assets/ParshaPicker.CPqXIDg4.css","./BJt2S0aA.js","./CfgJk93m.js","../assets/cue-authoring.DYcNihHZ.css","./bmzTKomM.js","./Cx3jA1EZ.js","../assets/media-panel.Be1OF_ev.css","./BVZf8LWP.js","./CJ7KFjv4.js"])))=>i.map(i=>d[i]);
import{B as e,F as t,L as n,M as r,N as i,O as a,P as o,Tt as s,U as c,V as l,Z as u,a as d,c as f,ct as p,d as m,dt as h,et as g,f as _,it as v,j as y,kt as b,lt as x,m as S,nt as C,ot as w,r as T,rt as E,tt as D,v as O,vt as k,wt as A,y as j,yt as M,z as N}from"./CJLdMZ-j.js";import{t as P}from"./HclGiUj8.js";import"./xihTtKlq.js";import{a as F,n as ee,o as I}from"./Caqp-XHW.js";import{i as L,n as R,t as te}from"./DEKaBRFm.js";import{a as ne,i as z,o as re,r as B,t as V}from"./-q-97J3V.js";import{a as ie,i as H,n as U,o as W,r as G,s as ae,t as oe}from"./CT4bspt6.js";import{a as K,i as se,n as ce,o as q,r as J}from"./CxkbxRrs.js";import{A as le,B as Y,D as ue,E as de,H as fe,N as pe,O as me,V as he,g as ge,h as _e,k as ve,m as ye,p as X,z as be}from"./CGTliPwN.js";import{t as xe}from"./B5OcMZss.js";import{l as Se,n as Ce,r as we}from"./CkaUEpHg.js";import{i as Te,r as Ee}from"./CfgJk93m.js";import{n as De,t as Z}from"./D0YNzAQW.js";import{A as Oe,C as ke,E as Q,S as Ae,T as $,_ as je,a as Me,b as Ne,c as Pe,f as Fe,h as Ie,i as Le,j as Re,l as ze,m as Be,n as Ve,o as He,p as Ue,r as We,s as Ge,u as Ke,v as qe,w as Je,y as Ye}from"./KkKzNkus.js";import{i as Xe,r as Ze,t as Qe}from"./CvqNZxHV.js";import{c as $e,i as et,n as tt,o as nt,r as rt,t as it}from"./C_sG4J_C.js";function at(e){if(!e.length)return e;let[t,...n]=e;return t.timeStart===0?e:[{...t,timeStart:0},...n]}var ot=new Set(J.filter(K).map(e=>e.parshaSlug)),st={kind:`range`,id:`rosh-chodesh`,name:`Rosh Chodesh`};function ct(e){if(!e.leining.isParsha)return null;let t=Se(e.leining.date.title.en.replace(/^Parshat\s+/i,``)),n=Ce(t);return n&&ot.has(n)?n:ot.has(t)?t:n??t}function lt({narratorId:e,run:t,aliyahIndex:n,recordings:r=J}){if(!n)return null;let i=t.aliyot.find(e=>e.index===n);if(!i)return null;let a=dt(t,i);if(a)return r.find(t=>q(t)&&t.status===`available`&&t.narratorId===e&&t.reading.id===a.id&&ft(t.range,i))??null;let o=ct(t);if(!o)return null;let s=n===`Maftir`?7:Math.max(1,Math.min(n,7));return r.find(t=>K(t)&&t.narratorId===e&&t.parshaSlug===o&&t.aliyah===s&&t.status===`available`)??null}function ut({narratorId:e,run:t,aliyahIndex:n,recordings:r=J}){if(!n)return null;let i=t.aliyot.find(e=>e.index===n);if(!i)return null;let a=lt({narratorId:e,run:t,aliyahIndex:n,recordings:r});if(a)return a;let o=n===`Maftir`?7:Math.max(1,Math.min(n,7)),s=dt(t,i);if(s){let t=r.find(t=>q(t)&&t.narratorId===e&&t.reading.id===s.id&&ft(t.range,i));if(t)return t;let n=`/audio/${e}/${s.id}/${o}.m4a`;return{id:`${s.id}-${o}`,narratorId:e,reading:s,range:{start:i.start,end:i.end},aliyah:o,title:`${s.name} Aliyah ${o}`,playSrc:n,downloadSrc:n,format:`m4a`,status:`missing`}}let c=ct(t);if(!c)return null;let l=r.find(t=>K(t)&&t.narratorId===e&&t.parshaSlug===c&&t.aliyah===o);if(l)return l;let u=r.find(t=>K(t)&&t.narratorId===e&&t.parshaSlug===c),d=u?.parshaName??(t.leining.date.title.en.replace(/^Parshat\s+/i,``).trim()||c),f=`/audio/${e}/${c}/${o}.m4a`;return{id:`${c}-${o}`,narratorId:e,reading:{kind:`parsha`,id:c,name:d,...u?.parshaNumber?{order:u.parshaNumber}:{}},parshaSlug:c,parshaName:d,...u?.parshaNumber?{parshaNumber:u.parshaNumber}:{},aliyah:o,title:`${d} Aliyah ${o}`,playSrc:f,downloadSrc:f,format:`m4a`,status:`missing`}}function dt(e,t){let n=new Re(e.leining.date.date),r=n.getDate()===1||n.getDate()===30,i=t.start.scroll===`torah`&&t.start.b===4&&t.start.c===28&&t.start.v>=1&&t.end.b===4&&t.end.c===28&&t.end.v<=15;return r&&i?st:null}function ft(e,t){return e.start.scroll===t.start.scroll&&e.end.scroll===t.end.scroll&&$(e.start,t.start)===0&&$(e.end,t.end)===0}function pt(){return se}function mt(){return J}async function ht(e){return Qe(e)}function gt(e){return Ze(e)}function _t(e){return Xe(e)}async function vt(e){return at((await ht(e))?.cues??[])}async function yt(e){let t=await ht(e);return t?t.tokenizationVersion===`v2`?t.cues:(console.warn(`Ignoring outdated passage timings for ${e.id}`),[]):[]}async function bt(e,t){let n=await ht(e);return de(n?.issues,e.id,t)}async function xt(e){let t=(await ht(e))?.savedAt;if(typeof t!=`string`)return null;let n=Date.parse(t);return Number.isFinite(n)?n:null}async function St(e){let t=await ht(e),n=t?.cueCount??t?.cues.length??0,r=t?.tokenCount??0;return{cueCount:n,tokenCount:r,isUnfinished:n>0&&r>0&&n<r,isComplete:n>0&&r>0&&n>=r}}function Ct({cueIndex:e,cueCount:t,tokenCount:n}){let r=n||t,i=t>0?Math.max(0,Math.min(r,Math.max(e+1,1))):0,a=r>0?Math.max(0,Math.min(1,i/r)):0;return{current:i,total:r,label:`${i} / ${r}`,ratio:a}}function wt({cueIndex:e,cueCount:t}){let n=Math.max(0,t),r=n>0?Math.max(1,Math.min(n,e+1)):0;return{current:r,total:n,label:`Cue ${r} / ${n}`}}var Tt=e=>`${e.pageNumber}:${e.lineIndex}:${e.fragmentIndex}:${e.wordIndex}`;function Et(e,t){let n=Math.min(e.length,t.length);for(let r=n;r>0;r--){let n=e.slice(-r),i=t.slice(0,r);if(n.every((e,t)=>e===i[t]))return i}return[]}function Dt(e,t){let n=new Set(t);return e.filter(e=>n.has(Tt(e)))}function Ot(e,t){if(!t.length)return!0;let n=new Set(e.map(Tt));return t.every(e=>n.has(e))}function kt(e,t,n){let r=Dt(e.cues,t),i=r[0];if(!i)return e.cues.length||n===`cue-boundary`?null:{recording:e.recording,tokenKeys:[...t],cues:[],startTime:0,endTime:null};let a=r[r.length-1],o=e.cues.indexOf(a),s=e.cues[o+1],c=n===`media-end`?null:a.timeEnd??s?.timeStart??a.timeStart+.75;return{recording:e.recording,tokenKeys:t.filter(e=>r.some(t=>Tt(t)===e)),cues:r,startTime:i.timeStart,endTime:c}}function At({target:e,tokenKeys:t,current:n,previous:r,previousTokenKeys:i=[]}){if(!t.length)return null;let a=Et(i,t),o=!!(n&&Ot(n.cues,a));if(n&&o){let r=kt(n,t,`media-end`);if(!r)return null;let i=r.tokenKeys[0]===t[0];return{target:e,tokenKeys:t,segments:[r],status:i?`current-only`:`partial-start`}}let s=!!(a.length&&r&&(!n||r.recording.narratorId===n.recording.narratorId)&&Ot(r.cues,a));if(r&&s){let i=kt(r,a,`cue-boundary`),o=t.slice(a.length),s=n?kt(n,o,`media-end`):null,c=[i,s].filter(e=>!!e);return c.length?{target:e,tokenKeys:t,segments:c,status:s?`previous-opening`:`overlap-only`}:null}if(!n)return null;let c=kt(n,t,`media-end`);return c?{target:e,tokenKeys:t,segments:[c],status:`partial-start`}:null}function jt(e){return{timeStart:e.timeStart,timeEnd:e.timeEnd,pageNumber:e.pageNumber,lineIndex:e.lineIndex,fragmentIndex:e.fragmentIndex,wordIndex:e.wordIndex,review:e.review}}function Mt(e,t){return e.length===t.length&&e.every((e,n)=>JSON.stringify(jt(e))===JSON.stringify(jt(t[n])))}var Nt=`tikkun-admin-draft:`,Pt=new Map(J.map(e=>[e.id,e])),Ft=new WeakMap,It=0;function Lt(){let e=globalThis.crypto;return typeof e?.randomUUID==`function`?e.randomUUID():typeof e?.getRandomValues==`function`?[...e.getRandomValues(new Uint32Array(4))].map(e=>e.toString(16).padStart(8,`0`)).join(``):(It+=1,`${Date.now().toString(36)}-${It.toString(36)}-${Math.random().toString(36).slice(2)}`)}function Rt(e){return typeof e==`string`&&e.length>0&&e.length<=128}function zt(){return Lt()}function Bt(e){return`${Nt}${e}`}function Vt(e){return typeof e==`string`?Pt.get(e)??null:e}function Ht(e){return typeof e==`number`?{tokenCount:e}:{tokenCount:e.length,tokenKeys:e}}function Ut(e,t){let n=Vt(e),r=typeof e==`string`?e:e.id,i=G(`local`),a=Bt(r),o;try{o=ie(i,a)}catch(e){return console.error(`Failed to read admin draft for ${r}`,e),{status:`unavailable`,revision:null}}if(o===null)return{status:`missing`,revision:null};let s;try{s=JSON.parse(o)}catch(e){return console.error(`Failed to parse admin draft for ${r}`,e),{status:`invalid`,reason:`invalid-json`,revision:o}}let c=n?ce(s,{recording:n,...Ht(t)}):null;return c?{status:`ready`,draft:c,revision:o}:{status:`invalid`,reason:`invalid-draft`,revision:o}}function Wt(e,t){let n=Ut(e,t);return n.status===`ready`?n.draft:null}function Gt(e){let t=Ft.get(e);return t||(t=new Map,Ft.set(e,t)),t}function Kt(e,t,n,r){if(!Rt(r.writerToken))throw TypeError(`Cannot persist an admin draft without a writer token`);let i=ce(e,{recording:t,tokenCount:e.tokenCount,tokenKeys:n});if(!i)throw TypeError(`Cannot persist an invalid admin draft`);let a=G(`local`);if(!a)throw new Jt(i.audioId);let o=Bt(i.audioId),s=JSON.stringify(i);try{let e=ie(a,o);if(e===s)return{revision:s};let c=null;if(e!==null)try{c=ce(JSON.parse(e),{recording:t,tokenCount:i.tokenCount,tokenKeys:n})}catch{c=null}let l=Gt(a).get(o),u=l?.rawValue===e&&l.writerToken===r.writerToken;if(r.expectedRevision!==e&&!u)throw new Yt(i.audioId,c?.updatedAt??null,i.updatedAt);if(c&&(c.updatedAt>i.updatedAt||c.updatedAt===i.updatedAt&&e!==s))throw new Yt(i.audioId,c.updatedAt,i.updatedAt);if(ie(a,o)!==e)throw new Yt(i.audioId,null,i.updatedAt);if(ae(a,o,s),ie(a,o)!==s)throw Error(`Admin draft write could not be verified`);return Gt(a).set(o,{rawValue:s,writerToken:r.writerToken}),{revision:s}}catch(e){throw e instanceof Yt?e:new Jt(i.audioId,e)}}async function qt(e,t,n,r){let i=globalThis.navigator?.locks;if(!i)throw new Jt(e.audioId,Error(`Web Locks are unavailable; refusing an unsafe draft write`));return i.request(`tikkun-admin-draft:${e.audioId}`,{mode:`exclusive`},()=>Kt(e,t,n,r))}var Jt=class extends Error{constructor(e,t){super(`Failed to access admin draft storage for ${e}`),this.name=`AdminDraftStorageError`,this.cause=t}},Yt=class extends Error{constructor(e,t,n){super(`Refusing to overwrite conflicting admin draft for ${e} (${t??`missing`} vs ${n})`),this.name=`AdminDraftConflictError`}},Xt=[{glyph:`א`,value:1},{glyph:`ב`,value:2},{glyph:`ג`,value:3},{glyph:`ד`,value:4},{glyph:`ה`,value:5},{glyph:`ו`,value:6},{glyph:`ז`,value:7},{glyph:`ח`,value:8},{glyph:`ט`,value:9},{glyph:`י`,value:10},{glyph:`כ`,value:20},{glyph:`ל`,value:30},{glyph:`מ`,value:40},{glyph:`נ`,value:50},{glyph:`ס`,value:60},{glyph:`ע`,value:70},{glyph:`פ`,value:80},{glyph:`צ`,value:90},{glyph:`ק`,value:100},{glyph:`ר`,value:200},{glyph:`ש`,value:300},{glyph:`ת`,value:400}].reverse(),Zt=e=>{if(e<=0)return``;if(e===15)return`טו`;if(e===16)return`טז`;let t=0;for(;e<Xt[t].value;)++t;let n=Xt[t];return`${n.glyph}${Zt(e-n.value)}`};function Qt(e,t){return t===1?`ראשון`:e}function $t(e=new URL(window.location.href)){let t=e.searchParams.get(`recording`)===`1`;return{enabled:t,audioId:t?e.searchParams.get(`audioId`):null}}function en({contentRect:e,viewport:t,margin:n}){let r=e=>Math.max(2,Math.floor(e/2)*2),i=()=>({x:0,y:0,width:r(t.width),height:r(t.height)});if(!e)return i();let a=e.x+e.width,o=e.y+e.height;if(a<=0||e.x>=t.width||o<=0||e.y>=t.height)return i();let s=e.x+e.width/2,c=Math.max(0,Math.floor(e.x-n)),l=Math.min(t.width,Math.ceil(a+n)),u=Math.min(t.width,l-c);return{x:Math.max(0,Math.min(t.width-u,Math.floor(s-u/2))),y:0,width:r(u),height:r(t.height)}}function tn(e){return{...e,playbackRate:1,autoScrollWithPlayback:!0,focalPointMode:`reader`,disableShiftNekudotHide:!1,themeMode:`light`}}function nn(e){return e.at(-1)?.annotatedText.trim().endsWith(`׃`)??!1}function rn(e,t=0){let n=e.findIndex((e,n)=>n>=t&&e.annotatedText.includes(`׃`));return n<0?e.length:n+1}function an({currentLineWords:e,previousLineWords:t,verseOrdinal:n}){let r=t.length&&!nn(t)?rn(e):0;for(let t=0;t<n;t+=1)r=rn(e,r);return r}function on({wordsByLine:e,startLineIndex:t,startVerseOrdinal:n,endLineIndex:r,endVerseOrdinal:i}){if(t<0||r<t||n<0||i<0)return[];let a=e[t],o=e[r];if(!a||!o)return[];let s=an({currentLineWords:a,previousLineWords:e[t-1]??[],verseOrdinal:n}),c=an({currentLineWords:o,previousLineWords:e[r-1]??[],verseOrdinal:i}),l=e.flat(),u=e.reduce((t,n,r)=>(t[r]=r?t[r-1]+e[r-1].length:0,t),[]),d=u[t]+s,f=u[r]+c,p=l.findIndex((e,t)=>t>=f&&e.annotatedText.includes(`׃`)),m=p<0?l.length:p+1;return l.slice(d,m).map(e=>e.tokenKey).filter(Boolean)}async function sn({start:e,end:t}){if(e.scroll!==t.scroll)throw Error(`Passage audio requires references in the same scroll`);let n=await Ne(e.scroll),r=n.physicalLocationFromRef(e),i=n.physicalLocationFromRef(t),a=Array.from({length:Math.min(n.getPageCount(),i.pageNumber+1)-Math.max(1,r.pageNumber-1)+1},(e,t)=>Math.max(1,r.pageNumber-1)+t),o=(await Promise.all(a.map(async t=>(await Fe(e.scroll,t)).map((e,n)=>({pageNumber:t,lineIndex:n,line:e}))))).flat(),s=(e,t)=>o[e]?.line.verses.findIndex(e=>e.book===t.b&&e.chapter===t.c&&e.verse===t.v)??-1,c=o.findIndex((t,n)=>s(n,e)>=0),l=o.findIndex((e,n)=>s(n,t)>=0),u=on({wordsByLine:o.map(e=>X(e.pageNumber,e.lineIndex,e.line)),startLineIndex:c,startVerseOrdinal:s(c,e),endLineIndex:l,endVerseOrdinal:s(l,t)});if(!u.length)throw Error(`Could not resolve passage audio words`);return u}function cn({state:e,available:t,cueIncomplete:n=!1,adminMissing:r=!1,playing:i=!1}){let a=e?.problem,o=r||!e?.recording&&(!t||a===`missing-audio`),s=!o&&(e?.canPlay??(t&&![`checking`,`timing-needed`,`load-failed`,`missing-audio`].includes(a??``))),c=o?`empty`:a===`load-failed`?`audio`:e?.issue??(a===`timing-needed`||a===`incomplete-cues`||n?`cue`:a===`partial-audio`||a===`missing-audio`?`audio`:`normal`),l=i?`Pause this aliyah`:`Play this aliyah`;return o?l=r?`No recording yet. Select this aliyah to record.`:`No recording available for this aliyah.`:a===`checking`?l=`Checking available audio and timing cues.`:a===`load-failed`?l=e?.message||`The recording could not load. Try again.`:a===`timing-needed`?l=`Audio exists, but timing cues are needed to play this excerpt.`:a===`partial-audio`?l=`${(e?.message||`Part of this aliyah is available`).replace(/[.!?]$/,``)}. Select for an available portion to play.`:c===`cue`?l=`Full audio available. Some word highlighting is missing.`:a===`missing-audio`&&(l=e?.message||`No playable audio available for this aliyah.`),{tone:c,dimmed:!s,tooltip:l,actionDisabled:!r&&(o||a===`checking`)}}function ln(){let e=new ke({ashkenazi:!0,israel:!1,includeModernHolidays:!1}),t=new Map;return n=>{if(!K(n))return n.range;t.has(n.parshaSlug)||t.set(n.parshaSlug,Pe(e,n.parshaSlug,new Date));let r=t.get(n.parshaSlug)?.run.aliyot.find(e=>e.index===n.aliyah);return r?{start:r.start,end:r.end}:null}}var un=({start:e,end:t})=>`${e.c}:${e.v}-${t.c}:${t.v}`,dn=(e,t)=>e.scroll===t.scroll&&$(e,t)===0,fn=(e,t)=>dn(e.start,t.start)&&dn(e.end,t.end),pn=e=>`${e.start.scroll}:${e.start.b}:${un(e)}`;function mn(e){let t=[];if(e.start.scroll!==`torah`||e.start.b!==e.end.b)return t;for(let n=e.start.c;n<=e.end.c;n++)for(let r of Ae(e.start.b,n)){let i={...e.start,c:n,v:r};$(i,e.start)>=0&&$(i,e.end)<=0&&t.push(i)}return t}var hn=class{constructor(e){this.options=e,this.cache=new Map,this.states=new Map,this.sources=e.recordings.flatMap(t=>{let n=e.rangeForRecording(t);return t.status===`available`&&n?[{recording:t,range:n}]:[]})}key(e,t){return`${t}:${pn(e)}`}candidates(e,t){return this.sources.filter(n=>n.recording.narratorId===t&&n.range.start.scroll===e.start.scroll&&n.range.start.b===e.start.b&&$(n.range.start,e.end)<=0&&$(n.range.end,e.start)>=0).sort((t,n)=>Number(fn(n.range,e))-Number(fn(t.range,e))||$(t.range.start,n.range.start)||$(n.range.end,t.range.end)||t.recording.id.localeCompare(n.recording.id))}peek(e,t){let n=this.states.get(this.key(e,t));if(n)return n;let r=this.candidates(e,t);return{problem:r.length?`checking`:`missing-audio`,message:r.length?`Checking audio coverage`:`Audio not available`,recording:r[0]?.recording??null}}resolve(e,t){let n=this.key(e,t),r=this.cache.get(n);if(r)return r;let i=this.build(e,t).then(e=>(this.states.set(n,e),e),r=>{throw this.cache.delete(n),this.states.set(n,{problem:`load-failed`,message:`Audio details could not be loaded. Retry playback.`,recording:this.candidates(e,t)[0]?.recording??null}),r});return this.cache.set(n,i),i}async build(e,t){let n=mn(e),r=new Map,i=e=>{let t=pn(e),n=r.get(t);return n||(n=this.options.loadTokens(e),r.set(t,n)),n},a=await i(e),o=await Promise.all(this.candidates(e,t).map(async e=>({...e,tokens:await i(e.range),cues:new Map((await this.options.loadCues(e.recording)).map(e=>[Y(e),e]))}))),s=new Map,c=!1,l=(e,t)=>{if(e>=n.length)return Promise.resolve({covered:0,cues:0,count:0,steps:[]});let r=`${e}:${t}`,a=s.get(r);if(a)return a;let u=(async()=>{let r=await l(e+1,!0),a={...r,steps:[{startIndex:e,endIndex:e,segment:null},...r.steps]};for(let r of o){if($(r.range.start,n[e])>0||$(r.range.end,n[e])<0||t&&$(r.range.start,n[e])<0)continue;let s=e;for(;s+1<n.length&&$(n[s+1],r.range.end)<=0;)s++;let u=new Set([s]);for(let t of o){let r=n.findIndex(e=>dn(e,t.range.start));r>e&&r<=s&&u.add(r-1)}for(let t of u){let o={start:n[e],end:n[t]},s=await i(o),u=r.tokens.indexOf(s[0]);if(u<0||!s.every((e,t)=>r.tokens[u+t]===e))continue;let d=dn(o.start,r.range.start)?0:r.cues.get(s[0])?.timeStart,f=s[s.length-1],p=r.tokens[u+s.length],m=dn(o.end,r.range.end)?null:r.cues.get(f)?.timeEnd??(p?r.cues.get(p)?.timeStart:void 0);if(d===void 0||m===void 0||m!==null&&m<=d){c=!0;continue}let h=s.flatMap((e,t)=>{let n=r.cues.get(e);if(!n)return[];let i=r.cues.get(s[t+1]),a=n.timeEnd??i?.timeStart??(t===s.length-1?m??void 0:n.timeStart);return[{...n,...a===void 0?{}:{timeEnd:m===null?a:Math.min(a,m)}}]}),g={recording:r.recording,tokenKeys:s,cues:h,startTime:d,endTime:m},_=await l(t+1,!1),v={covered:_.covered+t-e+1,cues:_.cues+h.length,count:_.count+1,steps:[{startIndex:e,endIndex:t,segment:g},..._.steps]};(v.covered>a.covered||v.covered===a.covered&&(v.count<a.count||v.count===a.count&&v.cues>a.cues))&&(a=v)}}return a})();return s.set(r,u),u},u=[],d=[],f=null;for(let e of(await l(0,!1)).steps)if(e.segment)f||(f={range:{start:n[e.startIndex],end:n[e.endIndex]},tokenKeys:[],segments:[]},u.push(f)),f.range.end=n[e.endIndex],f.tokenKeys.push(...e.segment.tokenKeys),f.segments.push(e.segment);else{let t=d[d.length-1];!f&&t?t.end=n[e.endIndex]:d.push({start:n[e.startIndex],end:n[e.endIndex]}),f=null}let p=u.length===1&&fn(u[0].range,e),m=p&&u[0].segments.every(e=>e.cues.length===e.tokenKeys.length);c=d.some(e=>o.some(t=>$(t.range.start,e.end)<=0&&$(t.range.end,e.start)>=0))&&c;let h=p?m?null:`incomplete-cues`:u.length?`partial-audio`:c?`timing-needed`:`missing-audio`,g=n.filter(e=>!o.some(t=>$(t.range.start,e)<=0&&$(t.range.end,e)>=0)),_=g.length?`audio`:p&&m?void 0:`cue`,v=d.map(e=>[je().find(t=>t.number===e.start.b)?.label,un(e)].filter(Boolean).join(` `)),y=g.length?`Audio unavailable for ${v.join(`, `)} ${d.length===1?`portion`:`portions`}`:`Excerpt timing needed: ${v.join(`, `)}`;return{problem:h,message:p?m?``:`Full audio available. Some word highlighting is missing.`:`${y}${g.length&&c?`. Some excerpts also need timing cues.`:``}`,recording:u[0]?.segments[0]?.recording??o[0]?.recording??null,portions:u,missing:d,tokenKeys:a,range:e,cueComplete:m,issue:_,canPlay:u.length>0}}};function gn(e,t,n,r){return{target:n,readingLabel:r,tokenKeys:t.tokenKeys,segments:t.segments,status:e.problem===`partial-audio`?`partial-passage`:`passage`,passage:{range:t.range,requestedRange:e.range,cueComplete:t.segments.every(e=>e.cues.length===e.tokenKeys.length)}}}var _n=e=>{let t=document.createElement(`template`);if(e=e.trim(),t.innerHTML=e,t.content.childElementCount!==1)throw Error(`Should render exactly one node`);return t.content.firstElementChild},vn=e=>typeof e==`string`?{key:e,ctrl:!1}:e,yn={htmlToElement:_n,whenKey:(e,t)=>n=>{let{key:r,ctrl:i}=vn(e);n.ctrlKey===i&&n.key===r&&!n.repeat&&t(n)},purgeNode:e=>{for(;e.firstChild;)e.removeChild(e.firstChild)}},bn=`.word[data-annotations-mode][data-annotations-alternate]`;function xn(e,t){e.querySelectorAll(bn).forEach(e=>{let n=e.closest(`[data-reader-annotations]`)?.dataset.readerAnnotations,r=n===`on`||n!==`off`&&t,i=r?`on`:`off`,a=(r?e.dataset.annotationsOnPresent:e.dataset.annotationsOffPresent)!==`false`,o=(r?e.dataset.annotationsOnKri:e.dataset.annotationsOffKri)===`true`;if(e.hidden=!a,e.classList.toggle(`ktiv-kri`,a&&o),e.dataset.annotationsMode===i)return;let s=e.innerHTML,c=e.dataset.annotationsAlternate??``;e.dataset.annotationsAlternate=s,e.innerHTML=a?c:``,e.dataset.annotationsMode=i})}var Sn=`.special-letter.mod-small`,Cn=`--special-letter-baseline-shift`,wn=/[א-ת]/u,Tn=/[א-ת]/gu,En=e=>`${e.fontStyle} ${e.fontWeight} ${e.fontSize} ${e.fontFamily}`,Dn=(e,t,n)=>{e.direction=n.direction===`rtl`?`rtl`:`ltr`,e.font=En(n),e.textBaseline=`alphabetic`;let r=e.measureText(t).actualBoundingBoxAscent;if(!Number.isFinite(r)||r<=0)throw Error(`Could not measure the visible top of special letter ${t}`);return r},On=(e,t)=>{let n=t.textContent?.match(wn)?.[0],r=Number(t.dataset.specialLetterPosition),i=e.textContent?.match(Tn)??[];if(!n||!Number.isSafeInteger(r)||r<1||i[r-1]!==n)throw Error(`Small special letter has invalid word-position metadata`);let a=[i[r-2],i[r]].filter(e=>!!e);if(!a.length)throw Error(`Small special letter requires a neighboring Hebrew letter`);return{targetLetter:n,neighbors:a}},kn=e=>{let t=e instanceof Document?e:e.ownerDocument,n=t.defaultView;if(!n)throw Error(`Special-letter alignment requires a window`);let r=t.createElement(`canvas`).getContext(`2d`);if(!r)throw Error(`Special-letter alignment requires Canvas 2D`);let i=e.querySelectorAll(Sn);return i.forEach(e=>{let t=e.closest(`.word`),i=e.textContent;if(!t||!i)throw Error(`Small special letter must remain inside a non-empty word`);let{targetLetter:a,neighbors:o}=On(t,e),s=n.getComputedStyle(t),c=Math.min(...o.map(e=>Dn(r,e,s)))-Dn(r,a,n.getComputedStyle(e));if(!Number.isFinite(c))throw Error(`Invalid special-letter baseline shift for ${i}`);e.style.setProperty(Cn,`${c}px`)}),i.length},An=async(e,t)=>{let n=e instanceof Document?e:e.ownerDocument;return n.fonts.status!==`loaded`&&await n.fonts.ready,t?.aborted||e instanceof Element&&!e.isConnected?0:kn(e)},jn=`(max-width: 550px)`;function Mn(e,t){let n=t.matchMedia(jn),r=new Set,i=n.matches?`compact`:`wide`;return n.addEventListener(`change`,e=>{let t=e.matches?`compact`:`wide`;if(t!==i){i=t;for(let e of[...r])e(i)}},{signal:e.signal}),{get mode(){return i},isCompact:()=>i===`compact`,onChange(t){return r.add(t),e.own(()=>r.delete(t))}}}var Nn=class{constructor(){this.currentInfo={aliyahRange:[],currentRun:null,previousLink:null,nextLink:null,relatedRuns:[]},this.firstAliyah=null,this.lastAliyah=null}get info(){return this.currentInfo}setLine(e,t){let n={...this.currentInfo},r=t.first?.aliyot[0]??t.center?.aliyot[0],i=t.last?.aliyot[0]??t.center?.aliyot[0],a=t.center?.run??t.last?.run??t.first?.run;if(!a)return this.currentInfo;if(n.currentRun=a,n.currentRun!==this.currentInfo.currentRun&&n.currentRun){n.relatedRuns=n.currentRun.leining.runs.filter(e=>Ye(e.scroll)).map(e=>({label:Ue(e.aliyot[0].index,e)||e.type,targetRun:e}));let t=n.currentRun.leining.date,r=e.generator.aroundDate(t.date).filter(e=>e.id===t.id||!Je(e,t)).flatMap(e=>e.leinings).filter(e=>e.runs.some(e=>Ye(e.scroll))),i=r.findIndex(e=>e.date.id===t.id&&e.id===n.currentRun?.leining.id);n.previousLink=Pn(r[i-1],n.currentRun),n.nextLink=Pn(r[i+1],n.currentRun)}if(n.currentRun?.scroll!==`torah`)n.aliyahRange=[];else if(r!==this.firstAliyah?.aliyah||i!==this.lastAliyah?.aliyah||n.currentRun!==this.currentInfo.currentRun){this.firstAliyah=e(r),this.lastAliyah=e(i),(r||i)&&(n.aliyahRange=this.generateAliyahRange(n.currentRun));function e(e){return e?{aliyah:e,run:Object.values(t).find(t=>t?.aliyot.includes(e)).run}:null}}return this.currentInfo=n,this.currentInfo}generateAliyahRange(e){return(this.firstAliyah?.aliyah===this.lastAliyah?.aliyah?[this.firstAliyah]:[this.firstAliyah,this.lastAliyah]).filter(e=>e!=null).map(t=>{let n=Ue(t.aliyah.index,t.run,{isEnd:!0});return t.run===e?n:`${t.run.leining.date.title.he} ${n}`})}};function Pn(e,t){let n=e?.runs.find(e=>Ye(e.scroll));return!e||!n?null:{targetRun:n,label:[e.date.id===t.leining.date.id?``:e.date.title.he,e.id].join(` `).trim()}}var Fn=`tikkun.last-reading`;function In(e,t){return ze(e.leining,t)??Le(e,t)}function Ln(e,t){if(!e||typeof e!=`object`)return!1;let n=e;return typeof n.hash==`string`&&F(n.hash)&&typeof n.parshaName==`string`&&n.parshaName.trim().length>0&&(n.aliyahLabel===void 0||typeof n.aliyahLabel==`string`)&&H(n.savedAt,{now:t})}function Rn(e,t,n=F){return U({storage:e,key:Fn,validate:e=>Ln(e,t)&&n(e.hash)})}function zn(e,t,n=Date.now()){if(!F(t.hash))return;let r=t.parshaName.trim();if(!r)return;let i={hash:t.hash,parshaName:r,aliyahLabel:t.aliyahLabel?.trim()||void 0,savedAt:n};try{let t=Rn(e,n),r=t.read();if(r.status===`unavailable`)throw r.error;W(t.write(i,r.revision)),re({reading:i})}catch(e){throw new Hn(e)}}function Bn(e,t=Date.now(),n=F){let r=Rn(e,t,n),i=r.read();return i.status===`unavailable`?(console.error(`Failed to read the last-reading checkpoint`,i.error),null):i.status===`invalid`?(i.reason===`invalid-json`?console.error(`Failed to parse the last-reading checkpoint`,i.error):console.error(`Invalid last-reading checkpoint`),null):i.status===`missing`?null:t-i.value.savedAt>1728e5?(Vn(r,i.revision),null):i.value}function Vn(e,t){try{let n=e.remove(t);if(n.status===`unavailable`)throw n.error}catch(e){console.error(`Failed to remove an expired last-reading checkpoint`,e)}}var Hn=class extends Error{constructor(e){super(`Failed to save the last-reading checkpoint`),this.name=`LastReadingStorageError`,this.cause=e}};function Un(e){let t=e.showWhenEmpty??!0,n=e.dedupeKey??e.label;return{...e,aliases:e.aliases??[],keywords:e.keywords??[],available:e.available??!0,showWhenEmpty:t,emptyPriority:t?e.emptyPriority??0:null,dedupeKey:n,destinationId:e.destinationId??n}}function Wn(e){return e===`Maftir`?`Maftir`:`Aliyah ${e}`}function Gn(e){return e===`Maftir`?[`m`,`maftir`]:[`${e}`,`aliyah ${e}`]}function Kn({run:e,displayTitle:t,navigate:n,showWhenEmpty:r=!0,emptyPriority:i,dedupeKeyPrefix:a}){let o=t.trim(),s=[o,...Ge(e.leining),...e.leining.isParsha?[]:Be(e.leining.date.title,`${e.leining.id}`)];return e.aliyot.flatMap(t=>{let c=t.index;if(!c)return[];let l=In(e,t.start);return[Un({id:`reading.${e.id}.${c}`,group:`reading`,label:`${o} ${Wn(c)}`,dedupeKey:`${a??`reading.${e.id}`}.${c}`,destinationId:l,searchConstraint:{kind:`aliyah`,aliyah:c,allowTerms:Gn(c)},href:l,aliases:s.flatMap(e=>[`${e} ${c}`,`${e} ${Wn(c)}`]),keywords:[...s,...Gn(c)],showWhenEmpty:r,emptyPriority:i,run:()=>n(l)})]})}function qn({navigateToPage:e}){let t=[];for(let n=1;n<=qe(`torah`);n+=1)t.push(Un({id:`page.torah.${n}`,group:`page`,label:`Torah page ${n}`,aliases:[`${n}`,`page ${n}`,`torah ${n}`,`torah page ${n}`,`chumash page ${n}`],keywords:[`page`,`torah`,`chumash`],showWhenEmpty:!1,run:()=>e(`torah`,n)}));for(let n=1;n<=qe(`esther`);n+=1)t.push(Un({id:`page.esther.${n}`,group:`page`,label:`Esther page ${n}`,aliases:[`esther ${n}`,`esther page ${n}`,`megillah ${n}`,`megillah page ${n}`,`megillat esther page ${n}`],keywords:[`page`,`esther`,`megillah`],showWhenEmpty:!1,run:()=>e(`esther`,n)}));return t}function Jn(e,t){let{load:n=()=>P(()=>import(`./BoyJLsD7.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13]),import.meta.url),onLoadError:r,...i}=t,a=null,o=null,s=null,c=0,l=!1,u=()=>{if(a)return Promise.resolve(a);if(s)return s;o??=n();let t=o.then(t=>e.signal.aborted?null:(a=t.createCommandPalette(e,i),a)).catch(t=>(o=null,e.signal.aborted||r(t),null)).finally(()=>{s===t&&(s=null)});return s=t,t},d=()=>{if(e.signal.aborted)return;if(a){a.open();return}l=!0;let t=++c;u().then(n=>{e.signal.aborted||t!==c||!l||(l=!1,n?.open())})},f=()=>{l=!1,c+=1,a?.close()},p={open:d,close:f,toggle:()=>{if(l||a?.isOpen()){f();return}d()},isOpen:()=>l||(a?.isOpen()??!1),refresh:()=>a?.refresh()};return e.own(()=>{l=!1,c+=1,a=null,s=null,o=null}),p}var Yn=[!0,!1].flatMap(e=>[!0,!1].flatMap(t=>[!0,!1].map(n=>({israel:e,ashkenazi:t,includeModernHolidays:n})))).map(e=>new ke(e));function Xn(e){if(!F(e))return!1;let t=e.replace(/^#/,``);return Yn.some(e=>Me(e,t)?.view===`reader`)}function Zn(e){let t=e.split(`?`)[0];if(!F(t))throw Error(`Open a reading before sharing it.`);return`https://tikkunreader.com/reader/${t}`}async function Qn(e,t){let n={title:`Tikkun Reader`,url:Zn(e)};try{if(t.nativeShare)return await t.nativeShare(n),`shared`;let e=t.navigator;if(e.share&&(!e.canShare||e.canShare(n)))return await e.share(n),`shared`;if(!e.clipboard?.writeText)throw Error(`Sharing and clipboard access are unavailable.`);return await e.clipboard.writeText(n.url),`copied`}catch(e){if(e instanceof Error&&(t.nativeShare?e.message===`Share canceled`:e.name===`AbortError`))return`cancelled`;throw e}}var $n=`reader`;function er(e){$n=e}function tr(e){let t=e.getBoundingClientRect(),n=$n===`browser`?document.documentElement.clientHeight/2:t.top+e.clientHeight/2;return Math.max(t.top,Math.min(t.bottom-1,n))}function nr(e){let t=e.getBoundingClientRect();return e.scrollTop+(tr(e)-t.top)}function rr(e,t){let n=t.getBoundingClientRect(),r=n.top+n.height/2;return Math.max(0,e.scrollTop+r-tr(e))}function ir(e,t,n={}){let r=rr(e,t),{minimumScrollDistance:i=0,...a}=n;return Math.abs(r-e.scrollTop)<=Math.max(0,i)?!1:a.behavior?(e.scrollTo({...a,top:r}),!0):(e.scrollTop=r,!0)}var ar=[`reading`,`match`],or=[`one`,`two`],sr=[`tikkun-right`,`torah-right`],cr={layout:`match`,sides:`one`},lr=e=>typeof e==`string`&&ar.some(t=>t===e),ur=e=>typeof e==`string`&&or.some(t=>t===e),dr=e=>typeof e==`string`&&sr.some(t=>t===e);function fr(e,t){return e===`two`&&!t?`two`:`one`}var pr=`tikkun.reader-preferences`,mr=[`automatic`,`light`,`sepia`,`dark`,`custom`],hr=[`browser`,`reader`],gr={background:`#eee6d6`,text:`#3b3026`},_r={playbackRate:{min:.5,max:3},highlightOpacity:{min:.05,max:.45},outlineWidth:{min:1,max:6},outlineOffset:{min:0,max:10},radius:{min:0,max:16},glow:{min:0,max:8}},vr={reducedMotion:`automatic`,narratorId:`yoni-davidov`,playbackRate:1,highlightFill:`#ffd700`,highlightOpacity:.15,outlineColor:`#ffd700`,outlineWidth:2,outlineOffset:3.5,radius:10,glow:3.5,autoScrollWithPlayback:!0,focalPointMode:`reader`,disableShiftNekudotHide:!1,themeMode:`automatic`,customBackgroundColor:gr.background,customTextColor:gr.text,readerTextLayout:`match`,readerSideMode:`one`,readerSideOrder:`tikkun-right`};function yr(){return typeof window>`u`||typeof window.matchMedia!=`function`?vr.readerTextLayout:window.matchMedia(`(max-width: 550px)`).matches?`reading`:`match`}function br(e){return typeof document>`u`||typeof getComputedStyle>`u`?``:getComputedStyle(document.documentElement).getPropertyValue(e).trim()}function xr(e,t){let n=Number.parseFloat(br(e));return Number.isFinite(n)?n:t}function Sr(e,t){return br(e)||t}function Cr(){return{...vr,readerTextLayout:yr(),highlightFill:Sr(`--reader-highlight-fill`,vr.highlightFill),outlineColor:Sr(`--reader-highlight-outline-color`,vr.outlineColor),outlineWidth:xr(`--reader-highlight-outline-width`,vr.outlineWidth),outlineOffset:xr(`--reader-highlight-outline-offset`,vr.outlineOffset),radius:xr(`--reader-highlight-border-radius`,xr(`--reader-highlight-radius`,vr.radius)),glow:xr(`--reader-highlight-glow`,vr.glow)}}function wr(){return{highlightFill:vr.highlightFill,highlightOpacity:vr.highlightOpacity,outlineColor:vr.outlineColor,outlineWidth:vr.outlineWidth,outlineOffset:vr.outlineOffset,radius:vr.radius,glow:vr.glow}}function Tr(e){return typeof e==`string`&&mr.some(t=>t===e)}function Er(e){return typeof e==`string`&&hr.some(t=>t===e)}function Dr(e){return!!e&&typeof e==`object`&&!Array.isArray(e)}function Or(e,t,{min:n,max:r}){return typeof e==`number`&&Number.isFinite(e)?Math.max(n,Math.min(r,e)):t}function kr(e,t){return typeof e==`string`&&/^#[0-9a-f]{6}$/i.test(e)?e:t}function Ar(e,t){let n=Dr(e)?e:{};return{reducedMotion:n.reducedMotion===`on`||n.reducedMotion===`off`||n.reducedMotion===`automatic`?n.reducedMotion:t.reducedMotion,narratorId:typeof n.narratorId==`string`&&n.narratorId.trim()?n.narratorId.trim():t.narratorId,playbackRate:Or(n.playbackRate,t.playbackRate,_r.playbackRate),highlightFill:kr(n.highlightFill,t.highlightFill),highlightOpacity:Or(n.highlightOpacity,t.highlightOpacity,_r.highlightOpacity),outlineColor:kr(n.outlineColor,t.outlineColor),outlineWidth:Or(n.outlineWidth,t.outlineWidth,_r.outlineWidth),outlineOffset:Or(n.outlineOffset,t.outlineOffset,_r.outlineOffset),radius:Or(n.radius,t.radius,_r.radius),glow:Or(n.glow,t.glow,_r.glow),autoScrollWithPlayback:typeof n.autoScrollWithPlayback==`boolean`?n.autoScrollWithPlayback:t.autoScrollWithPlayback,focalPointMode:Er(n.focalPointMode)?n.focalPointMode:t.focalPointMode,disableShiftNekudotHide:typeof n.disableShiftNekudotHide==`boolean`?n.disableShiftNekudotHide:t.disableShiftNekudotHide,themeMode:Tr(n.themeMode)?n.themeMode:t.themeMode,customBackgroundColor:kr(n.customBackgroundColor,t.customBackgroundColor),customTextColor:kr(n.customTextColor,t.customTextColor),readerTextLayout:lr(n.readerTextLayout)?n.readerTextLayout:t.readerTextLayout,readerSideMode:ur(n.readerSideMode)?n.readerSideMode:t.readerSideMode,readerSideOrder:dr(n.readerSideOrder)?n.readerSideOrder:t.readerSideOrder}}function jr(){return U({storage:G(`local`),key:pr,validate:Dr})}function Mr(){let e=Cr(),t=jr().read();return t.status===`unavailable`?(console.error(`Failed to read reader preferences`,t.error),{preferences:{...e},revision:null}):t.status===`invalid`?(t.reason===`invalid-json`?console.error(`Failed to parse reader preferences`,t.error):console.error(`Invalid reader preferences`),{preferences:{...e},revision:t.revision}):t.status===`missing`?{preferences:{...e},revision:t.revision}:{preferences:{...Ar(t.value,e),playbackRate:e.playbackRate},revision:t.revision}}function Nr(e,t){let n=Ar(e,Cr());try{let e=jr(),r={...n,playbackRate:vr.playbackRate},i=t;if(!i){let t=e.read();if(t.status===`unavailable`)throw t.error;i=t.revision}return W(e.write(r,i))}catch(e){throw new Pr(e)}}var Pr=class extends Error{constructor(e){super(`Failed to save reader preferences`),this.name=`ReaderPreferencesStorageError`,this.cause=e}};function Fr(e,t){return Ar({...e,...t},e)}function Ir(e){let t=document.documentElement;t.dataset.readerReducedMotion=e.reducedMotion;let n=Vr(e.highlightFill,e.highlightOpacity),r=`${e.highlightOpacity*100}%`,i=`${(1-e.highlightOpacity)*100}%`;t.dataset.readerTheme=e.themeMode,t.dataset.readerTextLayout=e.readerTextLayout,t.dataset.readerSideMode=e.readerSideMode,t.dataset.readerSideOrder=e.readerSideOrder,t.style.setProperty(`--reader-custom-background-color`,e.customBackgroundColor),t.style.setProperty(`--reader-custom-text-color`,e.customTextColor),t.style.colorScheme=e.themeMode===`custom`?zr(e.customBackgroundColor)<.32?`dark`:`light`:``,t.dataset.readerCustomScheme=t.style.colorScheme,er(e.focalPointMode),t.style.setProperty(`--reader-highlight-fill`,e.highlightFill),t.style.setProperty(`--reader-highlight-fill-tint`,n),t.style.setProperty(`--reader-highlight-fill-alpha`,`${e.highlightOpacity}`),t.style.setProperty(`--reader-highlight-fill-alpha-percent`,r),t.style.setProperty(`--reader-highlight-fill-alpha-inverse-percent`,i),t.style.setProperty(`--reader-highlight-outline-color`,e.outlineColor),t.style.setProperty(`--reader-highlight-outline-width`,`${e.outlineWidth}px`),t.style.setProperty(`--reader-highlight-border-radius`,`${e.radius}px`),t.style.setProperty(`--reader-highlight-glow`,`${e.glow}px`),t.style.setProperty(`--reader-highlight-outline-offset`,`${e.outlineOffset}px`)}function Lr(e,t){let n=Math.max(zr(e),zr(t)),r=Math.min(zr(e),zr(t));return(n+.05)/(r+.05)}function Rr(e){let t=`#191c22`,n=`#f8f7f3`;return Lr(e,t)>=Lr(e,n)?t:n}function zr(e){let[t,n,r]=Br(e).map(e=>{let t=e/255;return t<=.04045?t/12.92:((t+.055)/1.055)**2.4});return .2126*t+.7152*n+.0722*r}function Br(e){let t=/^#([0-9a-f]{6})$/i.exec(e.trim());return t?[0,2,4].map(e=>Number.parseInt(t[1].slice(e,e+2),16)):[0,0,0]}function Vr(e,t){let n=e.trim();if(!n.startsWith(`#`))return n;let r=n.slice(1);if(r.length!==6&&r.length!==3)return n;let[i,a,o]=(r.length===3?r.split(``).map(e=>e+e):[r.slice(0,2),r.slice(2,4),r.slice(4,6)]).map(e=>Number.parseInt(e,16));return`rgba(${i}, ${a}, ${o}, ${t})`}var Hr=1600,Ur=new WeakMap,Wr=new WeakSet;function Gr(e){e.dataset.copyState=`copied`,e.querySelector(`[data-aliyah-link-icon="link"]`)?.setAttribute(`hidden`,``),e.querySelector(`[data-aliyah-link-icon="check"]`)?.removeAttribute(`hidden`);let t=Ur.get(e);t&&window.clearTimeout(t),Ur.set(e,window.setTimeout(()=>Kr(e),Hr))}function Kr(e){let t=Ur.get(e);t!==void 0&&window.clearTimeout(t),delete e.dataset.copyState,e.querySelector(`[data-aliyah-link-icon="link"]`)?.removeAttribute(`hidden`),e.querySelector(`[data-aliyah-link-icon="check"]`)?.setAttribute(`hidden`,``),Ur.delete(e)}function qr(e){if(e instanceof HTMLAnchorElement)return e.href;let t=e.dataset.aliyahUrl;return t?new URL(t,window.location.href).href:null}async function Jr(e,t={}){let n=(e.target instanceof Element?e.target:null)?.closest(`[data-aliyah-link="true"]`);if(!n)return!1;if(e.preventDefault(),Wr.has(n))return!0;Wr.add(n),Kr(n);try{let e=qr(n);if(!e)throw Error(`Missing permalink URL.`);if(t.nativeWriteText)await t.nativeWriteText(Zn(new URL(e).hash));else{if(!navigator.clipboard?.writeText)throw Error(`Clipboard API is unavailable.`);await navigator.clipboard.writeText(e)}}catch(e){return console.warn(`Aliyah permalink copy failed.`,e),t.onError?.(),!0}finally{Wr.delete(n)}return n.isConnected&&Gr(n),!0}var Yr=new Set([Oe.Main,Oe.LastAliyah,Oe.Maftir]);function Xr(e){return e===`Maftir`?`מפטיר`:[`ראשון`,`שני`,`שלישי`,`רביעי`,`חמישי`,`ששי`,`שביעי`][e-1]}function Zr(e,t){return!!(e&&t&&e.runId===t.runId&&e.aliyahIndex===t.aliyahIndex)}function Qr({run:e,aliyah:t}){return`${e.id}:${t.index}`}function $r(e){return`${e.key}:${e.audioKey??``}:${e.recordingKey??``}:${e.audioState?`passage`:`recording`}:${e.audioState?.problem??``}:${e.audioState?.issue??``}:${e.audioState?.canPlay??``}`}function ei(e){return e.leining.runs.filter(t=>t.scroll===e.scroll&&Yr.has(t.type)).flatMap(e=>e.aliyot.flatMap(t=>t.index?[{run:e,aliyah:{...t,index:t.index}}]:[]))}function ti({entries:e,active:t,playback:n,signaturePrefix:r,getAudio:i}){let a=e.map(e=>{let{run:t,aliyah:n}=e,r={runId:t.id,aliyahIndex:n.index},a=i(e);return{key:Qr(e),target:r,label:Xr(n.index),compactLabel:n.index===`Maftir`?`M`:`${n.index}`,audioKey:a.playbackKey,recordingKey:a.recordingKey,audioState:a.audioState}});return{signature:`${r}:${a.map($r).join(`|`)}`,items:a,active:t,playback:n}}function ni({runId:e,current:t,playback:n,first:r}){return n.playing&&n.target?.runId===e?n.target:t?.runId===e?t:r}var ri=n(`<button type="button"></button>`),ii=n(`<button type="button"> </button>`),ai=n(`<span class="aliyah-rail-caption" aria-hidden="true">Aliyah</span> <!>`,1),oi=n(`<button type="button"><!></button>`),si=n(`<article><button class="mobile-aliyah-card-main" type="button"><span class="mobile-aliyah-card-label"> </span> <span class="mobile-aliyah-card-status"> </span></button> <!></article>`),ci=n(`<nav data-target-id="mobile-aliyah-segments" aria-label="Aliyah navigation"></nav> <nav data-target-id="aliyah-rail" aria-label="Aliyah navigation"><!></nav> <div data-target-id="mobile-aliyah-picker" id="mobile-aliyah-picker"><button class="mobile-aliyah-picker-backdrop" data-target-id="mobile-aliyah-picker-backdrop" type="button" aria-label="Close aliyah picker" tabindex="-1"></button> <div class="mobile-aliyah-sheet" role="dialog" aria-modal="true" aria-labelledby="mobile-aliyah-picker-title"><button class="mobile-aliyah-sheet-handle" data-target-id="mobile-aliyah-sheet-handle" type="button" aria-label="Close aliyah picker"></button> <header class="mobile-aliyah-sheet-header"><div class="mobile-aliyah-sheet-copy"><h2 id="mobile-aliyah-picker-title">Choose an aliyah</h2> <p>Tap a name to navigate, or play its recording.</p></div> <button class="mobile-aliyah-sheet-close" data-target-id="mobile-aliyah-picker-close" type="button" aria-label="Close aliyah picker"><!></button></header> <div class="mobile-aliyah-grid" data-target-id="mobile-aliyah-grid"></div></div></div>`,1);function li(n,r){M(r,!0);let o=d(r,`document`,7);function m(){let e=o().defaultView;if(!e)throw Error(`Aliyah Navigation requires an attached browser document`);return e}let g=m(),b={target:null,playing:!1,progressLabel:``},S=p(null),O=p(null),A=p(`hidden`),N=p(!1),P=p(!1),F=p(!1),ee=p(!1),I=p(0),L=p(v({})),R=p(v({})),te,ne,z,re=null,B=null,V=null,ie=0,H=null,U=!1,W=!1,G=!1,ae=0,oe=new xe,K=new xe;function se(e){return e?{...e,items:[...e.items],playback:{...e.playback}}:null}function ce(e,t=c(I)){return`${t}:${c(P)}:${$r(e)}`}function q(e,t=!1){return(t?[c(O)]:[c(S),c(O)]).some(t=>t?.items.some(t=>ce(t)===e))}function J(e,t=c(I)){for(let n of e.items){let e=ce(n,t);c(L)[e]!==void 0||oe.has(e)||(oe.add(e),r.loadCueStatus(n).then(t=>{oe.delete(e),!(G||r.signal.aborted||!q(e))&&(x(()=>{w(L,{...c(L),[e]:t},!0)}),r.onCueStatusChange(n,t))}).catch(t=>{oe.delete(e),!(G||r.signal.aborted||!q(e))&&r.onCueStatusError(t,n)}))}}function le(e,t=c(I)){for(let n of e.items){if(!n.audioKey)continue;let e=ce(n,t);c(R)[e]!==void 0||K.has(e)||(K.add(e),r.loadDurationLabel(n).then(t=>{K.delete(e),!(G||r.signal.aborted||!q(e,!0))&&x(()=>{w(R,{...c(R),[e]:t},!0)})}).catch(t=>{K.delete(e),!(G||r.signal.aborted||!q(e,!0))&&(r.onDurationError(t,n),x(()=>{w(R,{...c(R),[e]:`Available`},!0)}))}))}}function Y(){o().documentElement.style.setProperty(`--aliyah-rail-top`,`${r.toolbar.getBoundingClientRect().bottom}px`)}function ue(){let e=c(A)===`hidden`;o().documentElement.dataset.aliyahRailVisibility=c(A),e&&r.onWideHidden()}function de(){re!==null&&(g.clearTimeout(re),re=null)}function fe(e){x(()=>{w(A,e,!0)}),ue()}function pe(){de(),fe(`hidden`)}function me(e=pi){de(),re=g.setTimeout(()=>{re=null,!(U||W)&&pe()},e)}function he(e=`peek`,{autoHideMs:t=pi}={}){c(S)&&(Y(),fe(e),e===`expanded`?de():me(t))}function ge(e){x(()=>{w(S,se(e.desktop),!0),w(O,se(e.compact),!0),w(P,e.authoringEnabled,!0)}),c(S)?(Y(),ue(),J(c(S))):pe(),c(O)?(J(c(O)),le(c(O))):Te()}function _e(){ae+=1,Te(),x(()=>{w(S,null),w(O,null),w(P,!1),w(I,c(I)+1),w(L,{},!0),w(R,{},!0)}),oe.clear(),K.clear(),pe()}function ve(){x(()=>{w(I,c(I)+1),w(L,{},!0),w(R,{},!0)}),oe.clear(),K.clear(),c(S)&&J(c(S)),c(O)&&(J(c(O)),le(c(O)))}function ye(e){x(()=>{c(S)&&w(S,{...c(S),active:e},!0),c(O)&&w(O,{...c(O),active:e},!0)})}function X(e){x(()=>{c(O)&&w(O,{...c(O),playback:{...e}},!0)})}function be(e){x(()=>{w(N,e,!0)}),e||Te()}function Se(){return c(F)&&!c(ee)}function Ce(){ie&&=(g.cancelAnimationFrame(ie),0)}function we(){V!==null&&g.clearTimeout(V),V=null,x(()=>{w(ee,!1)})}function Te({focusTarget:e,restoreFocus:t=!0}={}){if(!c(F)||c(ee))return;Ce();let n=e??(t?H:null);H=null;let i=g.matchMedia(`(prefers-reduced-motion: reduce)`).matches;if(x(()=>{w(F,!1),w(ee,!i)}),r.onCompactOpenChange(!1),n&&r.restoreFocus(n),i){we();return}V=g.setTimeout(we,180)}function Ee(e){if(!c(N)||!c(O))return;X(r.onBeforeCompactOpen()),V!==null&&g.clearTimeout(V),V=null,Ce();let t=o().activeElement,n=t instanceof g.HTMLElement&&t!==o().body?t:null;H=e??n??r.getCompactToggle()??z,x(()=>{w(ee,!1),w(F,!0)}),r.onCompactOpenChange(!0),ie=g.requestAnimationFrame(()=>{ie=0,!(G||r.signal.aborted||!c(F))&&(ne.querySelector(`.mobile-aliyah-card.is-current .mobile-aliyah-card-main`)??z).focus()})}function De(e){return c(L)[ce(e)]??`none`}function Oe(e){let t=ce(e);return Object.prototype.hasOwnProperty.call(c(L),t)?c(L)[t]??null:null}function ke(e){if(e.audioState)return e.audioState.problem===`incomplete-cues`;let t=Oe(e);return!!(e.recordingKey&&t&&gi(t))}function Q(e){return cn({state:e.audioState,available:!!e.audioKey,cueIncomplete:ke(e),adminMissing:c(P)&&!e.recordingKey,playing:je(Me(),e.target)})}function Ae(e){if(e.audioState?.message&&!c(P)){if(!e.audioState.canPlay){if(e.audioState.problem===`missing-audio`)return`Audio unavailable`;if(e.audioState.problem===`timing-needed`)return`Timing cues needed`}return e.audioState.message}return c(P)&&!e.recordingKey?`Record audio + cues`:e.audioKey?c(R)[ce(e)]??`Loading…`:`Audio unavailable`}function $(e,t){return Zr(e.target,t)}function je(e,t){return e.playing&&$(e,t)}function Me(){return c(O)?.playback??b}function Ne(e,t){return je(t,e.target)?`Playing · ${t.progressLabel}`:$(t,e.target)?`Paused · ${t.progressLabel}`:Ae(e)}function Pe(e,t){if(c(P)&&!e.recordingKey)return`Select ${e.label} for audio and cue recording`;let n=Oe(e);return c(P)&&ke(e)&&n?_i({label:e.label,status:n,playing:je(t,e.target)}):`${je(t,e.target)?`Pause`:`Play`} ${e.label}${e.audioState?.message?` — ${e.audioState.message}`:``}`}function Fe(e,t){return je(t,e.target)?`${e.label} is playing. Go to aliyah.`:`Go to ${e.label}`}function Ie(e){r.onSelect(e),he(`expanded`),me()}function Le(e){ye(e),r.onSelect(e),r.onAfterNavigate()}function Re(e){Te(),ye(e),r.onSelect(e),r.onAfterNavigate()}async function ze(e){let t=c(O)?.items.find(t=>Zr(t.target,e));if(!t||Q(t).actionDisabled)return;ye(e),Te({focusTarget:r.getReaderFocusTarget()});let n=++ae,i=await r.onPlayCompact(e);G||r.signal.aborted||n!==ae||X(i)}function Be(){U=!0,he(`expanded`)}function Ve(){U=!1,me()}function He(){W=!0,he(`expanded`)}function Ue(){B!==null&&g.clearTimeout(B),B=g.setTimeout(()=>{B=null,W=o().activeElement?te.contains(o().activeElement):!1,W||me()},0)}function We(e){if(e.key===`Escape`){e.preventDefault(),Te();return}if(e.key!==`Tab`)return;let t=[...ne.querySelectorAll(`button:not(:disabled), input:not(:disabled), [tabindex]:not([tabindex="-1"])`)].filter(e=>e.offsetParent!==null),n=t[0],r=t[t.length-1];!n||!r||(e.shiftKey&&o().activeElement===n?(e.preventDefault(),r.focus()):!e.shiftKey&&o().activeElement===r&&(e.preventDefault(),n.focus()))}let Ge={syncContent:ge,clearContent:_e,invalidate:ve,setActive:ye,syncPlayback:X,setCompactAvailable:be,revealWide:he,revealWideForMovement:()=>he(`peek`),scheduleWideHide:me,openCompact:Ee,closeCompact:Te,isCompactOpen:Se};T(()=>(r.connect(Ge),g.addEventListener(`resize`,Y),g.visualViewport?.addEventListener(`resize`,Y),()=>{G=!0,ae+=1,de(),B!==null&&g.clearTimeout(B),V!==null&&g.clearTimeout(V),B=null,V=null,Ce(),H=null,U=!1,W=!1,oe.clear(),K.clear(),r.onCompactOpenChange(!1),r.onWideHidden(),o().documentElement.style.removeProperty(`--aliyah-rail-top`),delete o().documentElement.dataset.aliyahRailVisibility,g.removeEventListener(`resize`,Y),g.visualViewport?.removeEventListener(`resize`,Y)}));var Ke=ci(),qe=C(Ke);let Je;a(qe,21,()=>c(O)?.items.slice(0,7)??[],e=>e.key,(n,r)=>{var i=ri();let a;u((e,t,n,o)=>{a=j(i,1,`mobile-aliyah-segment`,null,a,e),_(i,`data-run-id`,c(r).target.runId),_(i,`data-aliyah-index`,c(r).target.aliyahIndex),_(i,`data-aliyah-label`,c(r).label),_(i,`title`,t),_(i,`aria-label`,n),_(i,`aria-current`,o)},[()=>({"is-current":Zr(c(O)?.active,c(r).target),"is-playing":je(Me(),c(r).target)}),()=>Fe(c(r),Me()),()=>Fe(c(r),Me()),()=>Zr(c(O)?.active,c(r).target)?`location`:void 0]),e(`click`,i,()=>Le(c(r).target)),t(n,i)}),s(qe);var Ye=E(qe,2);let Xe;var Ze=D(Ye),Qe=n=>{var r=ai(),o=E(C(r),2);a(o,17,()=>c(S).items,e=>e.key,(n,r)=>{var a=ii();let o;var l=D(a,!0);s(a),u((e,t,n,s)=>{o=j(a,1,`aliyah-rail-button`,null,o,e),_(a,`data-run-id`,c(r).target.runId),_(a,`data-aliyah-index`,c(r).target.aliyahIndex),_(a,`data-navigation-key`,c(r).key),_(a,`data-cue-status`,t),_(a,`title`,n),_(a,`aria-current`,s),i(l,c(r).compactLabel)},[()=>({"is-active":Zr(c(S).active,c(r).target)}),()=>De(c(r)),()=>`${c(r).label} · ${hi(De(c(r)))}`,()=>Zr(c(S).active,c(r).target)?`location`:void 0]),e(`click`,a,()=>Ie(c(r).target)),t(n,a)}),t(n,r)};y(Ze,e=>{c(S)&&e(Qe)}),s(Ye),f(Ye,e=>te=e,()=>te);var $e=E(Ye,2);let et;var tt=D($e),nt=E(tt,2),rt=D(nt),it=E(rt,2),at=E(D(it),2),ot=D(at);Z(ot,{name:`x`}),s(at),f(at,e=>z=e,()=>z),s(it);var st=E(it,2);a(st,21,()=>c(O)?.items??[],e=>e.key,(n,r)=>{var a=si();let o;var l=D(a),d=D(l),f=D(d,!0);s(d);var p=E(d,2),m=D(p,!0);s(p),s(l);var g=E(l,2),v=n=>{var i=oi();let a;var o=D(i);{let e=h(()=>je(Me(),c(r).target)?`pause`:`play`);Z(o,{get name(){return c(e)}})}s(i),u((e,t,n,o,s,l,u)=>{a=j(i,1,`mobile-aliyah-play`,null,a,e),_(i,`data-audio-problem`,c(r).audioState?.problem??``),_(i,`data-audio-tone`,t),_(i,`data-audio-dimmed`,n),_(i,`data-audio-tooltip`,o),_(i,`data-run-id`,c(r).target.runId),_(i,`data-aliyah-index`,c(r).target.aliyahIndex),_(i,`aria-disabled`,s),_(i,`aria-label`,l),_(i,`aria-pressed`,u)},[()=>({"is-missing-audio":c(P)&&!c(r).recordingKey,"is-cue-incomplete":ke(c(r))}),()=>Q(c(r)).tone,()=>Q(c(r)).dimmed,()=>Q(c(r)).tooltip,()=>Q(c(r)).actionDisabled,()=>Pe(c(r),Me()),()=>je(Me(),c(r).target)]),e(`click`,i,()=>ze(c(r).target)),t(n,i)};y(g,e=>{c(r).target&&e(v)}),s(a),u((e,t,n,s,u)=>{o=j(a,1,`mobile-aliyah-card`,null,o,e),_(a,`data-run-id`,c(r).target.runId),_(a,`data-aliyah-index`,c(r).target.aliyahIndex),_(l,`data-run-id`,c(r).target.runId),_(l,`data-aliyah-index`,c(r).target.aliyahIndex),_(l,`aria-label`,`Go to ${c(r).label}`),_(l,`aria-current`,t),i(f,c(r).label),_(p,`data-audio-key`,c(r).audioKey??``),_(p,`data-duration-label`,n),_(p,`title`,s),i(m,u)},[()=>({"is-current":Zr(c(O)?.active,c(r).target),"is-unavailable":!c(r).audioKey&&!c(P),"is-authoring-missing":c(P)&&!c(r).recordingKey,"is-playing":je(Me(),c(r).target)}),()=>Zr(c(O)?.active,c(r).target)?`location`:void 0,()=>Ae(c(r)),()=>Ne(c(r),Me()),()=>Ne(c(r),Me())]),e(`click`,l,()=>Re(c(r).target)),t(n,a)}),s(st),s(nt),s($e),f($e,e=>ne=e,()=>ne),u(()=>{Je=j(qe,1,`mobile-aliyah-segments`,null,Je,{"u-hidden":!c(O)}),Xe=j(Ye,1,`aliyah-rail`,null,Xe,{"u-hidden":!c(S),"is-peeking":c(A)===`peek`,"is-expanded":c(A)===`expanded`}),_(Ye,`data-visibility`,c(A)),_(Ye,`aria-hidden`,c(A)===`hidden`),Ye.inert=c(A)===`hidden`,et=j($e,1,`mobile-aliyah-picker`,null,et,{"u-hidden":!c(F)&&!c(ee),"is-closing":c(ee)}),_($e,`aria-hidden`,!c(F)),$e.inert=!c(F)}),l(`pointerenter`,Ye,Be),l(`pointerleave`,Ye,Ve),e(`focusin`,Ye,He),e(`focusout`,Ye,Ue),e(`keydown`,$e,We),e(`click`,tt,()=>Te()),e(`click`,rt,()=>Te()),e(`click`,at,()=>Te()),t(n,Ke),k()}N([`click`,`focusin`,`focusout`,`keydown`]);var ui=n(`<span class="mobile-aliyah-spinner"></span>`),di=n(`<div data-target-id="mobile-aliyah-capsule"><button data-target-id="mobile-aliyah-play-toggle" type="button"><span class="mobile-aliyah-play-icon" aria-hidden="true"><!></span> <span data-target-id="mobile-current-aliyah"> </span></button> <button class="mobile-aliyah-picker-toggle" data-target-id="mobile-aliyah-picker-toggle" type="button" title="Choose aliyah" aria-label="Choose aliyah" aria-haspopup="dialog" aria-controls="mobile-aliyah-picker"><span class="mobile-aliyah-picker-chevron" data-target-id="mobile-aliyah-picker-chevron" aria-hidden="true"><!></span></button></div> <span data-target-id="toolbar-current-aliyah-label"> </span> <button data-target-id="toolbar-current-aliyah-audio" type="button"><!></button>`,1);function fi(n,r){M(r,!0);let a=p(v({current:{labelVisible:!1,label:`—`,target:null,audioAvailable:!1,authoringAvailable:!1,authoringEnabled:!1,cueStatus:null,playing:!1},compact:{visible:!1,target:null,label:`ראשון`,playbackState:`default`,audioAvailable:!1}})),o=p(!1),l,d=p(`idle`),m=h(()=>c(a).compact.audioAvailable??!1),g=h(()=>cn({state:c(a).current.audioState,available:c(a).current.audioAvailable,cueIncomplete:P(),adminMissing:c(a).current.authoringAvailable,playing:c(a).current.playing})),b=h(()=>cn({state:c(a).compact.audioState,available:c(m),adminMissing:c(a).compact.authoringMissing,cueIncomplete:c(a).compact.cueIncomplete,playing:c(a).compact.playbackState===`playing`}));function S(e){let t=!Zr(c(a).compact.target,e.compact.target);x(()=>{w(a,{current:{...e.current},compact:{...e.compact}},!0),(t||e.compact.playbackState!=="default")&&w(d,`idle`)})}function O(e){x(()=>{w(o,e,!0)})}function A(e,t){Zr(c(a).current.target,e)&&x(()=>{w(a,{...c(a),current:{...c(a).current,cueStatus:t}},!0)})}function N(){x(()=>{w(a,{...c(a),current:{...c(a).current,cueStatus:null}},!0)})}function P(){let e=c(a).current.cueStatus;return c(a).current.audioState?c(a).current.audioState.problem===`incomplete-cues`:!!(c(a).current.audioAvailable&&e&&gi(e))}function F(){let e=c(a).current.cueStatus;return c(a).current.authoringEnabled&&P()&&e?_i({label:c(a).current.label,status:e,playing:c(a).current.playing}):`${c(a).current.playing?`Pause`:`Play`} ${c(a).current.label}${c(a).current.audioState?.message?` — ${c(a).current.audioState.message}`:``}`}function ee(){r.onToggleCompact(l)}async function I(){c(g).actionDisabled||!c(a).current.target||!c(a).current.audioAvailable&&!c(a).current.authoringAvailable||await r.onPlayCurrent(c(a).current.target)}async function L(){let e=c(a).compact.target;if(!(!e||c(b).actionDisabled||c(d)===`loading`)){w(d,c(a).compact.playbackState==="default"?`loading`:`idle`,!0);try{await r.onPlayCurrent(e),w(d,`idle`)}catch(e){console.error(`Failed to play the current aliyah`,e),w(d,`error`)}}}function R(){return c(m)?c(d)===`loading`?`Loading ${c(a).compact.label}`:c(d)===`error`?`Retry ${c(a).compact.label}`:`${c(a).compact.playbackState===`playing`?`Pause`:`Play`} ${c(a).compact.label}${c(a).compact.audioState?.message?` — ${c(a).compact.audioState.message}`:``}`:`Recording unavailable for ${c(a).compact.label}`}let te={sync:S,setCueStatus:A,invalidateCueStatus:N,setCompactOpen:O,getCompactToggle:()=>l};T(()=>{r.connect(te)});var ne=di(),z=C(ne);let re;var B=D(z);let V;var ie=D(B),H=D(ie),U=e=>{var n=ui();t(e,n)},W=e=>{Z(e,{name:`replay`})},G=e=>{{let t=h(()=>c(a).compact.playbackState===`playing`?`pause`:`play`);Z(e,{get name(){return c(t)}})}};y(H,e=>{c(d)===`loading`?e(U):c(d)===`error`?e(W,1):e(G,-1)}),s(ie);var ae=E(ie,2),oe=D(ae,!0);s(ae),s(B);var K=E(B,2),se=D(K),ce=D(se);{let e=h(()=>c(o)?`chevronUp`:`chevronDown`);Z(ce,{get name(){return c(e)}})}s(se),s(K),f(K,e=>l=e,()=>l),s(z);var q=E(z,2);let J;var le=D(q,!0);s(q);var Y=E(q,2);let ue;var de=D(Y);{let e=h(()=>c(a).current.playing?`pause`:`play`);Z(de,{get name(){return c(e)}})}s(Y),u((e,t,n)=>{re=j(z,1,`mobile-aliyah-capsule`,null,re,{"u-hidden":!c(a).compact.visible,"is-loaded":c(a).compact.playbackState===`loaded`,"is-playing":c(a).compact.playbackState===`playing`,"is-loading":c(d)===`loading`,"is-unavailable":!c(m)}),_(z,`data-audio-tone`,c(b).tone),_(z,`data-audio-dimmed`,c(b).dimmed),_(z,`data-run-id`,c(a).compact.target?.runId??``),_(z,`data-aliyah-index`,c(a).compact.target?`${c(a).compact.target.aliyahIndex}`:``),_(z,`data-playback-state`,c(a).compact.playbackState),V=j(B,1,`mobile-aliyah-play-toggle`,null,V,{"is-cue-incomplete":c(a).compact.audioState?.problem===`incomplete-cues`}),_(B,`data-audio-problem`,c(a).compact.audioState?.problem??``),_(B,`data-audio-tone`,c(b).tone),_(B,`data-audio-dimmed`,c(b).dimmed),_(B,`data-audio-tooltip`,c(d)===`loading`?`Preparing audio for this aliyah.`:c(b).tooltip),_(B,`aria-label`,e),_(B,`aria-disabled`,c(b).actionDisabled||c(d)===`loading`),i(oe,c(a).compact.label),_(K,`aria-expanded`,c(o)),J=j(q,1,`toolbar-current-aliyah-label`,null,J,{"u-hidden":!c(a).current.labelVisible}),i(le,c(a).current.label),ue=j(Y,1,`aliyah-audio-button toolbar-current-aliyah-audio`,null,ue,t),_(Y,`data-audio-problem`,c(a).current.audioState?.problem??``),_(Y,`data-audio-tone`,c(g).tone),_(Y,`data-audio-dimmed`,c(g).dimmed),_(Y,`data-audio-tooltip`,c(g).tooltip),_(Y,`data-run-id`,c(a).current.target?.runId??``),_(Y,`data-aliyah-index`,c(a).current.target?`${c(a).current.target.aliyahIndex}`:``),_(Y,`aria-disabled`,c(g).actionDisabled),_(Y,`aria-label`,n)},[()=>R(),()=>({"u-hidden":!c(a).current.target||!c(a).current.labelVisible,"is-active":c(a).current.playing,"is-missing-audio":c(a).current.authoringAvailable,"is-cue-incomplete":P()}),()=>c(a).current.authoringAvailable?`Select ${c(a).current.label} for audio and cue recording`:c(a).current.audioAvailable?F():`Recording unavailable`]),e(`click`,B,()=>void L()),e(`click`,K,ee),e(`click`,Y,I),t(n,ne),k()}N([`click`]);var pi=4e3;function mi({loaded:e,playing:t}){return e&&t?`playing`:e?`loaded`:`default`}function hi(e){return{none:`no cues`,pending:`partial published cues`,published:`complete published cues`,"local-draft":`local draft`,"generated-review":`generated draft needs review`}[e]}function gi(e){return e!==`published`}function _i({label:e,status:t,playing:n=!1}){return n?`Pause ${e}`:t===`none`?`Start ${e} cue recording`:`Resume ${e} cue recording`}function vi(e,t){let n=e.querySelector(`[data-target-id="${t}"]`);if(!n)throw Error(`Aliyah Navigation requires ${t}`);if(n.childNodes.length)throw Error(`Aliyah Navigation requires an empty ${t}`);return n}function yi(e,t){let n=e.querySelector(t);if(!n)throw Error(`Aliyah Navigation requires ${t}`);return n}function bi(e,t){let n=vi(t.document,`aliyah-toolbar-root`),i=vi(t.document,`aliyah-navigation-layer-root`),a=yi(t.document,`.app-toolbar`),s=null,c=null,l=r(li,{target:i,props:{document:t.document,signal:e.signal,toolbar:a,onSelect:t.onSelect,onPlayCompact:t.onPlayCompact,onBeforeCompactOpen:t.onBeforeCompactOpen,onAfterNavigate:t.onAfterNavigate,onWideHidden:t.onWideHidden,restoreFocus:t.restoreFocus,getReaderFocusTarget:t.getReaderFocusTarget,loadCueStatus:t.loadCueStatus,onCueStatusChange:(e,n)=>{s?.setCueStatus(e.target,n),t.onCueStatusChange(e,n)},loadDurationLabel:t.loadDurationLabel,onCueStatusError:t.onCueStatusError,onDurationError:t.onDurationError,getCompactToggle:()=>s?.getCompactToggle()??null,onCompactOpenChange:e=>{s?.setCompactOpen(e)},connect:e=>{c=e}}});x();let u=c;if(!u)throw o(l),Error(`Aliyah Navigation layer did not connect`);let d=r(fi,{target:n,props:{onToggleCompact:e=>{c?.isCompactOpen()?c.closeCompact():c?.openCompact(e)},onPlayCurrent:t.onPlayCurrent,connect:e=>{s=e}}});x();let f=s;if(!f)throw o(d),o(l),Error(`Aliyah Navigation toolbar did not connect`);return e.own(()=>{let e=o(d),t=o(l);Promise.all([e,t]).catch(e=>{console.error(`Failed to unmount Aliyah Navigation`,e)})}),{syncContent:e=>u.syncContent(e),clearContent:()=>u.clearContent(),invalidate:()=>{f.invalidateCueStatus(),u.invalidate()},setActive:e=>u.setActive(e),syncPlayback:e=>u.syncPlayback(e),syncToolbar:e=>{f.sync(e),u.setCompactAvailable(e.compact.visible)},revealWide:(e,t)=>u.revealWide(e,t),revealWideForMovement:()=>u.revealWideForMovement(),scheduleWideHide:e=>u.scheduleWideHide(e),openCompact:e=>u.openCompact(e),closeCompact:e=>u.closeCompact(e),isCompactOpen:()=>u.isCompactOpen()}}var xi=e=>e?.dataset.annotationsOnText??e?.textContent??``;function Si({currentLineWords:e,previousLineWords:t,verseOrdinal:n}){return an({currentLineWords:e.map(Ci),previousLineWords:t.map(Ci),verseOrdinal:n})}var Ci=e=>({tokenKey:e.dataset.tokenKey??``,annotatedText:xi(e)}),wi=e=>{let t=[...e.querySelectorAll(`[data-reader-canonical="true"] .fragment .word`)];return(t.length?t:[...e.querySelectorAll(`.fragment .word`)]).filter(e=>e.dataset.annotationsOnPresent!==`false`&&!!e.dataset.tokenKey)};function Ti({book:e,startLine:t,startVerseOrdinal:n}){let r=[...e.querySelectorAll(`[data-class="line"]`)],i=r.indexOf(t);if(i<0||n<0)return null;let a=r.map(wi);return{lines:r,startLineIndex:i,startWordIndex:Si({currentLineWords:a[i],previousLineWords:a[i-1]??[],verseOrdinal:n}),wordsByLine:a}}function Ei({book:e,startLine:t,startVerseOrdinal:n}){let r=Ti({book:e,startLine:t,startVerseOrdinal:n});return r?.wordsByLine[r.startLineIndex][r.startWordIndex]?.dataset.tokenKey??null}function Di(e){let t=[...e.childNodes].find(e=>e.nodeType===Node.TEXT_NODE&&!!e.textContent),n=t?.data.match(/^.\p{Mark}*/u)?.[0];if(!t||!n)return null;let r=e.ownerDocument.createRange();r.setStart(t,0),r.setEnd(t,n.length);let i=r.getBoundingClientRect();return r.detach(),i.width>0&&i.height>0?i:null}function Oi(e,t){return{x:t.left-e.left+t.width/2,y:t.top-e.top}}function ki({label:e,tokenKey:t}){let n=document.createElement(`button`);n.type=`button`,n.className=`aliyah-start-marker`,n.dataset.aliyahStartMarker=`true`,n.dataset.tokenKey=t,n.setAttribute(`aria-label`,`Aliyah ${e} begins here`),n.setAttribute(`aria-haspopup`,`dialog`),n.setAttribute(`aria-expanded`,`false`),n.setAttribute(`aria-controls`,`aliyah-start-popup`);let r=document.createElement(`span`);r.className=`aliyah-start-marker-rule`,r.setAttribute(`aria-hidden`,`true`);let i=document.createElement(`span`);i.className=`aliyah-start-marker-capsule`,i.textContent=e,i.setAttribute(`aria-hidden`,`true`);let a=document.createElement(`span`);return a.className=`aliyah-start-chevron`,a.innerHTML=De(`chevronDown`),a.setAttribute(`aria-hidden`,`true`),n.append(r,i,a),n}function Ai(e,t){let n=e?.aliyot.filter(e=>e.index)??[];return n[n.length-1]?.index===t}function ji(e,t){return e?.aliyot.find(e=>e.index===t)??null}function Mi(e,t,n){let r=ji(e,t);return r?n(r.start):null}async function Ni(e,t,n){let r=await e.resolver;return Mi(t,n,e=>r.physicalLocationFromRef(e))}var Pi=class{constructor(){this.locations=new Map}get size(){return this.locations.size}clear(){this.locations.clear()}async get(e,t,n){let r=t?`${t.id}:${n}`:`missing:${n}`;if(this.locations.has(r))return this.locations.get(r)??null;let i=await Ni(e,t,n);return this.locations.set(r,i),i}};function Fi(e){return Math.max(0,e.lineNumber-1)}function Ii(e){return[...e.querySelectorAll(`[data-class="line"][data-page-number][data-line-index]`)]}function Li(e,t){return e.querySelector(`[data-class="line"][data-line-index="${t}"]`)}function Ri(e,t){return{runId:e.id,index:t}}function zi(e,t){return!!(e&&t&&e.runId===t.runId&&e.index===t.index)}function Bi(e){if(e===`Maftir`)return`Maftir`;let t=Number(e);return Number.isInteger(t)&&t>=1&&t<=7?t:null}function Vi(e,t){return e.flatMap(e=>e.aliyot.flatMap(n=>n.index&&Q(n,t)?[Ri(e,n.index)]:[]))}function Hi({runs:e,lineRun:t,focalRef:n,aliyot:r,aliyahStarts:i}){let a=e=>t?e.flatMap(e=>e.index?[Ri(t,e.index)]:[]):[],o=a(i);return o.length?o:n?Vi(e,n):a(r)}function Ui({memberships:e,playback:t,pending:n,explicit:r}){return t||n||(e.length?e.find(e=>zi(e,r))||e[e.length-1]:null)}var Wi=[];function Gi(e,t=Wi){return t.find(t=>t.audioId===e)??null}var Ki=n(`<div data-target-id="floating-player" id="floating-player"><div class="floating-player-sheet-handle" aria-hidden="true"></div> <header class="floating-player-header"><button class="floating-player-drag-handle" data-target-id="floating-drag-handle" type="button" title="Drag to move the audio player" aria-label="Move audio player"><!></button> <div class="floating-player-heading"><strong class="floating-player-title mod-desktop" data-target-id="floating-player-title-desktop"> </strong> <strong class="floating-player-title mod-mobile" data-target-id="floating-player-title-mobile"> </strong> <span class="floating-player-subtitle mod-desktop" data-target-id="floating-player-subtitle"> </span> <span class="floating-player-subtitle mod-mobile" data-target-id="floating-player-parsha"> </span></div> <span class="floating-player-mode-group"><span class="floating-player-mode" data-target-id="floating-player-mode"> </span> <span data-target-id="floating-player-cue-progress"> </span></span> <button class="floating-player-button mod-expand" data-target-id="floating-expand-toggle" type="button"><!></button> <button class="floating-player-mobile-close" data-target-id="floating-mobile-close" type="button" aria-label="Close expanded player"><!></button></header> <div class="floating-player-controls"><button class="floating-player-button" data-target-id="floating-replay" type="button" title="Restart recording" aria-label="Restart recording"><span class="floating-player-tool-icon" data-target-id="floating-replay-icon"><!></span></button> <button class="floating-player-button" data-target-id="floating-prev" type="button"><!></button> <button class="floating-player-button" data-target-id="floating-play" type="button"><!></button> <button class="floating-player-minimized-summary" data-target-id="floating-minimized-summary" type="button"><strong> </strong> <span> </span></button> <button class="floating-player-button" data-target-id="floating-next" type="button"><!></button> <div class="floating-speed-control"><button class="floating-player-button mod-speed" data-target-id="floating-speed-toggle" type="button"><span class="floating-player-tool-icon" data-target-id="floating-speed-icon"><!></span> <span class="floating-player-tool-label" data-target-id="floating-speed-label"> </span> <span class="floating-player-tool-label mod-compact" data-target-id="floating-speed-compact-label" aria-hidden="true"> </span></button> <div data-target-id="floating-speed-popover"><input class="floating-speed-slider" data-target-id="floating-speed-slider" type="range" min="0.5" max="3" step="0.05" list="floating-speed-marks" aria-label="Playback speed"/> <datalist id="floating-speed-marks"><option label="0.5x"></option><option label="1x"></option><option label="1.5x"></option><option label="2x"></option><option label="3x"></option></datalist> <div class="floating-speed-ticks" aria-hidden="true"><span style="--speed-tick-position: 0%">0.5x</span> <span style="--speed-tick-position: 20%">1x</span> <span style="--speed-tick-position: 40%">1.5x</span> <span style="--speed-tick-position: 60%">2x</span> <span style="--speed-tick-position: 100%">3x</span></div></div></div></div> <div class="mobile-player-timeline"><span data-target-id="mobile-player-word-progress"> </span> <span class="mobile-player-time" data-target-id="mobile-player-current-time"> </span> <input class="mobile-player-seek" data-target-id="mobile-player-seek" type="range" min="0" max="1000" step="1" aria-label="Audio position"/> <span class="mobile-player-time" data-target-id="mobile-player-duration"> </span></div> <button class="floating-player-mobile-expand" data-target-id="floating-mobile-expand" type="button" aria-label="Expand audio player" aria-controls="floating-player"><!></button> <h3 class="floating-player-tools-heading">Playback controls</h3> <div class="floating-player-tools"><a data-target-id="floating-download" title="Save audio" aria-label="Save audio"><span class="floating-player-tool-icon" data-target-id="floating-download-icon"><!></span> <span class="floating-player-tool-label">Save</span></a> <a data-target-id="floating-video-download" title="Save aliyah video" aria-label="Save aliyah video"><span class="floating-player-tool-icon" data-target-id="floating-video-download-icon"><!></span> <span class="floating-player-tool-label">Video</span></a></div> <div class="floating-player-details" data-target-id="floating-player-details"><div class="floating-player-meta" data-target-id="floating-player-meta"><span data-target-id="floating-meta-status-wrap"><span class="floating-player-meta-label">Playback</span> <span class="floating-player-meta-value" data-target-id="floating-meta-status"> </span></span></div> <div class="floating-player-progress-list"><div class="floating-player-progress-item mod-word-progress"><div class="floating-player-progress-head"><span class="floating-player-progress-label">Word progress</span> <span class="floating-player-progress-value" data-target-id="floating-meta-cues"> </span></div></div></div></div> <span class="floating-player-minimized-progress" data-target-id="floating-minimized-progress" aria-hidden="true"></span></div> <button class="floating-player-backdrop" data-target-id="floating-player-backdrop" type="button" aria-label="Close expanded player" tabindex="-1"></button>`,1);function qi(n,r){M(r,!0);let a=p(v({visible:!1,untimed:!0,playing:!1,expanded:!1,compact:!1,desktopTitle:`—`,mobileTitle:`—`,subtitle:`Audio`,mobileReading:`—`,mode:`No cues`,status:``,playbackRate:1,audioDownload:null,videoDownload:null})),o=p(v({audioRatio:0,cueRatio:0,seekValue:0,seekDisabled:!0,seekValueText:`0:00 of --:--`,currentTime:`0:00`,duration:`--:--`,wordProgress:`0 / 0`,cueProgress:`Cue 0 / 0`,cueProgressVisible:!1,mobileWordProgress:`Word 0 of 0`,mobileWordProgressVisible:!1})),d=p(null),g=p(!1),y=p(!1),b=p(!1),N=null,P=null,F=null,ee=null,I=null,L=null,R=null,te=null,ne=null,z=null,re=null,B=null,V=h(()=>Fe(c(a).playbackRate)),ie=h(()=>c(a).playing?`Pause`:`Play`),H=h(()=>c(a).untimed?`Back 10 seconds`:`Previous Word`),U=h(()=>c(a).untimed?`Forward 10 seconds`:`Next Word`),W=h(()=>c(a).expanded?`Collapse player`:`Expand player`);function G(e,t){if(!e)throw Error(`Floating Player is missing ${t}`);return e}function ae(e){let t=e.getBoundingClientRect();return{left:t.left,top:t.top,width:t.width,height:t.height}}function oe(){B!==null&&(r.view.clearTimeout(B),B=null)}function K(e){c(b)!==e&&(x(()=>{w(b,e,!0)}),r.document.documentElement.toggleAttribute(`data-mobile-player-minimized`,e))}function se(){let e=r.document.activeElement;return!!(e instanceof HTMLElement&&N?.contains(e)&&e.matches(`:focus-visible`))}function ce(){return!!(c(a).visible&&c(a).compact&&!c(a).expanded&&!c(y)&&z===null&&re===null&&!se())}function q(){c(b)||B!==null||!ce()||(B=r.view.setTimeout(()=>{B=null,ce()&&K(!0)},4e3))}function J(){oe(),K(!1)}function le(){J(),q()}function Y(e){J(),e?G(I,`its play button`).focus({preventScroll:!0}):ee?.blur(),q()}function ue(){oe()}function de(e){let t=e.relatedTarget;t instanceof Node&&N?.contains(t)||q()}function fe(e){x(()=>{w(a,{...c(a),...e},!0)}),r.document.documentElement.toggleAttribute(`data-mobile-player-expanded`,c(a).expanded&&c(a).compact),!c(a).visible||!c(a).compact||c(a).expanded?(oe(),K(!1)):q()}function pe(e){x(()=>{w(o,{...c(o),...e},!0)})}function me(e){x(()=>{w(d,e,!0)})}function he(e){x(()=>{w(g,e,!0)})}function ge(){c(y)&&(x(()=>{w(y,!1)}),q())}function _e(){G(P,`its mobile close button`).focus({preventScroll:!0})}function ve(){return ae(G(N,`its player element`))}let ye={sync:fe,syncProgress:pe,setPosition:me,setDragging:he,closeSpeedPopover:ge,focusMobileClose:_e,measure:ve};function X(e){e.type!==`layout`&&!(c(b)&&e.type===`toggle-playback`)&&le(),r.action(e)}function be(e,t,n=null){X({type:`set-expanded`,expanded:e,source:t,returnFocus:n})}function xe(){J(),x(()=>{w(y,!c(y))}),c(y)?(oe(),G(te,`its speed slider`).focus({preventScroll:!0})):q()}function Se(e){let t=G(L,`its seek control`).getBoundingClientRect();return t.width<=0?null:Math.max(0,Math.min(1,(e-t.left)/t.width))}function Ce(e){c(o).seekValue=Math.round(e*1e3)}function we(e){let t=Number.parseFloat(e.currentTarget.value)/1e3;Ce(t),z===null&&X({type:`seek-commit`,ratio:t})}function Te(e){if(e.button!==0||c(o).seekDisabled||z!==null)return;let t=Se(e.clientX);if(t===null)return;e.preventDefault(),z=e.pointerId;let n=G(L,`its seek control`);n.focus({preventScroll:!0}),n.setPointerCapture(e.pointerId),Ce(t),X({type:`seek-preview`,phase:`start`,pointerId:e.pointerId,ratio:t})}function Ee(e){if(e.pointerId!==z)return;let t=Se(e.clientX);t!==null&&(Ce(t),X({type:`seek-preview`,phase:`move`,pointerId:e.pointerId,ratio:t}))}function De(e,t){if(e.pointerId!==z)return;let n=G(L,`its seek control`),r=(t?Se(e.clientX):null)??c(o).seekValue/1e3;Ce(r),X({type:`seek-finish`,pointerId:e.pointerId,ratio:r}),z=null,n.hasPointerCapture(e.pointerId)&&n.releasePointerCapture(e.pointerId)}function Oe(){if(z===null)return;let e=z;z=null,X({type:`seek-finish`,pointerId:e,ratio:c(o).seekValue/1e3})}function ke(e){let t=G(te,`its speed slider`).getBoundingClientRect();return .5+Math.max(0,Math.min(1,(e-t.left)/Math.max(t.width,1)))*2.5}function Q(e){re===null&&X({type:`set-rate`,rate:Number.parseFloat(e.currentTarget.value),snap:!0})}function Ae(e){e.preventDefault(),re=e.pointerId,G(te,`its speed slider`).setPointerCapture(e.pointerId),X({type:`set-rate`,rate:ke(e.clientX),snap:!0})}function $(e){e.pointerId===re&&X({type:`set-rate`,rate:ke(e.clientX),snap:!0})}function je(e,t){if(e.pointerId!==re)return;let n=G(te,`its speed slider`);t&&X({type:`set-rate`,rate:ke(e.clientX),snap:!0}),re=null,n.hasPointerCapture(e.pointerId)&&n.releasePointerCapture(e.pointerId)}function Me(e){c(a).compact||e.button!==0||(e.preventDefault(),ne=e.pointerId,X({type:`drag-start`,pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY,playerRect:ve()}))}function Ne(e){if(c(a).compact)return;if(e.key===`Home`){e.preventDefault(),X({type:`drag-reset`});return}let t={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];t&&(e.preventDefault(),X({type:`drag-key`,direction:t,shiftKey:e.shiftKey,playerRect:ve()}))}function Pe(e){if(!c(a).compact||!c(a).expanded)return;if(e.key===`Escape`){e.preventDefault(),be(!1,`close`);return}if(e.key!==`Tab`)return;let t=[...G(N,`its player element`).querySelectorAll(`button:not(:disabled), input:not(:disabled), a[href]:not([aria-disabled="true"]), [tabindex]:not([tabindex="-1"])`)].filter(e=>e.offsetParent!==null&&!e.closest(`.u-hidden`)),n=t[0],i=t[t.length-1];!n||!i||(e.shiftKey&&r.document.activeElement===n?(e.preventDefault(),i.focus()):!e.shiftKey&&r.document.activeElement===i&&(e.preventDefault(),n.focus()))}function Fe(e){return`${(Math.round(e*100)/100).toFixed(2).replace(/\.?0+$/,``)}x`}T(()=>{r.connect(ye);let e=e=>{e.pointerId===ne&&X({type:`drag-move`,pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY})},t=e=>{e.pointerId===ne&&(ne=null,X({type:`drag-finish`,pointerId:e.pointerId}))},n=()=>{ne!==null&&(ne=null,X({type:`drag-cancel`}))},i=e=>{if(!c(y))return;let t=e.target;t instanceof Node&&R?.contains(t)||ge()},a=()=>X({type:`layout`});r.view.addEventListener(`pointermove`,e),r.view.addEventListener(`pointerup`,t),r.view.addEventListener(`pointercancel`,t),r.view.addEventListener(`blur`,n),r.view.addEventListener(`resize`,a),r.document.addEventListener(`pointerdown`,i);let o=new ResizeObserver(a);return o.observe(G(N,`its player element`)),()=>{oe(),o.disconnect(),r.document.removeEventListener(`pointerdown`,i),r.view.removeEventListener(`resize`,a),r.view.removeEventListener(`blur`,n),r.view.removeEventListener(`pointercancel`,t),r.view.removeEventListener(`pointerup`,t),r.view.removeEventListener(`pointermove`,e),r.document.documentElement.removeAttribute(`data-mobile-player-expanded`),r.document.documentElement.removeAttribute(`data-mobile-player-minimized`)}});var Ie=Ki(),Le=C(Ie);let Re,ze;var Be=E(D(Le),2),Ve=D(Be),He=D(Ve);Z(He,{name:`grip`}),s(Ve);var Ue=E(Ve,2),We=D(Ue),Ge=D(We,!0);s(We);var Ke=E(We,2),qe=D(Ke,!0);s(Ke);var Je=E(Ke,2),Ye=D(Je,!0);s(Je);var Xe=E(Je,2),Ze=D(Xe,!0);s(Xe),s(Ue);var Qe=E(Ue,2),$e=D(Qe),et=D($e,!0);s($e);var tt=E($e,2);let nt;var rt=D(tt,!0);s(tt),s(Qe);var it=E(Qe,2),at=D(it);{let e=h(()=>c(a).expanded?`minimize2`:`expand`);Z(at,{get name(){return c(e)}})}s(it);var ot=E(it,2),st=D(ot);Z(st,{name:`x`}),s(ot),f(ot,e=>P=e,()=>P),s(Be);var ct=E(Be,2),lt=D(ct),ut=D(lt),dt=D(ut);Z(dt,{name:`replay`}),s(ut),s(lt);var ft=E(lt,2),pt=D(ft);{let e=h(()=>c(a).untimed?`rewind10`:`arrowRight`);Z(pt,{get name(){return c(e)}})}s(ft);var mt=E(ft,2),ht=D(mt);{let e=h(()=>c(a).playing?`pause`:`play`);Z(ht,{get name(){return c(e)}})}s(mt),f(mt,e=>I=e,()=>I);var gt=E(mt,2),_t=D(gt),vt=D(_t,!0);s(_t);var yt=E(_t,2),bt=D(yt,!0);s(yt),s(gt),f(gt,e=>ee=e,()=>ee);var xt=E(gt,2),St=D(xt);{let e=h(()=>c(a).untimed?`forward10`:`arrowLeft`);Z(St,{get name(){return c(e)}})}s(xt);var Ct=E(xt,2),wt=D(Ct),Tt=D(wt),Et=D(Tt);Z(Et,{name:`gauge`}),s(Tt);var Dt=E(Tt,2),Ot=D(Dt);s(Dt);var kt=E(Dt,2),At=D(kt,!0);s(kt),s(wt);var jt=E(wt,2);let Mt;var Nt=D(jt);m(Nt),f(Nt,e=>te=e,()=>te);var Pt=E(Nt,2),Ft=D(Pt);Ft.value=Ft.__value=`0.5`;var It=E(Ft);It.value=It.__value=`1`;var Lt=E(It);Lt.value=Lt.__value=`1.5`;var Rt=E(Lt);Rt.value=Rt.__value=`2`;var zt=E(Rt);zt.value=zt.__value=`3`,s(Pt),A(2),s(jt),s(Ct),f(Ct,e=>R=e,()=>R),s(ct);var Bt=E(ct,2),Vt=D(Bt);let Ht;var Ut=D(Vt,!0);s(Vt);var Wt=E(Vt,2),Gt=D(Wt,!0);s(Wt);var Kt=E(Wt,2);m(Kt),f(Kt,e=>L=e,()=>L);var qt=E(Kt,2),Jt=D(qt,!0);s(qt),s(Bt);var Yt=E(Bt,2),Xt=D(Yt);Z(Xt,{name:`chevronUp`}),s(Yt),f(Yt,e=>F=e,()=>F);var Zt=E(Yt,4),Qt=D(Zt);let $t;var en=D(Qt),tn=D(en);Z(tn,{name:`download`}),s(en),A(2),s(Qt);var nn=E(Qt,2);let rn;var an=D(nn),on=D(an);Z(on,{name:`download`}),s(an),A(2),s(nn),s(Zt);var sn=E(Zt,2),cn=D(sn),ln=D(cn);let un;var dn=E(D(ln),2),fn=D(dn,!0);s(dn),s(ln),s(cn);var pn=E(cn,2),mn=D(pn),hn=D(mn),gn=E(D(hn),2),_n=D(gn,!0);s(gn),s(hn),s(mn),s(pn),s(sn),A(2),s(Le),f(Le,e=>N=e,()=>N);var vn=E(Le,2);u(()=>{Re=j(Le,1,`floating-player`,null,Re,{"u-hidden":!c(a).visible,"mod-untimed":c(a).untimed,"is-playing":c(a).playing,"is-expanded":c(a).expanded,"is-minimized":c(b),"mod-expandable":c(a).visible,"is-dragging":c(g)}),_(Le,`data-cue-mode`,c(a).untimed?`untimed`:`timed`),_(Le,`role`,c(a).expanded&&c(a).compact?`dialog`:`region`),_(Le,`aria-modal`,c(a).expanded&&c(a).compact?`true`:void 0),_(Le,`aria-label`,c(a).expanded&&c(a).compact?`Expanded audio player`:c(b)?`Compact audio player`:`Audio player`),ze=O(Le,``,ze,{"--audio-progress-ratio":`${c(o).audioRatio}`,"--cue-progress-ratio":`${c(o).cueRatio}`,left:c(d)?`${c(d).left}px`:void 0,top:c(d)?`${c(d).top}px`:void 0}),i(Ge,c(a).desktopTitle),i(qe,c(a).mobileTitle),i(Ye,c(a).subtitle),i(Ze,c(a).mobileReading),i(et,c(a).mode),nt=j(tt,1,`floating-player-cue-progress`,null,nt,{"u-hidden":!c(o).cueProgressVisible}),i(rt,c(o).cueProgress),_(it,`title`,c(W)),_(it,`aria-label`,c(W)),_(it,`aria-expanded`,c(a).expanded),it.disabled=!c(a).visible,lt.disabled=!c(a).visible,_(ft,`title`,c(H)),_(ft,`aria-label`,c(H)),ft.disabled=!c(a).visible,_(mt,`data-audio-tooltip`,c(a).status||`${c(ie)} this aliyah`),_(mt,`aria-label`,c(ie)),mt.disabled=!c(a).visible,_(gt,`aria-label`,`Show audio controls for ${c(a).mobileTitle}`),_(gt,`aria-hidden`,!c(b)),_(gt,`tabindex`,c(b)?0:-1),i(vt,c(a).mobileTitle),i(bt,c(a).mobileReading),_(xt,`title`,c(U)),_(xt,`aria-label`,c(U)),xt.disabled=!c(a).visible,_(wt,`title`,`Playback speed, ${c(V)}`),_(wt,`aria-label`,`Playback speed, ${c(V)}`),_(wt,`aria-expanded`,c(y)),i(Ot,`${c(V)??``} speed`),i(At,c(V)),Mt=j(jt,1,`floating-speed-popover`,null,Mt,{"u-hidden":!c(y)}),S(Nt,c(a).playbackRate),Ht=j(Vt,1,`mobile-player-word-progress`,null,Ht,{"u-hidden":!c(o).mobileWordProgressVisible}),i(Ut,c(o).mobileWordProgress),i(Gt,c(o).currentTime),S(Kt,c(o).seekValue),Kt.disabled=c(o).seekDisabled,_(Kt,`aria-valuetext`,c(o).seekValueText),i(Jt,c(o).duration),_(Yt,`aria-expanded`,c(a).expanded),Yt.disabled=!c(a).visible,$t=j(Qt,1,`floating-player-button mod-tool mod-save`,null,$t,{"u-hidden":!c(a).audioDownload}),_(Qt,`href`,c(a).audioDownload?.href??`#`),_(Qt,`download`,c(a).audioDownload?.fileName),_(Qt,`aria-disabled`,c(a).audioDownload?`false`:`true`),_(Qt,`tabindex`,c(a).audioDownload?0:-1),rn=j(nn,1,`floating-player-button mod-tool mod-video`,null,rn,{"u-hidden":!c(a).videoDownload}),_(nn,`href`,c(a).videoDownload?.href??`#`),_(nn,`download`,c(a).videoDownload?.fileName),_(nn,`aria-disabled`,c(a).videoDownload?`false`:`true`),_(nn,`tabindex`,c(a).videoDownload?0:-1),un=j(ln,1,`floating-player-meta-item`,null,un,{"u-hidden":!c(a).status}),i(fn,c(a).status),i(_n,c(o).wordProgress),_(vn,`aria-hidden`,!c(a).expanded||!c(a).compact)}),e(`keydown`,Le,Pe),e(`focusin`,Le,ue),e(`focusout`,Le,de),e(`pointerdown`,Ve,Me),e(`dblclick`,Ve,()=>X({type:`drag-reset`})),e(`keydown`,Ve,Ne),e(`click`,it,()=>be(!c(a).expanded,`desktop`,r.document.activeElement)),e(`click`,ot,()=>be(!1,`close`)),e(`click`,lt,()=>X({type:`restart`})),e(`click`,ft,()=>X({type:`step`,delta:-1})),e(`click`,mt,()=>X({type:`toggle-playback`})),e(`click`,gt,e=>Y(e.detail===0)),e(`click`,xt,()=>X({type:`step`,delta:1})),e(`click`,wt,xe),e(`input`,Nt,Q),e(`pointerdown`,Nt,Ae),e(`pointermove`,Nt,$),e(`pointerup`,Nt,e=>je(e,!0)),l(`pointercancel`,Nt,e=>je(e,!1)),e(`change`,Nt,Q),e(`input`,Kt,we),e(`pointerdown`,Kt,Te),e(`pointermove`,Kt,Ee),e(`pointerup`,Kt,e=>De(e,!0)),l(`pointercancel`,Kt,e=>De(e,!1)),l(`lostpointercapture`,Kt,Oe),e(`click`,Yt,()=>be(!0,`mobile`,G(F,`its mobile expand button`))),e(`click`,vn,()=>be(!1,`close`)),t(n,Ie),k()}N([`keydown`,`focusin`,`focusout`,`pointerdown`,`dblclick`,`click`,`input`,`pointermove`,`pointerup`,`change`]);function Ji(e,t){let n=t.document.querySelector(`[data-target-id="floating-player-root"]`);if(!n)throw Error(`Floating Player requires its mount root`);if(n.childNodes.length)throw Error(`Floating Player requires an empty mount root`);let i=null,a=r(qi,{target:n,props:{document:t.document,view:t.view,action:t.action,connect:e=>{i=e}}});x();let s=i;if(!s)throw o(a),Error(`Floating Player did not connect its interface`);return e.own(()=>{o(a).catch(e=>{console.error(`Failed to unmount Floating Player`,e)})}),s}var Yi=`is-active-word`,Xi=400,Zi=.5,Qi=class{constructor(e){this.book=e,this.activeTokenKey=null,this.activeSequenceIndex=-1,this.activeElements=[],this.pendingActivation=null,this.pendingTokenKey=null,this.activationGeneration=0,this.sequence=[],this.sequenceIndexByTokenKey=new Map,this.display=null,this.tokenElementsByKey=new Map,this.activeTokenListeners=new Set}setDisplay(e){this.clear(),this.tokenElementsByKey.clear(),this.display=e}setSequence(e){this.sequence=e,this.sequenceIndexByTokenKey=new Map(e.map((e,t)=>[e,t])),this.activeSequenceIndex=this.activeTokenKey?this.sequenceIndexByTokenKey.get(this.activeTokenKey)??-1:-1}getSequence(){return[...this.sequence]}getActiveTokenKey(){return this.activeTokenKey}getActiveIndex(){return this.activeSequenceIndex}onActiveTokenChanged(e){return this.activeTokenListeners.add(e),()=>this.activeTokenListeners.delete(e)}clear(){this.activationGeneration+=1;let e=this.activeTokenKey!==null;this.activeElements.forEach(e=>e.classList.remove(Yi)),this.activeElements=[],this.activeTokenKey=null,this.activeSequenceIndex=-1,this.pendingActivation=null,this.pendingTokenKey=null,e&&this.emitActiveTokenChanged(null)}async activateCue(e,t){let n=Y(e);if(this.activeTokenKey===n)return this.getVisibleTokenElement(n)??this.getPrimaryTokenElement(n);if(this.pendingTokenKey===n&&this.pendingActivation)return this.pendingActivation;let r=++this.activationGeneration,i=this.display,a=(async()=>(await i?.ensurePageMounted(e.pageNumber),r!==this.activationGeneration||i!==this.display?null:this.applyTokenKey(n,t,r)))();return this.pendingTokenKey=n,this.pendingActivation=a,a.finally(()=>{this.pendingActivation===a&&(this.pendingTokenKey=null,this.pendingActivation=null)})}async activateTokenKey(e,{scroll:t=!0,scrollBehavior:n=`smooth`}={}){let r=++this.activationGeneration;return this.applyTokenKey(e,{scroll:t,scrollBehavior:n},r)}applyTokenKey(e,{scroll:t=!0,scrollBehavior:n=`smooth`}={},r=this.activationGeneration){if(r!==this.activationGeneration)return null;if(this.activeTokenKey===e)return this.getPrimaryTokenElement(e);this.activeElements.forEach(e=>e.classList.remove(Yi));let i=this.getTokenElements(e);i.forEach(e=>e.classList.add(Yi)),this.activeElements=i,this.activeTokenKey=e,this.activeSequenceIndex=this.sequenceIndexByTokenKey.get(e)??-1,this.emitActiveTokenChanged(e);let a=t?this.getVisibleTokenElement(e)??i[0]??null:i[0]??null;return a&&t&&this.scrollTokenIntoView(a,n),a}step(e,t){let n=this.getActiveIndex(),r=n<0?0:n+e;return r<0||r>=this.sequence.length?null:this.activateTokenKey(this.sequence[r],t)}getCueIndex(e,t){let n=0,r=e.length-1,i=-1;for(;n<=r;){let a=Math.floor((n+r)/2);t>=e[a].timeStart?(i=a,n=a+1):r=a-1}return i}getTokenKeyFromElement(e){return e.dataset.tokenKey??null}getTokenElements(e){let t=this.tokenElementsByKey.get(e);if(t){let n=t.filter(e=>e.isConnected);if(n.length)return this.rememberTokenElements(e,n),n;this.tokenElementsByKey.delete(e)}let n=[...this.book.querySelectorAll(`[data-token-key="${e}"]`)];return this.rememberTokenElements(e,n),n}getPrimaryTokenElement(e){return this.getTokenElements(e)[0]??null}getVisibleTokenElement(e){let t=this.book.getBoundingClientRect();return this.getTokenElements(e).find(e=>{let n=e.getBoundingClientRect();return n.width>0&&n.height>0&&n.top<t.bottom&&n.bottom>t.top})}scrollTokenIntoView(e,t){ir(this.book,e,{behavior:t,minimumScrollDistance:Zi})}rememberTokenElements(e,t){this.tokenElementsByKey.delete(e),this.tokenElementsByKey.set(e,t),this.pruneTokenElementCache()}pruneTokenElementCache(){for(;this.tokenElementsByKey.size>Xi;){let e=this.tokenElementsByKey.keys().next().value;if(!e)return;if(e===this.activeTokenKey){let t=this.tokenElementsByKey.get(e);this.tokenElementsByKey.delete(e),t&&this.tokenElementsByKey.set(e,t);continue}this.tokenElementsByKey.delete(e)}}emitActiveTokenChanged(e){for(let t of this.activeTokenListeners)t(e)}};function $i(e){return Y(e)}var ea=.5,ta=3,na=.09,ra=[.5,1,1.5,2,3],ia=10,aa=8,oa=56;function sa(e){if(!Number.isFinite(e))return`--:--`;if(e<0)return`0:00`;let t=Math.floor(e),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60;return n>0?`${n}:${String(r).padStart(2,`0`)}:${String(i).padStart(2,`0`)}`:`${r}:${String(i).padStart(2,`0`)}`}function ca(e,t){let n=e?.cues[t],r=e?.passage?n?e.tokenKeys.indexOf($i(n)):-1:t;return Ct({cueIndex:r,cueCount:e?.passage&&r<0?0:e?.cues.length??0,tokenCount:e?.tokenKeys.length??0})}function la(e,t){let{audioController:n,highlightController:r,document:i,view:a}=t,o=()=>{throw Error(`Floating Player action arrived before playback was ready`)},s=Ji(e,{document:i,view:a,action:e=>o(e)}),c=i.querySelector(`.reader-corner-controls`),l=null,u=!1,d=null,f=null,p=!1,m=null,h=null,g=0,_=t=>{g&&a.cancelAnimationFrame(g),g=a.requestAnimationFrame(()=>{g=0,e.signal.aborted||t()})},v=()=>{s.closeSpeedPopover()},y=()=>p&&m!==null?m:n.currentTime,b=()=>{let{duration:e}=n;return n.session&&Number.isFinite(e)&&e>0?Math.max(0,Math.min(1,y()/e)):0},x=(e,t)=>{let n=-1;for(let r=0;r<e.cues.length&&e.cues[r].timeStart<=t;r+=1)n=r;return n},S=(e=b())=>{let t=y(),{duration:r}=n;s.syncProgress({audioRatio:e,...p?{}:{seekValue:Math.round(e*1e3)},seekDisabled:!n.session||!Number.isFinite(r),seekValueText:`${sa(t)} of ${sa(r)}`,currentTime:sa(t),duration:sa(r)})},C=(e=n.session?x(n.session,y()):-1)=>{let t=n.session,r=ca(t,e),i=wt({cueIndex:e,cueCount:t?.cues.length??0});s.syncProgress({cueRatio:r.ratio,wordProgress:r.label,cueProgress:i.label,cueProgressVisible:i.total>0,mobileWordProgress:`Word ${r.current} of ${r.total}`,mobileWordProgressVisible:!!t?.cues.length&&r.total>0})},w=()=>{S(),C(),t.onChange({type:`aliyah-playback`})},T=e=>e===`Maftir`?Xr(7):e>1?Xr(e-1):`previous aliyah`,E=()=>{let e=n.session;if(!e){s.sync({desktopTitle:`—`,mobileTitle:`—`,subtitle:`Audio`,mobileReading:`—`,mode:`No cues`,status:``}),s.syncProgress({wordProgress:`0 / 0`});return}let t=ca(e,x(e,y())),r=n.error?`Recording unavailable`:{"current-only":``,"previous-opening":`Opening from ${T(e.aliyahIndex)}`,"partial-start":`Starts at first available cue`,"overlap-only":`Partial: shared opening only`,passage:e.passage?.cueComplete?``:`Audio available; word highlighting incomplete`,"partial-passage":`Available portion: ${e.passage?un(e.passage.range):``}${e.passage?.cueComplete?``:` · Word highlighting incomplete`}`}[e.status],i=e.readingLabel??e.recording.reading.name,a=Xr(e.aliyahIndex);s.sync({desktopTitle:`${i} · ${a}${e.status===`partial-passage`?` · available portion`:``}`,mobileTitle:`${a}${e.status===`partial-passage`?` · available portion`:``}`,subtitle:`Audio`,mobileReading:i,mode:e.cues.length?`Word cues`:`No cues`,status:r}),s.syncProgress({wordProgress:t.label})},D=e=>{let n=t.getPlaybackRate();return Number.isFinite(e)?Math.max(ea,Math.min(ta,e)):n},O=(e,t=na)=>{let n=D(e),r=ra.reduce((e,t)=>Math.abs(t-n)<Math.abs(e-n)?t:e);return Math.abs(r-n)<=t?r:n},k=()=>{let e=D(t.getPlaybackRate());s.sync({playbackRate:e}),n.playbackRate=e},A=(e,r=!1)=>{let i=r?O(e):D(e);t.onPlaybackRateChange(i),n.playbackRate=i,k()},j=(e,{returnFocus:r,restoreFocus:a=!0}={})=>{let o=t.viewport.isCompact(),c=u,l=e&&!!n.session;if(l&&o&&!c){let e=i.activeElement instanceof HTMLElement&&i.activeElement!==i.body?i.activeElement:null;d=r??e}if(u=l,!l&&c&&!o&&f?.(),s.sync({expanded:l,compact:o}),l&&o&&!c){_(()=>s.focusMobileClose());return}if(!l&&c){v();let e=a?d:null;d=null,e&&_(()=>t.restoreFocus(e))}},M=(e=`all`)=>{if(e===`progress`){w(),E();return}let r=n.session,i=r&&!r.passage?Gi(r.recording.id):null,a=!!(r&&r.status!==`overlap-only`&&(!r.passage||r.segments.length===1&&r.segments[0].startTime===0&&r.segments[0].endTime===null)),o=!!r?.cues.length,l=n.paused;r||j(!1,{restoreFocus:!1}),c?.classList.toggle(`mod-raised`,!!r),s.sync({visible:!!r,untimed:!!(r&&!o),playing:!!(r&&!l),compact:t.viewport.isCompact(),audioDownload:r&&a?{href:r.recording.downloadSrc,fileName:`${r.recording.id}.${r.recording.format}`}:null,videoDownload:i?{href:i.downloadSrc,fileName:`${i.audioId}_${i.quality}.mp4`}:null}),k(),w(),E(),t.onChange({type:`reader-chrome`})},N=async(e={})=>{let i=n.session;if(!i)return;let a=e.scroll??t.getAutoScroll();if(i.passage){let t=e.currentTime??n.currentTime,a=r.getCueIndex(i.cues,t),o=i.cues[a],s=i.segments.find(e=>t>=e.logicalStart&&t<e.logicalEnd);if(!o||!s||!s.tokenKeys.includes($i(o))||o.timeEnd!==void 0&&t>=o.timeEnd){r.clear();return}}if(i.cues.length){let t=r.getCueIndex(i.cues,e.currentTime??n.currentTime);t>=0&&(l=t,await r.activateCue(i.cues[t],{scroll:a,scrollBehavior:e.scrollBehavior}));return}!r.getActiveTokenKey()&&i.tokenKeys[0]&&await r.activateTokenKey(i.tokenKeys[0],{scroll:a,scrollBehavior:e.scrollBehavior})},P=e=>{let i=n.session;if(i){if(i.cues.length){let a=l??r.getCueIndex(i.cues,n.currentTime),o=i.cues[Math.max(0,a+e)];if(!o)return;l=i.cues.indexOf(o),n.seek(o.timeStart),r.activateCue(o,{scroll:t.getAutoScroll()});return}n.seek(n.currentTime+e*ia),M(`progress`)}},F=async e=>{if(!n.paused){n.pause(),M();return}await t.attemptPlayback(e)&&M()},ee=async(e=!0)=>{let i=n.session;if(!i)return;let a=e?t.attemptReplayFromStart(()=>ee(e)):null;i.cues.length&&(!i.passage||i.cues[0].timeStart===0)?(l=0,await r.activateCue(i.cues[0],{scroll:!0})):i.tokenKeys[0]&&await r.activateTokenKey(i.tokenKeys[0],{scroll:!0}),a&&await a},I=async e=>{switch(e.type){case`toggle`:await F(e.retry);return;case`step`:P(e.delta);return;case`set-rate`:A(e.rate,e.snap);return;case`set-cue-index`:l=e.index}},L=()=>{u&&t.viewport.isCompact()||t.focusReader()},R=e=>{let{duration:t}=n;return!n.session||!Number.isFinite(t)||t<=0?null:Math.max(0,Math.min(1,e))*t},te=e=>{let t=R(e);t!==null&&(m=t,M(`progress`),N({currentTime:t,scrollBehavior:`auto`}))},ne=e=>{let t=R(e);return t!==null&&(n.seek(t),M(`progress`),N({currentTime:t}),!0)},z=()=>{if(!p)return;let e=m;p=!1,m=null,h=null,e!==null&&(n.seek(e),M(`progress`),N({currentTime:e}),t.saveReadingPosition())},re=()=>{let n=null,r=null,i=null,o=()=>{s.setPosition(null)},c=(e,t)=>{let r=s.measure(),i=Math.max(aa,a.innerWidth-r.width-aa),o=Math.max(aa,a.innerHeight-r.height-aa);n={left:Math.max(aa,Math.min(e,i)),top:Math.max(aa,Math.min(t,o))},s.setPosition(n)},l=()=>{if(t.viewport.isCompact()){o();return}n&&c(n.left,n.top)},u=()=>{n=null,o()};return f=u,e.own(t.viewport.onChange(l)),e.own(()=>{i=null,s.setDragging(!1),o(),f===u&&(f=null)}),e=>{switch(e.type){case`drag-start`:{if(t.viewport.isCompact())return;let a=e.playerRect;!r&&!n&&(r={left:a.left,top:a.top}),i={pointerId:e.pointerId,pointerX:e.clientX,pointerY:e.clientY,playerLeft:a.left,playerTop:a.top},s.setDragging(!0);return}case`drag-move`:if(!i||i.pointerId!==e.pointerId)return;c(i.playerLeft+e.clientX-i.pointerX,i.playerTop+e.clientY-i.pointerY);return;case`drag-finish`:if(!i||i.pointerId!==e.pointerId)return;i=null,s.setDragging(!1),n&&r&&Math.hypot(n.left-r.left,n.top-r.top)<=oa&&u();return;case`drag-cancel`:i=null,s.setDragging(!1);return;case`drag-reset`:u();return;case`drag-key`:{if(t.viewport.isCompact())return;let i=e.playerRect;!r&&!n&&(r={left:i.left,top:i.top});let a=e.shiftKey?40:12;c(i.left+e.direction[0]*a,i.top+e.direction[1]*a);return}case`layout`:l()}}},B=()=>{e.own(t.viewport.onChange(()=>{j(!1,{restoreFocus:!1})}))},V=re();return B(),o=e=>{switch(e.type){case`toggle-playback`:(async()=>{await F(async()=>{await t.attemptPlayback()}),t.saveReadingPosition(),L()})();return;case`step`:P(e.delta),t.saveReadingPosition(),L();return;case`restart`:(async()=>{await ee(),t.saveReadingPosition(),L()})();return;case`seek-commit`:!p&&ne(e.ratio)&&t.saveReadingPosition();return;case`seek-preview`:if(e.phase===`start`){if(h!==null)return;p=!0,h=e.pointerId}if(e.pointerId!==h)return;te(e.ratio);return;case`seek-finish`:if(e.pointerId!==h)return;te(e.ratio),z();return;case`set-rate`:A(e.rate,e.snap);return;case`set-expanded`:if(!n.session&&e.expanded||e.source===`desktop`&&t.viewport.isCompact()||e.source===`mobile`&&!t.viewport.isCompact())return;j(e.expanded,{returnFocus:e.returnFocus});return;case`drag-start`:case`drag-move`:case`drag-finish`:case`drag-cancel`:case`drag-reset`:case`drag-key`:case`layout`:V(e)}},e.own(n.on(`playback-updated`,()=>{M()})),e.own(n.on(`session-loaded`,e=>{l=e.cues.length?0:null,r.setSequence(e.tokenKeys),t.onChange({type:`session-loaded`,session:e}),M()})),e.own(n.on(`segment-updated`,()=>{t.onChange({type:`segment-updated`}),M()})),e.own(n.on(`time-updated`,()=>{M(`progress`)})),e.own(n.on(`duration-updated`,()=>{M(`progress`)})),e.own(n.on(`playback-error`,({error:e,recording:n})=>{t.onChange({type:`playback-error`,error:e,recording:n}),M()})),e.own(n.on(`frame-updated`,({currentTime:e})=>{if(S(),t.isCueAuthoringRecording()||p)return;let i=n.session;if(i?.passage){N({currentTime:e}),C();return}if(!i?.cues.length)return;let a=r.getCueIndex(i.cues,e);if(a<0)return;l=a;let o=i.cues[a];C(a),r.getActiveTokenKey()!==Y(o)&&r.activateCue(o,{scroll:t.getAutoScroll()})})),e.own(n.on(`metadata-updated`,()=>M(`progress`))),e.own(()=>{g&&a.cancelAnimationFrame(g),g=0,p=!1,m=null,h=null,u=!1,d=null,v(),s.sync({expanded:!1,compact:!1}),s.setDragging(!1),i.documentElement.removeAttribute(`data-mobile-player-expanded`)}),M(),{get displayTime(){return y()},command:I,refresh:M,syncHighlight:N,closeOverlay(){return u?(j(!1),!0):(v(),!1)}}}var ua=class{constructor(){this.current=0}start(){return this.current+=1,this.current}isCurrent(e){return e===this.current}cancel(){this.current+=1}};function da(e){return e===`ready`||e===`audio-only`}var fa=e=>e instanceof Error?e.message:`Download operation failed.`;function pa({assets:e,backend:t,intent:n,dependencies:r,inUse:i=()=>!1}){let a=new Map;for(let t of e){let e=tt(t);a.has(e)||a.set(e,Object.freeze({key:e,asset:Object.freeze({...t}),phase:`idle`,downloadedBytes:0,error:null,readiness:`unchecked`}))}let o=new Map,s=`idle`,c=null,l=null,u=[],d=!1,f=!1,p=0,m=null,h=Promise.resolve(),g=new Map,_=new Map,v=new Map,y=async e=>{let t=[_.get(e),v.get(e)];_.delete(e),v.delete(e);for(let e of t)try{await e?.()}catch(e){l=fa(e),console.error(`Download reservation cleanup failed`,e),C()}},b=new Set,x=new AbortController,S=()=>Object.freeze({supported:t.supported,location:t.location??`browser`,phase:s,entries:Object.freeze([...a.values()]),inventory:Object.freeze([...o.values()]),error:c,persistenceError:l,unavailableIntent:Object.freeze([...u])}),C=()=>{f||b.forEach(e=>e(S()))},w=(e,t)=>{let n=a.get(e);n&&a.set(e,Object.freeze({...n,...t})),C()},T=async(e,t)=>{try{await n.update(e,t),l=null}catch(e){throw l=fa(e),C(),e}},E=e=>{let t=h.then(async()=>{if(f)throw Error(`Download library was destroyed.`);await e()});return h=t.catch(()=>{}),t},D=e=>[...new Set(e)].map(e=>{let t=a.get(e);if(!t)throw Error(`Recording is not in the current download catalog.`);return t}),O=()=>{if(f)return Promise.reject(Error(`Download library was destroyed.`));if(m)return m;let e=p;s=`checking`,c=null,C();let i=(async()=>{try{let i=d?null:await n.read(),c=await t.inventory(),l=new Map;if(r)for(let e of c){let t=tt(e);if(!g.has(t))try{l.set(t,{readiness:await r.check({...e,title:a.get(t)?.asset.title??e.audioId}),error:null})}catch(e){l.set(t,{readiness:`error`,error:fa(e)})}}if(f)return;if(e===p){o=new Map(c.map(e=>[tt(e),Object.freeze({...e})]));for(let[e,t]of o)a.has(e)||a.set(e,Object.freeze({key:e,asset:Object.freeze({...t,title:t.audioId}),phase:`stored`,downloadedBytes:t.byteLength,error:null,readiness:`unchecked`}));for(let[e,t]of a)if(!(g.has(e)||[`queued`,`removing`,`removal-pending`].includes(t.phase))){if(o.has(e)){let n=l.get(e)??{readiness:`unchecked`,error:null};w(e,{...n,phase:n.readiness===`error`?`error`:n.readiness===`missing`?`paused`:`stored`,downloadedBytes:t.asset.byteLength})}else t.phase===`stored`&&w(e,{phase:`idle`,downloadedBytes:0,readiness:`unchecked`})}}if(i){u=i.filter(e=>!a.has(e));for(let e of i)a.has(e)&&!o.has(e)&&w(e,{phase:`paused`})}d=!0,s=`ready`}catch(e){throw s=`error`,c=fa(e),e}finally{C()}})().finally(()=>{m===i&&(m=null)});return m=i,i},k=()=>{if(!f)for(let[e,n]of a){if(g.size>=2)break;if(n.phase!==`queued`)continue;let i=new AbortController,s=Promise.resolve().then(async()=>{w(e,{phase:r?`verifying`:`downloading`,downloadedBytes:o.get(e)?.byteLength??0,error:null});try{let a=r?await r.prepare(n.asset,i.signal):`unchecked`;i.signal.throwIfAborted(),w(e,{readiness:a});let s=o.get(e)??await t.download(n.asset,i.signal,t=>{if(!(i.signal.aborted||f)){if(!Number.isSafeInteger(t)||t<0||t>n.asset.byteLength)throw Error(`Invalid download progress.`);w(e,{phase:t===n.asset.byteLength?`verifying`:`downloading`,downloadedBytes:t})}});if(tt(s)!==e)throw Error(`Stored recording identity does not match the request.`);o.set(e,Object.freeze({...s})),p+=1,w(e,{phase:`stored`,downloadedBytes:s.byteLength,error:null}),await T([],[e])}catch(t){a.get(e)?.phase!==`stored`&&w(e,{phase:i.signal.aborted?`paused`:`error`,error:i.signal.aborted?null:fa(t),downloadedBytes:o.get(e)?.byteLength??0,readiness:i.signal.aborted?`unchecked`:`error`})}}).finally(async()=>{await y(e),g.delete(e),C(),k()});g.set(e,{controller:i,done:s}),w(e,{phase:`downloading`})}},A=async e=>{let n=a.get(e);if(i(n.asset)){w(e,{phase:`removal-pending`});return}w(e,{phase:`removing`,error:null});try{await t.remove(n.asset),o.delete(e),p+=1,w(e,{phase:`idle`,downloadedBytes:0,readiness:`unchecked`}),await T([],[e])}catch(t){throw w(e,{phase:`error`,error:fa(t)}),t}};return{snapshot:S,subscribe(e){return b.add(e),e(S()),()=>{b.delete(e)}},refresh:O,enqueue:e=>E(async()=>{d||await O(),await Promise.all(D(e).filter(e=>[`stored`,`paused`,`error`].includes(e.phase)).map(e=>g.get(e.key)?.done));let n=D(e).filter(e=>(!o.has(e.key)||r&&!da(e.readiness))&&!g.has(e.key)&&e.phase!==`queued`&&e.phase!==`removal-pending`);if(n.length){try{if(t.preflight||r?.preflight||r?.reserve){let e=new Map([...a.values()].filter(e=>g.has(e.key)||e.phase===`queued`).map(e=>[e.key,e]));for(let t of n)e.set(t.key,t);let i=[...e.values()].map(e=>e.asset);if(r?.reserve){let e=await r.reserve(i,x.signal),t=n.length;for(let r of n)v.set(r.key,async()=>{--t===0&&await e()})}else await r?.preflight?.(i,x.signal);let s=[...e.values()].filter(e=>!o.has(e.key)).map(e=>e.asset);s.length&&await t.preflight?.(s)}if(f)throw Error(`Download library was destroyed.`);if(t.protectQueued)for(let e of n)_.set(e.key,await t.protectQueued(e.asset,x.signal));if(f||(await T(n.map(e=>e.key),[]),f))throw Error(`Download library was destroyed.`)}catch(e){throw await Promise.all(n.map(e=>y(e.key))),e}for(let e of n)w(e.key,{phase:`queued`,error:null});k()}}),cancel:e=>E(async()=>{let t=D(e);for(let e of t)e.phase===`queued`&&w(e.key,{phase:`paused`}),g.get(e.key)?.controller.abort();await Promise.all(t.map(e=>g.get(e.key)?.done)),await Promise.all(t.map(e=>y(e.key))),await O()}),remove:e=>E(async()=>{d||await O();let t=D(e);for(let e of t)e.phase===`queued`&&w(e.key,{phase:`paused`}),g.get(e.key)?.controller.abort();await Promise.all(t.map(e=>g.get(e.key)?.done)),await Promise.all(t.map(e=>y(e.key)));let n=[];for(let e of t)try{await A(e.key)}catch(e){n.push(e)}if(n.length)throw AggregateError(n,`Some recording downloads could not be removed.`)}),releasePlayback:()=>E(async()=>{for(let[e,t]of a)t.phase===`removal-pending`&&!i(t.asset)&&await A(e)}),destroy(){if(!f){f=!0,x.abort(),b.clear();for(let e of g.values())e.controller.abort();Promise.allSettled([h,...[...g.values()].map(({done:e})=>e)]).then(()=>Promise.all([...new Set([..._.keys(),...v.keys()])].map(y))).then(()=>{r?.destroy?.(),t.destroy()})}}}}var ma=`tikkun.download-intent`;function ha(e,t){let n=U({storage:e,key:ma,validate:e=>Array.isArray(e)&&e.every(e=>typeof e==`string`&&e.length>0)&&new Set(e).size===e.length}),r=()=>{let e=n.read();if(e.status===`unavailable`)throw e.error;if(e.status===`invalid`)throw Error(`Saved download queue is invalid; existing data was not overwritten.`);return{keys:e.status===`ready`?e.value:[],revision:e.revision}};return{read:async()=>r().keys,async update(e,i){if(!t)throw Error(`Persistent download queue coordination is unavailable in this browser.`);await t.request(ma,()=>{let t=r(),a=new Set(t.keys);i.forEach(e=>a.delete(e)),e.forEach(e=>a.add(e)),W(n.write([...a],t.revision))})}}}var ga;function _a(){return ga??=L(`TikkunMedia`)}function va(e=_a()){let t=!1;return{supported:!0,location:`device`,preflight:t=>e.preflight({assets:t}),async inventory(){let t=await e.inventory();if(!t||typeof t!=`object`||!(`recordings`in t))throw Error(`Invalid native media inventory.`);return $e({type:`RECORDING_LIBRARY`,state:`ready`,recordings:t.recordings})},async download(n,r,i){if(r.throwIfAborted(),t)throw Error(`Native media storage was destroyed.`);let a=crypto.randomUUID(),o,s,c=()=>{s??=e.cancelDownload({requestId:a}).catch(e=>{o=e})},l=await e.addListener(`progress`,e=>{if(!(!e||typeof e!=`object`||!(`requestId`in e)||e.requestId!==a||r.aborted)){if(!(`bytes`in e)||typeof e.bytes!=`number`||!Number.isSafeInteger(e.bytes)||e.bytes<0||e.bytes>n.byteLength){o=Error(`Native media returned invalid progress.`),c();return}i(e.bytes)}});try{r.throwIfAborted();let t=e.download({requestId:a,asset:n});r.addEventListener(`abort`,c,{once:!0}),r.aborted&&c();let i=await t;if(await s,o)throw o;r.throwIfAborted();let l=$e({type:`RECORDING_LIBRARY`,state:`ready`,recordings:[i]})[0];if(tt(l)!==tt(n))throw Error(`Native recording identity changed during download.`);return l}catch(e){throw await s,o||e}finally{r.removeEventListener(`abort`,c),await l.remove()}},remove:t=>e.remove({asset:t}),destroy(){t=!0}}}function ya(e=_a()){return{async read(){let t=await e.readIntent();if(!t||typeof t!=`object`||!(`keys`in t)||!Array.isArray(t.keys)||!t.keys.every(e=>typeof e==`string`&&e.length>0)||new Set(t.keys).size!==t.keys.length)throw Error(`Invalid native download queue.`);return t.keys},update:(t,n)=>e.updateIntent({add:t,remove:n})}}async function ba(e,t=_a()){let n=nt(e);if(!n)return e.playSrc;let r=await t.resolve({asset:n});if(!r||typeof r!=`object`||!(`url`in r))throw Error(`Invalid native recording location.`);if(r.url===null)return e.playSrc;if(typeof r.url!=`string`)throw Error(`Invalid native recording location.`);let i=new URL(r.url);if(i.protocol!==`file:`||i.host||i.search||i.hash)throw Error(`Native recording location is not a local file.`);return r.url}var xa=`tikkun.download-capacity.v1`,Sa=e=>`${xa}:${e}`,Ca=e=>typeof e==`number`&&Number.isSafeInteger(e)&&e>=0,wa=e=>!!e&&typeof e==`object`&&`url`in e&&typeof e.url==`string`&&/^https?:\/\//.test(e.url)&&`byteLength`in e&&Ca(e.byteLength)&&e.byteLength>0;function Ta(e){let t=new Map;for(let n of e){if(!wa(n))throw Error(`Invalid download capacity asset.`);t.set(n.url,Math.max(t.get(n.url)??0,n.byteLength))}let n=t.size?[...t.values()].reduce((e,t)=>e+t*2,0)+33554432:0;if(!Number.isSafeInteger(n))throw Error(`Download capacity reservation is too large.`);return n}function Ea(e,t){let n=U({storage:e,key:xa,validate:e=>Array.isArray(e)&&e.every(e=>!!e&&typeof e==`object`&&typeof e.owner==`string`&&/^[a-f0-9-]{36}$/.test(e.owner)&&Array.isArray(e.assets)&&e.assets.every(wa))&&new Set(e.map(e=>e.owner)).size===e.length}),r=()=>{let e=n.read();if(e.status===`unavailable`)throw e.error;if(e.status===`invalid`)throw Error(`Saved download capacity data is invalid; existing data was kept.`);return{entries:e.status===`ready`?e.value:[],revision:e.revision}};return{async reserve(e,i){if(!t)throw Error(`Shared download capacity coordination is unavailable.`);let a=crypto.randomUUID(),o=await et(t,[Sa(a)],i);try{await t.request(xa,{signal:i},async()=>{let o=r(),{held:s}=await t.query();if(!s)throw Error(`Shared download capacity ownership is unavailable.`);let c=new Set(s.map(e=>e.name)),l=o.entries.filter(e=>c.has(Sa(e.owner))),u=await e();if(i.throwIfAborted(),u.availableBytes!==null&&!Ca(u.availableBytes))throw Error(`Invalid download capacity estimate.`);let d=Ta([...l.flatMap(e=>e.assets),...u.assets]);if(u.availableBytes!==null&&d>u.availableBytes)throw Error(`Not enough browser storage including downloads queued in other tabs. Cancel a batch or remove downloads and try again.`);W(n.write([...l,{owner:a,assets:[...u.assets]}],o.revision))})}catch(e){throw await o(),e}let s;return()=>s??=t.request(xa,()=>{let e=r();W(n.write(e.entries.filter(e=>e.owner!==a),e.revision))}).finally(o)}}}function Da({baseUrl:e,navigator:t,storage:n,inUse:r}){let i=mt(),a=te(t),o=R(),s,c=()=>s??=(o?P(async()=>{let{createBundledRecordingDependencies:e}=await import(`./C_qCsIQy.js`);return{createBundledRecordingDependencies:e}},__vite__mapDeps([14,15,6,7,1,8,9,10,16]),import.meta.url).then(({createBundledRecordingDependencies:t})=>t({recordings:i,baseUrl:e})):P(async()=>{let{createWebRecordingDependencies:e}=await import(`./dgLhgZvB.js`);return{createWebRecordingDependencies:e}},__vite__mapDeps([17,16,14,15,6,7,1,8,9,10]),import.meta.url).then(({createWebRecordingDependencies:r})=>r({recordings:i,baseUrl:e,serviceWorker:a,capacity:Ea(n,t.locks??null)}))).catch(e=>{throw s=void 0,e});return pa({assets:i.flatMap(t=>{let n=nt(t);return n?[rt(n,e)]:[]}),backend:o?va():it({serviceWorker:a,locks:t.locks??null}),intent:o?ya():ha(n,t.locks??null),dependencies:{reserve:o?void 0:async(e,t)=>{let n=await c();if(!n.reserve)throw Error(`Offline capacity reservations are unavailable.`);return n.reserve(e,t)},preflight:o?void 0:async(e,t)=>{let n=await c();if(!n.preflight)throw Error(`Offline download preflight is unavailable.`);await n.preflight(e,t)},check:async e=>(await c()).check(e),prepare:async(e,t)=>(await c()).prepare(e,t),destroy:()=>{s?.then(e=>e.destroy?.(),e=>console.error(`Offline content initialization failed`,e))}},inUse:r})}function Oa(e){let t=new Set,n=0,r=!1,i=()=>[...new Set([...t,...e.currentSources()])];return{sources:i,async sync(){if(r)return;t=new Set(i());let a=++n;await e.whenReleased(),!(r||a!==n)&&(t=new Set(e.currentSources()),await e.onReleased())},freeze(){return t=new Set(i()),r=!0,n+=1,[...t]}}}var ka=class{constructor(){this.listeners={}}emit(e,t){let n=this.listeners[e];if(n)for(let e of[...n])e(t)}on(e,t){let n=this.listeners[e]??[];return n.push(t),this.listeners[e]=n,()=>{let n=this.listeners[e];if(!n)return;let r=n.indexOf(t);r>=0&&n.splice(r,1),n.length||delete this.listeners[e]}}},Aa;function ja(){return Aa??=L(`TikkunPlayback`)}function Ma(e){if(!e||typeof e!=`object`)throw Error(`Invalid native playback state`);let t=e;if(!Number.isSafeInteger(t.revision)||Number(t.revision)<0||t.sessionID!==null&&(typeof t.sessionID!=`string`||!t.sessionID)||!Number.isSafeInteger(t.segmentIndex)||Number(t.segmentIndex)<0||typeof t.currentTime!=`number`||!Number.isFinite(t.currentTime)||t.currentTime<0||t.duration!==null&&(typeof t.duration!=`number`||!Number.isFinite(t.duration)||t.duration<0)||typeof t.paused!=`boolean`||typeof t.ended!=`boolean`||typeof t.rate!=`number`||!Number.isFinite(t.rate)||t.rate<.25||t.rate>3||![`idle`,`loading`,`ready`,`error`].includes(t.phase??``)||t.error!==null&&typeof t.error!=`string`)throw Error(`Invalid native playback state`);return t}var Na=15e3,Pa=Symbol(`playback-activation-cancelled`),Fa=class extends ka{constructor(e,{signal:t,protectPlayback:n}={}){super(),this.audio=e,this.activeSession=null,this.activeSegmentIndex=0,this.playbackFrame=0,this.nextSourcePreload=null,this.nextSourcePreloadCleanup=null,this.nextSourcePreloadKey=null,this.segmentTransitioning=!1,this.activationGeneration=0,this.segmentReady=Promise.resolve({status:`ready`}),this.cancelPendingActivation=null,this.failPendingActivation=null,this.activationError=null,this.activationNeedsReload=!1,this.mediaDurationsBySource=new Map,this.lifetimeController=new AbortController,this.destroyed=!1,this.pendingProtection=null,this.releaseProtection=null,this.pumpPlaybackFrame=()=>{if(this.audio.paused||this.audio.ended){this.playbackFrame=0;return}let e=this.activeSession?.segments[this.activeSegmentIndex]?.endTime;if(typeof e==`number`&&this.audio.currentTime>=e){this.advanceSegment(!0)||(this.audio.pause(),this.audio.currentTime=e,this.emit(`frame-updated`,{currentTime:this.currentTime}));return}this.emit(`frame-updated`,{currentTime:this.currentTime}),this.playbackFrame=requestAnimationFrame(this.pumpPlaybackFrame)},this.protectPlayback=n;let r={signal:this.lifetimeController.signal};e.addEventListener(`play`,()=>{this.startPlaybackFrameLoop(),this.emit(`playback-updated`,{playing:!0})},r),e.addEventListener(`pause`,()=>{this.stopPlaybackFrameLoop(),this.emit(`playback-updated`,{playing:!1})},r),e.addEventListener(`ended`,()=>{this.stopPlaybackFrameLoop(),!this.advanceSegment(!0)&&this.emit(`frame-updated`,{currentTime:this.currentTime})},r),e.addEventListener(`seeked`,()=>this.emit(`frame-updated`,{currentTime:this.currentTime}),r),e.addEventListener(`timeupdate`,()=>this.emit(`time-updated`,{currentTime:this.currentTime}),r);let i=()=>this.rememberActiveMediaDuration();e.addEventListener(`loadedmetadata`,i,r),e.addEventListener(`durationchange`,i,r),e.addEventListener(`error`,()=>{if(!this.activeSession)return;let e=this.mediaError();if(this.failPendingActivation){this.failPendingActivation(e);return}this.reportPlaybackError(e,this.activationGeneration,!0)},r);for(let t of[`loadedmetadata`,`durationchange`,`emptied`])e.addEventListener(t,()=>this.emit(`metadata-updated`,void 0),r);t?.addEventListener(`abort`,()=>this.destroy(),{once:!0}),t?.aborted&&this.destroy()}destroy(){this.destroyed||(this.destroyed=!0,this.clearSession(),this.stopPlaybackFrameLoop(),this.lifetimeController.abort())}startPlaybackFrameLoop(){this.playbackFrame||=requestAnimationFrame(this.pumpPlaybackFrame)}stopPlaybackFrameLoop(){this.playbackFrame&&=(cancelAnimationFrame(this.playbackFrame),0)}get session(){return this.activeSession}get paused(){return this.audio.paused}get ended(){return this.audio.ended}get playbackRate(){return this.audio.playbackRate}set playbackRate(e){this.audio.playbackRate=e}get error(){return this.activationError}get activeSegment(){return this.activeSession?.segments[this.activeSegmentIndex]??null}get currentTime(){let e=this.activeSession?.segments[this.activeSegmentIndex];return e?e.recording.status===`missing`?e.logicalStart:Math.min(e.logicalEnd,e.logicalStart+Math.max(0,this.audio.currentTime-e.startTime)):this.audio.currentTime}get duration(){let e=this.activeSession?.segments,t=e?.[e.length-1];if(!t)return this.audio.duration;if(Number.isFinite(t.logicalEnd))return t.logicalEnd;let n=this.mediaDurationsBySource.get(this.sourceKey(t.recording.playSrc));return n===void 0?1/0:t.logicalStart+Math.max(0,n-t.startTime)}async loadSession(e){if(this.destroyed)throw Error(`Playback controller was destroyed`);this.pendingProtection?.abort();let t=new AbortController;this.pendingProtection=t;let n=null;try{this.protectPlayback&&(n=await this.protectPlayback(e.segments.filter(({recording:e})=>e.status!==`missing`).map(({recording:e})=>e.playSrc),t.signal)),t.signal.throwIfAborted()}catch(e){throw n?.(),e}finally{this.pendingProtection===t&&(this.pendingProtection=null)}let r=this.releaseProtection;this.releaseProtection=n,this.activeSession=e,this.activeSegmentIndex=0;try{this.activateSegment(0,e.segments[0]?.logicalStart??0,!1)}catch(e){throw this.clearSession(),e}finally{r?.()}return this.emit(`session-loaded`,e),e}waitForFiniteDuration({signal:e,timeoutMs:t=Na}={}){let n=this.duration;return Number.isFinite(n)&&n>0?Promise.resolve(n):new Promise((n,r)=>{let i=!1,a=t=>{i||(i=!0,clearTimeout(l),this.audio.removeEventListener(`loadedmetadata`,o),this.audio.removeEventListener(`durationchange`,o),this.audio.removeEventListener(`error`,s),e?.removeEventListener(`abort`,c),`error`in t?r(t.error):n(t.duration))},o=()=>{let e=this.duration;Number.isFinite(e)&&e>0&&a({duration:e})},s=()=>a({error:this.mediaError()}),c=()=>a({error:new DOMException(`Audio duration wait cancelled`,`AbortError`)}),l=setTimeout(()=>a({error:Error(`Timed out waiting for a finite audio duration`)}),t);this.audio.addEventListener(`loadedmetadata`,o),this.audio.addEventListener(`durationchange`,o),this.audio.addEventListener(`error`,s),e?.addEventListener(`abort`,c,{once:!0}),e?.aborted?c():o()})}clearSession(){this.pendingProtection?.abort(),this.pendingProtection=null,this.audio.pause(),this.cancelPendingActivation?.(),this.activationGeneration+=1,this.activeSession=null,this.activeSegmentIndex=0,this.clearNextSourcePreload(),this.segmentTransitioning=!1,this.segmentReady=Promise.resolve({status:`cancelled`}),this.cancelPendingActivation=null,this.failPendingActivation=null,this.activationError=null,this.activationNeedsReload=!1,this.audio.removeAttribute(`src`),this.audio.load(),this.releaseProtection?.(),this.releaseProtection=null,this.emit(`playback-updated`,{playing:!1})}authorizePlayback(e){if(e.status===`missing`)return!1;let t=!this.isMediaSource(e.playSrc);return!t&&this.audio.readyState>=HTMLMediaElement.HAVE_METADATA||(t&&(this.activeSession?this.clearSession():(this.cancelPendingActivation?.(),this.audio.pause()),this.audio.src=e.playSrc),this.activationError=null,this.activationNeedsReload=!1,this.audio.load(),!0)}togglePlayback(){if(this.audio.paused)return this.play();this.audio.pause()}play(){if(!this.activeSession)return Promise.resolve();if(this.activeSegment?.recording.status===`missing`)return Promise.reject(Error(`No source recording is available; record microphone audio first`));this.activationNeedsReload&&this.activeSession?this.activateSegment(this.activeSegmentIndex,this.currentTime,!1,!0):this.activationError=null;let e=this.activationGeneration,t=this.segmentReady,n=this.startMediaPlayback(e);if(!this.segmentTransitioning)return n;let r=t.then(t=>{if(t.status===`cancelled`||e!==this.activationGeneration)throw Pa;if(t.status===`failed`)throw t.error});return Promise.all([r,n]).then(()=>void 0).catch(e=>{if(e!==Pa)throw e})}async startMediaPlayback(e){try{await this.audio.play()}catch(t){if(e!==this.activationGeneration)return;let n=this.asError(t,`Audio playback failed`);throw this.reportPlaybackError(n,e,!1),n}}pause(){this.audio.pause()}seek(e){if(!Number.isFinite(e))throw TypeError(`Seek time must be finite`);let t=this.activeSession?.segments;if(!t?.length){this.audio.currentTime=e;return}let n=this.duration,r=Number.isFinite(n)?Math.max(0,Math.min(e,n)):Math.max(0,e),i=Math.max(0,t.findIndex((e,n)=>r>=e.logicalStart&&(r<e.logicalEnd||n===t.length-1))),a=t[i];if(a.recording.status===`missing`){i!==this.activeSegmentIndex||this.segmentTransitioning?this.activateSegment(i,a.logicalStart,!1):this.emit(`frame-updated`,{currentTime:a.logicalStart});return}if(i===this.activeSegmentIndex&&!this.segmentTransitioning){this.audio.currentTime=a.startTime+Math.max(0,r-a.logicalStart),this.emit(`frame-updated`,{currentTime:this.currentTime});return}this.activateSegment(i,r,!this.audio.paused)}replayFromStart(){let e=this.activeSession?.passage?0:this.activeSession?.cues[0]?.timeStart??0;return this.seek(e),this.play()}replayCurrentCue(){if(!this.activeSession?.cues.length)return;let e=this.currentTime,t=-1;for(let n=this.activeSession.cues.length-1;n>=0;n--)if(this.activeSession.cues[n].timeStart<=e){t=n;break}let n=this.activeSession.cues[Math.max(t,0)];if(n)return this.seek(n.timeStart),this.play()}advanceSegment(e){let t=this.activeSegmentIndex+1;return!this.activeSession?.segments[t]||this.segmentTransitioning?!1:(this.activateSegment(t,this.activeSession.segments[t].logicalStart,e),!0)}activateSegment(e,t,n,r=!1){let i=this.activeSession?.segments[e];if(!i)return;this.cancelPendingActivation?.();let a=++this.activationGeneration;this.segmentTransitioning=!0,this.activationError=null,this.activationNeedsReload=!1,this.activeSegmentIndex=e,this.emit(`segment-updated`,{index:e,segment:i});let o=i.recording.status===`missing`,s=o?!!this.audio.src:r||!this.isMediaSource(i.recording.playSrc);o?(this.audio.pause(),s&&(this.audio.removeAttribute(`src`),this.audio.load())):s&&(this.audio.src=i.recording.playSrc,this.audio.load());let c=i.startTime+Math.max(0,t-i.logicalStart),l=()=>{};this.segmentReady=new Promise(e=>{l=e});let u=!1,d=null,f=()=>{d!==null&&clearTimeout(d),this.audio.removeEventListener(`loadedmetadata`,m)},p=e=>{if(!u&&(u=!0,f(),l(e),a===this.activationGeneration)){if(this.cancelPendingActivation=null,this.failPendingActivation=null,this.segmentTransitioning=!1,e.status===`failed`){this.reportPlaybackError(e.error,a,!0);return}e.status!==`cancelled`&&(o||(this.rememberMediaDuration(i,this.audio),this.audio.currentTime=c),this.emit(`frame-updated`,{currentTime:this.currentTime}),n&&this.play().catch(()=>{}))}},m=()=>p({status:`ready`});this.cancelPendingActivation=()=>p({status:`cancelled`}),this.failPendingActivation=e=>p({status:`failed`,error:e}),o?p({status:`ready`}):this.audio.readyState<HTMLMediaElement.HAVE_METADATA?(this.audio.addEventListener(`loadedmetadata`,m,{once:!0}),d=setTimeout(()=>{p({status:`failed`,error:Error(`Timed out loading audio metadata for ${i.recording.id}`)})},Na)):p({status:`ready`}),this.preloadNextSegment()}preloadNextSegment(){let e=this.activeSession?.segments[this.activeSegmentIndex+1];if(e?.recording.status===`missing`){this.clearNextSourcePreload();return}let t=e?this.sourceKey(e.recording.playSrc):null;if(e&&t===this.nextSourcePreloadKey&&this.nextSourcePreload||(this.clearNextSourcePreload(),!e||!t))return;let n=new Audio;n.preload=`metadata`,n.src=e.recording.playSrc,this.nextSourcePreload=n,this.nextSourcePreloadKey=t;let r=()=>{this.rememberMediaDuration(e,n),a()},i=()=>a(),a=()=>{n.removeEventListener(`loadedmetadata`,r),n.removeEventListener(`error`,i),this.nextSourcePreloadCleanup===a&&(this.nextSourcePreloadCleanup=null)};this.nextSourcePreloadCleanup=a,n.addEventListener(`loadedmetadata`,r,{once:!0}),n.addEventListener(`error`,i,{once:!0}),n.readyState>=HTMLMediaElement.HAVE_METADATA&&r()}clearNextSourcePreload(){let e=this.nextSourcePreload;this.nextSourcePreloadCleanup?.(),this.nextSourcePreloadCleanup=null,this.nextSourcePreload=null,this.nextSourcePreloadKey=null,e&&(e.pause(),e.removeAttribute(`src`),e.load())}sourceKey(e){return new URL(e,window.location.href).href}isMediaSource(e){let t=this.audio.currentSrc||this.audio.src;return!!(t&&this.sourceKey(t)===this.sourceKey(e))}rememberActiveMediaDuration(){let e=this.activeSession?.segments[this.activeSegmentIndex];if(!e||e.recording.status===`missing`)return;let t=this.audio.currentSrc||this.audio.src;!t||this.sourceKey(t)!==this.sourceKey(e.recording.playSrc)||this.rememberMediaDuration(e,this.audio)}rememberMediaDuration(e,t){if(!Number.isFinite(t.duration)||t.duration<=0)return;let n=this.sourceKey(e.recording.playSrc);if(this.mediaDurationsBySource.get(n)===t.duration)return;this.mediaDurationsBySource.set(n,t.duration);let r=this.duration;Number.isFinite(r)&&this.emit(`duration-updated`,{duration:r})}reportPlaybackError(e,t,n){t!==this.activationGeneration||!this.activeSession||(this.activationError=e,this.audio.pause(),this.activationNeedsReload=n,this.emit(`playback-error`,{error:e,recording:this.activeSession.segments[this.activeSegmentIndex]?.recording??this.activeSession.recording}))}mediaError(){let e=this.audio.error?.code;return Error(e?`Audio media failed with code ${e}`:`Audio media failed to load`)}asError(e,t){return e instanceof Error?e:Error(t)}};function Ia(e){La(e);let t=0,n=e.segments.map(e=>{let n=e.endTime===null?1/0:Math.max(.001,e.endTime-e.startTime),r={...e,logicalStart:t,logicalEnd:t+n};return t=r.logicalEnd,r}),r=n.flatMap(e=>e.cues.map(t=>({...t,timeStart:e.logicalStart+(t.timeStart-e.startTime),timeEnd:t.timeEnd===void 0?void 0:e.logicalStart+(t.timeEnd-e.startTime)}))),i=n[n.length-1]?.recording;if(!i)throw Error(`Playback plan must contain at least one segment`);return{recording:i,cues:r,runId:e.target.runId,aliyahIndex:e.target.index,tokenKeys:e.tokenKeys,segments:n,status:e.status,readingLabel:e.readingLabel,passage:e.passage}}function La(e){if(!e.segments.length)throw TypeError(`Playback plan must contain at least one segment`);for(let[t,n]of e.segments.entries()){if(!Number.isFinite(n.startTime)||n.startTime<0)throw TypeError(`Playback segment ${t} has an invalid start time`);if(n.endTime===null){if(t!==e.segments.length-1)throw TypeError(`Only the final playback segment may be open-ended`)}else if(!Number.isFinite(n.endTime)||n.endTime<=n.startTime)throw TypeError(`Playback segment ${t} has an invalid end time`);let r=-1/0;for(let e of n.cues){if(!Number.isFinite(e.timeStart)||e.timeStart<n.startTime||n.endTime!==null&&e.timeStart>n.endTime||e.timeStart<r||e.timeEnd!==void 0&&(!Number.isFinite(e.timeEnd)||e.timeEnd<e.timeStart||n.endTime!==null&&e.timeEnd>n.endTime))throw TypeError(`Playback segment ${t} has invalid cue ordering`);r=e.timeStart}}}var Ra=class extends ka{constructor(e,t=ja(),n=async e=>e.playSrc){super(),this.bridge=t,this.resolveSource=n,this.useWeb=!1,this.activeSession=null,this.id=null,this.installedID=null,this.state=null,this.failure=null,this.rate=1,this.destroyed=!1,this.tail=Promise.resolve(),this.clearing=null,this.web=new Fa(e);let r=e=>{this.web.on(e,t=>{this.useWeb&&this.emit(e,t)})};r(`session-loaded`),r(`segment-updated`),r(`playback-updated`),r(`frame-updated`),r(`time-updated`),r(`duration-updated`),r(`metadata-updated`),r(`playback-error`),this.registrations=[t.addListener(`stateChanged`,e=>{try{this.accept(e)}catch(e){this.report(e)}}),t.addListener(`commandError`,e=>{e&&typeof e==`object`&&`sessionID`in e&&e.sessionID===this.id&&`message`in e&&typeof e.message==`string`&&this.report(Error(e.message))})],this.bridgeReady=Promise.all(this.registrations),this.bridgeReady.catch(e=>this.report(e))}get session(){return this.useWeb?this.web.session:this.activeSession}get error(){return this.useWeb?this.web.error:this.failure}get activeSegment(){return this.useWeb?this.web.activeSegment:this.activeSession?.segments[this.state?.segmentIndex??0]??null}get currentTime(){return this.useWeb?this.web.currentTime:this.state?.currentTime??0}get duration(){return this.useWeb?this.web.duration:this.state?.duration??this.activeSession?.segments.at(-1)?.logicalEnd??1/0}get paused(){return this.useWeb?this.web.paused:this.state?.paused??!0}get ended(){return this.useWeb?this.web.ended:this.state?.ended??!1}get playbackRate(){return this.rate}set playbackRate(e){if(!Number.isFinite(e)||e<.25||e>3)throw TypeError(`Invalid playback rate`);if(e===this.rate)return;this.rate=e,this.web.playbackRate=e;let t=this.id;t&&this.background(this.command(t,()=>this.bridge.setRate({sessionID:t,rate:e})))}async loadSession(e){if(this.destroyed)throw Error(`Playback controller was destroyed`);if(this.clearSession(),this.useWeb=e.segments.some(({recording:e})=>e.status===`missing`||e.playSrc.startsWith(`blob:`)),this.useWeb){if(await this.clearing,this.destroyed)throw Error(`Playback controller was destroyed`);return this.web.loadSession(e)}this.activeSession=e;let t=crypto.randomUUID();return this.id=t,this.emit(`session-loaded`,e),await this.command(t,async()=>{await this.bridgeReady;let n=await Promise.all(e.segments.map(async({recording:e,startTime:t,endTime:n})=>({url:await this.resolveSource(e),start:t,end:n})));if(this.destroyed||this.id!==t)throw new DOMException(`Playback session was replaced.`,`AbortError`);let r=await this.bridge.setSession({sessionID:t,title:e.readingLabel??e.recording.title,segments:n});return this.installedID=t,this.accept(r),this.bridge.setRate({sessionID:t,rate:this.rate})}),e}clearSession(){let e=this.id;if(this.id=null,this.activeSession=null,this.state=null,this.failure=null,this.web.clearSession(),this.useWeb=!1,e){let t=this.tail.then(async()=>{this.installedID===e&&(await this.bridge.clear({sessionID:e}),this.installedID=null)});this.clearing=t,this.tail=t.catch(e=>{console.error(`Could not clear native playback`,e),this.report(e)})}this.emit(`playback-updated`,{playing:!1}),this.emit(`metadata-updated`,void 0)}authorizePlayback(e){return e.status===`missing`||e.playSrc.startsWith(`blob:`)?this.web.authorizePlayback(e):!this.destroyed}play(){if(this.useWeb)return this.web.play();let e=this.id;return e?this.command(e,()=>this.bridge.play({sessionID:e})):Promise.resolve()}pause(){if(this.useWeb){this.web.pause();return}let e=this.id;e&&this.background(this.command(e,()=>this.bridge.pause({sessionID:e})))}togglePlayback(){if(this.paused)return this.play();this.pause()}seek(e){if(!Number.isFinite(e))throw TypeError(`Seek time must be finite`);if(this.useWeb){this.web.seek(e);return}let t=this.id;t&&this.background(this.command(t,()=>this.bridge.seek({sessionID:t,time:e})))}replayFromStart(){return this.seek(this.session?.passage?0:this.session?.cues[0]?.timeStart??0),this.play()}replayCurrentCue(){let e=this.session?.cues;if(!e?.length)return;let t=e.findLast(e=>e.timeStart<=this.currentTime)??e[0];return this.seek(t.timeStart),this.play()}waitForFiniteDuration({signal:e,timeoutMs:t=15e3}={}){if(this.useWeb)return this.web.waitForFiniteDuration({signal:e,timeoutMs:t});let n=this.id;return new Promise((r,i)=>{let a=[],o=e=>{a.forEach(e=>e()),e?i(e):r(this.duration)},s=()=>{this.destroyed||this.id!==n||e?.aborted?o(new DOMException(`Audio duration wait cancelled`,`AbortError`)):this.failure?o(this.failure):Number.isFinite(this.duration)&&this.duration>0&&o()};a.push(this.on(`metadata-updated`,s),this.on(`playback-error`,s));let c=setTimeout(()=>o(Error(`Timed out waiting for a finite audio duration`)),t);a.push(()=>clearTimeout(c)),e?.addEventListener(`abort`,s,{once:!0}),a.push(()=>e?.removeEventListener(`abort`,s)),s()})}whenCleared(){return this.clearing??Promise.resolve()}destroy(){if(!this.destroyed){this.destroyed=!0,this.clearSession(),this.web.destroy();for(let e of this.registrations)e.then(e=>e.remove()).catch(e=>console.error(`Could not release native playback listener`,e))}}command(e,t){let n=this.tail.then(async()=>{this.destroyed||this.id!==e||this.accept(await t())});return this.tail=n.catch(t=>{this.id===e&&this.report(t)}),n}background(e){e.catch(()=>{})}accept(e){let t=Ma(e);if(this.destroyed||!this.id||t.sessionID!==this.id||this.useWeb)return;if(!this.activeSession?.segments[t.segmentIndex])throw Error(`Native playback returned an invalid segment`);let n=this.state;n&&t.revision<n.revision||(this.state=t,t.error?this.failure?.message!==t.error&&this.report(Error(t.error)):this.failure=null,n?.segmentIndex!==t.segmentIndex&&this.emit(`segment-updated`,{index:t.segmentIndex,segment:this.activeSegment}),(n?.paused!==t.paused||n?.ended!==t.ended)&&this.emit(`playback-updated`,{playing:!t.paused&&!t.ended}),n?.duration!==t.duration&&(this.emit(`duration-updated`,{duration:this.duration}),this.emit(`metadata-updated`,void 0)),this.emit(`time-updated`,{currentTime:t.currentTime}),this.emit(`frame-updated`,{currentTime:t.currentTime}))}report(e){if(this.destroyed)return;let t=e instanceof Error?e:Error(`Native playback failed`);this.failure=t;let n=this.activeSegment?.recording??this.activeSession?.recording;n?this.emit(`playback-error`,{error:t,recording:n}):console.error(`Native playback is unavailable`,t)}},za=e=>`tikkun-recording-playback:${e}`;function Ba(e,t){return async(n,r)=>{r.throwIfAborted();let i=[...new Set(n.map(e=>new URL(e,t)).filter(e=>e.protocol===`https:`||e.protocol===`http:`).map(e=>e.href))];return!e||i.length===0?()=>{}:et(e,i.map(za),r)}}function Va(e,t){return!!(e&&e.runId===t.runId&&e.aliyahIndex===t.aliyahIndex&&(t.recordingId===null||e.recording.id===t.recordingId))}function Ha(e,t){if(e.status===`overlap-only`)return null;let n=e.segments.find(e=>e.recording.id===t);return n?{...e,status:n.tokenKeys[0]===e.tokenKeys[0]?`current-only`:`partial-start`,segments:[{...n,startTime:0,endTime:null}]}:null}function Ua(e){if(!e||e.status===`overlap-only`||e.passage||e.segments.length!==1)return null;let t=e.segments[0];return t&&t.recording.id===e.recording.id&&t.startTime===0&&t.endTime===null?t:null}function Wa(e){return Ua(e)!==null}function Ga(e,t){let n=Ua(e);return n?(e.cues=t,n.cues=t,!0):!1}var Ka=class{constructor(){this.generation=0,this.checkpoint=null}begin(e,t){if(!Number.isFinite(t)||t<0)throw TypeError(`Reader playback checkpoint time must be finite and nonnegative`);return this.checkpoint??={session:e,currentTime:t},++this.generation}isCurrent(e){return e===this.generation}leave(){this.generation+=1;let e=this.checkpoint;return this.checkpoint=null,e}},qa=e=>e.map(e=>({...e}));function Ja(e){let{audioController:t,highlightController:n,library:r,display:i,authoring:a,presentation:o}=e,s=new Map,c=new Ka,l=0,u=null,d=()=>(u?.abort(),u=new AbortController,{generation:++l,signal:u.signal}),f=e=>e.generation===l&&u?.signal===e.signal&&!e.signal.aborted,p=()=>{l+=1,u?.abort(),u=null},m=({runId:e,aliyahIndex:t})=>`${e}:${t}`,h=async(e,t)=>{let n=m(e),r=s.get(n);if(r)return[...r];let a=await i.collectTokenKeys(e);return f(t)?(a.length&&s.set(n,[...a]),[...a]):[]},g=(t,n)=>r.findRecording({narratorId:e.getNarratorId(),run:t,aliyahIndex:n}),_=(e,t)=>{let n=ei(e),r=n.findIndex(n=>n.run.id===e.id&&n.aliyah.index===t);return{target:r>=0?n[r]:null,previous:r>0?n[r-1]:null}},v=(e,t)=>{let{target:n,previous:r}=_(e,t);return!n||!r?.aliyah.index||n.aliyah.start.scroll!==r.aliyah.end.scroll||$(n.aliyah.start,r.aliyah.start)<0||$(n.aliyah.start,r.aliyah.end)>0?null:g(r.run,r.aliyah.index)},y=(t,n)=>{let r=g(t,n),i=v(t,n),o=t.aliyot.find(e=>e.index===n),s=!e.recordingMode&&!a.isActive()&&t.scroll===`torah`&&o?e.passages?.peek(o,e.getNarratorId()):void 0;return{recording:r,overlapRecording:i,available:s?!!s.recording:!!(r||i),passage:s}},b=async(s,{mode:c=`reader`,recordingOverride:l}={})=>{let u=d(),p=i.resolveRun(s.runId);if(!p)return null;let m=await h(s,u);if(!f(u)||!m.length)return null;let v=c===`authoring`||a.isActive(),y=null;if(e.passages&&p.scroll===`torah`&&!v&&!e.recordingMode&&l===void 0){let n=p.aliyot.find(e=>e.index===s.aliyahIndex);if(!n)return null;let r=await e.passages.resolve(n,e.getNarratorId());if(!f(u))return null;let i=r.problem===null||r.problem===`incomplete-cues`;i||t.pause();let a=i?r.portions[0]:await e.choosePassagePortion?.(r,u.signal,e=>{let n=e.segments[0]?.recording;n&&t.authorizePlayback(n)});if(!a||!f(u))return null;if(y=gn(r,a,{runId:s.runId,index:s.aliyahIndex},p.leining.date.title.en.replace(/^Parshat\s+/i,``)),y.segments.length>1){let{loadRecordingDuration:e}=await P(async()=>{let{loadRecordingDuration:e}=await import(`./Dtzlsesb.js`);return{loadRecordingDuration:e}},[],import.meta.url);y.segments=await Promise.all(y.segments.map(async t=>({...t,endTime:t.endTime??await e(t.recording,u.signal)})))}if(!f(u))return null}let b=l===void 0?c===`authoring`?r.findAuthoringRecording({narratorId:e.getNarratorId(),run:p,aliyahIndex:s.aliyahIndex}):g(p,s.aliyahIndex):l,x=b&&!y?{recording:b,cues:qa(await r.loadCues(b))}:null;if(!f(u))return null;let S=null,C=[];if(!y&&!e.recordingMode&&!v){let e=_(p,s.aliyahIndex).previous;if(e?.aliyah.index){let t=g(e.run,e.aliyah.index);if(t){let n={runId:e.run.id,aliyahIndex:e.aliyah.index};if(C=await h(n,u),!f(u))return null;S={recording:t,cues:qa(await r.loadCues(t))}}}}if(!f(u))return null;let w=y??At({target:{runId:s.runId,index:s.aliyahIndex},tokenKeys:m,current:x,previous:S,previousTokenKeys:C});if(!w)return null;let T=v?b&&Ha(w,b.id):w;if(!T||!f(u))return null;let E=Ia(T);if(await t.loadSession(E),!f(u))return null;n.setSequence(E.tokenKeys);let D=E.cues[0];if(D&&(!y||D.timeStart===0)){if(t.seek(D.timeStart),await o.setCueIndex(0),!f(u))return null;await n.activateCue(D,{scroll:!0})}else E.tokenKeys[0]&&await n.activateTokenKey(E.tokenKeys[0],{scroll:!0});if(!f(u))return null;if(Wa(E)){if(await a.bindSession(),!f(u))return null;await o.setCueIndex(E.cues.length&&t.currentTime?n.getCueIndex(E.cues,t.currentTime):E.cues.length?0:null)}else a.clearSession();return f(u)?(o.sessionLoaded(E),E):null};return{lookup:y,load:(e,{mode:t=`reader`}={})=>b(e,{mode:t}),loadByAudioId:async e=>{let n=r.listRecordings().find(t=>t.id===e)??null;if(!n||!K(n))return null;await i.waitUntilReady();let a=i.resolveRunForRecording(n);if(!a)return null;let o=await b({runId:a.id,aliyahIndex:n.aliyah},{recordingOverride:n});if(!o)return null;let s={generation:l,signal:u?.signal??AbortSignal.abort()};return await t.waitForFiniteDuration({signal:s.signal}),f(s)?o:null},enterAuthoring:async()=>{let e=t.session;if(!e||a.hasSession()||e.status===`overlap-only`)return;let n=e.segments[e.segments.length-1];if(!n||n.recording.id!==e.recording.id)return;if(e.passage){let t=i.resolveRun(e.runId);if(e.segments.length!==1||n.startTime!==0||n.endTime!==null||!t||g(t,e.aliyahIndex)?.id!==e.recording.id)return}let r=c.begin(e,t.currentTime);t.pause();let o=await b({runId:e.runId,aliyahIndex:e.aliyahIndex},{mode:`authoring`,recordingOverride:e.recording});if(!(!c.isCurrent(r)||!a.isVisible())&&(!o||!Wa(o)))throw Error(`Could not create an authoring session for ${e.recording.id}`)},leaveAuthoring:async()=>{let e=c.leave();e&&(p(),t.pause(),await t.loadSession(e.session),!(a.isVisible()||t.session!==e.session)&&(t.seek(e.currentTime),o.sessionLoaded(e.session)))},replaceAuthoringCues:e=>{let n=t.session;return n?Ga(n,qa(e)):!1},reset:()=>{p(),s.clear(),c.leave()},tokenCacheSize:()=>s.size}}function Ya(e,t){let n=R()?new Ra(t.audioElement,void 0,ba):new Fa(t.audioElement,{signal:e.signal,protectPlayback:Ba(t.view.navigator.locks??null,t.document.baseURI)});e.own(()=>n.destroy()),n.playbackRate=t.initialPlaybackRate;let r=new Qi(t.book);e.own(()=>r.clear());let i=new Set,a=new Set,o=0,s=0,c=null,l=null,u=null,d=new WeakMap,f=null,p=null,m=-1,h=null,g=null,_=-1,v=null,y=null,b=-1,x=Object.freeze([]),S=null,C=-1,w=-1,T=null,E=e=>{let t=d.get(e);if(t)return t;let n=`range`in e?Object.freeze({...e,reading:Object.freeze({...e.reading}),...e.mediaIdentity?{mediaIdentity:Object.freeze({...e.mediaIdentity})}:{},range:Object.freeze({start:Object.freeze({...e.range.start}),end:Object.freeze({...e.range.end})})}):Object.freeze({...e,reading:Object.freeze({...e.reading}),...e.mediaIdentity?{mediaIdentity:Object.freeze({...e.mediaIdentity})}:{}});return d.set(e,n),n},D=()=>{let e=n.session;if(!e)return null;let t=n.activeSegment?.recording??e.recording;return f===e&&p===t&&m===s&&h?h:(f=e,p=t,m=s,h=Object.freeze({recording:E(e.recording),activeRecording:E(t),mediaSources:Object.freeze([...new Set(e.segments.map(e=>e.recording.playSrc))]),runId:e.runId,aliyahIndex:e.aliyahIndex,status:e.status,cueCount:e.cues.length,tokenCount:e.tokenKeys.length,tokenKeys:Object.freeze([...e.tokenKeys])}),h)},O=()=>{let e=n.session;return e?g===e&&_===o&&v?v:(g=e,_=o,v=Object.freeze({sessionRevision:o,recording:E(e.recording),tokenKeys:Object.freeze([...e.tokenKeys])}),v):null},k=()=>{let e=n.session;return e?y===e&&b===s?x:(y=e,b=s,x=Object.freeze(e.cues.map(e=>Object.freeze({...e}))),x):Object.freeze([])},A=()=>{let e=n.session,t=n.currentTime;return Object.freeze({sessionRevision:o,hasSession:!!e,activeTokenKey:r.getActiveTokenKey(),activeTokenIndex:r.getActiveIndex(),currentCueIndex:e?.cues.length?r.getCueIndex(e.cues,t):-1,currentTime:t,displayTime:c?.displayTime??t,duration:n.duration,paused:n.paused,ended:n.ended,error:n.error})},j=()=>{let e=n.session;return e?S===e&&C===o&&w===s&&T?T:(S=e,C=o,w=s,T=Object.freeze({sessionRevision:o,recording:E(e.recording),runId:e.runId,aliyahIndex:e.aliyahIndex,status:e.status,cues:Object.freeze(e.cues.map(e=>Object.freeze({...e}))),tokenKeys:Object.freeze([...e.tokenKeys])}),T):null},M=()=>Object.freeze({session:j(),currentTime:n.currentTime,duration:n.duration,activeTokenKey:r.getActiveTokenKey()}),N=()=>{let e=n.session,t=e?.cues.length?r.getCueIndex(e.cues,n.currentTime):-1;return Object.freeze({sessionRevision:o,session:D(),activeTokenKey:r.getActiveTokenKey(),activeTokenIndex:r.getActiveIndex(),currentCueIndex:t,currentTime:n.currentTime,displayTime:c?.displayTime??n.currentTime,duration:n.duration,paused:n.paused,ended:n.ended,playing:!!(e&&!n.paused&&!n.ended),error:n.error,tokenCacheSize:l?.tokenCacheSize()??0})},P=e=>{if(!i.size)return;let t=N();for(let n of i)n(e,t)},F=e=>{if(!a.size)return;let t=A();for(let n of a)n(e,t)},ee=async()=>{try{return await n.play(),!0}catch{return!1}},I=async e=>(u=e??null,ee()),L=async e=>{u=e??null;try{return await n.replayFromStart(),!0}catch{return!1}};c=la(e,{...t.timeline,document:t.document,view:t.view,viewport:t.viewport,audioController:n,highlightController:r,attemptPlayback:I,attemptReplayFromStart:L,onChange:e=>{if(e.type===`session-loaded`){o+=1,s+=1,P({type:`session-loaded`}),F({type:`session`});return}P(e),e.type===`reader-chrome`?F({type:`playback`}):e.type===`aliyah-playback`?F({type:`display-progress`}):e.type===`playback-error`&&(F({type:`error`}),!t.view.navigator.onLine&&n.session&&P({type:`offline-media-error`,retry:u??(async()=>{await I()})}))}}),l=Ja({...t.recording,audioController:n,highlightController:r,presentation:{setCueIndex:e=>c?.command({type:`set-cue-index`,index:e}),sessionLoaded:()=>c?.refresh()}}),e.own(()=>l?.reset()),e.own(r.onActiveTokenChanged(e=>{P({type:`active-token-changed`,tokenKey:e})})),e.own(n.on(`frame-updated`,()=>{F({type:`media-progress`})})),e.own(()=>i.clear()),e.own(()=>a.clear());let te=async(e,t)=>(u=null,await l?.load(e,t)?D():null),ne=(e,t)=>r.activateTokenKey(e,t),z=async(e,{play:t=!1,seekToCue:i=!1,retry:a,...o}={})=>{let s=n.session,l=s?.cues.findIndex(t=>Y(t)===e)??-1,d=l>=0?s?.cues[l]??null:null;return d&&i&&(await c?.command({type:`set-cue-index`,index:l}),n.seek(d.timeStart)),t&&d&&(u=a??null,await ee()),d?r.activateCue(d,o):r.activateTokenKey(e,o)},re=async(e={})=>{let t=n.session;if(!t)return null;let i=r.getActiveTokenKey(),a=t.cues.length?r.getCueIndex(t.cues,n.currentTime):-1;return t.cues.length&&a>=0?r.activateCue(t.cues[a],e):i?r.activateTokenKey(i,e):t.cues[0]?r.activateCue(t.cues[0],e):t.tokenKeys[0]?r.activateTokenKey(t.tokenKeys[0],e):null},B=Object.freeze({snapshot:A,session:O,readCues:k,subscribe(e){return a.add(e),()=>a.delete(e)},prepareAuthoringSession:()=>l.enterAuthoring(),restoreReaderSession:()=>l.leaveAuthoring(),play:I,pause:()=>n.pause(),seek:e=>n.seek(e),async activateToken(e,t){await r.activateTokenKey(e,t)},clearHighlight:()=>r.clear(),replaceCues(e){let t=l.replaceAuthoringCues(e);return t&&(s+=1),t},refresh:e=>c.refresh(e),setCueIndex:e=>c.command({type:`set-cue-index`,index:e})}),V=Object.freeze({snapshot:M,async loadByAudioId(e){let t=await l.loadByAudioId(e);return t&&n.session===t?j():null},seek:e=>n.seek(e),play:()=>n.play(),pause:()=>n.pause(),syncHighlight:()=>c.syncHighlight(),async activateHighlightAt(e,{scroll:t}){let i=n.session;if(!i?.cues.length)return await c.syncHighlight(),!!(i&&n.session===i);let a=r.getCueIndex(i.cues,e);return a<0?(await c.syncHighlight(),n.session===i):(r.clear(),await r.activateCue(i.cues[a],{scroll:t}),n.session===i)}});return{snapshot:N,whenAudioReleased:()=>n instanceof Ra?n.whenCleared():Promise.resolve(),subscribe(e){return i.add(e),()=>i.delete(e)},setDisplay(e){r.setDisplay(e)},resetRoute(){n.clearSession(),r.clear(),l.reset(),c.refresh(),o+=1,P({type:`route-reset`})},resetRecordingCache:()=>l.reset(),lookupRecording:(e,t)=>l.lookup(e,t),loadRecording:te,isTargetActive:e=>Va(n.session,n.session?.passage?{...e,recordingId:null}:e),authorizePlayback(...e){let t=e.find(e=>!!(e&&e.status!==`missing`));return t?n.authorizePlayback(t):!1},pause:()=>n.pause(),play:I,async replayCurrentCue(){u=async()=>{await n.replayCurrentCue()},await n.replayCurrentCue()},toggle:e=>c.command({type:`toggle`,retry:e}),step:e=>c.command({type:`step`,delta:e}),seek(e){n.seek(e),c.refresh(`progress`)},setPlaybackRate:(e,t)=>c.command({type:`set-rate`,rate:e,snap:t}),syncHighlight:e=>c.syncHighlight(e),restoreActiveHighlight:re,activateToken:ne,activateSessionToken:z,cueForToken(e){let t=n.session?.cues.find(t=>Y(t)===e);return t?Object.freeze({...t}):null},tokenIndex:e=>n.session?.tokenKeys.indexOf(e)??-1,protectedCuePageNumbers(e){let t=n.session;if(!t?.cues.length)return[];let i=Math.max(0,r.getCueIndex(t.cues,n.currentTime)),a=[];for(let n=i;n<t.cues.length&&a.length<=e;n+=1){let e=t.cues[n]?.pageNumber;Number.isInteger(e)&&e>0&&!a.includes(e)&&a.push(e)}return Object.freeze(a)},closeOverlay:()=>c.closeOverlay(),cueAuthoringAdapter:()=>B,recordingHarnessAdapter:()=>V}}var Xa=class extends Error{constructor(e,t){super(e),this.name=`MountCleanupError`,this.errors=t}};function Za(e){return e instanceof Xa?e.errors:[e]}function Qa(e){return typeof e!=`object`&&typeof e!=`function`||e===null?!1:typeof e.then==`function`}function $a(){let e=null,t=!1,n=t=>{if(t.destroyed)return;t.destroyed=!0,e===t&&(e=null);let n=[];try{t.controller.abort()}catch(e){n.push(e)}let r=t.teardowns.splice(0);for(let e=r.length-1;e>=0;--e)try{r[e]()}catch(e){n.push(e)}if(n.length)throw new Xa(`Mount teardown failed`,n)};return r=>{if(t)throw Error(`Mount transitions cannot be nested`);t=!0;try{e&&n(e);let i={controller:new AbortController,teardowns:[],destroyed:!1};e=i;let a=e=>{if(typeof e!=`function`)throw TypeError(`Owned teardown must be a function`);let t=!0,n=()=>{if(!t)return;t=!1;let r=i.teardowns.indexOf(n);r>=0&&i.teardowns.splice(r,1),e()};return i.destroyed?n():i.teardowns.push(n),n};try{if(Qa(r({signal:i.controller.signal,own:a})))throw TypeError(`Mount setup must be synchronous`)}catch(e){try{n(i)}catch(t){throw new Xa(`Mount setup and rollback failed`,[e,...Za(t)])}throw e}return()=>{if(!i.destroyed){if(t)throw Error(`Mount transitions cannot be nested`);t=!0;try{n(i)}finally{t=!1}}}}finally{t=!1}}}function eo(e){return fe(e)}function to({audioId:e,label:t,tokenKey:n,timeStart:r}){if(!he(n))throw TypeError(`Invalid checkpoint token key: ${n}`);return{id:`cue:${e}:${n}`,kind:`cue`,source:`playback`,label:t,audioId:e,tokenKey:n,timeStart:r}}function no(e){if(!he(e.tokenKey))throw TypeError(`Invalid recording-issue token key: ${e.tokenKey}`);return{id:`issue:${e.id}`,kind:`recording-issue`,source:`recording-issue`,label:e.note?.trim()||e.kind,audioId:e.audioId,tokenKey:e.tokenKey,timeStart:e.timeStart,createdAt:e.createdAt}}function ro(e,t){let n=eo(e.tokenKey),r=eo(t.tokenKey);return(n&&r?be(n,r):n?-1:r?1:e.tokenKey.localeCompare(t.tokenKey))||(e.timeStart??0)-(t.timeStart??0)}var io=`tikkun.bookmarks`;function ao({hash:e,label:t,tokenKey:n,audioId:r,timeStart:i,createdAt:a=Date.now()}){return{id:`bookmark:${n}:${a}`,hash:e,label:t,tokenKey:n,...r?{audioId:r}:{},...i===void 0?{}:{timeStart:i},createdAt:a}}function oo(e,t=F){if(!e||typeof e!=`object`)return!1;let n=e;return typeof n.id==`string`&&n.id.length>0&&typeof n.hash==`string`&&F(n.hash)&&t(n.hash)&&typeof n.label==`string`&&n.label.trim().length>0&&typeof n.tokenKey==`string`&&he(n.tokenKey)&&typeof n.createdAt==`number`&&Number.isSafeInteger(n.createdAt)&&n.createdAt>=0&&(n.audioId===void 0||typeof n.audioId==`string`&&n.audioId.length>0)&&(n.timeStart===void 0||typeof n.timeStart==`number`&&Number.isFinite(n.timeStart)&&n.timeStart>=0)}function so(e){return U({storage:e,key:io,validate:e=>Array.isArray(e)})}function co(e,t=F){let n=so(e).read();return n.status===`unavailable`?(console.error(`Failed to read reader bookmarks`,n.error),{bookmarks:[],revision:null}):n.status===`invalid`?(n.reason===`invalid-json`?console.error(`Failed to parse reader bookmarks`,n.error):console.error(`Invalid reader bookmarks`),{bookmarks:[],revision:n.revision}):n.status===`missing`?{bookmarks:[],revision:n.revision}:{bookmarks:n.value.filter(e=>oo(e,t)).sort((e,t)=>t.createdAt-e.createdAt),revision:n.revision}}function lo(e,t,n){let r=new Set,i=new Set;if(t.some(e=>!oo(e)||r.has(e.id)||i.has(e.tokenKey)?!0:(r.add(e.id),i.add(e.tokenKey),!1)))throw TypeError(`Cannot persist invalid or duplicate reader bookmarks`);try{let r=so(e),i=[...t].sort((e,t)=>t.createdAt-e.createdAt),a=n;if(!a){let e=r.read();if(e.status===`unavailable`)throw e.error;a=e.revision}return W(r.write(i,a))}catch(e){throw new uo(e)}}var uo=class extends Error{constructor(e){super(`Failed to save reader bookmarks`),this.name=`BookmarkStorageError`,this.cause=e}};function fo(e,t){let{load:n=()=>P(()=>import(`./B55PeGk9.js`),__vite__mapDeps([18,1,2,9,7,8,10,19,20,21,13,22,6,16,23]),import.meta.url),onLoadError:r,...i}=t,a=i.document.querySelector(`[data-target-id="settings-toggle"]`);if(!a)throw Error(`Lazy Reader Settings requires [data-target-id="settings-toggle"]`);let o=null,s=null,c=null,l=null,u=0,d=e=>{e?a.setAttribute(`aria-busy`,`true`):a.removeAttribute(`aria-busy`)},f=()=>{if(o)return Promise.resolve(o);if(c)return c;s??=n();let t=s.then(t=>e.signal.aborted?null:(o=t.createReaderSettings(e,i),o)).catch(t=>(s=null,e.signal.aborted||r(t),null)).finally(()=>{c===t&&(c=null)});return c=t,t},p=(t={})=>{if(e.signal.aborted)return;if(o){o.open(t);return}l=t,d(!0);let n=++u;f().then(t=>{if(e.signal.aborted||n!==u||l===null)return;let r=l;l=null,d(!1),t?.open(r)})},m=e=>{let t=l!==null;return l=null,u+=1,d(!1),o?.close(e)??t},h={open:p,close:m,sync:()=>o?.sync()};return a.addEventListener(`click`,()=>{if(l!==null){m();return}o?.close()||p({returnFocus:a})},{signal:e.signal}),e.own(()=>{l=null,u+=1,d(!1),o=null,c=null,s=null}),h}var po=n(`<button class="toolbar-button mod-icon-label toolbar-share-current" data-target-id="share-current-reading" type="button" title="Share Reading" aria-label="Share Reading"><!></button>`),mo=n(`<button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="media"><span>Media &amp; Storage</span><span class="toolbar-overflow-icon" aria-hidden="true"><!></span></button>`),ho=n(`<button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="share"><span>Share Reading</span><span class="toolbar-overflow-icon" aria-hidden="true"><!></span></button>`),go=n(`<button data-target-id="bookmark-current" type="button"><!></button> <!> <button class="toolbar-button mod-icon-label toolbar-overflow-toggle" data-target-id="toolbar-overflow-toggle" type="button" title="Reader controls" aria-label="Reader controls" aria-controls="toolbar-overflow-menu"><!></button> <div data-target-id="toolbar-overflow-menu" id="toolbar-overflow-menu" role="group" aria-label="Reader actions"><button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="bookmark"><span data-target-id="toolbar-overflow-bookmark-label"> </span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-bookmark-icon"><!></span></button> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="aliyah-rail"><span>Choose Aliyah</span></button> <button class="toolbar-overflow-item mod-aliyah-starts" type="button" data-toolbar-overflow-action="aliyah-starts"><span>Show Aliyah Starts</span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-aliyah-starts-icon" aria-hidden="true"><!></span></button> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="annotations"><span data-target-id="toolbar-overflow-annotations-label"> </span> <span class="toolbar-overflow-icon mod-annotations" data-target-id="toolbar-overflow-annotations-icon" aria-hidden="true"><span class="toggle mod-compact"><span class="annotations-toggle-icon"><span class="toggle-state mod-off">א</span> <span class="toggle-state mod-on">אֶ֨</span></span></span></span></button> <!> <!> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="settings"><span>Reader Settings</span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-settings-icon" aria-hidden="true"><!></span></button></div>`,1);function _o(n,r){M(r,!0);function a(){return{...r.getState()}}let o=p(v(a())),l=p(!1),d=p(!1),m;function g(){x(()=>{w(o,a(),!0)})}function b({restoreFocus:e=!1}={}){return c(l)?(x(()=>{w(l,!1)}),e&&m.focus({preventScroll:!0}),!0):!1}function S(e){if(e.stopPropagation(),c(l)){b();return}g(),x(()=>{w(l,!0)})}function O(e){b(),e()}async function N(e=m){if(!(c(d)||!r.shareReading)){w(d,!0),b();try{await r.shareReading(e)}finally{x(()=>{w(d,!1)}),e.isConnected&&e.focus({preventScroll:!0})}}}function P(e){let t=r.document.defaultView?.Element;return!!(t&&e instanceof t)}let F={close:b,sync:g};T(()=>{let e=e=>{!c(l)||!P(e.target)||e.target.closest(`[data-target-id="toolbar-overflow-menu"]`)||e.target.closest(`[data-target-id="toolbar-overflow-toggle"]`)||b()},t=e=>{e.key!==`Escape`||!c(l)||(e.preventDefault(),b({restoreFocus:!0}))};return r.connect(F),r.document.addEventListener(`pointerdown`,e),r.document.addEventListener(`keydown`,t),()=>{r.document.removeEventListener(`pointerdown`,e),r.document.removeEventListener(`keydown`,t),b()}});var ee=go(),I=C(ee);let L;var R=D(I);{let e=h(()=>c(o).bookmarked?`bookmarkFilled`:`bookmark`);Z(R,{get name(){return c(e)}})}s(I);var te=E(I,2),ne=n=>{var r=po(),i=D(r);Z(i,{name:`link`}),s(r),u(()=>r.disabled=c(d)||!c(o).shareAvailable),e(`click`,r,e=>N(e.currentTarget)),t(n,r)};y(te,e=>{r.shareReading&&e(ne)});var z=E(te,2),re=D(z);Z(re,{name:`cog`}),s(z),f(z,e=>m=e,()=>m);var B=E(z,2);let V;var ie=D(B),H=D(ie),U=D(H,!0);s(H);var W=E(H,2),G=D(W);{let e=h(()=>c(o).bookmarked?`bookmarkFilled`:`bookmark`);Z(G,{get name(){return c(e)}})}s(W),s(ie);var ae=E(ie,2),oe=E(ae,2),K=E(D(oe),2),se=D(K);Z(se,{name:`chevronDown`}),s(K),s(oe);var ce=E(oe,2),q=D(ce),J=D(q,!0);s(q),A(2),s(ce);var le=E(ce,2),Y=n=>{var i=mo(),a=E(D(i)),o=D(a);Z(o,{name:`download`}),s(a),s(i),e(`click`,i,()=>O(()=>r.openMedia?.(m))),t(n,i)};y(le,e=>{r.openMedia&&e(Y)});var ue=E(le,2),de=n=>{var r=ho(),i=E(D(r)),a=D(i);Z(a,{name:`link`}),s(i),s(r),u(()=>r.disabled=c(d)||!c(o).shareAvailable),e(`click`,r,()=>N()),t(n,r)};y(ue,e=>{r.shareReading&&e(de)});var fe=E(ue,2),pe=E(D(fe),2),me=D(pe);Z(me,{name:`settings2`}),s(pe),s(fe),s(B),u(()=>{L=j(I,1,`toolbar-button mod-icon-label`,null,L,{"is-active":c(o).bookmarked}),_(I,`title`,c(o).bookmarked?`Remove bookmark`:`Bookmark current word`),_(I,`aria-label`,c(o).bookmarked?`Remove bookmark`:`Bookmark current word`),_(I,`aria-pressed`,c(o).bookmarked),I.disabled=!c(o).bookmarkAvailable,_(z,`aria-expanded`,c(l)),V=j(B,1,`toolbar-overflow-menu`,null,V,{"u-hidden":!c(l)}),_(B,`aria-hidden`,!c(l)),ie.disabled=!c(o).bookmarkAvailable,i(U,c(o).bookmarked?`Remove Bookmark`:`Bookmark Word`),ae.disabled=!c(o).aliyahNavigationAvailable,oe.disabled=!c(o).aliyahNavigationAvailable,_(ce,`aria-pressed`,c(o).annotationsEnabled),i(J,c(o).annotationsEnabled?`Hide Nekudot`:`Show Nekudot`)}),e(`click`,I,function(...e){r.toggleBookmark?.apply(this,e)}),e(`click`,z,S),e(`click`,ie,()=>O(r.toggleBookmark)),e(`click`,ae,()=>O(()=>r.openAliyahNavigation(m))),e(`click`,oe,()=>O(r.showAliyahStarts)),e(`click`,ce,()=>O(r.toggleAnnotations)),e(`click`,fe,()=>O(()=>r.openSettings(m))),t(n,ee),k()}N([`click`]);function vo(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Controls requires ${t}`);return n}function yo(e,t){let n=vo(t.document,`[data-target-id="reader-controls-root"]`);if(n.childNodes.length)throw Error(`Reader Controls requires an empty controls root`);let i=null,a=()=>i,s=r(_o,{target:n,props:{...t,connect:e=>{i=e}}});x();let c=a();if(!c)throw o(s),Error(`Reader Controls did not connect its component API`);return e.own(()=>{c.close(),o(s).catch(e=>{console.error(`Failed to unmount Reader Controls`,e)})}),c}var bo=n(`<header class="app-toolbar" data-reader-shell-owner="true"><div class="toolbar-content u-page-wrap"><div class="toolbar-wrapper mod-left"><div class="toolbar-item"><button data-target-id="about-link" type="button">About</button> <button class="mobile-library-button" data-target-id="mobile-library" type="button" title="Home" aria-label="Open main page"><span class="mobile-library-icon" data-target-id="mobile-library-icon"><!></span></button></div></div> <div class="toolbar-wrapper mod-center"><div class="toolbar-item"><button class="parsha-title" data-target-id="parsha-title" data-tooltip="Tip: Press Cmd/Ctrl+K to search"> </button></div></div> <div class="toolbar-wrapper mod-right"><div class="toolbar-item"><div class="aliyah-navigation-root" data-target-id="aliyah-toolbar-root"></div> <div class="reader-controls-root" data-target-id="reader-controls-root"></div> <button data-target-id="settings-toggle" type="button" title="Reader settings" aria-label="Reader settings" aria-haspopup="dialog" aria-expanded="false" aria-controls="reader-settings-pane"><!></button></div></div></div></header> <div class="aliyah-navigation-root" data-target-id="aliyah-navigation-layer-root"></div> <div class="last-reading-prompt u-hidden" data-target-id="last-reading-prompt" role="status" aria-live="polite"><span data-target-id="last-reading-copy">Resume reading?</span> <button class="last-reading-button" data-target-id="last-reading-resume" type="button">Resume</button> <button class="last-reading-dismiss" data-target-id="last-reading-dismiss" type="button" aria-label="Dismiss reading prompt"></button></div> <div data-target-id="reader-progress-mobile" aria-hidden="true"><div class="reader-progress-mobile-fill" data-target-id="reader-progress-mobile-fill"></div></div> <div id="js-app" class="app-body"><main data-target-id="reader-shell" aria-label="Torah reader"><div><div data-target-id="floating-player-root"></div></div> <div class="reader-main" style="direction: rtl"><div class="reader-text-forehead" data-target-id="reader-text-forehead" aria-label="Torah and Tikkun sides"><div class="reader-side-heading mod-left" lang="he" dir="rtl"><span data-reader-heading-form="torah">תורה</span> <span data-reader-heading-form="tikkun">תיקון</span></div> <button class="reader-side-swap" data-target-id="reader-side-swap" data-reader-no-form-toggle="true" type="button" title="Swap Torah and Tikkun sides" aria-label="Swap Torah and Tikkun sides"><!></button> <div class="reader-side-heading mod-right" lang="he" dir="rtl"><span data-reader-heading-form="torah">תורה</span> <span data-reader-heading-form="tikkun">תיקון</span></div></div> <div data-target-id="tikkun-book" tabindex="-1"></div></div> <div><div data-target-id="reader-progress" role="progressbar" aria-label="Reading progress" aria-valuemin="0" aria-valuemax="100"><div class="reader-progress-label" data-target-id="reader-progress-label"> </div> <div class="reader-progress-rail"><div class="reader-progress-fill" data-target-id="reader-progress-fill"></div></div> <div class="reader-progress-percent" data-target-id="reader-progress-percent"> </div></div></div></main> <section data-target-id="about-view"></section></div> <div><button data-test-id="annotations-toggle" data-target-id="annotations-toggle" data-tooltip="Tip: Hold &quot;Shift&quot; to toggle quickly" data-tooltip-position="top-left" type="button"><span class="toggle" aria-hidden="true"><span class="shadowed-circle"><span class="toggle-state mod-off">א</span> <span class="toggle-state mod-on">אֶ֨</span></span></span></button></div> <div data-target-id="settings-root"></div>`,1);function xo(n,r){M(r,!0);let a=d(r,`onSwapSides`,3,()=>{});function o(){return r.initialTitle}function m(){return r.initialAnnotationsEnabled}let y=p(`reader`),b=p(!1),S=p(v(o())),N=p(v({label:`—`,percent:0})),P=p(v(m())),F,ee=p(!1),I=`--mobile-parsha-title-font-size`,L=h(()=>c(y)===`reader`&&!c(b));function R(e){x(()=>{w(y,e,!0)})}function te(e){x(()=>{w(b,e,!0)})}function ne(e){x(()=>{w(S,e,!0)}),z()}function z(){F.style.removeProperty(I);let e=F.ownerDocument.defaultView;if(!e)throw Error(`Reader Shell title requires a browser window`);if(!e.matchMedia(`(max-width: 550px)`).matches)return;let t=e.getComputedStyle(F),n=Number.parseFloat(t.paddingInlineStart)+Number.parseFloat(t.paddingInlineEnd),r=F.clientWidth-n,i=F.ownerDocument.createRange();i.selectNodeContents(F);let a=i.getBoundingClientRect().width;if(r<=0||a<=r+.5)return;let o=Number.parseFloat(t.fontSize),s=Math.max(9,Math.floor(o*(r-1)*100/a)/100);F.style.setProperty(I,`${s}px`)}function re(e){if(e.percent!==void 0&&!Number.isFinite(e.percent))throw TypeError(`Reader Shell progress must be finite`);x(()=>{w(N,{label:e.label??c(N).label,percent:e.percent===void 0?c(N).percent:Math.max(0,Math.min(100,Math.round(e.percent)))},!0)})}function B(e){x(()=>{w(P,e,!0)})}function V(){F.focus({preventScroll:!0})}let ie={setView:R,setPickerOpen:te,setTitle:ne,setProgress:re,setAnnotationsEnabled:B,focusTitle:V,isReaderVisible:()=>c(y)===`reader`};T(()=>{let e=F.closest(`.toolbar-content`);if(!e)throw Error(`Reader Shell toolbar is missing`);let t=F.ownerDocument,n=t.defaultView;if(!n)throw Error(`Reader Shell toolbar requires a browser window`);let i=new n.ResizeObserver(z);i.observe(e);let a=!0;return z(),t.fonts.ready.then(()=>{a&&z()}),r.connect(ie),()=>{a=!1,i.disconnect()}});var H=bo();l(`pointerdown`,g,()=>{w(ee,!0)}),l(`keydown`,g,()=>{w(ee,!1)});var U=C(H),W=D(U),G=D(W),ae=D(G),oe=D(ae);let K;var se=E(oe,2),ce=D(se),q=D(ce);Z(q,{name:`houseFilled`}),s(ce),s(se),s(ae),s(G);var J=E(G,2),le=D(J),Y=D(le),ue=D(Y,!0);s(Y),f(Y,e=>F=e,()=>F),s(le),s(J);var de=E(J,2),fe=D(de),pe=E(D(fe),4);let me;var he=D(pe);Z(he,{name:`settings2`}),s(pe),s(fe),s(de),s(W),s(U);var ge=E(U,6);let _e;var ve=D(ge);let ye;s(ge);var X=E(ge,2),be=D(X);let xe;var Se=D(be);let Ce;var we=E(Se,2),Te=D(we),Ee=D(Te),De=E(Ee,2),Oe=D(De);Z(Oe,{name:`arrowLeftRight`}),s(De);var ke=E(De,2);s(Te);var Q=E(Te,2);let Ae;s(we);var $=E(we,2);let je;var Me=D($);let Ne;var Pe=D(Me),Fe=D(Pe,!0);s(Pe);var Ie=E(Pe,2),Le=D(Ie);let Re;s(Ie);var ze=E(Ie,2),Be=D(ze);s(ze),s(Me),s($),s(be);var Ve=E(be,2);let He;s(X);var Ue=E(X,2);let We;var Ge=D(Ue);let Ke;s(Ue),A(2),u(()=>{_(U,`data-header-pointer`,c(ee)||void 0),K=j(oe,1,`toolbar-button`,null,K,{"u-hidden":c(b),"mod-animated":c(b)}),i(ue,c(S)),me=j(pe,1,`toolbar-button`,null,me,{"u-hidden":c(b),"mod-animated":c(b)}),_e=j(ge,1,`reader-progress-mobile`,null,_e,{"u-hidden":!c(L),"mod-animated":!c(L)}),ye=O(ve,``,ye,{"--reader-progress-ratio":`${c(N).percent/100}`}),xe=j(be,1,`reader-shell`,null,xe,{"u-hidden":c(y)!==`reader`}),Ce=j(Se,1,`reader-side mod-left`,null,Ce,{"u-hidden":!c(L),"mod-animated":!c(L)}),Ee.dir=Ee.dir,ke.dir=ke.dir,Ae=j(Q,1,`tikkun-book`,null,Ae,{"mod-annotations-on":c(P),"mod-annotations-off":!c(P),"u-hidden":c(b),"mod-animated":c(b)}),je=j($,1,`reader-side mod-right`,null,je,{"u-hidden":!c(L),"mod-animated":!c(L)}),Ne=j(Me,1,`reader-progress`,null,Ne,{"u-hidden":!c(L),"mod-animated":!c(L)}),_(Me,`aria-valuenow`,c(N).percent),_(Me,`aria-valuetext`,`${c(N).label}, ${c(N).percent}%`),i(Fe,c(N).label),Re=O(Le,``,Re,{"--reader-progress-ratio":`${c(N).percent/100}`}),i(Be,`${c(N).percent??``}%`),He=j(Ve,1,`about-route`,null,He,{"u-hidden":c(y)!==`optional`}),We=j(Ue,1,`reader-corner-controls`,null,We,{"u-hidden":!c(L),"mod-animated":!c(L)}),Ke=j(Ge,1,`annotations-toggle`,null,Ke,{"u-hidden":c(b),"mod-animated":c(b)}),_(Ge,`title`,c(P)?`Hide nekudot`:`Show nekudot`),_(Ge,`aria-label`,c(P)?`Hide nekudot and cantillation marks`:`Show nekudot and cantillation marks`),_(Ge,`aria-pressed`,c(P))}),e(`click`,oe,function(...e){r.onAboutClick?.apply(this,e)}),e(`click`,se,function(...e){r.onAboutClick?.apply(this,e)}),e(`click`,Y,function(...e){r.onTitleClick?.apply(this,e)}),e(`click`,De,function(...e){a()?.apply(this,e)}),e(`click`,Ge,()=>r.onAnnotationsChange(!c(P))),t(n,H),k()}N([`click`]);function So(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Shell requires ${t}`);return n}function Co(e,t){let n=So(t.document,`[data-target-id="app-root"]`),i=So(t.document,`[data-target-id="reader-shell-anchor"]`);if(i.parentElement!==n)throw Error(`Reader Shell anchor must be a direct child of the app root`);if(n.querySelector(`[data-reader-shell-owner="true"]`))throw Error(`Reader Shell is already mounted`);let a=null,s=()=>a,c=r(xo,{target:n,anchor:i,props:{initialTitle:t.initialTitle,initialAnnotationsEnabled:t.initialAnnotationsEnabled,onTitleClick:t.onTitleClick,onAboutClick:t.onAboutClick,onAnnotationsChange:t.onAnnotationsChange,onSwapSides:t.onSwapSides,connect:e=>{a=e}}});x();let l=s();if(!l)throw o(c),Error(`Reader Shell did not connect its component interface`);return e.own(()=>{o(c).catch(e=>{console.error(`Failed to unmount Reader Shell`,e)})}),l}var wo=e=>e.length?e.length===1?e[0]:[e[0],e[e.length-1]].join(`-`):``,To={asVersesRange:e=>wo(e.map(e=>{let t=[];return e.v===1&&t.push(e.c),t.push(e.v),t.map(e=>Zt(e)).join(`:`)}))},Eo={schemaVersion:1,tradition:`contemporary-ashkenazi-sephardi`,entries:[{id:`genesis-2-4-small-he`,verse:{book:1,chapter:2,verse:4},word:{text:`בהבראם`,occurrence:1},letter:{text:`ה`,position:2},form:{type:`small`}},{id:`genesis-23-2-small-kaf`,verse:{book:1,chapter:23,verse:2},word:{text:`ולבכתה`,occurrence:1},letter:{text:`כ`,position:4},form:{type:`small`}},{id:`genesis-27-46-small-qof`,verse:{book:1,chapter:27,verse:46},word:{text:`קצתי`,occurrence:1},letter:{text:`ק`,position:1},form:{type:`small`}},{id:`leviticus-1-1-small-alef`,verse:{book:3,chapter:1,verse:1},word:{text:`ויקרא`,occurrence:1},letter:{text:`א`,position:5},form:{type:`small`}},{id:`leviticus-6-2-small-mem`,verse:{book:3,chapter:6,verse:2},word:{text:`מוקדה`,occurrence:1},letter:{text:`מ`,position:1},form:{type:`small`}},{id:`numbers-10-35-inverted-nun`,verse:{book:4,chapter:10,verse:35},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-10-36-inverted-nun`,verse:{book:4,chapter:10,verse:36},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-25-11-small-yod`,verse:{book:4,chapter:25,verse:11},word:{text:`פינחס`,occurrence:1},letter:{text:`י`,position:2},form:{type:`small`}},{id:`deuteronomy-32-18-small-yod`,verse:{book:5,chapter:32,verse:18},word:{text:`תשי`,occurrence:1},letter:{text:`י`,position:3},form:{type:`small`}}]},Do=e=>!!e&&typeof e==`object`&&!Array.isArray(e),Oo=e=>Number.isSafeInteger(e)&&Number(e)>0,ko=e=>typeof e==`string`&&/^[א-ת]$/u.test(e),Ao=e=>e.match(/[א-ת\u05c6]/gu)?.join(``)??``,jo=(e,t)=>{let n=`Special-letter entry ${t+1}`;if(!Do(e))throw Error(`${n} must be an object`);let{id:r,verse:i,word:a,letter:o,form:s}=e;if(typeof r!=`string`||!/^[a-z0-9-]+$/.test(r))throw Error(`${n} has an invalid id`);if(!Do(i)||!Oo(i.book)||!Oo(i.chapter)||!Oo(i.verse))throw Error(`${n} has an invalid verse`);if(!Do(a)||typeof a.text!=`string`||Ao(a.text)!==a.text||!Oo(a.occurrence))throw Error(`${n} has an invalid word target`);if(!Do(o)||!(ko(o.text)||o.text===`׆`)||!Oo(o.position)||Array.from(a.text)[o.position-1]!==o.text)throw Error(`${n} has an invalid letter target`);if(!Do(s)||s.type!==`small`&&s.type!==`inverted`)throw Error(`${n} has an unsupported form`);if(s.type===`inverted`?a.text!==`׆`||o.text!==`׆`:!ko(o.text))throw Error(`${n} has an invalid target for its form`);return{id:r,verse:{book:i.book,chapter:i.chapter,verse:i.verse},word:{text:a.text,occurrence:a.occurrence},letter:{text:o.text,position:o.position},form:{type:s.type}}},Mo=(e=>{if(!Do(e)||e.schemaVersion!==1)throw Error(`Special-letter catalog has an unsupported schema version`);if(typeof e.tradition!=`string`||!e.tradition.trim())throw Error(`Special-letter catalog must name its tradition`);if(!Array.isArray(e.entries))throw Error(`Special-letter catalog entries must be an array`);let t=e.entries.map(jo),n=new Set,r=new Set;for(let e of t){if(n.has(e.id))throw Error(`Duplicate special-letter id: ${e.id}`);n.add(e.id);let t=[e.verse.book,e.verse.chapter,e.verse.verse,e.word.text,e.word.occurrence,e.letter.position].join(`:`);if(r.has(t))throw Error(`Duplicate special-letter target: ${t}`);r.add(t)}return{schemaVersion:1,tradition:e.tradition,entries:t}})(Eo),No=({b:e,c:t,v:n})=>`${e}:${t}:${n}`,Po=({verse:e})=>`${e.book}:${e.chapter}:${e.verse}`,Fo=Mo.entries.reduce((e,t)=>{let n=Po(t);return e.set(n,[...e.get(n)??[],t]),e},new Map),Io=(e,t)=>`<span
  class="special-letter mod-${t.form.type}"
  data-special-letter-id="${t.id}"
  data-special-letter-form="${t.form.type}"
  data-special-letter-position="${t.letter.position}"
>${e}</span>`,Lo=(e,t)=>{let n=new Map(t.map(e=>[e.letter.position,e])),r=0;return(e.match(/.\p{Mark}*/gu)??[]).map(e=>{let t=e.match(/[א-ת\u05c6]/u)?.[0];if(!t)return e;r+=1;let i=n.get(r);return!i||i.letter.text!==t?e:Io(e,i)}).join(``)},Ro=e=>{let t=[...new Set(e.filter(e=>!!e).map(No))].flatMap(e=>Fo.get(e)??[]),n=new Map;return e=>{let r=Ao(e),i=t.filter(e=>e.word.text===r);if(!i.length)return e;let a=(n.get(r)??0)+1;n.set(r,a);let o=i.filter(e=>e.word.occurrence===a);return o.length?Lo(e,o):e}};function zo(e,t){let n=(t,n)=>e[t]?.[n]??0,r=Math.max(n(`fragments-3`,0),n(`fragments-3`,2),n(`closing`,0)),i=n(`fragments-3`,1),a=Math.max(...e[`fragments-2`]??[],n(`extended-left`,0),n(`penultimate`,1)),o=n(`extended-left`,1),s=n(`penultimate`,0);return{required:Math.max(n(`opening`,0),2*r+i+2*t,2*a+t,a+o+t,s+a+t,r+n(`closing`,1)+t),outer:r,middle:i,half:a,extendedLeft:o,penultimateRight:s}}var Bo=`opening.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.extended-left.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.penultimate.closing`.split(`.`);function Vo(e,t){if(e!==78)return null;let n=Bo[t-5];return n?{pattern:n}:null}var Ho=e=>e?`mod-petucha`:``,Uo=e=>e.length>1?`mod-setuma`:``,Wo=e=>e.replace(/&/g,`&amp;`).replace(/"/g,`&quot;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),Go=e=>e.normalize(`NFD`).replace(/\p{M}/gu,``),Ko=({annotatedText:e,unannotatedText:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,fragmentIndex:a,renderAnnotatedSpecialLetters:o,renderUnannotatedSpecialLetters:s,readingLayout:c})=>{let l=ge(e),u=ge(t),d=Math.max(l.length,u.length);return Array.from({length:d},(e,t)=>{let d=l[t],f=u[t],p=d?o(d.text):``,m=f?s(f.text):``,h=n?d:f,g=n?p:m,_=n?m:p,v=`${r}:${i}:${a}:${t}`,y=!!d?.text.includes(`׃`);return`<span
        class="word ${h?.isKri?`ktiv-kri`:``}${y?` mod-sof-pasuk`:``}"
        ${_e(d?.text??``)?``:`data-token-key="${v}"`}
        data-page-number="${r}"
        data-line-index="${i}"
        data-fragment-index="${a}"
        data-word-index="${t}"
        data-annotations-mode="${n?`on`:`off`}"
        data-annotations-alternate="${Wo(_)}"
        data-annotations-on-text="${Wo(d?.text??``)}"
        data-annotations-on-present="${!!d}"
        data-annotations-off-present="${!!f}"
        data-annotations-on-kri="${!!d?.isKri}"
        data-annotations-off-kri="${!!f?.isKri}"
        ${h?``:`hidden`}
      >${g}</span>${c&&y?`<br class="reader-pasuk-break" aria-hidden="true">`:``}`}).join(` `)},qo=e=>e.replace(/([־-])/g,`$1<wbr>`),Jo=e=>e?.leining.date.title.he.replace(/^פרשת /,``)??e?.leining.date.title.en.replace(/^Parshat\s+/i,``)??``,Yo=new Map([[1,`ראשון`],[2,`שני`],[3,`שלישי`],[4,`רביעי`],[5,`חמישי`],[6,`ששי`],[7,`שביעי`],[`Maftir`,`מפטיר`]]),Xo=e=>e.map(e=>Yo.get(e.index)).filter(Boolean).join(`, `),Zo=({c:e,v:t})=>`${Zt(e)}:${Zt(t)}`,Qo=e=>e.map(e=>{let t=Zo(e.start),n=e.start.c===e.end.c?Zt(e.end.v):Zo(e.end);return t===n?t:`${t}-${n}`}).join(`, `),$o=(e,t,n,r)=>`
  <span
    class="aliyah-badge${n?.index?` mod-with-audio`:``}"
    ${n?.index?`data-aliyah-marker="true"`:``}
    ${t?`data-run-id="${t}"`:``}
    ${n?.index?`data-aliyah-index="${n.index}"`:``}
  >
    ${n?.index?`<button
            type="button"
            class="aliyah-audio-button"
            data-audio-button="true"
            data-run-id="${t}"
            data-aliyah-index="${n.index}"
            aria-label="Play ${e}"
          >${De(`play`)}</button>`:``}
    <span class="aliyah-label-text">${qo(e)}</span>
    ${es(e,r,n)}
  </span>
`,es=(e,t,n)=>!t||!n?.start?``:`
    <button
      type="button"
      class="aliyah-link"
      data-aliyah-link="true"
      data-aliyah-url="${Wo(In(t,n.start))}"
      aria-label="Copy link to ${Wo(e)}"
      title="Copy link to ${Wo(e)}"
    ><span data-aliyah-link-icon="link">${De(`link`)}</span><span data-aliyah-link-icon="check" hidden>${De(`check`)}</span></button>
  `,ts=(e,t,n,r)=>{let i=t?.b===2&&Vo(n,r);return i?{kind:`sea`,pattern:i.pattern}:t&&t.b===5&&t.c===32&&t.v>=1&&t.v<=43&&e.length===2?{kind:`haazinu`,pattern:`columns-2`}:null},ns=({text:e,references:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,presentation:a,surface:o})=>{let s=o===`tikkun`||o!==`torah`&&null,c=s??n,l=Ro(t),u=Ro(t);return`<div
    class="reader-text-side mod-${o}"
    data-reader-canonical="${o!==`torah`}"
    ${s===null?``:`data-reader-annotations="${c?`on`:`off`}"`}
    ${o===`torah`?`aria-hidden="true"`:``}
  >
    <div class="reader-text-flow">
      ${e.map((e,t)=>`
        <div class="column">
          ${e.map((n,o)=>{let s=ye({text:n,annotated:!0}),d=a.layout===`reading`&&a.sides===`two`?Go(s):ye({text:n,annotated:!1});return`
            <span class="fragment ${Uo(e)}">${Ko({annotatedText:s,unannotatedText:d,annotationsEnabled:c,pageNumber:r,lineIndex:i,fragmentIndex:t*100+o,renderAnnotatedSpecialLetters:l,renderUnannotatedSpecialLetters:u,readingLayout:a.layout===`reading`})}</span>
          `}).join(``)}
        </div>
      `).join(``)}
    </div>
  </div>`},rs=({pageNumber:e,lineIndex:t,run:n,aliyahStarts:r,startTitle:i,startLabel:a,startVerse:o,mirror:s})=>`
    data-line-index="${t}"
    data-page-number="${e}"
    ${s?`data-reader-mirror="true"`:`data-class="line"`}
    ${n?`data-run-id="${n.id}"`:``}
    ${!s&&r.length?`data-aliyah-starts="${r.map(e=>e.index).join(`,`)}"`:``}
    ${!s&&r.length&&i?`data-aliyah-start-title="${Wo(i)}"`:``}
    ${!s&&r.length&&a?`data-aliyah-start-label="${Wo(a)}"`:``}
    ${!s&&r.length&&o?`data-aliyah-start-verse="${Wo(o)}"`:``}
  `,is=({pageNumber:e,text:t,verses:n,focalRef:r,isPetucha:i,labels:a,aliyahStarts:o,run:s,lineIndex:c,annotationsEnabled:l=!0,presentation:u=cr,surface:d=`single`,mirror:f=!1,renderVerseGutter:p=!0,pageReference:m})=>{let h=Xo(o),g=Jo(s),_=Qo(o),v=[r,...n],y=n[0]??r??m,b=u.layout===`match`?ts(t,y,e,c):null,x=u.layout===`match`?t.length>1||b!==null:!1,S=rs({pageNumber:e,lineIndex:c,run:s,aliyahStarts:o,startTitle:g,startLabel:h,startVerse:_,mirror:f}),C=u.sides===`two`&&d===`single`?[`tikkun`,`torah`].map(n=>ns({text:t,references:v,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:n})).join(``):ns({text:t,references:v,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:d});return u.layout===`reading`?`
      <div
        class="${f?`reader-mirror-line`:`line`} mod-reading-line${x?` mod-shirah`:``}"
        ${S}
      >
        <div class="line-content">${C}</div>
        ${p?`<div class="line-gutter mod-verses">
                <span class="location-indicator mod-verses">${To.asVersesRange(n)}</span>
              </div>`:``}
        ${f?``:`<div class="line-gutter mod-aliyot">
                <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>$o(e,s?.id,o[t],s)).join(``)}</span>
              </div>`}
      </div>
    `:`
  <tr
    class="${x?`mod-shirah`:``}"
    ${S}
    ${b?`data-shirah-kind="${b.kind}" data-shirah-pattern="${b.pattern}"`:``}
  >
    <td class="line ${Ho(i)}">
      <div class="line-content">${C}</div>
      <div class="line-gutter mod-verses">
        <span class="location-indicator mod-verses">${To.asVersesRange(n)}</span>
      </div>
      <div class="line-gutter mod-aliyot">
        <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>$o(e,s?.id,o[t],s)).join(``)}</span>
      </div>
    </td>
  </tr>
`},as=(e,{annotationsEnabled:t=!0,presentation:n=cr}={})=>{let r=e.lines.find(e=>e.verses.length)?.verses[0];if(n.layout===`reading`){let r=({surface:r=`single`,mirror:i=!1}={})=>e.lines.map((a,o)=>is({pageNumber:e.pageNumber,lineIndex:o,annotationsEnabled:t,presentation:n,surface:r,mirror:i,...a})).join(``);return`
      <div
        class="reader-reading-page mod-${n.sides}-side"
        data-page-number="${e.pageNumber}"
      >
        <span class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</span>
        ${n.sides===`two`?`<div class="reader-reading-page-side mod-tikkun">${r({surface:`tikkun`})}</div>
               <div class="reader-reading-page-side mod-torah" aria-hidden="true">${r({surface:`torah`,mirror:!0})}</div>`:`<div class="reader-reading-page-side mod-single">${r()}</div>`}
      </div>
    `}return`
  <table data-page-number="${e.pageNumber}" data-reader-sides="${n.sides}">
    <caption class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</caption>
    ${e.lines.map((i,a)=>is({pageNumber:e.pageNumber,lineIndex:a,annotationsEnabled:t,presentation:n,pageReference:r,...i})).join(``)}
  </table>
`};function os(e){return e.getBoundingClientRect().height||e.offsetHeight||null}function ss(e){let t=[...e].sort((e,t)=>e.pageNumber-t.pageNumber);return{mountedPageCount:t.filter(e=>e.state===`mounted`).length,pages:t}}var cs=`[
  {
    "text": [
      [
        "הַבָּאִ֥ים אַחֲרֵיהֶ֖ם בַּיָּ֑ם לֹֽא־נִשְׁאַ֥ר בָּהֶ֖ם עַד־אֶחָֽד׃ וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בַיַּבָּשָׁ֖ה בְּת֣וֹךְ הַיָּ֑ם וְהַמַּ֤יִם לָהֶם֙ חֹמָ֔ה מִֽימִינָ֖ם וּמִשְּׂמֹאלָֽם׃ וַיּ֨וֹשַׁע"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֜ה בַּיּ֥וֹם הַה֛וּא אֶת־יִשְׂרָאֵ֖ל מִיַּ֣ד מִצְרָ֑יִם וַיַּ֤רְא יִשְׂרָאֵל֙ אֶת־מִצְרַ֔יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מֵ֖ת עַל־שְׂפַ֥ת הַיָּֽם׃ וַיַּ֨רְא יִשְׂרָאֵ֜ל אֶת־הַיָּ֣ד הַגְּדֹלָ֗ה אֲשֶׁ֨ר עָשָׂ֤ה יְהֹוָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּמִצְרַ֔יִם וַיִּֽירְא֥וּ הָעָ֖ם אֶת־יְהֹוָ֑ה וַיַּֽאֲמִ֙ינוּ֙ בַּֽיהֹוָ֔ה וּבְמֹשֶׁ֖ה עַבְדּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        "אָ֣ז יָשִֽׁיר־מֹשֶׁה֩ וּבְנֵ֨י יִשְׂרָאֵ֜ל אֶת־הַשִּׁירָ֤ה הַזֹּאת֙ לַֽיהֹוָ֔ה וַיֹּאמְר֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 1
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֵאמֹ֑ר",
        " אָשִׁ֤ירָה לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה",
        " ס֥וּס"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " עָזִּ֤י וְזִמְרָת֙ יָ֔הּ וַֽיְהִי־לִ֖י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לִֽישׁוּעָ֑ה",
        " זֶ֤ה אֵלִי֙ וְאַנְוֵ֔הוּ",
        " אֱלֹהֵ֥י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָבִ֖י וַאֲרֹמְמֶֽנְהוּ׃",
        " יְהֹוָ֖ה אִ֣ישׁ מִלְחָמָ֑ה יְהֹוָ֖ה"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁמֽוֹ׃",
        " מַרְכְּבֹ֥ת פַּרְעֹ֛ה וְחֵיל֖וֹ יָרָ֣ה בַיָּ֑ם",
        " וּמִבְחַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָֽׁלִשָׁ֖יו טֻבְּע֥וּ בְיַם־סֽוּף׃",
        " תְּהֹמֹ֖ת יְכַסְיֻ֑מוּ יָרְד֥וּ בִמְצוֹלֹ֖ת כְּמוֹ־"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָֽבֶן׃",
        " יְמִֽינְךָ֣ יְהֹוָ֔ה נֶאְדָּרִ֖י בַּכֹּ֑חַ",
        " יְמִֽינְךָ֥"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה תִּרְעַ֥ץ אוֹיֵֽב׃",
        " וּבְרֹ֥ב גְּאוֹנְךָ֖ תַּהֲרֹ֣ס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 7
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָמֶ֑יךָ",
        " תְּשַׁלַּח֙ חֲרֹ֣נְךָ֔ יֹאכְלֵ֖מוֹ כַּקַּֽשׁ׃",
        " וּבְר֤וּחַ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַפֶּ֙יךָ֙ נֶ֣עֶרְמוּ מַ֔יִם",
        " נִצְּב֥וּ כְמוֹ־נֵ֖ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נֹזְלִ֑ים",
        " קָֽפְא֥וּ תְהֹמֹ֖ת בְּלֶב־יָֽם׃",
        " אָמַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אוֹיֵ֛ב אֶרְדֹּ֥ף אַשִּׂ֖יג",
        " אֲחַלֵּ֣ק שָׁלָ֑ל תִּמְלָאֵ֣מוֹ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נַפְשִׁ֔י",
        " אָרִ֣יק חַרְבִּ֔י תּוֹרִישֵׁ֖מוֹ יָדִֽי׃",
        " נָשַׁ֥פְתָּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְרוּחֲךָ֖ כִּסָּ֣מוֹ יָ֑ם",
        " צָֽלְלוּ֙ כַּֽעוֹפֶ֔רֶת בְּמַ֖יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַדִּירִֽים׃",
        " מִֽי־כָמֹ֤כָה בָּֽאֵלִם֙ יְהֹוָ֔ה",
        " מִ֥י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כָּמֹ֖כָה נֶאְדָּ֣ר בַּקֹּ֑דֶשׁ",
        " נוֹרָ֥א תְהִלֹּ֖ת עֹ֥שֵׂה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶֽלֶא׃",
        " נָטִ֙יתָ֙ יְמִ֣ינְךָ֔ תִּבְלָעֵ֖מוֹ אָֽרֶץ׃",
        " נָחִ֥יתָ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 12
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 13
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְחַסְדְּךָ֖ עַם־ז֣וּ גָּאָ֑לְתָּ",
        " נֵהַ֥לְתָּ בְעׇזְּךָ֖ אֶל־נְוֵ֥ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קׇדְשֶֽׁךָ׃",
        " שָֽׁמְע֥וּ עַמִּ֖ים יִרְגָּז֑וּן",
        " חִ֣יל"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָחַ֔ז יֹשְׁבֵ֖י פְּלָֽשֶׁת׃",
        " אָ֤ז נִבְהֲלוּ֙ אַלּוּפֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱד֔וֹם",
        " אֵילֵ֣י מוֹאָ֔ב יֹֽאחֲזֵ֖מוֹ רָ֑עַד",
        " נָמֹ֕גוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כֹּ֖ל יֹשְׁבֵ֥י כְנָֽעַן׃",
        " תִּפֹּ֨ל עֲלֵיהֶ֤ם אֵימָ֙תָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וָפַ֔חַד",
        " בִּגְדֹ֥ל זְרוֹעֲךָ֖ יִדְּמ֣וּ כָּאָ֑בֶן",
        " עַד־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲבֹ֤ר עַמְּךָ֙ יְהֹוָ֔ה",
        " עַֽד־יַעֲבֹ֖ר עַם־ז֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָנִֽיתָ׃",
        " תְּבִאֵ֗מוֹ וְתִטָּעֵ֙מוֹ֙ בְּהַ֣ר נַחֲלָֽתְךָ֔",
        " מָכ֧וֹן"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְשִׁבְתְּךָ֛ פָּעַ֖לְתָּ יְהֹוָ֑ה",
        " מִקְּדָ֕שׁ אֲדֹנָ֖י כּוֹנְנ֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָדֶֽיךָ׃",
        " יְהֹוָ֥ה ׀ יִמְלֹ֖ךְ לְעֹלָ֥ם וָעֶֽד׃",
        " כִּ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 18
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 19
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָא֩ ס֨וּס פַּרְעֹ֜ה בְּרִכְבּ֤וֹ וּבְפָרָשָׁיו֙ בַּיָּ֔ם",
        " וַיָּ֧שֶׁב יְהֹוָ֛ה עֲלֵהֶ֖ם אֶת־מֵ֣י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַיָּ֑ם",
        " וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ בַיַּבָּשָׁ֖ה בְּת֥וֹךְ הַיָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּקַּח֩ מִרְיָ֨ם הַנְּבִיאָ֜ה אֲח֧וֹת אַהֲרֹ֛ן אֶת־הַתֹּ֖ף בְּיָדָ֑הּ וַתֵּצֶ֤אןָ כׇֽל־הַנָּשִׁים֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֶ֔יהָ בְּתֻפִּ֖ים וּבִמְחֹלֹֽת׃ וַתַּ֥עַן לָהֶ֖ם מִרְיָ֑ם שִׁ֤ירוּ לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה ס֥וּס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " וַיַּסַּ֨ע מֹשֶׁ֤ה אֶת־יִשְׂרָאֵל֙ מִיַּם־ס֔וּף וַיֵּצְא֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶל־מִדְבַּר־שׁ֑וּר וַיֵּלְכ֧וּ שְׁלֹֽשֶׁת־יָמִ֛ים בַּמִּדְבָּ֖ר וְלֹא־מָ֥צְאוּ מָֽיִם׃ וַיָּבֹ֣אוּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָרָ֔תָה וְלֹ֣א יָֽכְל֗וּ לִשְׁתֹּ֥ת מַ֙יִם֙ מִמָּרָ֔ה כִּ֥י מָרִ֖ים הֵ֑ם עַל־כֵּ֥ן קָרָֽא־שְׁמָ֖הּ מָרָֽה׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  }
]`,ls=`[
  {
    "text": [
      [
        "וְאָעִ֣ידָה בָּ֔ם אֶת־הַשָּׁמַ֖יִם וְאֶת־הָאָֽרֶץ׃ כִּ֣י יָדַ֗עְתִּי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֵ֤י מוֹתִי֙ כִּֽי־הַשְׁחֵ֣ת תַּשְׁחִת֔וּן וְסַרְתֶּ֣ם מִן־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדֶּ֔רֶךְ אֲשֶׁ֥ר צִוִּ֖יתִי אֶתְכֶ֑ם וְקָרָ֨את אֶתְכֶ֤ם הָרָעָה֙"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּאַחֲרִ֣ית הַיָּמִ֔ים כִּֽי־תַעֲשׂ֤וּ אֶת־הָרַע֙ בְּעֵינֵ֣י יְהֹוָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְהַכְעִיס֖וֹ בְּמַעֲשֵׂ֥ה יְדֵיכֶֽם׃ וַיְדַבֵּ֣ר מֹשֶׁ֗ה בְּאׇזְנֵי֙ כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קְהַ֣ל יִשְׂרָאֵ֔ל אֶת־דִּבְרֵ֥י הַשִּׁירָ֖ה הַזֹּ֑את עַ֖ד תֻּמָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַאֲזִ֥ינוּ הַשָּׁמַ֖יִם וַאֲדַבֵּ֑רָה"
      ],
      [
        "וְתִשְׁמַ֥ע הָאָ֖רֶץ אִמְרֵי־פִֽי׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 1
      }
    ],
    "aliyot": [
      {
        "standard": 1
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲרֹ֤ף כַּמָּטָר֙ לִקְחִ֔י"
      ],
      [
        "תִּזַּ֥ל כַּטַּ֖ל אִמְרָתִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּשְׂעִירִ֣ם עֲלֵי־דֶ֔שֶׁא"
      ],
      [
        "וְכִרְבִיבִ֖ים עֲלֵי־עֵֽשֶׂב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י שֵׁ֥ם יְהֹוָ֖ה אֶקְרָ֑א"
      ],
      [
        "הָב֥וּ גֹ֖דֶל לֵאלֹהֵֽינוּ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַצּוּר֙ תָּמִ֣ים פׇּֽעֳל֔וֹ"
      ],
      [
        "כִּ֥י כׇל־דְּרָכָ֖יו מִשְׁפָּ֑ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֵ֤ל אֱמוּנָה֙ וְאֵ֣ין עָ֔וֶל"
      ],
      [
        "צַדִּ֥יק וְיָשָׁ֖ר הֽוּא׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שִׁחֵ֥ת ל֛וֹ לֹ֖א בָּנָ֣יו מוּמָ֑ם"
      ],
      [
        "דּ֥וֹר עִקֵּ֖שׁ וּפְתַלְתֹּֽל׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַ לְיְהֹוָה֙ תִּגְמְלוּ־זֹ֔את"
      ],
      [
        "עַ֥ם נָבָ֖ל וְלֹ֣א חָכָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הֲלוֹא־הוּא֙ אָבִ֣יךָ קָּנֶ֔ךָ"
      ],
      [
        "ה֥וּא עָשְׂךָ֖ וַֽיְכֹנְנֶֽךָ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "זְכֹר֙ יְמ֣וֹת עוֹלָ֔ם"
      ],
      [
        "בִּ֖ינוּ שְׁנ֣וֹת דֹּר־וָדֹ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 7
      }
    ],
    "aliyot": [
      {
        "standard": 2
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁאַ֤ל אָבִ֙יךָ֙ וְיַגֵּ֔דְךָ"
      ],
      [
        "זְקֵנֶ֖יךָ וְיֹ֥אמְרוּ לָֽךְ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּהַנְחֵ֤ל עֶלְיוֹן֙ גּוֹיִ֔ם"
      ],
      [
        "בְּהַפְרִיד֖וֹ בְּנֵ֣י אָדָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַצֵּב֙ גְּבֻלֹ֣ת עַמִּ֔ים"
      ],
      [
        "לְמִסְפַּ֖ר בְּנֵ֥י יִשְׂרָאֵֽל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י חֵ֥לֶק יְהֹוָ֖ה עַמּ֑וֹ"
      ],
      [
        "יַעֲקֹ֖ב חֶ֥בֶל נַחֲלָתֽוֹ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִמְצָאֵ֙הוּ֙ בְּאֶ֣רֶץ מִדְבָּ֔ר"
      ],
      [
        "וּבְתֹ֖הוּ יְלֵ֣ל יְשִׁמֹ֑ן"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְסֹבְבֶ֙נְהוּ֙ יְב֣וֹנְנֵ֔הוּ"
      ],
      [
        "יִצְּרֶ֖נְהוּ כְּאִישׁ֥וֹן עֵינֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כְּנֶ֙שֶׁר֙ יָעִ֣יר קִנּ֔וֹ"
      ],
      [
        "עַל־גּוֹזָלָ֖יו יְרַחֵ֑ף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִפְרֹ֤שׂ כְּנָפָיו֙ יִקָּחֵ֔הוּ"
      ],
      [
        "יִשָּׂאֵ֖הוּ עַל־אֶבְרָתֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה בָּדָ֣ד יַנְחֶ֑נּוּ"
      ],
      [
        "וְאֵ֥ין עִמּ֖וֹ אֵ֥ל נֵכָֽר׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 12
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַרְכִּבֵ֙הוּ֙ עַל־במותי#[בָּ֣מֳתֵי] אָ֔רֶץ"
      ],
      [
        "וַיֹּאכַ֖ל תְּנוּבֹ֣ת שָׂדָ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 13
      }
    ],
    "aliyot": [
      {
        "standard": 3
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיֵּנִקֵ֤הֽוּ דְבַשׁ֙ מִסֶּ֔לַע"
      ],
      [
        "וְשֶׁ֖מֶן מֵחַלְמִ֥ישׁ צֽוּר׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חֶמְאַ֨ת בָּקָ֜ר וַחֲלֵ֣ב צֹ֗אן"
      ],
      [
        "עִם־חֵ֨לֶב כָּרִ֜ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵילִ֤ים בְּנֵֽי־בָשָׁן֙ וְעַתּוּדִ֔ים"
      ],
      [
        "עִם־חֵ֖לֶב כִּלְי֣וֹת חִטָּ֑ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְדַם־עֵנָ֖ב תִּשְׁתֶּה־חָֽמֶר׃"
      ],
      [
        "וַיִּשְׁמַ֤ן יְשֻׁרוּן֙ וַיִּבְעָ֔ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָׁמַ֖נְתָּ עָבִ֣יתָ כָּשִׂ֑יתָ"
      ],
      [
        "וַיִּטֹּשׁ֙ אֱל֣וֹהַּ עָשָׂ֔הוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיְנַבֵּ֖ל צ֥וּר יְשֻׁעָתֽוֹ׃"
      ],
      [
        "יַקְנִאֻ֖הוּ בְּזָרִ֑ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּתוֹעֵבֹ֖ת יַכְעִיסֻֽהוּ׃"
      ],
      [
        "יִזְבְּח֗וּ לַשֵּׁדִים֙ לֹ֣א אֱלֹ֔הַּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱלֹהִ֖ים לֹ֣א יְדָע֑וּם"
      ],
      [
        "חֲדָשִׁים֙ מִקָּרֹ֣ב בָּ֔אוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֹ֥א שְׂעָר֖וּם אֲבֹתֵיכֶֽם׃"
      ],
      [
        "צ֥וּר יְלָדְךָ֖ תֶּ֑שִׁי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 18
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּשְׁכַּ֖ח אֵ֥ל מְחֹלְלֶֽךָ׃"
      ],
      [
        "וַיַּ֥רְא יְהֹוָ֖ה וַיִּנְאָ֑ץ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 19
      }
    ],
    "aliyot": [
      {
        "standard": 4
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִכַּ֥עַס בָּנָ֖יו וּבְנֹתָֽיו׃"
      ],
      [
        "וַיֹּ֗אמֶר אַסְתִּ֤ירָה פָנַי֙ מֵהֶ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶרְאֶ֖ה מָ֣ה אַחֲרִיתָ֑ם"
      ],
      [
        "כִּ֣י ד֤וֹר תַּהְפֻּכֹת֙ הֵ֔מָּה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָּנִ֖ים לֹא־אֵמֻ֥ן בָּֽם׃"
      ],
      [
        "הֵ֚ם קִנְא֣וּנִי בְלֹא־אֵ֔ל"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּעֲס֖וּנִי בְּהַבְלֵיהֶ֑ם"
      ],
      [
        "וַאֲנִי֙ אַקְנִיאֵ֣ם בְּלֹא־עָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּג֥וֹי נָבָ֖ל אַכְעִיסֵֽם׃"
      ],
      [
        "כִּי־אֵשׁ֙ קָדְחָ֣ה בְאַפִּ֔י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,us=`[
  {
    "text": [
      [
        "וַתִּיקַ֖ד עַד־שְׁא֣וֹל תַּחְתִּ֑ית"
      ],
      [
        "וַתֹּ֤אכַל אֶ֙רֶץ֙ וִֽיבֻלָ֔הּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתְּלַהֵ֖ט מוֹסְדֵ֥י הָרִֽים׃"
      ],
      [
        "אַסְפֶּ֥ה עָלֵ֖ימוֹ רָע֑וֹת"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חִצַּ֖י אֲכַלֶּה־בָּֽם׃"
      ],
      [
        "מְזֵ֥י רָעָ֛ב וּלְחֻ֥מֵי רֶ֖שֶׁף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 24
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְקֶ֣טֶב מְרִירִ֑י"
      ],
      [
        "וְשֶׁן־בְּהֵמֹת֙ אֲשַׁלַּח־בָּ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "עִם־חֲמַ֖ת זֹחֲלֵ֥י עָפָֽר׃"
      ],
      [
        "מִחוּץ֙ תְּשַׁכֶּל־חֶ֔רֶב"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 25
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמֵחֲדָרִ֖ים אֵימָ֑ה"
      ],
      [
        "גַּם־בָּחוּר֙ גַּם־בְּתוּלָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יוֹנֵ֖ק עִם־אִ֥ישׁ שֵׂיבָֽה׃"
      ],
      [
        "אָמַ֖רְתִּי אַפְאֵיהֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 26
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁבִּ֥יתָה מֵאֱנ֖וֹשׁ זִכְרָֽם׃"
      ],
      [
        "לוּלֵ֗י כַּ֤עַס אוֹיֵב֙ אָג֔וּר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 27
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶּֽן־יְנַכְּר֖וּ צָרֵ֑ימוֹ"
      ],
      [
        "פֶּן־יֹֽאמְרוּ֙ יָדֵ֣נוּ רָ֔מָה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְלֹ֥א יְהֹוָ֖ה פָּעַ֥ל כׇּל־זֹֽאת׃"
      ],
      [
        "כִּי־ג֛וֹי אֹבַ֥ד עֵצ֖וֹת הֵ֑מָּה"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 28
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין בָּהֶ֖ם תְּבוּנָֽה׃"
      ],
      [
        "ל֥וּ חָכְמ֖וּ יַשְׂכִּ֣ילוּ זֹ֑את"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 29
      }
    ],
    "aliyot": [
      {
        "standard": 5
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָבִ֖ינוּ לְאַחֲרִיתָֽם׃"
      ],
      [
        "אֵיכָ֞ה יִרְדֹּ֤ף אֶחָד֙ אֶ֔לֶף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּשְׁנַ֖יִם יָנִ֣יסוּ רְבָבָ֑ה"
      ],
      [
        "אִם־לֹא֙ כִּי־צוּרָ֣ם מְכָרָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַֽיהֹוָ֖ה הִסְגִּירָֽם׃"
      ],
      [
        "כִּ֛י לֹ֥א כְצוּרֵ֖נוּ צוּרָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֹיְבֵ֖ינוּ פְּלִילִֽים׃"
      ],
      [
        "כִּֽי־מִגֶּ֤פֶן סְדֹם֙ גַּפְנָ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 32
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמִשַּׁדְמֹ֖ת עֲמֹרָ֑ה"
      ],
      [
        "עֲנָבֵ֙מוֹ֙ עִנְּבֵי־ר֔וֹשׁ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכְּלֹ֥ת מְרֹרֹ֖ת לָֽמוֹ׃"
      ],
      [
        "חֲמַ֥ת תַּנִּינִ֖ם יֵינָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 33
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹ֥אשׁ פְּתָנִ֖ים אַכְזָֽר׃"
      ],
      [
        "הֲלֹא־ה֖וּא כָּמֻ֣ס עִמָּדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 34
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חָת֖וּם בְּאוֹצְרֹתָֽי׃"
      ],
      [
        "לִ֤י נָקָם֙ וְשִׁלֵּ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 35
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְעֵ֖ת תָּמ֣וּט רַגְלָ֑ם"
      ],
      [
        "כִּ֤י קָרוֹב֙ י֣וֹם אֵידָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְחָ֖שׁ עֲתִדֹ֥ת לָֽמוֹ׃"
      ],
      [
        "כִּֽי־יָדִ֤ין יְהֹוָה֙ עַמּ֔וֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 36
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְעַל־עֲבָדָ֖יו יִתְנֶחָ֑ם"
      ],
      [
        "כִּ֤י יִרְאֶה֙ כִּֽי־אָ֣זְלַת יָ֔ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֶ֖פֶס עָצ֥וּר וְעָזֽוּב׃"
      ],
      [
        "וְאָמַ֖ר אֵ֣י אֱלֹהֵ֑ימוֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 37
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "צ֖וּר חָסָ֥יוּ בֽוֹ׃"
      ],
      [
        "אֲשֶׁ֨ר חֵ֤לֶב זְבָחֵ֙ימוֹ֙ יֹאכֵ֔לוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 38
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִשְׁתּ֖וּ יֵ֣ין נְסִיכָ֑ם"
      ],
      [
        "יָק֙וּמוּ֙ וְיַעְזְרֻכֶ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהִ֥י עֲלֵיכֶ֖ם סִתְרָֽה׃"
      ],
      [
        "רְא֣וּ ׀ עַתָּ֗ה כִּ֣י אֲנִ֤י אֲנִי֙ ה֔וּא"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 39
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין אֱלֹהִ֖ים עִמָּדִ֑י"
      ],
      [
        "אֲנִ֧י אָמִ֣ית וַאֲחַיֶּ֗ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָחַ֙צְתִּי֙ וַאֲנִ֣י אֶרְפָּ֔א"
      ],
      [
        "וְאֵ֥ין מִיָּדִ֖י מַצִּֽיל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּֽי־אֶשָּׂ֥א אֶל־שָׁמַ֖יִם יָדִ֑י"
      ],
      [
        "וְאָמַ֕רְתִּי חַ֥י אָנֹכִ֖י לְעֹלָֽם׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 40
      }
    ],
    "aliyot": [
      {
        "standard": 6
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אִם־שַׁנּוֹתִי֙ בְּרַ֣ק חַרְבִּ֔י"
      ],
      [
        "וְתֹאחֵ֥ז בְּמִשְׁפָּ֖ט יָדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 41
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָשִׁ֤יב נָקָם֙ לְצָרָ֔י"
      ],
      [
        "וְלִמְשַׂנְאַ֖י אֲשַׁלֵּֽם׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכִּ֤יר חִצַּי֙ מִדָּ֔ם"
      ],
      [
        "וְחַרְבִּ֖י תֹּאכַ֣ל בָּשָׂ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 42
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִדַּ֤ם חָלָל֙ וְשִׁבְיָ֔ה"
      ],
      [
        "מֵרֹ֖אשׁ פַּרְע֥וֹת אוֹיֵֽב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַרְנִ֤ינוּ גוֹיִם֙ עַמּ֔וֹ"
      ],
      [
        "כִּ֥י דַם־עֲבָדָ֖יו יִקּ֑וֹם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 43
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְנָקָם֙ יָשִׁ֣יב לְצָרָ֔יו"
      ],
      [
        "וְכִפֶּ֥ר אַדְמָת֖וֹ עַמּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיָּבֹ֣א מֹשֶׁ֗ה וַיְדַבֵּ֛ר אֶת־כׇּל־דִּבְרֵ֥י הַשִּׁירָֽה־הַזֹּ֖את בְּאׇזְנֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 44
      }
    ],
    "aliyot": [
      {
        "standard": 7
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הָעָ֑ם ה֖וּא וְהוֹשֵׁ֥עַ בִּן־נֽוּן׃ וַיְכַ֣ל מֹשֶׁ֗ה לְדַבֵּ֛ר אֶת־כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 45
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדְּבָרִ֥ים הָאֵ֖לֶּה אֶל־כׇּל־יִשְׂרָאֵֽל׃ וַיֹּ֤אמֶר אֲלֵהֶם֙ שִׂ֣ימוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 46
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְבַבְכֶ֔ם לְכׇ֨ל־הַדְּבָרִ֔ים אֲשֶׁ֧ר אָנֹכִ֛י מֵעִ֥יד בָּכֶ֖ם הַיּ֑וֹם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֲשֶׁ֤ר תְּצַוֻּם֙ אֶת־בְּנֵיכֶ֔ם לִשְׁמֹ֣ר לַעֲשׂ֔וֹת אֶת־כׇּל־דִּבְרֵ֖י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַתּוֹרָ֥ה הַזֹּֽאת׃ כִּ֠י לֹֽא־דָבָ֨ר רֵ֥ק הוּא֙ מִכֶּ֔ם כִּי־ה֖וּא חַיֵּיכֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 47
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,ds=JSON.parse(cs),fs=JSON.parse(ls),ps=JSON.parse(us);function ms(e){return(e===`sea`?[{pageNumber:78,lines:ds}]:[{pageNumber:242,lines:fs},{pageNumber:243,lines:ps}]).flatMap(({pageNumber:t,lines:n})=>{let r,i=n.find(e=>e.verses.length)?.verses[0],a=i?{b:i.book,c:i.chapter,v:i.verse}:void 0;return n.flatMap((n,i)=>{let o=n.verses.map(({book:e,chapter:t,verse:n})=>({b:e,c:t,v:n})),s=r??o[0];return r=o.at(-1)??r,ts(n.text,o[0]??s??a,t,i)?.kind===e?[{pageNumber:t,lineIndex:i,markup:ns({text:n.text,references:[s,...o],annotationsEnabled:!0,pageNumber:t,lineIndex:i,presentation:{layout:`match`,sides:`one`},surface:`single`})}]:[]})})}var hs=(e,t)=>[...e.querySelectorAll(t)].filter(e=>!e.hidden&&e.getClientRects().length>0);function gs(e){e.querySelectorAll(`.word[data-token-key]`).forEach(e=>e.style.removeProperty(`--reader-paired-word-width`))}var _s=new WeakMap,vs=new WeakMap;function ys(e){let t=getComputedStyle(e);return`${t.fontStyle} ${t.fontWeight} ${t.fontSize}/${t.lineHeight} ${t.fontFamily}`}function bs(e){let t=[...e.querySelectorAll(`tr:not([data-shirah-kind]) [data-reader-canonical="true"] .reader-text-flow`)];if(!t.length)return[];let n=ys(e),r=vs.get(t[0]);if(r?.font===n&&document.fonts.check(n,`אשר`))return r.widths;let i=document.createElement(`div`);i.className=`match-shirah-measure`,i.style.font=n,i.setAttribute(`aria-hidden`,`true`);let a=t.map(e=>e.cloneNode(!0));i.append(...a),document.body.append(i);let o=[];for(let e of[!0,!1]){xn(i,e);for(let e of a){let t=[...e.querySelectorAll(`.ktiv-kri:not([hidden])`)].reduce((e,t)=>{let n=getComputedStyle(t);return e+Number.parseFloat(n.paddingLeft)+Number.parseFloat(n.paddingRight)+Number.parseFloat(n.borderLeftWidth)+Number.parseFloat(n.borderRightWidth)},0);o.push({width:e.getBoundingClientRect().width,fixedInsets:t})}}return i.remove(),document.fonts.check(n,`אשר`)&&vs.set(t[0],{font:n,widths:o}),o}function xs(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind])`),r=e.closest(`.tikkun-book`),i=e.querySelector(`table`);if(!n||!r||!i||r.clientWidth===0)return;let a=bs(e),o=Math.max(...a.map(e=>e.width))+2,s=n.querySelector(`.line-content`),c=s.getBoundingClientRect(),l=t===`two`?1+2*Number.parseFloat(getComputedStyle(s).columnGap):0,u=t===`two`?2:1,d=u*o+l;if(d<=c.width)return;let f=r.getBoundingClientRect(),p=getComputedStyle(n.querySelector(`.line`)).gridTemplateColumns.split(` `).map(Number.parseFloat),m=p[2]+p[3],h=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),g=(c.left+c.right)/2,_=t===`two`?2*Math.min(g-f.left-h,f.right-m-h-g):f.width-m-2*h,v=Math.max(c.width,Math.min(d,_)),y=t===`two`?g+v/2:Math.min(g+v/2,f.right-m-h);i.style.width=getComputedStyle(i).width,e.classList.add(`mod-match-fitted`),e.style.setProperty(`--match-ordinary-inline-size`,`${v}px`),e.style.setProperty(`--match-ordinary-inline-offset`,`${y-c.right}px`);let b=(v-l)/u,x=Math.min(1,...a.map(e=>(b-e.fixedInsets)/(e.width-e.fixedInsets+2)));e.style.setProperty(`--match-text-scale`,`${x}em`)}function Ss(e){e.classList.remove(`mod-match-song-frame`);for(let t of[`inline-size`,`inline-offset`,`gutter-inline-offset`,`ordinary-flow-size`,`shirah-flow-size`])e.style.removeProperty(`--match-page-${t}`)}function Cs(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind]) .line-content`),r=e.querySelector(`tr[data-shirah-kind] .line-content`),i=e.closest(`.tikkun-book`);if(!n||!r||!i)return;let a=n.getBoundingClientRect(),o=r.getBoundingClientRect(),s=a.width>o.width?a:o,c=getComputedStyle(r).transform,l=o.right-(c===`none`?0:new DOMMatrixReadOnly(c).m41),u=e.querySelector(`table`);u.style.width=getComputedStyle(u).width,e.style.setProperty(`--match-page-ordinary-flow-size`,`${n.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-shirah-flow-size`,`${r.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-inline-size`,`${s.width}px`),e.style.setProperty(`--match-page-inline-offset`,`${s.right-l}px`),e.classList.add(`mod-match-song-frame`);let d=i.getBoundingClientRect().right,f=[...e.querySelectorAll(`.location-indicator.mod-verses`)],p=Math.max(0,...f.map(e=>e.getBoundingClientRect().right-d+1));e.style.setProperty(`--match-page-gutter-inline-offset`,`${s.right-l-p}px`)}function ws(e,t){let n=e.closest(`.tikkun-book`);if(!n||n.clientWidth===0)return;let r=e.querySelector(`tr[data-shirah-kind]`)?.dataset.shirahKind;if(r!==`sea`&&r!==`haazinu`||r!==`haazinu`&&t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let i=[...n.querySelectorAll(`tr[data-shirah-kind="${r}"]`)],a=[...new Set(i.map(e=>e.closest(`.tikkun-page`)))];for(let e of a)Ss(e),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-haazinu-gap`);let o=ys(e),s=_s.get(n)??new Map;_s.set(n,s);let c=`${r}:${o}`,l=s.get(c)??{half:0,gap:0,trailingSpace:0,sea:{},pageFirstSpanWidths:new Map},u=document.createElement(`div`);u.className=`match-shirah-measure`,u.style.font=o,u.setAttribute(`aria-hidden`,`true`);let d=document.createElement(`span`);d.className=`fragment`,d.textContent=`אשר אשר אשר`;let f=document.createElement(`span`);f.textContent=`\xA0`,u.append(d,f);let p=l.gap?[]:ms(r).map(({pageNumber:e,lineIndex:t,markup:n})=>{let r=document.createElement(`div`);r.innerHTML=n;let i=[...r.querySelectorAll(`.fragment`)];return u.append(...i),{pageNumber:e,seaLayout:Vo(e,t),fragments:i}});(p.length||!l.gap)&&document.body.append(u),l.gap||(l.gap=d.getBoundingClientRect().width,l.trailingSpace=f.getBoundingClientRect().width);for(let e of[!0,!1]){xn(u,e);for(let{pageNumber:e,seaLayout:t,fragments:n}of p){let r=n.map(e=>e.getBoundingClientRect().width);if(t){let e=l.sea[t.pattern]??[];r.forEach((t,n)=>{e[n]=Math.max(e[n]??0,t+1)}),l.sea[t.pattern]=e}else l.half=Math.max(l.half,...r),l.pageFirstSpanWidths.set(e,Math.max(l.pageFirstSpanWidths.get(e)??0,r[0]))}}u.remove(),document.fonts.check(o,`אשר`)&&s.set(c,l);let m=r===`sea`?zo(l.sea,l.gap):null;if(m){let t=Number.parseFloat(getComputedStyle(e).fontSize);a.forEach(e=>{e.style.setProperty(`--match-sea-outer`,`${m.outer/t}em`),e.style.setProperty(`--match-sea-middle`,`${m.middle/t}em`),e.style.setProperty(`--match-sea-half`,`${m.half/t}em`),e.style.setProperty(`--match-sea-extended-left`,`${m.extendedLeft/t}em`),e.style.setProperty(`--match-sea-penultimate-right`,`${m.penultimateRight/t}em`),e.style.setProperty(`--match-sea-gap`,`${l.gap/t}em`)})}r===`haazinu`&&t===`one`&&a.forEach(e=>e.style.setProperty(`--match-haazinu-page-first-span-width`,`${(l.pageFirstSpanWidths.get(Number(e.querySelector(`table`)?.dataset.pageNumber))??0)+l.trailingSpace}px`));let h=a.map(e=>e.querySelector(`tr[data-shirah-kind="${r}"] .line-content`).getBoundingClientRect()),g=i[0].querySelector(r===`haazinu`?`.reader-text-flow`:`.column`),_=r===`haazinu`?l.gap:Number.parseFloat(getComputedStyle(g).columnGap),v=n.getBoundingClientRect(),y=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),b=m?.required??2*l.half+_,x=r===`haazinu`||i.some(e=>e.querySelector(`.line-gutter.mod-aliyot`)?.textContent?.trim()),S=i[0].querySelector(`.line`),C=getComputedStyle(S).gridTemplateColumns.split(` `).map(Number.parseFloat),w=x&&(C[3]??0)>0,T=C[2]+(w?C[3]:0);if(r===`haazinu`||t===`two`){T=Math.max(T,...i.map(e=>{let t=e.querySelector(`.location-indicator.mod-verses`),n=e.querySelector(`.line-content`);return t?t.getBoundingClientRect().right-n.getBoundingClientRect().right:0}));let n=t===`two`?2:1,r=i[0].querySelector(`.line-content`),o=t===`two`?1+2*Number.parseFloat(getComputedStyle(r).columnGap):0,s=n*(b+2),c=Math.ceil(s+o),l=Math.min(y,Math.max(2,(v.width-T-c)/2)),u=t===`two`?(h[0].left+h[0].right)/2:(v.left+v.right)/2,d=t===`two`?2*Math.min(u-v.left-l,v.right-T-l-u):v.width-T-2*l,f=Math.min(1,(d-o)/s),p=t===`two`?s*f+o:Math.min(c,d),m=t===`two`?u+p/2:Math.min(u+p/2,v.right-T-l),g=Number.parseFloat(getComputedStyle(e).fontSize);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${p}px`),e.style.setProperty(`--match-shirah-inline-offset`,`${m-h[t].right}px`),e.style.setProperty(`--match-shirah-text-scale`,`${f}em`),e.style.setProperty(`--match-haazinu-gap`,`${_/g}em`),e.style.setProperty(`--match-shirah-aliyah-display`,w?`flex`:`none`)}),a}let E=Math.ceil(b+1),D=y,O=Math.min(y,Math.max(2,v.width-T-D-E)),k=Math.min(E,v.width-T-D-O),A=Math.min((v.left+v.right+k)/2,v.right-T-O);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${k}px`),e.style.setProperty(`--match-shirah-text-scale`,`${Math.min(1,k/E)}em`),e.style.setProperty(`--match-shirah-inline-offset`,`${A-h[t].right}px`),e.style.setProperty(`--match-shirah-aliyah-display`,x?`flex`:`none`)}),a}function Ts(e){gs(e);let t=new Map,n=[];for(let n of hs(e,`.reader-reading-page-side.mod-torah .word[data-token-key]`)){let e=n.dataset.tokenKey;e&&t.set(e,n)}for(let r of hs(e,`.reader-reading-page-side.mod-tikkun .word[data-token-key]`)){let e=r.dataset.tokenKey,i=e?t.get(e):void 0;if(!i)continue;let a=Number.parseFloat(getComputedStyle(r).fontSize),o=Number.parseFloat(getComputedStyle(i).fontSize),s=Math.max(a,o);if(!Number.isFinite(s)||s<=0)continue;let c=`${(Math.max(r.getBoundingClientRect().width,i.getBoundingClientRect().width)/s).toFixed(4)}em`;n.push({torah:i,tikkun:r,width:c})}for(let{torah:e,tikkun:t,width:r}of n)t.style.setProperty(`--reader-paired-word-width`,r),e.style.setProperty(`--reader-paired-word-width`,r)}function Es(e){let t=e.querySelector(`.reader-reading-page`),n=e.closest(`.tikkun-book`);if(!t||!n)return;let r=t.getBoundingClientRect();for(let t of e.querySelectorAll(`.reader-reading-page-side`)){let e=t.classList.contains(`mod-torah`)?`mod-torah`:`mod-tikkun`,i=[...n.querySelectorAll(`.reader-reading-page-side.${e} .mod-reading-line`)];for(let e of t.querySelectorAll(`.mod-reading-line`)){let t=e.querySelector(`.line-gutter.mod-verses`);if(!t?.textContent?.trim())continue;let n=i.indexOf(e),a=hs(e,`.word[data-token-key]`),o=a[Si({currentLineWords:a,previousLineWords:n>0?hs(i[n-1],`.word[data-token-key]`):[],verseOrdinal:0})]??a[0];o&&t.style.setProperty(`--reading-verse-gutter-top`,`${o.getBoundingClientRect().top-r.top}px`)}}}function Ds(e){let t=e.closest(`.tikkun-book`);if(!t)return;let n=t.getBoundingClientRect(),r=[...t.querySelectorAll(`.mod-reading-line[data-class="line"]`)];for(let i of e.querySelectorAll(`.mod-reading-line[data-class="line"]`)){let e=i.querySelector(`.line-gutter.mod-verses`);if(!e?.textContent?.trim())continue;let a=r.indexOf(i),o=hs(i,`[data-reader-canonical="true"] .word[data-token-key]`),s=o[Si({currentLineWords:o,previousLineWords:a>0?hs(r[a-1],`[data-reader-canonical="true"] .word[data-token-key]`):[],verseOrdinal:0})]??o[0];s&&e.style.setProperty(`--reading-verse-gutter-top`,`${s.getBoundingClientRect().top-n.top+t.scrollTop}px`)}}function Os(e,t){if(Ss(e),e.style.removeProperty(`--reading-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-expansion`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-aliyah-display`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-text-scale`),e.style.removeProperty(`--match-haazinu-gap`),e.style.removeProperty(`--match-ordinary-inline-size`),e.style.removeProperty(`--match-ordinary-inline-offset`),e.classList.remove(`mod-match-fitted`),e.querySelector(`table`)?.style.removeProperty(`width`),gs(e),t.layout===`match`){let n=ws(e,t.sides);xs(e,t.sides),n?.forEach(e=>Cs(e,t.sides));return}t.sides===`two`?(Ts(e),Es(e)):Ds(e)}var{htmlToElement:ks,purgeNode:As}=yn,js=.5,Ms=class{constructor(e,t){this.viewModel=e,this.root=t,this.renderPrevious=this.generateRender(`afterbegin`),this.renderNext=this.generateRender(`beforeend`),this.renderedPages=new Map,this.pageMounts=new Map,this.renderedEntries=new Map,this.pageNumberMountPromises=new Map,this.contentMountPromises=new Map,this.disposed=!1,this.accessCounter=0,this.edgeLoadingReady=!1,this.pendingInitialCenterScrollTop=null,this.edgeLoadPromise=null,this.pageLayoutFrame=0,this.presentationAnchor=null,this.handleEdgeScroll=()=>{if(this.disposed||!this.edgeLoadingReady||this.consumePendingInitialCenterScroll()||this.edgeLoadPromise)return;let e=this.getEdgeLoadDirection();if(!e)return;let t=this.loadAdjacentPage(e);this.edgeLoadPromise=t,t.catch(t=>{console.error(`Failed to load ${e} reader page`,t)}).finally(()=>{this.edgeLoadPromise===t&&(this.edgeLoadPromise=null)})},this.presentation=Ws(t),Gs(t,this.presentation),this.pageLayoutObserver=typeof ResizeObserver>`u`?null:new ResizeObserver(()=>this.schedulePageLayoutRefresh()),this.pageLayoutObserver?.observe(t),t.scrollTop=0,As(t),t.addEventListener(`scroll`,this.handleEdgeScroll,{passive:!0}),this.rendered=e.startingLocation.then(async({page:t,lineNumber:n})=>{let r=[...this.renderNext(t,{preserveViewport:!1}).querySelectorAll(`.line`)],i=n-1;if(i<r.length/2){let t=await e.fetchPreviousPage();t&&this.renderPrevious(t,{preserveViewport:!1})}else{let t=await e.fetchNextPage();t&&this.renderNext(t,{preserveViewport:!1})}return r[i]}),this.scrolled=this.rendered.then(async e=>{await Us(this.root),await new Promise(requestAnimationFrame),this.refreshMountedPageLayouts(),this.scrollTo({element:e}),this.edgeLoadingReady=!0})}destroy(){this.disposed=!0,this.edgeLoadingReady=!1,this.pendingInitialCenterScrollTop=null,this.root.removeEventListener(`scroll`,this.handleEdgeScroll),this.pageLayoutObserver?.disconnect(),this.pageLayoutFrame&&cancelAnimationFrame(this.pageLayoutFrame),this.pageLayoutFrame=0}setPresentation(e,t){if(this.presentation.layout===e.layout&&this.presentation.sides===e.sides)return!1;let n=this.getPresentationAnchor(),r=[];return this.mutatePreservingViewport(null,()=>{t?.(),this.presentation={...e},Gs(this.root,this.presentation);for(let e of this.pageMounts.values()){let t=e.node,n=t?.tikkunPage;!t||!n||e.state!==`mounted`||(t.replaceChildren(ks(as(n,{annotationsEnabled:this.annotationsEnabled(),presentation:this.presentation}))),Os(t,this.presentation),e.measuredHeight=os(t),this.touchPageRecord(e),r.push({page:n,node:t}))}for(let{page:e,node:t}of r)this.dispatchPageRendered(e,t)},n),this.presentationAnchor=n,this.presentation.layout===`reading`&&this.schedulePageLayoutRefresh(),!0}updateAnnotations(e){let t=this.getPresentationAnchor();this.mutatePreservingViewport(null,()=>{e(),this.refreshMountedPageLayouts()},t),this.presentationAnchor=t}getPresentationAnchor(){let e=this.presentationAnchor,t=e&&Bs(this.root,e);return t&&Math.abs(Hs(this.root,t,e.alignment)-e.viewportOffset)<1?e:Rs(this.root)}usesPresentation(e){return this.presentation.layout===e.layout&&this.presentation.sides===e.sides}schedulePageLayoutRefresh(){this.disposed||this.pageLayoutFrame||(this.pageLayoutFrame=requestAnimationFrame(()=>{this.pageLayoutFrame=0,this.refreshMountedPageLayouts()}))}refreshMountedPageLayouts(){for(let e of this.pageMounts.values())e.state!==`mounted`||!e.node?.isConnected||(Os(e.node,this.presentation),e.measuredHeight=os(e.node))}scrollTo({element:e}){if(this.disposed)return;let t=Ls(e)??e,n=ir(this.root,t);this.pendingInitialCenterScrollTop=n?this.root.scrollTop:null,this.root.dispatchEvent(new Event(`scroll`))}generateRender(e){return(t,{preserveViewport:n=!0}={})=>{let r=t.type===`page`&&this.pageMounts.get(t.contentIndex)?.state===`evicted`,i=()=>{let n;return n=t.type===`message`?this.mountMessageEntry(t,e):this.mountPageEntry(t,e),n},a=n?this.mutatePreservingViewport(t.contentIndex,i):i();return this.disposed?a:(t.type===`page`&&r&&this.dispatchPageRemounted(t.pageNumber,a),this.dispatchPageRendered(t,a),this.presentation.layout===`reading`&&this.schedulePageLayoutRefresh(),a)}}consumePendingInitialCenterScroll(){let e=this.pendingInitialCenterScrollTop;return e!==null&&(this.pendingInitialCenterScrollTop=null,Math.abs(this.root.scrollTop-e)<=.5)}getEdgeLoadDirection(){let e=this.root.clientHeight;return this.root.scrollTop<js*e?`previous`:this.root.scrollHeight-(e+this.root.scrollTop)<js*e?`next`:null}async loadAdjacentPage(e){let t=e===`previous`?await this.viewModel.fetchPreviousPage():await this.viewModel.fetchNextPage();return!t||this.disposed?null:e===`previous`?this.renderPrevious(t):this.renderNext(t)}ensureNextContentMounted(){return this.loadAdjacentPage(`next`)}dispatchPageRendered(e,t){this.root.dispatchEvent(new CustomEvent(`page-rendered`,{detail:{entry:e,node:t}}))}dispatchPageRemounted(e,t){this.root.dispatchEvent(new CustomEvent(`page-remounted`,{detail:{pageNumber:e,node:t}}))}mutatePreservingViewport(e,t,n=Rs(this.root)){let r=this.root.scrollHeight,i=this.root.scrollTop,a=t();return zs(this.root,n,{affectedContentIndex:e,previousScrollHeight:r,previousScrollTop:i}),a}getMountedPageNode(e){let t=this.getNearestMountedPageRecord(e);return t?.node?(this.touchPageRecord(t),t.node):null}getMountedPageNumbers(){return[...this.renderedPages.entries()].sort(([e],[t])=>e-t).flatMap(([,e])=>e.tikkunPage?[e.tikkunPage.pageNumber]:[])}getKnownPageNumbers(){return[...this.pageMounts.values()].sort((e,t)=>e.contentIndex-t.contentIndex).map(e=>e.pageNumber)}getViewportAnchorPageRecord(){let e=[...this.pageMounts.values()].filter(e=>e.state===`mounted`&&e.node?.isConnected);if(!e.length)return null;let t=this.root.getBoundingClientRect(),n=t.top+t.height/2,r=null,i=1/0;for(let t of e){let e=t.node;if(!e)continue;let a=Ps(e,n);a<i&&(i=a,r=t)}return r??e[0]??null}getViewportAnchorPageNumber(){return this.getViewportAnchorPageRecord()?.pageNumber??null}isPageMounted(e){return this.getPageRecords(e).some(e=>e.state===`mounted`&&e.node?.isConnected)}async ensurePageMounted(e,t){if(this.disposed)return null;if(t){let n=await this.viewModel.fetchPageByPageNumber(e,t);return this.disposed||!n||n.type!==`page`?null:this.mountPageByContentIndex(n.contentIndex)}return this.mountPageByNumber(e)}async ensurePageMountedForNavigation(e,t){if(this.disposed)return null;let n=await this.viewModel.fetchPageByPageNumber(e,t);if(this.disposed||!n||n.type!==`page`)return null;let r=n.contentIndex,i=this.getViewportAnchorPageRecord()?.contentIndex;if(i===void 0)return this.mountPageByContentIndex(r);let a=r>=i?1:-1,o=r===i?r:i+a,s=r+a,c=null;for(let e=o;a>0?e<=s:e>=s;e+=a){let t=e===r?n:await this.viewModel.fetchPageByContentIndex(e);if(this.disposed)return null;if(!t){if(e===s)break;return null}let i=await this.ensureRenderedEntryMounted(t);if(this.disposed)return null;e===r&&i instanceof HTMLElement&&(c=i)}return c??this.renderedPages.get(r)??null}async ensureRenderedEntryMounted(e){if(e.type===`page`)return this.mountPageByContentIndex(e.contentIndex);let t=this.renderedEntries.get(e.contentIndex);if(t?.isConnected)return t;let n=this.mutatePreservingViewport(e.contentIndex,()=>this.mountMessageEntry(e));return this.disposed||this.dispatchPageRendered(e,n),n}async mountPageByNumber(e){if(this.disposed)return null;let t=this.getNearestMountedPageRecord(e);if(t?.node)return this.touchPageRecord(t),t.node;let n=this.getPageRecords(e).find(e=>e.state===`evicted`);if(n)return this.mountPageByContentIndex(n.contentIndex);let r=this.pageNumberMountPromises.get(e);if(r)return r;let i=(async()=>{let t=await this.viewModel.fetchPageByPageNumber(e);return this.disposed||!t||t.type!==`page`?null:this.mountFetchedPage(t)})();return this.pageNumberMountPromises.set(e,i),i.then(()=>this.clearPageNumberMount(e,i),()=>this.clearPageNumberMount(e,i)),i}async mountPageByContentIndex(e){if(this.disposed)return null;let t=this.pageMounts.get(e);if(t?.state===`mounted`&&t.node?.isConnected)return this.touchPageRecord(t),t.node;let n=this.contentMountPromises.get(e);if(n)return n;let r=(async()=>{let t=await this.viewModel.fetchPageByContentIndex(e);return this.disposed||!t||t.type!==`page`?null:this.mountFetchedPage(t)})();return this.contentMountPromises.set(e,r),t&&(t.mountPromise=r),r.then(()=>this.clearContentMount(e,r),()=>this.clearContentMount(e,r)),r}clearPageNumberMount(e,t){this.pageNumberMountPromises.get(e)===t&&this.pageNumberMountPromises.delete(e)}clearContentMount(e,t){this.contentMountPromises.get(e)===t&&this.contentMountPromises.delete(e);let n=this.pageMounts.get(e);n?.mountPromise===t&&(n.mountPromise=null)}mountFetchedPage(e){let t=this.pageMounts.get(e.contentIndex);if(t?.state===`mounted`&&t.node?.isConnected)return this.touchPageRecord(t),t.node;let n=t?.state===`evicted`,r=this.mutatePreservingViewport(e.contentIndex,()=>n&&t.placeholderNode?this.mountEvictedPage(e,t):this.mountPageEntry(e,`beforeend`));return n&&this.dispatchPageRemounted(e.pageNumber,r),this.dispatchPageRendered(e,r),r}getPageRecords(e){return[...this.pageMounts.values()].filter(t=>t.pageNumber===e).sort((e,t)=>e.contentIndex-t.contentIndex)}getNearestMountedPageRecord(e){let t=this.getPageRecords(e).filter(e=>e.state===`mounted`&&e.node?.isConnected);if(t.length<=1)return t[0]??null;let n=this.root.getBoundingClientRect(),r=n.top+n.height/2;return t.reduce((e,t)=>!e.node||!t.node?e:Ps(t.node,r)<Ps(e.node,r)?t:e)}evictPage(e){if(this.disposed)return!1;let t=this.getPageRecords(e),n=!1;for(let e of t)this.evictPageRecord(e)&&(n=!0);return n}evictPageRecord(e){if(!e||e.state!==`mounted`||!e.node||e.mountPromise)return!1;let t=e.node,n=os(t)??e.measuredHeight??0,r=Fs(e.pageNumber,e.contentIndex,n);return this.mutatePreservingViewport(e.contentIndex,()=>{t.replaceWith(r),this.renderedPages.delete(e.contentIndex),this.renderedEntries.set(e.contentIndex,r),e.state=`evicted`,e.node=null,e.placeholderNode=r,e.measuredHeight=n,e.mountPromise=null,this.touchPageRecord(e)}),this.root.dispatchEvent(new CustomEvent(`page-evicted`,{detail:{pageNumber:e.pageNumber,node:t}})),!0}evictPages(e){return e.filter(e=>this.evictPage(e))}getEvictedPageNumbersNearViewport({marginPx:e=this.root.clientHeight}={}){return this.getEvictedPageRecordsNearViewport({marginPx:e}).map(e=>e.pageNumber)}getEvictedPageRecordsNearViewport({marginPx:e=this.root.clientHeight}={}){let t=this.root.getBoundingClientRect(),n=t.top-Math.max(0,e),r=t.bottom+Math.max(0,e),i=[];for(let e of this.pageMounts.values()){if(e.state!==`evicted`||!e.placeholderNode?.isConnected)continue;let t=e.placeholderNode.getBoundingClientRect();t.bottom>=n&&t.top<=r&&i.push(e)}return i.sort((e,t)=>e.contentIndex-t.contentIndex)}async ensureEvictedPagesMountedNearViewport(e){let t=this.getEvictedPageRecordsNearViewport(e),n=[];for(let e of t)await this.mountPageByContentIndex(e.contentIndex)&&n.push(e.pageNumber);return n}getPageLifecycleSnapshot(){return ss([...this.pageMounts.values()].map(e=>({pageNumber:e.pageNumber,state:e.state,measuredHeight:e.measuredHeight,lastAccessedAt:e.lastAccessedAt})))}markPageMounted(e,t){let n=this.setPageRecord(e.contentIndex,e.pageNumber,`mounted`);n.node=t,n.placeholderNode=null,n.measuredHeight=os(t),n.mountPromise=null,this.touchPageRecord(n)}setPageRecord(e,t,n){let r=this.pageMounts.get(e);if(r)return r.pageNumber=t,r.state=n,r.lastAccessedAt=this.nextAccessToken(),n!==`mounted`&&(r.node=null,n!==`evicted`&&(r.placeholderNode=null,r.measuredHeight=null)),n!==`mounting`&&(r.mountPromise=null),r;let i={contentIndex:e,pageNumber:t,state:n,node:null,placeholderNode:null,measuredHeight:null,lastAccessedAt:this.nextAccessToken(),mountPromise:null};return this.pageMounts.set(e,i),i}touchPageRecord(e){e.lastAccessedAt=this.nextAccessToken(),e.node&&(e.measuredHeight=os(e.node))}nextAccessToken(){return this.accessCounter+=1,this.accessCounter}mountPageEntry(e,t){if(this.disposed)return Ns(e,this.annotationsEnabled(),this.presentation);let n=this.pageMounts.get(e.contentIndex);if(n?.state===`mounted`&&n.node?.isConnected)return this.touchPageRecord(n),n.node;if(n?.state===`evicted`&&n.placeholderNode?.isConnected)return this.mountEvictedPage(e,n);let r=Ns(e,this.annotationsEnabled(),this.presentation);return this.insertEntryNodeInOrder(e.contentIndex,r,t),Os(r,this.presentation),this.renderedPages.set(e.contentIndex,r),this.renderedEntries.set(e.contentIndex,r),this.markPageMounted(e,r),r}mountMessageEntry(e,t=`beforeend`){let n=this.renderedEntries.get(e.contentIndex);if(n?.isConnected)return n;let r=Is(e);return this.disposed?r:(this.insertEntryNodeInOrder(e.contentIndex,r,t),this.renderedEntries.set(e.contentIndex,r),r)}insertEntryNodeInOrder(e,t,n=`beforeend`){let r=this.getNextKnownEntryDomNode(e);r?this.root.insertBefore(t,r):this.root.insertAdjacentElement(n,t)}getNextKnownEntryDomNode(e){let t=1/0,n=null;for(let[r,i]of this.renderedEntries)r<=e||r>=t||!i.isConnected||(t=r,n=i);return n}mountEvictedPage(e,t){let n=Ns(e,this.annotationsEnabled(),this.presentation);return this.disposed?n:(t.placeholderNode?.replaceWith(n),Os(n,this.presentation),this.renderedPages.set(e.contentIndex,n),this.renderedEntries.set(e.contentIndex,n),this.markPageMounted(e,n),n)}annotationsEnabled(){return this.root.classList.contains(`mod-annotations-on`)}};function Ns(e,t,n){let r=document.createElement(`div`);return r.classList.add(`tikkun-page`),r.dataset.contentIndex=`${e.contentIndex}`,r.tikkunPage=e,r.appendChild(ks(as(e,{annotationsEnabled:t,presentation:n}))),r}function Ps(e,t){let n=e.getBoundingClientRect();return n.top<=t&&n.bottom>=t?0:Math.min(Math.abs(n.top-t),Math.abs(n.bottom-t))}function Fs(e,t,n){let r=document.createElement(`div`);return r.className=`tikkun-page-placeholder`,r.dataset.pagePlaceholder=`${e}`,r.dataset.contentIndex=`${t}`,r.setAttribute(`aria-hidden`,`true`),r.style.minHeight=`${Math.max(0,n)}px`,r.style.height=`${Math.max(0,n)}px`,r}function Is(e){let t=document.createElement(`div`);t.classList.add(`tikkun-message`),t.dataset.contentIndex=`${e.contentIndex}`;let n=document.createElement(`span`);return n.classList.add(`tikkun-message-text`),n.textContent=e.text,t.appendChild(n),t}function Ls(e){return[...e.querySelectorAll(`.word`)].find(e=>{let t=e.getBoundingClientRect();return t.width>0&&t.height>0})??null}function Rs(e){let t=tr(e),n=null,r=1/0,i=[...e.querySelectorAll(`[data-reader-canonical="true"] .word:not([hidden])`)].filter(Vs),a=i.length?i:e.querySelectorAll(`[data-class="line"]`);for(let e of a){let i=e.getBoundingClientRect(),a=Math.abs((i.top+i.bottom)/2-t);a>=r||(n=e,r=a)}if(!n)return null;let o=Number(n.closest(`[data-content-index]`)?.dataset.contentIndex),s=Number(n.dataset.pageNumber),c=Number(n.dataset.lineIndex);if(!Number.isInteger(o)||!Number.isInteger(s)||!Number.isInteger(c))return null;let l=Ls(n)??n,u=l.matches(`.word`)?`center`:`top`;return{contentIndex:o,pageNumber:s,lineIndex:c,tokenKey:l.dataset.tokenKey??null,alignment:u,viewportOffset:Hs(e,l,u)}}function zs(e,t,{affectedContentIndex:n,previousScrollHeight:r,previousScrollTop:i}){if(!t)return;let a=e.querySelector(`[data-content-index="${t.contentIndex}"]`),o=Bs(e,t),s=a?.querySelector(`[data-page-number="${t.pageNumber}"][data-line-index="${t.lineIndex}"]`),c=o??s;if(c){let n=o?t.alignment:`top`;for(let r=0;r<2;r+=1){let r=Hs(e,c,n)-t.viewportOffset;if(Math.abs(r)<=.5)break;e.scrollTop+=r}return}n!==null&&n<t.contentIndex&&(e.scrollTop=i+(e.scrollHeight-r))}function Bs(e,t){return t.tokenKey?[...e.querySelector(`[data-content-index="${t.contentIndex}"]`)?.querySelectorAll(`[data-reader-canonical="true"] .word`)??[]].find(e=>e.dataset.tokenKey===t.tokenKey&&Vs(e))??null:null}function Vs(e){let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function Hs(e,t,n){let r=t.getBoundingClientRect();return(n===`center`?(r.top+r.bottom)/2:r.top)-tr(e)}async function Us(e){let t=document.fonts;if(!t)return;let n=e.querySelector(`.tikkun-page`);n&&await t.load(ys(n),`אשר`),await t.ready}function Ws(e){return{layout:lr(e.dataset.readerLayout)?e.dataset.readerLayout:cr.layout,sides:ur(e.dataset.readerSides)?e.dataset.readerSides:cr.sides}}function Gs(e,t){e.dataset.readerLayout=t.layout,e.dataset.readerSides=t.sides}var Ks=class{constructor(){this.generation=0,this.activeController=null}begin(){this.activeController?.abort();let e=++this.generation,t=new AbortController;return this.activeController=t,{generation:e,signal:t.signal,isCurrent:()=>this.generation===e&&this.activeController===t&&!t.signal.aborted}}cancel(){this.generation+=1,this.activeController?.abort(),this.activeController=null}},qs=class extends ka{constructor(e){super(),this.handleScroll=()=>this.scheduleUpdate(),this.destroyed=!1,this.updateFrame=0,this.book=e,this.lineTrackers={first:new Zs(Js.Down,e),center:new Zs(Js.Down,e),last:new Zs(Js.Up,e)},this.update(),e.addEventListener(`scroll`,this.handleScroll)}refresh(){this.destroyed||(this.updateFrame&&=(cancelAnimationFrame(this.updateFrame),0),this.update(!0))}destroy(){this.destroyed||(this.destroyed=!0,this.book.removeEventListener(`scroll`,this.handleScroll),this.updateFrame&&=(cancelAnimationFrame(this.updateFrame),0))}scheduleUpdate(){this.destroyed||this.updateFrame||(this.updateFrame=requestAnimationFrame(()=>{this.updateFrame=0,!(this.destroyed||!this.book.isConnected)&&this.update()}))}update(e=!1){let t=!1,n=this.book.getBoundingClientRect(),r=parseFloat(getComputedStyle(this.book).paddingTop),i=document.documentElement.clientHeight-1,a=e=>Math.max(0,Math.min(i,e)),o=a(n.top+r),s=a(tr(this.book)),c=a(n.bottom-1);this.lineTrackers.first.update(o,e)&&(t=!0),this.lineTrackers.center.update(s,e)&&(t=!0),this.lineTrackers.last.update(c,e)&&(t=!0),(t||e)&&this.emit(`viewport-updated`,{first:this.lineTrackers.first.current,center:this.lineTrackers.center.current,last:this.lineTrackers.last.current})}},Js={Down:{coordinate:`top`,nextElement:`nextNode`},Up:{coordinate:`bottom`,nextElement:`previousNode`}},Ys={[-1]:Js.Up,1:Js.Down},Xs=Math.sign,Zs=class{constructor(e,t){this.direction=e,this.root=t,this.walker=document.createTreeWalker(t,NodeFilter.SHOW_ELEMENT,e=>!(e instanceof HTMLElement)||e.tagName===`TD`?NodeFilter.FILTER_REJECT:e.dataset.lineIndex?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP)}get current(){return Qs(this.walker.currentNode)}resetWalker(e){let t=document.elementFromPoint(document.documentElement.clientWidth/2,e)?.closest(`[data-line-index]`);this.walker.currentNode=t&&this.root.contains(t)?t:this.root,this.walker.currentNode===this.root&&this.walker.nextNode()}update(e,t=!1){let n=this.current;return t&&this.resetWalker(e),this.maybeUpdate(e),n!==this.current}maybeUpdate(e){if(this.walker.currentNode===this.root&&this.resetWalker(e),this.root.contains(this.walker.currentNode)||this.resetWalker(e),!(this.walker.currentNode instanceof Element))throw Error(`Not an element?`);let t=!0,n=Xs(0);for(;;){let r=e-this.walker.currentNode.getBoundingClientRect()[this.direction.coordinate];if(Math.abs(r)<.8*this.walker.currentNode.clientHeight)break;if(t&&Math.abs(r)>100){this.resetWalker(e),t=!1;continue}if(t=!1,n&&n!==Xs(r)||(n=Xs(r),!n))break;let i=this.walker.currentNode;if(this.walker[Ys[n].nextElement](),this.walker.currentNode===i)break}let r=0;for(;!Qs(this.walker.currentNode)?.aliyot.length&&++r<40;)this.walker[this.direction.nextElement]()}};function Qs(e){return e instanceof HTMLElement?e.closest(`.tikkun-page`)?.tikkunPage?.lines[Number(e.dataset.lineIndex)]??null:null}var $s={viewportRadius:2,playbackForwardPageCount:2},ec=[`viewport`,`rail-target`,`playback`,`initial-neighbor`];function tc({mountedPageNumbers:e,viewportPageNumber:t=null,railTargetPageNumber:n=null,playbackPageNumbers:r=[],initialNeighborPageNumbers:i=[],config:a={}}){let o=rc(a),s=ic(e),c=new Map;if(ac(t))for(let e=t-o.viewportRadius;e<=t+o.viewportRadius;e+=1)oc(c,e,`viewport`);ac(n)&&oc(c,n,`rail-target`),ic(r).slice(0,o.playbackForwardPageCount+1).forEach(e=>{oc(c,e,`playback`)}),ic(i).forEach(e=>{oc(c,e,`initial-neighbor`)});let l=[...c.keys()].sort((e,t)=>e-t),u=new Set(l);return{config:o,retainedPages:l,evictionCandidates:s.filter(e=>!u.has(e)),retainReasons:l.map(e=>({pageNumber:e,reasons:sc(c.get(e)??new Set)}))}}function nc({enabled:e,policy:t,evictPages:n}){return e?{enabled:e,evictedPages:n(t.evictionCandidates)}:{enabled:e,evictedPages:[]}}function rc(e){return{viewportRadius:Math.max(0,Math.floor(e.viewportRadius??$s.viewportRadius)),playbackForwardPageCount:Math.max(0,Math.floor(e.playbackForwardPageCount??$s.playbackForwardPageCount))}}function ic(e){return[...new Set(e.filter(ac))].sort((e,t)=>e-t)}function ac(e){return Number.isInteger(e)&&Number(e)>0}function oc(e,t,n){if(!ac(t))return;let r=e.get(t)??new Set;r.add(n),e.set(t,r)}function sc(e){return ec.filter(t=>e.has(t))}var cc={viewportRadius:2,playbackForwardPageCount:2},lc=2,uc=1400;function dc({search:e,frame:t,timer:n,getPlaybackProtectedPageNumbers:r,refreshViewport:i,invalidateReaderPosition:a,config:o=cc}){let s=new URLSearchParams(e).get(`virtualizePages`)===`1`,c=tc({mountedPageNumbers:[],config:o}).config,l=null,u=0,d=null,f=null,p=0,m=0,h=0,g=0,_=null,v=!1,y=new Set;function b(e,t){return!v&&l===e&&u===t}function x(){return!!(l&&d===l)}function S(){let e=l;return e?tc({mountedPageNumbers:e.getMountedPageNumbers(),viewportPageNumber:e.getViewportAnchorPageNumber(),railTargetPageNumber:f,playbackPageNumbers:[...r(c.playbackForwardPageCount)],config:c}):null}function C(){let e=l;if(!e||!x())return;let t=S();t&&nc({enabled:s&&p===0,policy:t,evictPages:t=>e.evictPages(t)})}function w(){if(v)return()=>!1;p+=1;let e=!1;return()=>!e&&(e=!0,p=Math.max(0,p-1),!0)}function T(){let e=w();return{release(){e()&&p===0&&_&&k()}}}function E(){let e=w(),t=!1,r=0,i=()=>{t||(t=!0,r&&(n.clear(r),y.delete(r)),e()&&p===0&&C())};return{release:i,releaseAfterNavigation(){let e=n.set(()=>{y.delete(e),i()},uc);r=e,y.add(e)}}}function D(){m&&=(t.cancel(m),0)}function O({clearPending:e=!0}={}){e&&(_=null),h&&=(t.cancel(h),0)}function k(){let e=_;if(!e||!b(e.display,e.generation)||!x()){_=null;return}h||=t.request(()=>{h=0;let e=_;if(!e||e.scrollRevision!==g||!b(e.display,e.generation)||!x()){_=null;return}p>0||(_=null,C())})}function A(e,t){!b(e,t)||!x()||(_={display:e,generation:t,scrollRevision:g},k())}async function j(){let e=l,t=u;if(!e||!b(e,t))return[];let n=e.root.clientHeight*lc;if(!e.getEvictedPageNumbersNearViewport({marginPx:n}).length)return[];let r=T(),o=[];try{o=await e.ensureEvictedPagesMountedNearViewport({marginPx:n}),b(e,t)&&(i(),a())}finally{r.release()}return o.length>0&&A(e,t),o}return{replaceDisplay(e){v||(l=e,u+=1,f=null,d=null,D(),O(),g=0)},markReady(e){v||l!==e||(d=e)},setRailTarget(e){v||(f=e)},pauseEviction:T,holdNavigation:E,onReaderScroll(){v||!x()||(g+=1,_&&={..._,scrollRevision:g},O({clearPending:!1}),!m&&(m=t.request(()=>{m=0,j().catch(e=>{console.error(`Failed to remount pages near the reader viewport`,e)}).finally(k)})))},afterPageRendered(){C()},destroy(){v||(v=!0,D(),O(),y.forEach(e=>n.clear(e)),y.clear(),l=null,d=null,u+=1,p=0)}}}var fc=[`viewport-title`,`inline-audio`,`reader-position`,`playback-state`];function pc({frame:e,present:t}){let n=new Set,r=new Set,i=null,a=!1,o=0,s=e=>fc.filter(t=>e.has(t)),c=()=>i===null&&(i=e.request(()=>{if(i=null,a)return;let e=Object.freeze(s(n));n.clear();try{e.length>0&&(o+=1,t(Object.freeze({revision:o,invalidations:e})))}finally{if(r.size>0){for(let e of r)n.add(e);r.clear()}n.size>0&&c()}}),!0);return{invalidate(...e){if(!(a||e.length===0)){for(let t of e)n.add(t);c()}},invalidateAfterLayout(...e){if(!(a||e.length===0)){for(let t of e)r.add(t);c()}},destroy(){a||(a=!0,n.clear(),r.clear(),i!==null&&e.cancel(i),i=null)}}}var mc=`[data-line-index][data-aliyah-starts]:not([data-reader-mirror])`;function hc(e,t){let n=!1,r=!0,i=0,a=null,o=new Map,s=()=>{if(n)throw Error(`Reader progress anchor index has been destroyed`)},c=(e,t)=>{if(e.length===0)return Object.freeze({index:-1,current:null,next:null});let n=0,r=e.length;for(;n<r;){let i=n+Math.floor((r-n)/2);e[i].position<=t?n=i+1:r=i}let i=Math.max(0,n-1);return Object.freeze({index:i,current:e[i]??null,next:e[i+1]??null})},l=e=>{let t=e.closest(`.tikkun-page`);return t?t.tikkunPage?.lines[Number(e.dataset.lineIndex)]??null:null},u=()=>{let n=t?.now(),s=e.getBoundingClientRect(),u=[...e.querySelectorAll(mc)],d=new Map,f=u.map((t,n)=>{let r=t.getBoundingClientRect(),i=t.querySelector(`.aliyah-label-text`)?.textContent?.trim()??`—`,a=(t.dataset.aliyahStarts??``).split(`,`),o=Bi(a[a.length-1]),c=l(t);return{anchor:Object.freeze({line:t,label:a.includes(`1`)?`ראשון`:i,run:c?.run??null,aliyahIndex:o,position:e.scrollTop+(r.top-s.top)}),sourceIndex:n}}).sort((e,t)=>e.anchor.position-t.anchor.position||e.sourceIndex-t.sourceIndex).map(({anchor:e})=>e),p=Object.freeze(f),m=i+1,h=Object.freeze({revision:m,anchors:p,at:e=>c(p,e)});for(let e of p)e.line&&d.set(e.line,e);return i=m,o=d,a=h,r=!1,t&&n!==void 0&&t.measure(`tikkun:reader:progress-anchor-rebuild`,{start:n,end:t.now(),detail:{anchorCount:p.length}}),h},d=()=>(s(),!r&&a?a:u());return{snapshot:d,anchorForElement(t){s();let n=t.closest(`[data-line-index]`);if(!n)return null;let r=d(),i=o.get(n);if(i)return i;let a=e.getBoundingClientRect(),c=n.getBoundingClientRect(),l=e.scrollTop+(c.top-a.top);return r.at(l).current},invalidate(){n||(r=!0)},destroy(){n||(n=!0,r=!1,a=null,o.clear())}}}var gc=900;function _c({document:e,view:t,root:n,search:r,frame:i,timer:a,background:o,effects:s,factories:c=vc()}){let l=new URLSearchParams(r).get(`debugPerformance`)===`1`?t.performance:void 0,u=new Ks,d=new Pi,f=new Map,p=new Map,m=hc(n,l),h=null,g=null,_=null,v=null,y=0,b=null,x=null,S=!1,C=pc({frame:i,present:({invalidations:e})=>{if(!l){s.present(e);return}let t=l.now();try{s.present(e)}finally{l.measure(`tikkun:reader:presentation`,{start:t,end:l.now(),detail:{invalidations:e}})}}}),w=null,T=dc({search:r,frame:i,timer:a,getPlaybackProtectedPageNumbers:e=>s.getPlaybackProtectedPageNumbers(e),refreshViewport:()=>w?.refresh(),invalidateReaderPosition:()=>C.invalidate(`reader-position`)});w=c.viewport(n);let E=w.on(`viewport-updated`,e=>{!h||n.style.visibility===`hidden`||(_=e,C.invalidate(`viewport-title`,`reader-position`))});function D(e,t){return!S&&h===e&&g===t&&t.isCurrent()}function O(e,t){let n={generation:t.generation,signal:t.signal,viewModel:e.viewModel,rendered:e.rendered,scrolled:e.scrolled,isCurrent:()=>D(e,t),getMountedPageNode:t=>e.getMountedPageNode(t),ensurePageMounted:(t,n)=>e.ensurePageMounted(t,n),ensurePageMountedForNavigation:(t,n)=>e.ensurePageMountedForNavigation(t,n),ensureNextContentMounted:()=>e.ensureNextContentMounted()};return Object.freeze(n)}function k(){let e=h,t=g;return!e||!t||!D(e,t)?null:O(e,t)}function A(){x?.pause(),x?.removeAttribute(`src`),x?.load(),x=null}function j(){y&&=(o.cancel(y),0)}function M(){m.invalidate(`reader-model`),d=new Pi,f.clear(),p.clear(),s.resetDisplayResources(),j(),b=null,A(),v=null}function N(e){return new Promise(t=>{let n=e=>{if(e<=0){t();return}i.request(()=>n(e-1))};n(e)})}function P(e){h?.destroy(),_=null,s.beforeDisplayReplacement(),M(),s.afterDisplayReplacementReset();let t=u.begin();g=t,n.style.visibility=`hidden`,n.setAttribute(`aria-busy`,`true`);let r=c.display(e,n);h=r,T.replaceDisplay(r),s.displayCreated(r);let i=r.rendered,a=r.scrolled.then(async()=>{D(r,t)&&(T.markReady(r),await N(2),D(r,t)&&(n.style.visibility=``,n.removeAttribute(`aria-busy`),w?.refresh()))});return a.catch(e=>{h===r&&(n.style.visibility=``,n.removeAttribute(`aria-busy`)),s.reportError(``,e)}),{ready:i,complete:a,isCurrent:()=>D(r,t),getMountedPageNode:e=>r.getMountedPageNode(e)}}function F(){u.cancel(),g=null,s.displayDeactivating(),h?.destroy(),h=null,T.replaceDisplay(null),M()}function ee(e,t){return`${e}:${t}`}function I(e,t){return`${e}:${t}`}function L(e){let[t]=e.split(`:`).map(Number);return Number.isInteger(t)?t:null}function R(e){let t=e.closest(`[data-page-number]`),n=Number(t?.dataset.pageNumber);return Number.isInteger(n)&&n>0?n:null}function te(e,t){return`[data-aliyah-marker="true"][data-run-id="${e}"][data-aliyah-index="${t}"]`}function ne(e){Ii(e).forEach(e=>{let t=Number(e.dataset.pageNumber),n=Number(e.dataset.lineIndex);Number.isFinite(t)&&Number.isFinite(n)&&p.set(I(t,n),e)}),e.querySelectorAll(`[data-aliyah-marker="true"]`).forEach(e=>{let t=e.dataset.runId,n=Bi(e.dataset.aliyahIndex);!t||!n||f.set(ee(t,n),e)})}function z(e){for(let[t]of p)L(t)===e&&p.delete(t);for(let[t,n]of f)(R(n)===e||!n.isConnected)&&f.delete(t)}function re(e,t){return t.viewModel.relevantRuns.find(t=>t.id===e)??s.resolveRun(e)}async function B(e,t,n=k()){if(!n)return null;let r=re(e,n);return r?d.get(n.viewModel,r,t):null}function V(t,n){let r=ee(t,n),i=f.get(r);if(i?.isConnected)return i;let a=e.querySelector(te(t,n));return a?f.set(r,a):f.delete(r),a}function ie(e,t=k(),n){if(!t)return null;let r=Fi(e);if(n)return Li(n,r);let i=I(e.pageNumber,r),a=p.get(i);if(a?.isConnected)return a;let o=t.getMountedPageNode(e.pageNumber),s=o?Li(o,r):null;return s&&p.set(i,s),s}async function H(e,t){let n=k();if(!n)return null;let r=V(e,t);if(r)return T.setRailTarget(R(r)),{element:r,marker:r};let i=await B(e,t,n);if(!n.isCurrent())return null;if(i){T.setRailTarget(i.pageNumber);let a=await n.ensurePageMountedForNavigation(i.pageNumber,{runId:e});if(!n.isCurrent())return null;if(r=V(e,t),r)return{element:r,marker:r};let o=a?ie(i,n,a):null;if(o)return{element:o,marker:null}}for(;!r;){if(!n.isCurrent())return null;let i=await n.ensureNextContentMounted();if(!n.isCurrent()||!i)return null;r=V(e,t)}return{element:r,marker:r}}function U(e){let t=k();if(!t)return Promise.resolve();if(v)return v;let n=(async()=>{let n=m.snapshot().anchors;for(;t.isCurrent()&&n.length<=e+1;){let e=await t.ensureNextContentMounted();if(!t.isCurrent()||!e)break;n=m.snapshot().anchors}})().finally(()=>{v===n&&(v=null)});return v=n,n}function W(e){let n=e?new URL(e,t.location.href).href:null;if(x?.src===n||(A(),!e))return;let r=c.audio();r.preload=`metadata`,r.src=e,r.load(),x=r}function G(e,t){let n=k();if(!n||t===b)return;b=t,j();let r=0,i=new Set,a=()=>{if(y=0,!n.isCurrent()||t!==b)return;if(s.isPlaybackActive()){y=o.delay(a,gc);return}let c=e[r];c&&(r+=1,(async()=>{let e=await d.get(n.viewModel,c.run,c.aliyahIndex),t=e?`${c.run.id}:${e.pageNumber}`:null;e&&t&&!i.has(t)&&n.isCurrent()&&(i.add(t),await n.viewModel.fetchPageByPageNumber(e.pageNumber,{runId:c.run.id})),n.isCurrent()&&await s.prewarmCueData(c)})().catch(e=>{s.reportError(`Failed to prewarm aliyah resources`,e)}).finally(()=>{r<e.length&&n.isCurrent()&&t===b&&(y=o.request(a))}))};n.scrolled.then(()=>{!n.isCurrent()||t!==b||(y=o.request(a))})}return{render:P,deactivate:F,capture:k,isReaderReady:()=>k()!==null,async waitUntilReaderReady(){let e=k();e&&(await e.rendered,await e.scrolled)},viewportRange:()=>_,resetViewport(){_=null},refreshViewport(){w?.refresh()},setPagePresentation(e,t){return!h||h.usesPresentation(e)||(p.clear(),f.clear(),!h.setPresentation(e,t))?!1:(m.invalidate(`text-layout`),w?.refresh(),C.invalidateAfterLayout(`reader-position`),!0)},updateAnnotations(e){h?h.updateAnnotations(e):e(),m.invalidate(`annotations`),w?.refresh(),C.invalidateAfterLayout(`reader-position`)},progressSnapshot:()=>m.snapshot(),progressAnchorForElement:e=>m.anchorForElement(e),invalidateProgressAnchors:e=>m.invalidate(e),ensureNextProgressAnchorLoaded:U,invalidatePresentation:(...e)=>C.invalidate(...e),invalidatePresentationAfterLayout:(...e)=>C.invalidateAfterLayout(...e),onReaderScroll(e){e(),C.invalidate(`reader-position`),T.onReaderScroll()},pageRendered(e,t){l?.mark(`tikkun:reader:page-rendered`,{detail:{generation:g?.generation??null}}),ne(e),t(),m.invalidate(`page-rendered`),T.afterPageRendered(),C.invalidateAfterLayout(`reader-position`)},pageEvicted(e){l?.mark(`tikkun:reader:page-evicted`,{detail:{generation:g?.generation??null,pageNumber:e}}),m.invalidate(`page-evicted`),C.invalidateAfterLayout(`reader-position`),e!==null&&z(e)},getRenderedLineForLocation:ie,ensureAliyahDomTargetRendered:H,pauseEviction:()=>T.pauseEviction(),holdNavigation:()=>T.holdNavigation(),syncAudioPreload:W,scheduleResourcePrewarm:G,destroy(){S||(S=!0,u.cancel(),g=null,h?.destroy(),h=null,M(),E(),w?.destroy(),w=null,_=null,C.destroy(),m.destroy(),T.destroy())}}}function vc(){return{display:(e,t)=>new Ms(e,t),viewport:e=>new qs(e),audio:()=>new Audio}}function yc({source:e,viewportPosition:t,getScrollHeight:n,rangeCurrent:r,isLastAnchor:i}){let a=e.anchors;if(a.length===0)return Object.freeze({kind:`empty`,current:null,label:`Loading`,progressIndex:-1,percent:0,requestNextAnchor:null});let{index:o,current:s}=e.at(t),c=r??s,l=c?.line!==null&&c?.line!==void 0?a.findIndex(e=>e.line===c.line):o,u=l>=0?l:o,d=a[u]??s,f={current:c,label:c?.label??`—`,progressIndex:u};if(!d)return Object.freeze({...f,kind:`ready`,percent:0,requestNextAnchor:null});let p=u+1;for(;a[p]?.position<=d.position;)p+=1;let m=a[p]?.position??(i(d)?Math.max(d.position+1,n()):null);if(m===null)return Object.freeze({...f,kind:`request-next-anchor`,percent:null,requestNextAnchor:Object.freeze({afterIndex:u})});let h=Math.max(0,Math.min(1,(t-d.position)/(m-d.position)));return Object.freeze({...f,kind:`ready`,percent:h*100,requestNextAnchor:null})}function bc(){return`
    <main class="page-not-found">
      <p class="page-not-found-eyebrow">Reader</p>
      <h1>Page Not Found</h1>
      <p>This passage isn't available. Return to the Reading Index to choose another place.</p>
      <button class="page-not-found-action" data-target-id="open-reading-index" type="button">
        Open Reading Index
      </button>
    </main>
  `}async function xc(e,{signal:t,load:n=()=>P(()=>import(`./Ft8YMWpR.js`),__vite__mapDeps([24,25,8,1,10,7,9,13,2,5,6,11,26]),import.meta.url)}){let r=await n();t.aborted||(e.innerHTML=r.default(),!t.aborted&&await r.mountCueAnalyticsPage(e,{signal:t}))}var Sc=`תיקון קוראים`;function Cc(e){return e?.replace(/^פרשת /,``)??`תיקון קוראים`}var wc=`#/next`,Tc=`תיקון קוראים`;function Ec(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Route requires ${t}`);return n}function Dc(e){if(!e)return null;let[,t]=e.match(/^#\/(?:torah|esther)\/page\/(\d+)$/)??[];if(!t)return null;let n=Number(t);return Number.isInteger(n)?n:null}function Oc(e,t){let{document:n,view:r,shell:i,host:a}=t,o=Ec(n,`[data-target-id="about-view"]`),s=Ec(n,`[data-target-id="reader-shell"]`),c=!1,l=null,u=()=>{l?.resolve(),l=null},d=null,f=null,p=!1,m=0,h=null,g=!1,_=null,v=null,y=null,b=wc,x=Sc,S=!1,C=null,w=null,T=null,E=(e=r.location.hash)=>e.split(`?`,1)[0],D=e=>Me(t.createGenerator(),E(e).replace(/^#/,``)),O=()=>D(r.location.hash),k=e=>{x=e,i.setTitle(e)},A=()=>{d?.abort(),d=null},j=()=>{f?.destroy(),f=null},M=()=>{let e=!!f||p,t=T,r=_===`not-found`&&O()?.view===`not-found`;m+=1,p=!1,_=null,w=null,T=null,g=!1,j(),i.setPickerOpen(!1),a.pickerChanged(!1),r&&i.setView(`optional`),e&&(t?.focus({preventScroll:!0}),n.activeElement!==t&&i.focusTitle())},N=(e,t={})=>{if(C=t.offerReturnToPreviousReading?w??a.captureReadingPosition():null,t.saveReadingAfterRender&&(S=!0,a.dismissLastReadingPrompt()),(f||p)&&M(),r.location.hash===e){let t=D(e);t&&U(t);return}r.location.hash=e},F=e=>{let t=E(e);if(!c||y===null||!i.isReaderVisible()||!t||t===y&&t===E())return!1;let n=D(t);if(n?.view!==`reader`)return!1;let a=I(y,n.canonicalHash??t);if(!a)return!1;let o=new URL(r.location.href);o.hash=a;let s=o.href!==r.location.href;return s&&r.history.replaceState(r.history.state,``,o),y=a,b=a,s},ee=()=>(h??=(t.loadParshaPicker??(()=>P(()=>import(`./DKcmOp2B.js`),__vite__mapDeps([27,1,2,13,5,6,7,8,9,10,11,28,3,4,12,29]),import.meta.url)))().catch(e=>{throw h=null,e}),h),L=()=>{let e=_===`not-found`&&O()?.view===`not-found`;_=null,g=!1,i.setPickerOpen(!1),a.pickerChanged(!1),e&&i.setView(`optional`)},R=(r=null,{animate:o=!1,focusSearch:c=!o}={})=>{T=n.activeElement instanceof HTMLElement?n.activeElement:null,j();let l=o,u=++m;p=!0,g=c,_=r,w=a.captureReadingPosition(),a.preparePicker(),ee().then(({default:n})=>{if(e.signal.aborted||u!==m||!p)return;let r=n(t.createGenerator(),{calendarSettings:t.getCalendarSettings(),animateOnOpen:l,onCalendarSettingsChange:e=>{if(t.updateCalendarSettings(e),!f)return;let n=_;M(),R(n)},navigate:e=>{N(e,{saveReadingAfterRender:!0,offerReturnToPreviousReading:!0})},getActions:t.getSearchActions,requestClose:M,isBookmarkAction:t.isBookmarkAction,formatBadge:t.formatSearchBadge});try{s.appendChild(r.node),r.onMount(),f=r,p=!1,_===`not-found`&&i.setView(`reader`),i.setPickerOpen(!0),a.pickerChanged(!0);let e=g;g=!1,e?r.focusSearch():r.node.focus({preventScroll:!0})}catch(e){if(r.destroy(),u!==m)return;p=!1,L(),a.pickerLoadFailed(e)}}).catch(t=>{e.signal.aborted||u!==m||(p=!1,L(),a.pickerLoadFailed(t))})},te=(e={})=>{let t=O(),n=!!(v?.isCurrent()&&i.isReaderVisible());if(t?.view!==`reader`&&!n){N(b);return}f||p?M():R(null,e)},ne=()=>f?(f.focusSearch(),!0):p?(g=!0,!0):!1,z=()=>{f?.refreshSearch()},re=(e,t)=>{let n=Dc(e);if(!n)return;let i=t.getMountedPageNode(n)?.querySelector(`.tikkun-page-number`);i&&(i.classList.remove(`mod-route-reveal`),i.offsetWidth,i.classList.add(`mod-route-reveal`),r.setTimeout(()=>{i.classList.remove(`mod-route-reveal`)},1900))},B=()=>{v=null,a.leaveReader(),A()},V=()=>{B(),M(),i.setView(`optional`),o.innerHTML=bc(),Ec(n,`[data-target-id="open-reading-index"]`).addEventListener(`click`,()=>{R(`not-found`,{animate:!0})},{signal:e.signal}),k(Tc)},ie=e=>{if(B(),e.view===`about`){a.openAbout();return}i.setView(`optional`),o.innerHTML=`<section class="about-card" aria-busy="true"><h2>Loading Cue Analytics</h2></section>`;let t=new AbortController;d=t,xc(o,{signal:t.signal}).catch(e=>{t.signal.aborted||(console.error(`Failed to load Cue Data analytics`,e),o.innerHTML=`<section class="about-card"><h2>Analytics unavailable</h2><p>Reload this page to try again.</p></section>`)}),k(Tc)},H=(e,t)=>{A(),k(Cc(e.model.initialTitle)),i.setView(`reader`),o.innerHTML=``;let n=(e.canonicalHash??E())||b,s=new URL(r.location.href);s.hash=n,s.href!==r.location.href&&r.history.replaceState(null,``,s);let c=y!==null&&y!==n;c&&a.readerRouteChanged(n),c&&(f||p)&&M(),y=n,b=n;let d=a.renderReader(e.model);v=d;let m=S;S=!1;let h=()=>v===d&&d.isCurrent(),g=d.ready.then(()=>{h()&&(a.readerReady(),t&&t.hash!==n&&a.showReturnToPreviousReading(t))});Promise.all([g,d.complete]).then(()=>{h()&&(m&&a.saveReadingPosition(),re(n,d),u())}).catch(e=>{h()&&(console.error(`Failed to render reader route`,e),l?.reject(e),l=null)})};function U(e){let t=C;if(C=null,e.view===`not-found`){V(),u();return}if(e.view===`about`||e.view===`cue-analytics`){ie(e),u();return}H(e,t)}return e.own(()=>{A(),l=null,v=null,m+=1,p=!1,h=null,C=null,w=null,j()}),{start:n=>{if(c)throw Error(`Reader Route is already started`);c=!0;let i=new Promise((e,t)=>{l={resolve:e,reject:t}});r.addEventListener(`hashchange`,()=>{let e=O();e?U(e):C=null},{signal:e.signal});let a=!r.location.hash&&n!==void 0,o=a?n.resumeHash:null,s=o?D(o):null,u=o&&s?.view===`reader`?{...s,canonicalHash:s.canonicalHash??E(o)}:null;return U(u??O()??{view:`reader`,canonicalHash:wc,model:Ke.forDate(t.createGenerator(),new Date)}),a&&!u&&R(null,{focusSearch:!1}),i},navigate:N,syncScrolledReading:F,toggleAbout:()=>{a.openAbout()},togglePicker:te,focusPickerSearch:ne,refreshPickerSearch:z,closePicker:M,setTitle:k,snapshot:()=>({view:O()?.view??null,hashPath:E(),currentReaderHash:y,title:x,pickerOpen:!!f||p})}}function kc(e,t){let n=t.document.querySelector(`[data-target-id="last-reading-prompt"]`),r=t.document.querySelector(`[data-target-id="last-reading-copy"]`),i=t.document.querySelector(`[data-target-id="last-reading-dismiss"]`),a=t.document.querySelector(`[data-target-id="last-reading-resume"]`),o=null,s=()=>{n?.classList.add(`u-hidden`)},c=()=>{o=null,s()};return i?.addEventListener(`click`,c,{signal:e.signal}),a?.addEventListener(`click`,()=>{if(!o)return;let e=o;c(),t.onResume(e)},{signal:e.signal}),e.own(()=>{o=null,s()}),{show:(e,s=`resume`)=>{if(t.disabled||!n||!r)return;let c=e.aliyahLabel?`${e.parshaName}, ${e.aliyahLabel}`:e.parshaName;r.textContent=`${s===`return`?`Return to`:`Resume`} ${c}?`,a&&(a.textContent=s===`return`?`Return`:`Resume`),i?.setAttribute(`aria-label`,s===`return`?`Dismiss return prompt`:`Dismiss resume prompt`),o=e,n.classList.remove(`u-hidden`)},hide:s,dismiss:c}}function Ac(e,t){let n=t.document.querySelector(`[data-target-id="app-offline-prompt"]`),r=t.document.querySelector(`[data-target-id="app-offline-dismiss"]`),i=!1,a=null,o=({force:e=!1}={})=>{e&&(i=!1),i||n?.classList.remove(`u-hidden`)},s=()=>{n?.classList.add(`u-hidden`)};return r?.addEventListener(`click`,()=>{i=!0,s()},{signal:e.signal}),t.view.addEventListener(`online`,()=>{i=!1,s();let e=a;a=null,!(!e||e.isCurrent?.()===!1)&&e.retry().catch(n=>{e.isCurrent?.()!==!1&&t.onRetryError(n)})},{signal:e.signal}),e.own(()=>{a=null,s()}),{recordPlaybackFailure:(e,t)=>{a={retry:e,isCurrent:t},o({force:!0})},clearPlaybackFailure:()=>{a=null,s()},hide:s}}function jc({getValue:e,setValue:t,isDisabled:n}){let r=null,i=()=>{if(r===null)return;let e=r;r=null,t(e)};return{handleKeyDown(i){i.key!==`Shift`||i.repeat||i.metaKey||i.ctrlKey||i.altKey||Pc(i.target)||n()||r!==null||(r=e(),t(!r))},handleKeyUp(e){e.key===`Shift`&&i()},release:i}}function Mc(e){return{metaOrCtrl:!1,shift:!1,alt:!1,...e,key:e.key.toLocaleLowerCase()}}function Nc(e,t,n){let r=t.key.toLocaleLowerCase();return e.find(e=>e.modes.includes(n)&&e.key===r&&e.metaOrCtrl===(t.metaKey||t.ctrlKey)&&e.shift===t.shiftKey&&e.alt===t.altKey)??null}function Pc(e){if(!e||typeof e!=`object`)return!1;let t=e;return!!(t.isContentEditable||t.closest?.(`input, textarea, select, button, [contenteditable="true"]`))}function Fc(e,t){let n=$a(),r=null,i=null,a=null,o=0,s=!1,c=()=>{if(r)return Promise.resolve(r);if(a)return a;i??=(t.load??(()=>P(()=>import(`./BJt2S0aA.js`),__vite__mapDeps([30,1,2,10,25,8,7,9,31,13,15,6,32]),import.meta.url)))();let o=i.then(i=>{if(e.signal.aborted)return null;let a=null,o=n(e=>{let n=t.mount(e,i);a=n,r=n,t.onMounted(n),e.own(()=>{t.onUnmounted(n),r===n&&(r=null)})});e.own(o);let c=a;return c?.restoreAccessState(),s&&c?.setVisible(!1),c}).catch(e=>(i=null,t.onLoadError(e),null)).finally(()=>{a===o&&(a=null)});return a=o,o},l=()=>{s=!0,o+=1,r?.setVisible(!1)},u=()=>{if(r)return r.isUnlocked();try{return Te(t.sessionStorage).unlocked}catch(e){return t.onLoadError(e),!1}};return e.own(()=>{s=!0,o+=1,r=null,a=null,i=null}),{isUnlocked:u,open:()=>{if(!u())return;s=!1;let e=++o;c().then(t=>{!t||e!==o||s||t.setVisible(!0)})},restoreIfOpen:()=>{try{if(!Te(t.sessionStorage).panelOpen)return}catch(e){t.onLoadError(e);return}s=!1,c()},handleShortcut:e=>{if(r)return r.handleKeydown(e);if(!Ee(e))return!1;e.preventDefault(),s=!1;let t=++o;return c().then(n=>{!n||t!==o||s||n.handleKeydown(e)}),!0},close:l}}function Ic({document:e,view:t,localStorage:n,sessionStorage:r,recordingMode:i,aboutHref:a,downloadOwner:o,openAbout:s}){let c=t,l=t.location,u=t.navigator,d=t.requestAnimationFrame.bind(t),f=t.cancelAnimationFrame.bind(t),{whenKey:p}=yn,m=B(n),h=m.settings,g=m.revision,_=()=>new ke(ne(h)),v=$a(),y=null,b=null,x=Cr(),S=0,C=null,w=null,T=null,E=null,D=null,O=null,k=new Map,A=ln(),j=new hn({recordings:mt(),rangeForRecording:A,loadTokens:sn,loadCues:yt}),M=new Set,N=new Map;function I(e,t){let n=`${e.id}:${t}:${x.narratorId}`,r=W?.snapshot();if(r?.error&&r.session?.runId===e.id&&r.session.aliyahIndex===t)return{problem:`load-failed`,issue:`audio`,canPlay:!1,recording:r.session.recording,message:`The recording could not load. Try again.`};if(N.has(n))return N.get(n);let a=e.aliyot.find(e=>e.index===t);if(!a||e.scroll!==`torah`||i.enabled||H?.isActive())return;let o=x.narratorId,s=j.peek(a,o),c=`${e.id}:${t}:${o}`;return s.problem===`checking`&&!M.has(c)&&(M.add(c),j.resolve(a,o).then(()=>{M.delete(c),W&&(Kr(),Wr())},e=>{M.delete(c),console.error(`Could not resolve passage audio`,e),W&&(Kr(),Wr())})),s}function L(e){if(!e)return;let t=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.runId)??_().parseId(e.runId);return t?I(t,e.aliyahIndex):void 0}let ie=null,H=null,U=null,W=null,G=null,ae=null,se=null,ce=null,q=null,J=null,Y=null,de=null,he=[],ge=null,_e=null,ye=[],X=[],be=null,xe=[],Se=i.enabled?`recording`:`normal`,Ce=!0,Te=!1,Ee=!1,Z=null,Oe=!1;function Q(){if(!y)throw Error(`Reader display session is not mounted`);return y}function Ae(e,t,n){return`${e}:${t}:${n}`}function je(e,t,n){return k.get(Ae(e,t,n))??null}function Me(){k.clear(),O?.invalidate()}function Ne(e,t){An(e,t).then(()=>{t.aborted||!y||(y.invalidateProgressAnchors(`text-layout`),Ur())}).catch(e=>{console.error(`Failed to align special Hebrew letters`,e)})}function Fe(){return new URLSearchParams(l.search).get(`debugActiveToken`)}function Le(e){return Q().render(e)}function ze(){y?.deactivate()}function Ue(t,{assertive:n=!1}={}){let r=e.querySelector(`[data-target-id="persistence-toast"]`);r&&(b!==null&&c.clearTimeout(b),r.setAttribute(`role`,n?`alert`:`status`),r.setAttribute(`aria-live`,n?`assertive`:`polite`),r.textContent=t,r.classList.remove(`u-hidden`),b=c.setTimeout(()=>{r.classList.add(`u-hidden`),r.textContent=``,r.setAttribute(`role`,`status`),r.setAttribute(`aria-live`,`polite`),b=null},6e3))}let Ge=e=>Ue(e);function Ke(e){if(!e?.run)return null;let t=e.run.aliyot.find(t=>t.index===e.aliyahIndex),n=t?.start?In(e.run,t.start):In(e.run);return!n||n===`#/next`?null:n}function qe(e){let t=y?.capture(),n=Ke(e);return!t||!e?.run||!n?null:{hash:n,parshaName:t.viewModel.displayTitleForRun(e.run),aliyahLabel:e.label===`—`?void 0:e.label}}function Je(e){if(i.enabled||q?.snapshot().view!==`reader`)return;let t=qe(e);if(t)try{zn(n,t)}catch(e){console.error(`Failed to save the current reading position`,e),Ge(`Your reading position could not be saved in this browser.`)}}function Ye(){let e=y;if(!e?.capture())return null;let t=ht();return e.progressSnapshot().at(nr(t)).current}function Xe(){let e=q?.snapshot();if(i.enabled||e?.view!==`reader`)return null;let t=qe(Ye()),n=Date.now();if(t)return{...t,savedAt:n};let r=y?.capture();if(r){let t=r.viewModel.relevantRuns.find(t=>Cc(r.viewModel.displayTitleForRun(t))===e.title);if(t)return{hash:In(t,t.aliyot[0]?.start),parshaName:r.viewModel.displayTitleForRun(t),savedAt:n}}let a=e.currentReaderHash===`#/next`?null:e.currentReaderHash;return a?{hash:a,parshaName:e.title,savedAt:n}:null}function Ze(){Je(Ye())}function Qe(){O?.closeCompact(),W?.resetRoute(),ye=[],X=[],be=null,xe=[],H?.recordingIssuesChanged(),H?.clearSession(),Yn(),Ar(),jr(null)}function $e(e){try{g=z(e,n,g)}catch(t){if(console.error(`Failed to save calendar settings`,t),t instanceof V&&t.cause instanceof oe&&t.cause.reason===`conflict`){let t=B(n);try{g=z(e,n,t.revision)}catch(e){console.error(`Failed to save calendar settings after refreshing browser state`,e),Ge(`Calendar settings changed in another tab. This choice applies now but could not be saved.`)}}else Ge(`Calendar settings will apply now but could not be saved.`)}h=e}let et=e=>{let t=ht(),n=y,r=()=>{Ce=e,xt().setAnnotationsEnabled(e),xn(t,e)};n?n.updateAnnotations(r):r();let i=n?.capture();i&&Ne(t,i.signal),gr(t),n&&Ur(),ae?.sync()},tt=(e,t)=>{let n=null,r=()=>{n!==null&&clearTimeout(n),n=setTimeout(()=>{n=null,e()},t)};return r.cancel=()=>{n!==null&&clearTimeout(n),n=null},r},nt=()=>{e.documentElement.style.setProperty(`--app-height`,`${c.innerHeight}px`)},rt=0;function it(){rt&&=(f(rt),0),e.querySelectorAll(`.debug-focal-line, .debug-focal-measure`).forEach(e=>e.remove())}function at(){if(e.querySelector(`.debug-focal-line, .debug-focal-measure`)){it();return}let t=(t,n)=>{let r=e.createElement(`div`);return r.className=`debug-focal-line`,r.style.cssText=`
        position: fixed;
        left: 0;
        right: 0;
        height: 0;
        border-top: 2px solid ${t};
        z-index: 999999;
        pointer-events: none;
        font: 13px sans-serif;
        color: white;
        text-shadow: 0 1px 2px black;
      `,r.textContent=n,e.body.appendChild(r),r},n=(t,n,r)=>{let i=e.createElement(`div`),a=e.createElement(`div`);return i.className=`debug-focal-measure`,a.className=`debug-focal-measure`,i.style.cssText=`
        position: fixed;
        left: ${n}px;
        width: 0;
        border-left: 2px dashed ${t};
        z-index: 999999;
        pointer-events: none;
      `,a.style.cssText=`
        position: fixed;
        left: ${n+8}px;
        z-index: 999999;
        pointer-events: none;
        padding: 2px 6px;
        border-radius: 4px;
        background: rgba(0, 0, 0, 0.72);
        color: white;
        font: 13px sans-serif;
        white-space: nowrap;
      `,e.body.append(i,a),{update(e,t){let n=Math.min(e,t),o=Math.abs(t-e);i.style.top=`${n}px`,i.style.height=`${o}px`,a.style.top=`${n+o/2-12}px`,a.textContent=`${r}: ${Math.round(o)}px`}}},r=`lightskyblue`,i=t(`red`,`Browser center`),a=t(r,`Reader center`),o=n(`red`,24,`Browser top`),s=n(`red`,104,`Browser bottom`),c=n(r,220,`Reader top`),l=n(r,300,`Reader bottom`),u=()=>{let t=e.querySelector(`[data-target-id="tikkun-book"]`);if(!t||!i.isConnected){it();return}let n=t.getBoundingClientRect(),r=e.documentElement.clientHeight,f=r/2,p=n.top,m=n.top+t.clientHeight,h=p+t.clientHeight/2;i.style.top=`${f}px`,a.style.top=`${h}px`,o.update(0,f),s.update(f,r),c.update(p,h),l.update(h,m),rt=d(u)};u()}function ot(t){e.addEventListener(`click`,e=>{let t=e.target;t instanceof Element&&t.closest(`[data-target-id="debug-focal-measure-toggle"]`)&&at()},{signal:t.signal}),t.own(it)}function st(e,t){let n=()=>{t.classList.add(`mod-pull-releasing`),t.style.setProperty(`--pull-translation`,`0`)},r=0;t.addEventListener(`touchstart`,e=>{t.classList.remove(`mod-pull-releasing`),r=e.changedTouches[0].screenX},{signal:e.signal}),t.addEventListener(`touchmove`,e=>{let n=e.changedTouches[0].screenX,i=-Math.max(n-r,-100);i<30||t.style.setProperty(`--pull-translation`,`${30-i}px`)},{signal:e.signal}),t.addEventListener(`touchend`,n,{signal:e.signal}),t.addEventListener(`touchcancel`,n,{signal:e.signal}),e.own(()=>{t.classList.remove(`mod-pull-releasing`),t.style.removeProperty(`--pull-translation`)})}function dt(e){T=e,E=q?.snapshot().hashPath??l.hash.split(`?`,1)[0]}function ft(){T=null,E=null}function ht(){return e.querySelector(`[data-target-id="tikkun-book"]`)}function gt(){return{layout:x.readerTextLayout,sides:fr(x.readerSideMode,wt())}}function _t({rerender:e=!0,beforeLayout:t}={}){let n=ht(),r=gt(),i=e&&(y?.setPagePresentation(r,t)??!1);if(i||t?.(),n.dataset.readerLayout=r.layout,n.dataset.readerSides=r.sides,!i)return!1;y?.invalidateProgressAnchors(`text-layout`);let a=y?.capture()?.signal;return a&&Ne(n,a),gr(n),Ur(),W?.syncHighlight({scroll:!1}),!0}function xt(){if(!ce)throw Error(`Reader Shell is not mounted`);return ce}function Ct(){ht().focus({preventScroll:!0})}function wt(){return ie?.isCompact()??!1}function Tt(e){return e instanceof HTMLElement?e.isContentEditable||!!e.closest(`input, textarea, select, button`):!1}function Et(){return i.enabled?`recording`:H?.isActive()?`admin-authoring`:Se===`practice-focus`?`practice-focus`:`normal`}function Dt(){U?U.close():H?.setVisible(!1)}function Ot(){let t=Et(),n=t!==Se;Se=t,e.documentElement.dataset.readerMode=Se,n&&(W?qr():Fn())}function kt(){return W?.snapshot().activeTokenKey||At()}function At(){let e=wr(ht());return e?e.dataset.tokenKey?e.dataset.tokenKey:Sr(e)?.dataset.tokenKey??e.querySelector(`.word[data-token-key]`)?.dataset.tokenKey??null:null}function jt(t){return e.querySelector(`[data-token-key="${t}"]`)?.textContent?.trim().replace(/\s+/g,` `)||`Word ${t}`}async function Nt(e,t={}){let n=fe(e);if(!n)throw TypeError(`Invalid token key: ${e}`);let r=Q(),i=r.holdNavigation();try{await r.capture()?.ensurePageMountedForNavigation(n.pageNumber),i.releaseAfterNavigation();let a=await W?.activateToken(e,{scroll:!0});a||i.release(),t.audioTime!==void 0&&W?.snapshot().session&&W.seek(t.audioTime),a&&jr(r.progressAnchorForElement(a)),Ct()}catch(e){throw i.release(),e}}function Pt(){let e=At();if(!e)return;if(he.find(t=>t.tokenKey===e)){let t=he.filter(t=>t.tokenKey!==e);if(!Ft(t))return;he=t,rn(),ae?.sync();return}let t=W?.snapshot().session,n=W?.cueForToken(e),r=[ao({hash:Lt(e),label:jt(e),tokenKey:e,audioId:t?.recording.id,timeStart:n?.timeStart}),...he.filter(t=>t.tokenKey!==e)];Ft(r)&&(he=r,rn(),ae?.sync())}function Ft(e){try{return ge=lo(n,e,ge),!0}catch(e){if(console.error(`Failed to save reader bookmarks`,e),e instanceof uo&&e.cause instanceof oe&&e.cause.reason===`conflict`){let e=co(n,Xn);return he=e.bookmarks,ge=e.revision,rn(),ae?.sync(),Ge(`Bookmarks changed in another tab. Review the latest list and try again.`),!1}return Ge(`Bookmarks could not be saved in this browser.`),!1}}function It(e=At()){let t=!!(e&&he.some(t=>t.tokenKey===e));return{bookmarkAvailable:!!e,bookmarked:t,annotationsEnabled:Ce,aliyahNavigationAvailable:kn(),shareAvailable:F(Rt())}}function Lt(t){let n=e.querySelector(`[data-token-key="${t}"]`),r=n?Er(n):null,i=r?.verses[0],a=i&&r?.run?{...i,scroll:r.run.scroll}:r?.run?.aliyot[0]?.start;if(r?.run)return In(r.run,a);let o=q?.snapshot().currentReaderHash;return o&&o!==`#/next`?o:l.hash}function Rt(){let e=At();return e?Lt(e):q?.snapshot().currentReaderHash??``}function zt(e){return{id:e.id,kind:`bookmark`,source:`bookmark`,label:e.label,hash:e.hash,audioId:e.audioId,tokenKey:e.tokenKey,timeStart:e.timeStart,createdAt:e.createdAt}}function Vt(e){let t=/^#\/run\/([^/]+)/.exec(e.hash)?.[1];if(t){let e=_().parseId(t);return e?Yt(e):null}let n=/^#\/(?:torah|esther)\/parsha\/([^/]+)/.exec(e.hash)?.[1];return n?n.replace(/-/g,` `):null}function Ht(e){return/[A-Za-z]/.test(e)?e.replace(/\S+/g,e=>e.charAt(0).toLocaleUpperCase()+e.slice(1).toLocaleLowerCase()):e}function Ut(e){return e.id.startsWith(`checkpoint.bookmark:`)}function Gt(){let e=[...he.map(zt),...me(xe).map(no)],t=W?.snapshot().session,n=kt();if(t&&n){let r=W?.cueForToken(n);r&&e.push(to({audioId:t.recording.id,label:`Current word`,tokenKey:n,timeStart:r.timeStart}))}return e.sort(ro)}function Kt(e){if(e.hash&&e.hash!==l.hash){l.hash=e.hash,c.setTimeout(()=>{Nt(e.tokenKey,{audioTime:e.timeStart})},0);return}Nt(e.tokenKey,{audioTime:e.timeStart})}async function qt(e,t,n=ar.start()){let r=Q(),i=r.holdNavigation(),a;try{a=await r.ensureAliyahDomTargetRendered(e,t)}catch(e){throw i.release(),e}if(!ar.isCurrent(n)||!a){i.release();return}let o=a.element.closest(`[data-line-index]`);i.releaseAfterNavigation(),ir(ht(),o??a.element,{behavior:`smooth`}),jr(r.progressAnchorForElement(o??a.element)),r.refreshViewport(),Wr(),c.setTimeout(()=>{r.refreshViewport(),Wr()},500),Ct()}function Jt(){let e=_(),t=new Date;t.setHours(0,0,0,0);let n=new Re(t).getFullYear(),r=[],i=new Set;for(let a=n;a<=n+2;a+=1)for(let n of e.forHebrewYear(a))if(!(n.date<t))for(let e of n.leinings){let t=Ie(e);if(!t||i.has(t.id))continue;i.add(t.id);let a=`${n.title.en} / ${n.title.he}`;if(r.push(Un({id:`reading.holiday.${t.id}`,group:`reading`,label:a,aliases:[n.title.en,n.title.he],keywords:Be(n.title,`${e.id}`),showWhenEmpty:!1,destinationId:In(t),href:In(t),run:()=>q?.navigate(In(t))})),r.length>=16)return r}return r}function Yt(e){return e.leining.date.title.he||e.leining.date.title.en}function Xt(){let e=_(),t=new Date;t.setHours(0,0,0,0);let n=new Re(t).getFullYear(),r=[],i=new Set;for(let a=n;a<=n+2;a+=1)for(let n of e.forHebrewYear(a))if(!(n.date<t)){for(let e of n.leinings)if(e.isParsha)for(let t of e.runs){if(t.scroll!==`torah`||i.has(t.id))continue;i.add(t.id);let e=ct(t);r.push(...Kn({run:t,displayTitle:Yt(t),showWhenEmpty:!1,dedupeKeyPrefix:e?`reading.parsha.${e}`:void 0,navigate:e=>q?.navigate(e)}))}}return r}function Zt(e){let t=Ie(e);return t?[t]:[]}function $t(){let e=_(),t=new Re(new Date).getFullYear(),n=[],r=new Set;for(let i=t;i<=t+1;i+=1)for(let t of e.forHebrewYear(i))for(let e of t.leinings)if(!e.isParsha)for(let t of Zt(e))r.has(t.id)||(r.add(t.id),n.push(...Kn({run:t,displayTitle:Yt(t),showWhenEmpty:!1,navigate:e=>q?.navigate(e)})));return n}function en(e){let t=[e.parshaSlug,e.parshaName,...we(e.parshaSlug)];return[...t,...t.flatMap(t=>[`${t} ${e.aliyah}`,`${t} Aliyah ${e.aliyah}`])]}function nn(){let e=[Un({id:`reading.current`,group:`reading`,label:`Today / Next Reading`,aliases:[`Today`,`Next Reading`,`Next Shabbat`],keywords:[`current reading`,`upcoming reading`],emptyPriority:100,destinationId:`#/next`,href:`#/next`,run:()=>q?.navigate(`#/next`)}),Un({id:`tools.analytics`,group:`tools`,label:`Cue Analytics`,aliases:[`Playback Analytics`,`Word Analytics`],keywords:[`timing`],emptyPriority:40,run:()=>q?.navigate(Ve())}),Un({id:`tools.media`,group:`tools`,label:`Media & Storage`,aliases:[`Downloads`,`Offline audio`],keywords:[`download`,`storage`,`recordings`],emptyPriority:38,run:()=>se?.()}),Un({id:`tools.settings`,group:`tools`,label:`Reader Settings`,aliases:[`Preferences`],keywords:[`theme`,`highlight`],emptyPriority:39,run:()=>G?.open()}),Un({id:`admin.open`,group:`admin`,label:`Cue Authoring`,keywords:[`timing`,`authoring`,`record cues`],available:U?.isUnlocked()??!1,emptyPriority:30,run:()=>U?.open()})];e.push(...Jt());let t=y?.capture();if(t){let n=Q().progressSnapshot().anchors,r=br(y?.viewportRange()??null,n)?.run??n.find(e=>e.run)?.run??null;if(r){let n=r.leining.isParsha?ct(r):null;e.push(...Kn({run:r,displayTitle:t.viewModel.displayTitleForRun(r),dedupeKeyPrefix:n?`reading.parsha.${n}`:void 0,emptyPriority:85,showWhenEmpty:!1,navigate:e=>q?.navigate(e)}))}}for(let t of mt()){if(t.status!==`available`||!K(t))continue;let n=Pe(_(),t.parshaSlug),r=n?.run.aliyot.find(e=>e.index===t.aliyah),i=n&&r?In(n.run,r.start):He(t.parshaSlug);e.push(Un({id:`reading.${t.id}`,group:`reading`,label:`${t.parshaName} Aliyah ${t.aliyah}`,dedupeKey:`reading.parsha.${t.parshaSlug}.${t.aliyah}`,destinationId:i,searchConstraint:{kind:`aliyah`,aliyah:t.aliyah,allowTerms:[`recording`,`audio`]},href:i,aliases:en(t),keywords:[`recording`,`audio`],showWhenEmpty:!1,run:()=>q?.navigate(i)}))}e.push(...Xt()),e.push(...$t()),e.push(...qn({navigateToPage:(e,t)=>q?.navigate(We(e,t))}));let r=Bn(n,Date.now(),Xn);r&&e.push(Un({id:`resume.last-reading`,group:`resume`,label:`Resume ${r.aliyahLabel?`${r.parshaName}, ${r.aliyahLabel}`:r.parshaName}`,aliases:[`Resume Reading`,`Last Reading`],keywords:[`resume`,`last reading`],emptyPriority:95,destinationId:r.hash,href:r.hash,run:()=>q?.navigate(r.hash)}));for(let t of Gt()){let n=t.kind===`bookmark`?he.find(e=>e.id===t.id):null;e.push(Un({id:`checkpoint.${t.id}`,group:t.kind===`bookmark`?`resume`:`checkpoint`,label:t.label,badgeLabel:n?Vt(n)??void 0:void 0,keywords:[`bookmark`,`checkpoint`,t.tokenKey],emptyPriority:t.kind===`bookmark`?90:88,run:()=>Kt(t)}))}return e}function rn(){Y?.refresh(),q?.refreshPickerSearch()}function an(){if(q?.focusPickerSearch()){Y?.close();return}Y?.open()}function on(e){(e?.isConnected&&e.getClientRects().length>0?e:ht()).focus({preventScroll:!0})}let un=null,dn=null,fn=null;function pn(){return un||(un=e.createElement(`div`),un.className=`aliyah-start-popup u-hidden`,un.id=`aliyah-start-popup`,un.setAttribute(`role`,`dialog`),un.setAttribute(`aria-label`,`Aliyah start`),e.body.appendChild(un),un)}function mn(){un?.classList.add(`u-hidden`),fn?.setAttribute(`aria-expanded`,`false`),dn=null,fn=null}function gn(e){let t=e.querySelector(`.aliyah-start-marker`);if(!t)return null;let n=t.getBoundingClientRect();return n.width>0&&n.height>0?t:null}function _n(e,t){let n=e.target?.closest(`.aliyah-start-marker`);return n&&t.contains(n)?n:null}function vn(e){return e.closest(`[data-line-index][data-aliyah-starts]`)}function bn(t,n,r){if(!r)return;let i=e.createElement(`div`);i.className=`aliyah-start-popup-row`;let a=e.createElement(`span`);a.className=`aliyah-start-popup-label`,a.textContent=n;let o=e.createElement(`span`);o.className=`aliyah-start-popup-value`,o.textContent=r,i.append(a,o),t.appendChild(i)}function Sn(e,t,n=gn(t)){let r=t.querySelector(`.line-content`);if(!r)return;let i=(n??r).getBoundingClientRect(),a=e.getBoundingClientRect(),o=n?i.left+i.width/2:i.right-4,s=i.top,l=Math.max(8,Math.min(o-a.width/2,c.innerWidth-a.width-8)),u=s-a.height-8,d=u>=8?u:Math.min(s+24,c.innerHeight-a.height-8);e.style.left=`${l}px`,e.style.top=`${Math.max(8,d)}px`}function Cn(e,t=gn(e)){if(dn===e&&fn===t&&un&&!un.classList.contains(`u-hidden`))return;let n=pn();fn?.setAttribute(`aria-expanded`,`false`),dn=e,fn=t,t?.setAttribute(`aria-expanded`,`true`),n.replaceChildren(),bn(n,`Parsha`,e.dataset.aliyahStartTitle??``),bn(n,`Aliyah`,t?.dataset.aliyahStartLabel??e.dataset.aliyahStartLabel??``),bn(n,`Verses:`,e.dataset.aliyahStartVerse??``),n.classList.remove(`u-hidden`),Sn(n,e,t)}function wn(t){let n=ht();n.addEventListener(`click`,e=>{if(!wt()){mn();return}if(!(e instanceof MouseEvent))return;let t=_n(e,n),r=t?vn(t):null;if(!r||!t){mn();return}e.preventDefault(),e.stopImmediatePropagation(),Cn(r,t)},{signal:t.signal}),n.addEventListener(`pointerover`,e=>{if(!wt()||e.pointerType===`touch`)return;let t=_n(e,n),r=t?vn(t):null;!r||!t||Cn(r,t)},{signal:t.signal}),n.addEventListener(`pointerout`,e=>{if(e.pointerType===`touch`)return;let t=_n(e,n);if(!t)return;let r=e.relatedTarget;r instanceof Node&&t.contains(r)||mn()},{signal:t.signal}),n.addEventListener(`focusin`,e=>{if(!wt())return;let t=e.target?.closest(`.aliyah-start-marker`),n=t?vn(t):null;n&&t&&Cn(n,t)},{signal:t.signal}),n.addEventListener(`scroll`,mn,{passive:!0,signal:t.signal}),c.addEventListener(`resize`,()=>{mn(),C!==null&&c.clearTimeout(C),C=c.setTimeout(()=>{C=null,t.signal.aborted||gr(n)},120)},{signal:t.signal});let r=()=>{t.signal.aborted||(y?.invalidateProgressAnchors(`text-layout`),gr(n),y&&Ur())};e.fonts.ready.then(r),e.fonts.addEventListener(`loadingdone`,r,{signal:t.signal}),e.addEventListener(`pointerdown`,e=>{let t=e.target;!un||un.classList.contains(`u-hidden`)||t&&un.contains(t)||t?.closest(`.aliyah-start-marker`)||t?.closest(`[data-aliyah-starts]`)||mn()},{signal:t.signal}),t.own(()=>{mn(),un?.remove(),un=null,C!==null&&(c.clearTimeout(C),C=null),S&&=(f(S),0)})}function Tn(t){let n=[Mc({id:`palette.open`,key:`k`,metaOrCtrl:!0,modes:[`normal`,`practice-focus`,`admin-authoring`],run:an}),Mc({id:`issue.mark`,key:`m`,modes:[`admin-authoring`],run:()=>H?.openIssue()}),Mc({id:`phrase.replay`,key:`r`,modes:[`admin-authoring`],run:()=>{W?.replayCurrentCue()}})];e.addEventListener(`keydown`,e=>{Ot();let t=Nc(n,e,Se);if(!t||t.id===`palette.open`&&e.target instanceof Element&&e.target.closest(`[data-target-id="reader-search"]`))return;let r=t.id===`palette.open`&&((Y?.isOpen()??!1)||(q?.snapshot().pickerOpen??!1));Pc(e.target)&&!r||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),t.run())},{capture:!0,signal:t.signal})}function En(e){let t=q?.snapshot(),n=t?.hashPath.match(/^#\/torah\/parsha\/([^/?]+)/)?.[1],r=y?.capture();if(!n||!r)return e;let i=Pe(_(),decodeURIComponent(n)),a=i?r.viewModel.relevantRuns.find(e=>e.id===i.run.id)??null:null;if(!a)return e;let o=Cc(r.viewModel.displayTitleForRun(a));return t?.title===o?a:e}function Dn(){let e=W?.snapshot(),t=e?.session;return{target:t?{runId:t.runId,aliyahIndex:t.aliyahIndex}:null,playing:e?.playing??!1,progressLabel:e&&t?`${sa(e.currentTime)}/${sa(e.duration)}`:``}}async function On(e){let t=jn(e.target,{includePreviousOverlap:!0}),n=L(e.target);if(n)return n.message||`Available`;if(!t)return`Available`;let r=await vt(t),i=r[r.length-1],a=i?.timeEnd??i?.timeStart??0;return a>0?sa(a):`Available`}function kn(){let e=q?.snapshot();return e?.view===`reader`&&!e.pickerOpen}function jn(e,{includePreviousOverlap:t=!1}={}){let n=(y?.capture())?.viewModel.relevantRuns.find(t=>t.id===e.runId)??_().parseId(e.runId);return n?lt({narratorId:x.narratorId,run:n,aliyahIndex:e.aliyahIndex})??I(n,e.aliyahIndex)?.recording??(t?Or(n,e.aliyahIndex):null):null}function Pn(e,t,n){return ti({entries:e,active:t,playback:n,signaturePrefix:x.narratorId,getAudio:({run:e,aliyah:t})=>{let n=lt({narratorId:x.narratorId,run:e,aliyahIndex:t.index}),r=I(e,t.index);return{audioState:r,playbackKey:(r?.recording??n??Or(e,t.index))?.id??null,recordingKey:n?.id??null}}})}function Fn(e=y?.viewportRange()??null,t){if(!kn()){O?.clearContent(),y?.syncAudioPreload(null);return}let n=t??Q().progressSnapshot(),r=n.anchors,i=br(e,r)??n.at(nr(ht())).current,a=i?.run??r.find(e=>e.run)?.run??null;if(!a){O?.clearContent(),y?.syncAudioPreload(null);return}let o=Dn(),s=i?.run&&i.aliyahIndex?{runId:i.run.id,aliyahIndex:i.aliyahIndex}:null,c=ei(a),l=Pn(c,s,o),u=En(a)??a,d=ei(u),f=Pn(d,ni({runId:u.id,current:s,playback:o,first:d[0]?{runId:d[0].run.id,aliyahIndex:d[0].aliyah.index}:null}),o);ur(a,s?.aliyahIndex??null),Q().scheduleResourcePrewarm(c.flatMap(({run:e,aliyah:t})=>t.index?[{run:e,aliyahIndex:t.index}]:[]),l.signature),O?.syncContent({desktop:l,compact:f,authoringEnabled:H?.isActive()??!1})}function Ln(e,t){let n=performance.now();w={runId:e,aliyahIndex:t,expiresAt:n+2500,maxExpiresAt:n+6e3},dt({runId:e,index:t}),O?.setActive({runId:e,aliyahIndex:t}),qt(e,t,ar.start())}function Rn(t){let r=bi(t,{document:e,onSelect:e=>Ln(e.runId,e.aliyahIndex),onPlayCompact:async e=>(await Vr(e),t.signal.aborted||Ze(),Dn()),onPlayCurrent:async e=>{await Vr(e),Ct()},onBeforeCompactOpen:()=>{let e=W?.snapshot();return e?.session&&e.playing&&W?.pause(),Dn()},onAfterNavigate:Ct,onWideHidden:mn,restoreFocus:on,getReaderFocusTarget:ht,loadCueStatus:async e=>{if(e.recordingKey||!e.audioState)return Hn(jn(e.target));let t=(y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.target.runId)??_().parseId(e.target.runId))?.aliyot.find(t=>t.index===e.target.aliyahIndex);if(!t)return`none`;let n=await j.resolve(t,x.narratorId);return n.cueComplete?`published`:n.portions.some(e=>e.segments.some(e=>e.cues.length>0))?`pending`:`none`},onCueStatusChange:(e,t)=>{e.recordingKey&&(k.set(Ae(e.target.runId,e.target.aliyahIndex,e.recordingKey),t),Ar())},loadDurationLabel:On,onCueStatusError:(e,t)=>{console.error(`Failed to load Cue Data status for ${t.key}`,e)},onDurationError:(e,t)=>{console.error(`Failed to load duration for ${t.audioKey??t.key}`,e)}});O=r;let i=new Set(mt().map(e=>Bt(e.id)));c.addEventListener(`storage`,e=>{e.storageArea===n&&(e.key!==null&&!i.has(e.key)||(Me(),Ar()))},{signal:t.signal}),t.own(()=>{O===r&&(O=null)})}function Vn(){w&&(w.expiresAt=Math.min(w.maxExpiresAt,performance.now()+500))}async function Hn(e){if(!e)return`none`;let t=A(e),[n,r]=await Promise.all([St(e),t?sn(t):null]);if(r){let t=Wt(e,r);if(t?.cues.length){let n=await vt(e);if(!n.length||!Mt(t.cues,n))return`local-draft`}}return n?.isComplete?`published`:n?.isUnfinished?`pending`:`none`}async function Wn(){let e=W?.snapshot(),t=e?.session,r=H?.isVisible()&&H.getSession()?t?.recording??null:t?.activeRecording??t?.recording??null,i=e?.sessionRevision,a=sr.start();if(ye=[],X=[],be=null,xe=[],H?.recordingIssuesChanged(),Gn(),Yn(),t&&r){let e=await bt(r,`v2`),t=W?.snapshot(),o=H?.isVisible()&&H.getSession()?t?.session?.recording??null:t?.session?.activeRecording??null;if(!sr.isCurrent(a)||t?.sessionRevision!==i||o?.id!==r.id)return;let s={issues:[],revision:null};try{s=ve(n,r.id,`v2`)}catch(e){console.error(`Recording issue storage is unavailable for ${r.id}`,e)}ye=e,X=s.issues,be=s.revision,xe=le(ye,X),H?.recordingIssuesChanged(),Gn(),Yn()}rn()}function Gn(e=ht()){e.querySelectorAll(`.word[data-recording-issue]`).forEach(e=>{e.removeAttribute(`data-recording-issue`),e.removeAttribute(`title`)});for(let t of ue(xe))e.querySelectorAll(`[data-token-key="${t.tokenKey}"]`).forEach(e=>{e.dataset.recordingIssue=t.kind,e.title=pe(t)})}function Yn(){let t=e.querySelector(`[data-target-id="reader-issue-toast"]`);if(!t)return;let n=kt(),r=n?ue(xe).find(e=>e.tokenKey===n):null;if(!r){t.classList.add(`u-hidden`),t.textContent=``;return}t.textContent=pe(r),t.classList.remove(`u-hidden`)}function Zn(e){let t=W;if(!t)return;let n=y?.capture(),r=t.snapshot().sessionRevision;de?.recordPlaybackFailure(e,()=>W===t&&t.snapshot().sessionRevision===r&&(n?.isCurrent()??!0))}function $n(e){return Bi(e)}function er({recording:e,runId:t,aliyahIndex:n}){return!!(t&&n&&W?.isTargetActive({recordingId:e?.id??null,runId:t,aliyahIndex:n}))}function tr(e,t){let n=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e);return Ai(n,t)}function rr(e){return!!(e?.run?.id&&e.aliyahIndex&&tr(e.run.id,e.aliyahIndex))}let ar=new ua,or=new ua,sr=new ua;function cr(){W?.resetRecordingCache(),ar.cancel(),or.cancel()}function lr(){return W?.snapshot().playing??!1}function ur(e,t){let n=t?lt({narratorId:x.narratorId,run:e,aliyahIndex:t}):null,r=t?Or(e,t):null,i=n?.playSrc??r?.playSrc??null;y?.syncAudioPreload(i)}function dr(e){let t=c;return t.requestIdleCallback?t.requestIdleCallback(e):c.setTimeout(e,150)}function pr(e){c.cancelIdleCallback?.(e),c.clearTimeout(e)}function mr(e,t){e&&(e.innerHTML=De(t))}function hr(e){i.enabled&&e.querySelectorAll(`[data-aliyah-marker="true"]`).forEach(e=>{let t=e.querySelector(`.aliyah-label-text`);if(!t)return;let n=e.dataset.aliyahIndex?Number(e.dataset.aliyahIndex):null;t.textContent=Qt(t.textContent??``,n)})}function gr(e){S||=d(()=>{S=0,_r(e)})}function _r(e,t=e){fn&&t instanceof Node&&t.contains(fn)&&mn(),t.querySelectorAll(`.aliyah-start-marker`).forEach(e=>e.remove()),t.querySelectorAll(`[data-line-index][data-aliyah-starts]`).forEach(t=>{let n=Er(t);if(!n?.aliyahStarts.length)return;let r=t.querySelector(`.line-content`);if(!r)return;let i=new Map;n.aliyahStarts.forEach(r=>{let a=Ei({book:e,startLine:t,startVerseOrdinal:n.verses.findIndex(e=>$(e,r.start)===0)});if(!a)return;let o=i.get(a);o?o.push(r):i.set(a,[r])}),i.forEach((e,n)=>{let i=e.map(e=>$n(`${e.index??``}`)).filter(e=>!!e).map(Xr).join(`, `);if(!i)return;let a=[...t.querySelectorAll(`.word[data-token-key="${n}"]`)].map(e=>Di(e)).find(e=>e!==null);if(!a)return;let o=ki({label:i,tokenKey:n});o.dataset.aliyahStartLabel=i,r.append(o);let s=o.offsetParent instanceof HTMLElement?o.offsetParent:r,c=s.getBoundingClientRect(),l=Oi({left:c.left+s.clientLeft-s.scrollLeft,top:c.top+s.clientTop-s.scrollTop},a);o.style.setProperty(`--aliyah-start-anchor-x`,`${l.x}px`),o.style.setProperty(`--aliyah-start-anchor-y`,`${l.y}px`)})})}function vr(e){let t=e?.center,n=t?.run,r=y?.capture();return{centerRun:n,memberships:t?Hi({runs:r?.viewModel.relevantRuns??(n?[n]:[]),lineRun:n,focalRef:t.focalRef,aliyot:t.aliyot,aliyahStarts:t.aliyahStarts}):[]}}function yr(e,t,n){if(!e)return null;let r=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.runId)??(t?.id===e.runId?t:null);if(!r)return null;let i=n.find(t=>t.run?.id===e.runId&&t.aliyahIndex===e.index);return i?{...i,label:Xr(e.index)}:{line:null,label:Xr(e.index),run:r,aliyahIndex:e.index,position:nr(ht())}}function br(e,t){let{centerRun:n,memberships:r}=vr(e),i=w?{runId:w.runId,index:w.aliyahIndex}:null;if(w){let e=w.expiresAt<=performance.now(),t=r.some(e=>zi(e,i));(e||t)&&(w=null,i=null)}let a=W?.snapshot().session,o=a&&lr()?{runId:a.runId,index:a.aliyahIndex}:null,s=Ui({memberships:r,playback:o,pending:i,explicit:T});return T&&!i&&!o&&!r.some(e=>zi(e,T))&&ft(),yr(s,n,t)}function xr(e,t,n){if(t===null||n===t)return null;if(n>t){for(let r=e.length-1;r>=0;--r){let i=e[r];if(!(i.position>n)){if(i.position<=t)break;return i}}return null}for(let r of e)if(!(r.position<n)){if(r.position>=t)break;return r}return null}function Sr(e){return[...e.querySelectorAll(`.word`)].find(e=>{let t=e.getBoundingClientRect();return t.width>0&&t.height>0})??null}function wr(e){let t=e.querySelector(`.word.is-active-word`);if(t)return t;let n=y?.viewportRange()?.center;if(!n)return null;let r=[...e.querySelectorAll(`[data-line-index]`)].find(e=>Er(e)===n);return r?Sr(r)??r:null}function Tr(e,t={}){let n=ht();e?.isConnected&&ir(n,e,t),y?.refreshViewport(),Wr()}function Er(e){let t=e.closest(`[data-line-index]`),n=t?.closest(`.tikkun-page`);return!t||!(n instanceof HTMLElement)?null:n.tikkunPage?.lines[Number(t.dataset.lineIndex)]??null}function Dr(e){let t=Er(e),n=$n(e.dataset.aliyahIndex);if(!t||!n)return null;let r=e.dataset.runId??t?.run?.id,i=(y?.capture())?.viewModel.relevantRuns.find(e=>e.id===r)??(t?.run?.id===r?t.run:null)??(r?_().parseId(r):null);if(!i)return null;let a=W?.lookupRecording(i,n),o=a?.recording??lt({narratorId:x.narratorId,run:i,aliyahIndex:n});return{lineInfo:t,run:i,aliyahIndex:n,recording:o,audioState:I(i,n),available:a?.available??!!(o||Or(i,n))}}function Or(e,t){return W?.lookupRecording(e,t).overlapRecording??null}function kr(...e){W?.authorizePlayback(...e)}function Ar(){let t=W?.snapshot();for(let n of e.querySelectorAll(`[data-audio-button="true"]`)){let e=Dr(n),r=!!e?.available,i=H?.isActive()??!1,a=!!(e&&i&&!e.recording),o=e?.recording?je(e.run.id,e.aliyahIndex,e.recording.id):null,s=e?.audioState?e.audioState.problem===`incomplete-cues`:!!(e?.recording&&o&&gi(o)),c=!!(er({recording:e?.recording,runId:e?.run.id,aliyahIndex:e?.aliyahIndex})&&t?.playing),l=cn({state:e?.audioState,available:r,cueIncomplete:s,adminMissing:a,playing:c});n.disabled=!1,n.setAttribute(`aria-disabled`,String(l.actionDisabled)),n.dataset.audioTone=l.tone,n.dataset.audioDimmed=String(l.dimmed),n.dataset.audioTooltip=l.tooltip,mr(n,c?`pause`:`play`);let u=e?.lineInfo.labels[0]??`aliyah`;n.title=a?`Select ${u} for audio and cue recording`:i&&s&&o?_i({label:u,status:o,playing:c}):r?`${c?`Pause`:`Play`} ${u}`:`Recording unavailable`,!i&&e?.audioState?.message&&(n.title+=` — ${e.audioState.message}`),n.dataset.audioProblem=e?.audioState?.problem??``,n.setAttribute(`aria-label`,n.title),n.removeAttribute(`title`),o?n.dataset.cueStatus=o:delete n.dataset.cueStatus,n.classList.toggle(`is-active`,c),n.classList.toggle(`is-missing-audio`,a),n.classList.toggle(`is-cue-incomplete`,s)}}function jr(e){let t=W?.snapshot(),n=e?.run&&e.aliyahIndex?lt({narratorId:x.narratorId,run:e.run,aliyahIndex:e.aliyahIndex}):null,r=e?.run&&e.aliyahIndex?Or(e.run,e.aliyahIndex):null,i=H?.isActive()??!1,a=e?.run&&e.aliyahIndex&&n?je(e.run.id,e.aliyahIndex,n.id):null,o=q?.snapshot().pickerOpen??!1,s=e?.run&&e.aliyahIndex?I(e.run,e.aliyahIndex):void 0,c=!!(e?.run&&e.aliyahIndex&&(n||r||s?.recording)&&!o),l=!!(e?.run&&e.aliyahIndex&&!n&&i&&!o),u=!!(er({recording:n,runId:e?.run?.id,aliyahIndex:e?.aliyahIndex})&&t?.playing),d=En(e?.run??null),f=d?ei(d):[],p=t?.session,m=!!(d&&p?.runId===d.id),h=!!(m&&lr()),g=h?p?.aliyahIndex??null:e?.run?.id===d?.id?e?.aliyahIndex??null:f[0]?.aliyah.index??null,_=h?p?.runId??``:e?.run?.id===d?.id?e?.run?.id??``:d?.id??``,v=!!(m&&p?.runId===_&&p?.aliyahIndex===g),y=_&&g?{runId:_,aliyahIndex:g}:null,b=!!(y&&(jn(y,{includePreviousOverlap:!0})||H?.isActive()));O?.syncToolbar({current:{labelVisible:!!(e&&!o),label:e?.label??`—`,target:e?.run&&e.aliyahIndex?{runId:e.run.id,aliyahIndex:e.aliyahIndex}:null,audioAvailable:c,audioState:s,authoringAvailable:l,authoringEnabled:i,cueStatus:a,playing:u},compact:{visible:!!(d&&g&&!o),target:y,label:g?Xr(g):`—`,playbackState:mi({loaded:v,playing:v&&h}),audioAvailable:b,audioState:L(y),authoringMissing:!!(i&&y&&!jn(y)),cueIncomplete:!!(a&&gi(a)&&e?.run?.id===_&&e?.aliyahIndex===g)}})}async function Lr({runId:e,aliyahIndex:t}){let n=Q().capture();if(!n)return[];let r=n.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e),i=ji(r,t);if(!r||!i)return[];let a=await sn(i);return n.isCurrent()?[...a]:[]}async function Rr({runId:e,aliyahIndex:t},n){let r=W;if(!r)return;dt({runId:e,index:t});let i=await r.loadRecording({runId:e,aliyahIndex:t},{mode:`authoring`});if(or.isCurrent(n)){if(!i){console.error(`Could not prepare ${e}:${t} for audio authoring`);return}Kr()}}async function zr(e,t){let n=`${t.runId}:${t.aliyahIndex}:${x.narratorId}`;N.delete(n);try{return await e.loadRecording(t)}catch(e){return e instanceof DOMException&&e.name===`AbortError`?null:(console.error(`Could not prepare aliyah playback`,e),N.set(n,{problem:`load-failed`,issue:`audio`,canPlay:!1,recording:jn(t),message:`The recording could not load. Try again.`}),Kr(),Wr(),Ue(e instanceof Error?e.message:`Audio could not be loaded. Retry playback.`),null)}}async function Br(e){if(e.getAttribute(`aria-disabled`)===`true`)return;let t=W;if(!t)return;let n=Dr(e);if(!n)return;let r=or.start();if(H?.isActive()&&!n.recording){await Rr({runId:n.run.id,aliyahIndex:n.aliyahIndex},r);return}if(!n.available||n.audioState?.problem===`checking`)return;if(dt({runId:n.run.id,index:n.aliyahIndex}),t.isTargetActive({recordingId:n.recording?.id??null,runId:n.run.id,aliyahIndex:n.aliyahIndex})){let n=t.snapshot().paused,r=t.toggle(()=>Br(e));n&&await t.restoreActiveHighlight({scroll:!0}),await r;return}let i=t.lookupRecording(n.run,n.aliyahIndex);(!i.passage||![`partial-audio`,`timing-needed`].includes(i.passage.problem??``))&&kr(i.passage?.recording,i.recording,i.overlapRecording,n.recording),await zr(t,{runId:n.run.id,aliyahIndex:n.aliyahIndex})&&or.isCurrent(r)&&await t.play(()=>Br(e))}async function Vr({runId:e,aliyahIndex:t}){let n=W;if(!n)return;let r=or.start(),i=(y?.capture())?.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e);if(!i)return;let a=n.lookupRecording(i,t),o=!!(H?.isActive()&&!a.recording);if(!o&&(!a.available||a.passage?.problem===`checking`))return;if(n.isTargetActive({recordingId:a.recording?.id??null,runId:e,aliyahIndex:t})){dt({runId:e,index:t}),await n.toggle(()=>Vr({runId:e,aliyahIndex:t}));return}let s=()=>Vr({runId:e,aliyahIndex:t});!o&&(!a.passage||![`partial-audio`,`timing-needed`].includes(a.passage.problem??``))&&kr(a.passage?.recording,a.recording,a.overlapRecording);let c=await Q().ensureAliyahDomTargetRendered(e,t);if(or.isCurrent(r)&&(c?.marker??c?.element)){if(o){await Rr({runId:e,aliyahIndex:t},r);return}dt({runId:e,index:t}),await zr(n,{runId:e,aliyahIndex:t})&&or.isCurrent(r)&&await n.play(s)}}function Hr(e=y?.viewportRange()??null){let t=ht(),n=Q().progressSnapshot(),r=n.anchors,a=r.length?nr(t):0,o=Oe&&r.length?xr(r,Z,a):null;Ee&&(Z=a,Oe=!1);let s=yc({source:n,viewportPosition:a,getScrollHeight:()=>t.scrollHeight,rangeCurrent:r.length?br(e,r):null,isLastAnchor:rr});if(Ee&&!i.enabled){let e=Ke(o);e&&q?.syncScrolledReading(e)}if(s.kind===`empty`){xt().setProgress({label:s.label,percent:s.percent}),jr(null),ae?.sync(),Fn(e,n);return}if(xt().setProgress({label:s.label}),jr(s.current),ae?.sync(),Fn(e,n),s.kind===`request-next-anchor`){Q().ensureNextProgressAnchorLoaded(s.requestNextAnchor.afterIndex).then(()=>Ur()).catch(e=>{console.error(`Failed to load the next reader progress anchor`,e)});return}xt().setProgress({percent:s.percent})}function Ur(){if(y){y.invalidatePresentationAfterLayout(`reader-position`);return}Hr()}function Wr(){if(y){y.invalidatePresentation(`reader-position`);return}Hr()}function Gr(e=!1){if(!e){let e=Q().progressSnapshot(),t=nr(ht());jr(e.at(t).current)}O?.syncPlayback(Dn())}function Kr(){if(y){y.invalidatePresentation(`inline-audio`,`playback-state`);return}Ar(),Gr()}function qr(){if(y){y.invalidatePresentation(`inline-audio`,`reader-position`);return}Ar(),Hr()}function Yr(e){let t=e.focalPointMode!==void 0&&e.focalPointMode!==x.focalPointMode?wr(ht()):null,n=e.readerTextLayout!==void 0&&e.readerTextLayout!==x.readerTextLayout||e.readerSideMode!==void 0&&e.readerSideMode!==x.readerSideMode,r=Fr(x,e);try{_e=Nr(r,_e)}catch(t){if(console.error(`Failed to save reader preferences`,t),t instanceof Pr&&t.cause instanceof oe&&t.cause.reason===`conflict`){let t=Mr(),n=Fr(t.preferences,e);try{_e=Nr(n,t.revision),r=n}catch(e){console.error(`Failed to save reader preferences after refreshing browser state`,e),Ge(`Reader settings changed in another tab. This change applies now but could not be saved.`)}}else Ge(`Reader settings will apply now but could not be saved.`)}x=r,n?_t({beforeLayout:()=>Ir(x)}):Ir(x),Tr(t,{behavior:`smooth`}),qr()}function Zr(e,t){let n=null,r=0,i=()=>{y?.invalidateProgressAnchors(`viewport-resized`),n??=wr(t),nt(),!r&&(r=d(()=>{r=0;let i=n;n=null,Ne(t,e.signal),Tr(i)}))};nt(),c.addEventListener(`resize`,i,{signal:e.signal}),c.visualViewport?.addEventListener(`resize`,i,{signal:e.signal}),e.own(()=>{n=null,r&&f(r),r=0})}let Qr=!l.hash,$r=e.querySelector(`[data-target-id="reader-audio"]`);i.enabled&&(e.documentElement.dataset.recordingMode=`true`);let ri=Mr();_e=ri.revision,x=i.enabled?tn(ri.preferences):ri.preferences,Ir(x);let ii=co(n,Xn);he=ii.bookmarks,ge=ii.revision;let ai,oi=v(m=>{let g=o??ee();o||m.own(()=>g.destroy()),P(async()=>{let{mountAudioButtonTooltip:e}=await import(`./Dtzlsesb.js`);return{mountAudioButtonTooltip:e}},[],import.meta.url).then(({mountAudioButtonTooltip:t})=>{m.signal.aborted||t(m,e)}).catch(e=>console.error(`Could not load audio tooltips`,e));let v=Co(m,{document:e,initialTitle:Sc,initialAnnotationsEnabled:Ce,onTitleClick:()=>{Y?.close(),q?.togglePicker({animate:!0})},onAboutClick:()=>{O?.closeCompact(),q?.toggleAbout()},onAnnotationsChange:et,onSwapSides:()=>{Yr({readerSideOrder:x.readerSideOrder===`tikkun-right`?`torah-right`:`tikkun-right`})}});ce=v,m.own(()=>{ce===v&&(ce=null)});let S=ht(),C=Mn(m,c);ie=C,_t({rerender:!1}),C.onChange(()=>{_t(),G?.sync()}),m.own(()=>{ie===C&&(ie=null)});let w=new Nn,T=_c({document:e,view:c,root:S,search:l.search,frame:{request:d,cancel:f},timer:{set:(e,t)=>c.setTimeout(e,t),clear:e=>c.clearTimeout(e)},background:{request:dr,delay:(e,t)=>c.setTimeout(e,t),cancel:pr},effects:{beforeDisplayReplacement(){k.clear()},resetDisplayResources:cr,afterDisplayReplacementReset:Fn,displayCreated(e){W?.setDisplay(e)},displayDeactivating(){de?.clearPlaybackFailure()},resolveRun:e=>_().parseId(e),getPlaybackProtectedPageNumbers:e=>W?.protectedCuePageNumbers(e)??[],isPlaybackActive:lr,async prewarmCueData({run:e,aliyahIndex:t}){let n=lt({narratorId:x.narratorId,run:e,aliyahIndex:t});n&&await vt(n)},present(e){let t=e.includes(`viewport-title`),n=e.includes(`reader-position`),r=e.includes(`playback-state`),i=y?.capture(),a=y?.viewportRange()??null;if(t&&i&&a){w.setLine(i.viewModel,a);let e=w.info.currentRun;q?.setTitle(Cc(e?i.viewModel.displayTitleForRun(e):void 0))}e.includes(`inline-audio`)&&Ar(),n&&Hr(),r&&Gr(n)},reportError(e,t){e?console.error(e,t):console.error(t)}}});y=T,m.own(()=>{T.destroy(),y===T&&(y=null)});let A=null,M;m.own(()=>M?.());let N=Ya(m,{document:e,view:c,audioElement:$r,book:S,viewport:C,initialPlaybackRate:x.playbackRate,timeline:{getAutoScroll:()=>x.autoScrollWithPlayback,getPlaybackRate:()=>x.playbackRate,onPlaybackRateChange:e=>{x=Fr(x,{playbackRate:e}),Ir(x),G?.sync()},isCueAuthoringRecording:()=>H?.isRecording()??!1,saveReadingPosition:Ze,focusReader:Ct,restoreFocus:on},recording:{passages:j,choosePassagePortion:async(t,n,r)=>{let{createPassageAudioDialog:i}=await P(async()=>{let{createPassageAudioDialog:e}=await import(`./Dtzlsesb.js`);return{createPassageAudioDialog:e}},[],import.meta.url);return n.aborted||m.signal.aborted?null:(A??=i(m,e),A(t,n,r))},library:{findRecording:lt,findAuthoringRecording:ut,listRecordings:mt,loadCues:vt},display:{resolveRun:e=>T.capture()?.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e),collectTokenKeys:Lr,waitUntilReady:()=>T.waitUntilReaderReady(),resolveRunForRecording:e=>K(e)?T.capture()?.viewModel.relevantRuns.find(t=>ct(t)===e.parshaSlug)??null:null},authoring:{isActive:()=>H?.isActive()??!1,isVisible:()=>H?.isVisible()??!1,hasSession:()=>!!H?.getSession(),bindSession:async()=>{await H?.bindSession()},clearSession:()=>H?.clearSession()},getNarratorId:()=>x.narratorId,recordingMode:i.enabled}});W=N;let I=e.baseURI,L=g.getLibrary(e=>Da({baseUrl:I,navigator:u,storage:n,inUse:e}),{view:c,document:e,intentKey:ma}),ne=Oa({currentSources:()=>N.snapshot().session?.mediaSources??[],whenReleased:()=>N.whenAudioReleased(),onReleased:()=>L.releasePlayback()}),z,B=g.protectPlayback(e=>(z??ne.sources()).some(t=>new URL(t,I).href===e.url));m.signal.addEventListener(`abort`,()=>{z=ne.freeze()},{once:!0}),M=()=>{N.whenAudioReleased().then(B).catch(e=>console.error(`Could not release recording download protection`,e))};let V,oe,ue=t=>{if(G?.close({restoreFocus:!1}),V){V.open({returnFocus:t,narratorId:x.narratorId});return}oe||=P(async()=>{let{createMediaPanel:e}=await import(`./bmzTKomM.js`);return{createMediaPanel:e}},__vite__mapDeps([33,1,8,2,34,11,13,5,6,7,9,10,16,35]),import.meta.url).then(({createMediaPanel:n})=>{m.signal.aborted||(V=n(m,{document:e,generator:_(),library:L,recordings:mt(),narrators:pt(),narratorId:x.narratorId}),V.open({returnFocus:t,narratorId:x.narratorId}))}).catch(e=>{console.error(`Could not open Media`,e),m.signal.aborted||Ge(`Media could not be opened. Try again.`)}).finally(()=>{oe=void 0})};se=ue,m.own(()=>{se===ue&&(se=null)}),m.own(N.subscribe((e,t)=>{(e.type===`session-loaded`||e.type===`route-reset`)&&ne.sync().catch(e=>console.error(`Could not remove released recordings`,e)),e.type===`reader-chrome`?(t.playing&&de?.clearPlaybackFailure(),Kr()):e.type===`aliyah-playback`?O?.syncPlayback(Dn()):e.type===`session-loaded`?(de?.clearPlaybackFailure(),Ar(),Wn(),Me(),Fn(),G?.sync()):e.type===`segment-updated`?(Wn(),G?.sync()):e.type===`active-token-changed`?Yn():e.type===`playback-error`?(Kr(),Wr(),u.onLine&&(console.error(`Audio playback failed for ${e.recording.id}`,e.error),Ue(`This recording could not play. Check your connection and try again.`,{assertive:!0}))):e.type===`offline-media-error`&&Zn(e.retry)})),m.own(()=>{ze(),W===N&&(W=null)});let fe=N.cueAuthoringAdapter(),pe=Fc(m,{sessionStorage:r,mount:(t,i)=>i.createCueAuthoring(t,{document:e,view:c,playback:fe,localStorage:n,sessionStorage:r,getAutoScroll:()=>x.autoScrollWithPlayback,getActiveTokenKey:kt,getMergedRecordingIssues:()=>xe,getLocalRecordingIssues:()=>X,getLocalRecordingIssueRevision:()=>be,focusReader:Ct,formatDuration:sa,onChange:e=>{e===`access`?rn():e===`cue-data`?(Me(),Ar(),Wn()):e===`draft`?(Me(),Ar()):e===`mode`?Ot():e===`playback`?fe.refresh():e===`playback-progress`&&fe.refresh(`progress`)},onCueNavigationChange:e=>{fe.setCueIndex(e)},onLocalRecordingIssuesChanged:(e,t)=>{X=e,be=t,xe=le(ye,X),Gn(),Yn(),rn()},showPersistenceNotice:Ge}),onMounted:e=>{H=e},onUnmounted:e=>{H===e&&(H=null)},onLoadError:e=>{console.error(`Failed to load Cue Authoring`,e)}});U=pe,m.own(()=>{U===pe&&(U=null)});let me=kc(m,{document:e,disabled:i.enabled,onResume:e=>{q?.navigate(e.hash,{saveReadingAfterRender:!0})}});J=me,m.own(()=>{J===me&&(J=null)});let he=Jn(m,{document:e,getActions:nn,createGenerator:_,restoreFocus:Ct,isBookmarkAction:Ut,formatBadge:Ht,onLoadError:e=>{console.error(`Failed to load the search overlay`,e),Ge(`Search could not be opened. Reload this page to try again.`)}});Y=he,m.own(()=>{Y===he&&(Y=null)});let ge=Ac(m,{document:e,view:c,onRetryError:e=>{console.error(`Failed to retry recording after reconnecting`,e)}});de=ge,m.own(()=>{de===ge&&(de=null)}),Rn(m);let _e=yo(m,{document:e,getState:It,toggleBookmark:()=>{Pt(),Ct()},openAliyahNavigation:e=>{if(wt()){O?.openCompact(e);return}O?.revealWide(`expanded`),O?.scheduleWideHide(),Ct()},showAliyahStarts:()=>{O?.revealWide(`peek`),Ct()},toggleAnnotations:()=>{et(!Ce),Ct()},openSettings:e=>{G?.open({returnFocus:e})},openMedia:ue,shareReading:async()=>{try{let e=await Qn(Rt(),{navigator:u,nativeShare:R()?async e=>{let{Share:t}=await P(async()=>{let{Share:e}=await import(`./BVZf8LWP.js`);return{Share:e}},__vite__mapDeps([36,6,9]),import.meta.url);return t.share(e)}:void 0});!m.signal.aborted&&e===`copied`&&Ue(`Reading link copied.`)}catch(e){console.error(`Could not share reading`,e),m.signal.aborted||Ue(`Reading could not be shared. Try again.`,{assertive:!0})}}});ae=_e,m.own(()=>{ae===_e&&(ae=null)}),Tn(m);let ve=Qr&&!i.enabled?Bn(n,Date.now(),Xn):null;wn(m),st(m,S),Zr(m,S);let Se=fo(m,{document:e,view:c,narrators:pt(),getPreferences:()=>x,updatePreferences:e=>Yr(e),setPlaybackRate:e=>{N.setPlaybackRate(e),qr()},restoreFocus:on,animateThemeChanges:!i.enabled,serviceWorker:te(c.navigator),getCurrentRecording:()=>N.snapshot().session?.activeRecording??null,downloadLibrary:L,openMedia:()=>ue(e.querySelector(`[data-target-id="settings-toggle"]`)??void 0),prepareForUpdate:()=>{if(!N.snapshot().paused)throw Error(`Pause audio before applying the update.`);if(H?.isActive()||i.enabled)throw Error(`Finish recording or editing before applying the update.`);if(L?.snapshot().entries.some(e=>[`queued`,`downloading`,`verifying`,`removing`].includes(e.phase)))throw Error(`Wait for downloads to finish, or pause them before applying the update.`);let e=Xe();if(!e)throw Error(`Wait for your reading to load before applying the update.`);zn(n,e)},onLoadError:e=>{console.error(`Failed to load Reader Settings`,e),Ge(`Reader Settings could not be opened. Reload this page to try again.`)}});G=Se,m.own(()=>{G===Se&&(G=null)}),ot(m);let we=tt(()=>Ze(),1e3);m.own(we.cancel);let De=()=>{(!Ee||Z===null)&&(Z=nr(S)),Ee=!0},ke=()=>{Te=!0,De(),J?.dismiss()};S.addEventListener(`pointerdown`,De,{passive:!0,signal:m.signal}),S.addEventListener(`keydown`,De,{signal:m.signal}),S.addEventListener(`wheel`,ke,{passive:!0,signal:m.signal}),S.addEventListener(`touchstart`,ke,{passive:!0,signal:m.signal}),S.addEventListener(`keydown`,p(`ArrowDown`,ke),{signal:m.signal}),S.addEventListener(`keydown`,p(`ArrowUp`,ke),{signal:m.signal}),S.addEventListener(`keydown`,p(`PageDown`,e=>{ke(e),O?.revealWideForMovement()}),{signal:m.signal}),S.addEventListener(`keydown`,p(`PageUp`,e=>{ke(e),O?.revealWideForMovement()}),{signal:m.signal}),S.addEventListener(`scroll`,()=>{Ee&&(Oe=!0),T.onReaderScroll(()=>{let e=S.scrollTop,t=D;D=e,Vn(),t!==null&&Math.abs(e-t)>=28&&!N.snapshot().playing&&O?.revealWideForMovement()}),Te&&we()},{signal:m.signal}),S.addEventListener(`page-rendered`,e=>{let t=e instanceof CustomEvent?e.detail?.node:null,n=t instanceof Element?t:S;xn(n,Ce),Ne(n,m.signal),T.pageRendered(n,()=>{_r(S,S.dataset.readerLayout===`reading`?S:n),hr(n),Gn(n)}),!lr()&&(qr(),N.syncHighlight({scroll:!1}))},{signal:m.signal}),S.addEventListener(`page-evicted`,e=>{let t=e instanceof CustomEvent?e.detail?.pageNumber:null;T.pageEvicted(Number.isInteger(t)?t:null)},{signal:m.signal});let Q=null,Ae=[`button`,`a`,`input`,`select`,`textarea`,`[contenteditable="true"]`,`[data-reader-no-form-toggle="true"]`].join(`,`);S.addEventListener(`pointerdown`,e=>{let t=e.target;if(!wt()||!(t instanceof Element)||!S.contains(t)||t.closest(Ae)){Q=null;return}Q={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,startedAt:performance.now(),canceled:!1,readyAt:null}},{passive:!0,signal:m.signal}),S.addEventListener(`pointermove`,e=>{!Q||Q.pointerId!==e.pointerId||Math.hypot(e.clientX-Q.startX,e.clientY-Q.startY)>8&&(Q.canceled=!0)},{passive:!0,signal:m.signal}),S.addEventListener(`pointerup`,e=>{if(!Q||Q.pointerId!==e.pointerId)return;let t=performance.now()-Q.startedAt;Q.readyAt=!Q.canceled&&t<450?performance.now():null},{passive:!0,signal:m.signal}),S.addEventListener(`pointercancel`,()=>{Q=null},{passive:!0,signal:m.signal});function $(e){let t=Q;if(Q=null,!t?.readyAt||performance.now()-t.readyAt>500||gt().sides!==`one`)return!1;let n=e.target;if(!(n instanceof Element)||!S.contains(n)||n.closest(Ae))return!1;let r=c.getSelection();return!r||r.isCollapsed}S.addEventListener(`click`,async t=>{let n=t.target,r=n.closest(`[data-audio-button="true"]`);if(r){t.preventDefault(),await Br(r),Je(T.progressAnchorForElement(r)),Ct();return}if(await Jr(t,{nativeWriteText:R()?async e=>{let{Clipboard:t}=await P(async()=>{let{Clipboard:e}=await import(`./CJ7KFjv4.js`);return{Clipboard:e}},__vite__mapDeps([37,9]),import.meta.url);await t.write({string:e})}:void 0,onError:()=>{m.signal.aborted||Ue(`Reading link could not be copied. Try again.`,{assertive:!0})}}))return;let i=n.closest(`.word`),a=N.snapshot();if($(t)&&(!i||!a.session)){t.preventDefault(),et(!Ce),Ct();return}if(!i||!a.session)return;let o=i.dataset.tokenKey??null;if(!o)return;let s=N.tokenIndex(o),c=N.cueForToken(o),l=a.playing;if(H?.isActive()&&!H.isRecording()&&s>=0){t.preventDefault(),await H.selectReaderToken(s,{play:l&&!!c,preservePlayback:l,seekToCue:!!c,focusRow:!0}),jr(T.progressAnchorForElement(i));return}let u=await N.activateSessionToken(o,{play:!!c,seekToCue:!!c,retry:async()=>{e.body.contains(i)&&i.click()},scroll:x.autoScrollWithPlayback}),d=T.progressAnchorForElement(u??i);jr(d),Je(d)},{signal:m.signal});let je=jc({getValue:()=>Ce,setValue:et,isDisabled:()=>x.disableShiftNekudotHide});e.addEventListener(`keydown`,je.handleKeyDown,{signal:m.signal}),e.addEventListener(`keyup`,je.handleKeyUp,{signal:m.signal}),c.addEventListener(`blur`,je.release,{signal:m.signal}),m.own(je.release),e.addEventListener(`keydown`,p(`/`,e=>{Tt(e.target)||(e.preventDefault(),Y?.close(),q?.togglePicker())}),{signal:m.signal}),e.addEventListener(`keydown`,p(`Escape`,e=>{if(O?.isCompactOpen()&&(e.preventDefault(),O.closeCompact()),N.closeOverlay()){e.preventDefault();return}q?.snapshot().pickerOpen&&(e.preventDefault(),q.closePicker()),G?.close(),H?.closeOverlays(),Y?.close(),mn()}),{signal:m.signal}),e.addEventListener(`click`,e=>{if(e.defaultPrevented)return;let t=e.target.closest(`a[href^="#/"]`);if(!t)return;let n=t.getAttribute(`href`);(!n||n===l.hash)&&(e.preventDefault(),q?.navigate(n??l.hash))},{signal:m.signal}),e.addEventListener(`keydown`,e=>{if(!pe.handleShortcut(e)&&!e.defaultPrevented&&!Tt(e.target)&&!(q?.snapshot().view!==`reader`||!N.snapshot().session)){if(e.code===`Space`){e.preventDefault(),N.toggle(async()=>{await N.play()});return}if(e.key===`ArrowRight`){e.preventDefault(),N.step(1);return}e.key===`ArrowLeft`&&(e.preventDefault(),N.step(-1))}},{signal:m.signal}),i.enabled&&P(async()=>{let{mountRecordingHarness:e}=await import(`./DYtFn8bC.js`);return{mountRecordingHarness:e}},[],import.meta.url).then(({mountRecordingHarness:t})=>{if(m.signal.aborted)return;let n=N.recordingHarnessAdapter();t(m,{document:e,view:c,playback:n,isReaderReady:()=>T.isReaderReady(),waitUntilReaderReady:()=>T.waitUntilReaderReady(),getBook:ht})}).catch(e=>{m.signal.aborted||console.error(`Failed to load the Recording Harness`,e)}),pe.restoreIfOpen();let Pe=Oc(m,{document:e,view:c,shell:v,createGenerator:_,getCalendarSettings:()=>h,updateCalendarSettings:$e,getSearchActions:nn,isBookmarkAction:Ut,formatSearchBadge:Ht,host:{renderReader:Le,leaveReader:()=>{N.pause(),ze(),Dt(),J?.hide()},openAbout:()=>{if(!s){t.location.assign(a);return}s().catch(e=>{console.error(`Could not open About`,e),m.signal.aborted||Ue(`About could not be opened. Try again.`,{assertive:!0})})},readerRouteChanged:e=>{Ee=!1,Z=null,Oe=!1,E!==e&&ft(),Qe(),T.resetViewport(),ae?.close(),mn(),O?.revealWide(`peek`)},readerReady:()=>{let e=T.capture();qr();let t=q?.snapshot();!i.enabled&&t?.view===`reader`&&F(t.currentReaderHash)&&re({reading:{hash:t.currentReaderHash,parshaName:t.title}}),W===N&&N.syncHighlight({scroll:!1}).catch(t=>{e?.isCurrent()&&console.error(`Failed to restore reader highlight`,t)});let n=Fe();n&&W===N&&N.activateToken(n,{scroll:!1}).catch(t=>{e?.isCurrent()&&console.error(`Failed to activate debug token`,t)})},preparePicker:()=>{Y?.close(),Dt()},pickerChanged:e=>{Fn(),e?jr(null):qr()},pickerLoadFailed:e=>{console.error(`Failed to load the Reading Index`,e),Ge(`The Reading Index could not be opened. Reload this page to try again.`)},captureReadingPosition:Xe,showReturnToPreviousReading:e=>{J?.show(e,`return`)},dismissLastReadingPrompt:()=>J?.dismiss(),saveReadingPosition:Ze}});q=Pe,m.own(()=>{q===Pe&&(q=null)});let Ie=R()&&!i.enabled;ai=Pe.start(Ie?{resumeHash:ve?.hash??null}:void 0),m.own(()=>{b!==null&&(c.clearTimeout(b),b=null);let t=e.querySelector(`[data-target-id="persistence-toast"]`);t&&(t.classList.add(`u-hidden`),t.textContent=``,t.setAttribute(`role`,`status`),t.setAttribute(`aria-live`,`polite`)),Y?.close(),de?.hide(),J?.hide()}),ve&&!Ie&&J?.show(ve)});return{ready:ai,destroy:oi}}var Lc=b({startApp:()=>zc,stopApp:()=>Bc}),Rc=null;function zc(e={}){if(Rc)return Rc;let t=document.querySelector(`[data-target-id="app-root"]`)?.dataset.aboutHref;if(!t)throw Error(`Reader bootstrap requires an About page URL`);return Rc=Ic({document,view:window,localStorage:G(`local`),sessionStorage:G(`session`),recordingMode:$t(new URL(window.location.href)),aboutHref:t,...e}),Rc}function Bc(){Rc?.destroy(),Rc=null}export{St as C,mt as D,pt as E,_t as O,gt as S,vt as T,Ut as _,Ir as a,Dt as b,Fr as c,un as d,en as f,zt as g,Jt as h,da as i,at as k,Rr as l,Yt as m,wa as n,Lr as o,Zt as p,_a as r,wr as s,zc as startApp,Bc as stopApp,Lc as t,jn as u,qt as v,xt as w,Ct as x,Mt as y};