import{a as e}from"./CxkbxRrs.js";import{n as t}from"./D0YNzAQW.js";import{C as n,c as r,o as i,t as a}from"./KkKzNkus.js";import{C as o,D as s,E as c,T as l,p as u,w as d}from"./CmEV0pKi.js";var f=8,p=10;function m(e){return e.reduce((e,t)=>e+t,0)}function h(e){return e.length?m(e)/e.length:0}function g(e){if(!e.length)return 0;let t=[...e].sort((e,t)=>e-t),n=Math.floor(t.length/2);return t.length%2==0?(t[n-1]+t[n])/2:t[n]}function _(e,t){if(!e.length)return 0;let n=[...e].sort((e,t)=>e-t),r=(n.length-1)*t,i=Math.floor(r),a=Math.ceil(r);if(i===a)return n[i];let o=r-i;return n[i]*(1-o)+n[a]*o}function v(e){let t=[];for(let n=1;n<e.length;n+=1){let r=e[n-1],i=e[n];!r||!i||t.push({previousCue:r,cue:i,gap:Number((i.timeStart-r.timeStart).toFixed(3))})}return t}function y(e){return e.map(e=>e.gap).filter(e=>e>0)}function b(e){if(e.length<4)return{lower:0,upper:1/0};let t=_(e,.25),n=_(e,.75),r=n-t;return{lower:Math.max(0,t-r*1.5),upper:n+r*1.5}}function x(e,t,n){return e.map((e,r)=>{let{cue:i,previousCue:a,gap:o}=e,s=o<=0,c=Math.max(f,t.upper),l=!s&&o>=c,u=s?`invalid`:l?`slow`:null,d=s||u===null?null:Number(c.toFixed(3)),m=s||u===null?null:`above`,h=s?`Out of order`:l?`Long pause outlier`:`Within expected range`,g=s?p:d&&d>0?o/d:0;return{cueNumber:i.cueNumber??r+2,previousCueNumber:a.cueNumber??r+1,gap:o,wordsPerMinute:o>0?60/o:0,isOutlier:s||u!==null,isStructuralPause:!1,outlierDirection:u,severity:g,reviewLabel:h,deviationSeconds:Number((o-n).toFixed(3)),localMedianGap:Number(n.toFixed(3)),thresholdGap:d,thresholdDirection:m}})}function S({recording:e,narratorName:t,cues:n,cueSource:r=`published`,cueUpdatedAt:i=null}){let a=v(n),o=y(a),s=b(o),c=x(a,s,g(o)),l=n.length>1?Number((n[n.length-1].timeStart-n[0].timeStart).toFixed(3)):0;return{recording:e,narratorName:t,cueCount:n.length,intervalCount:o.length,transitionCount:a.length,cues:n,intervals:o,intervalSamples:c,totalDuration:l,averageGap:h(o),medianGap:g(o),longestGap:o.length?Math.max(...o):0,shortestGap:o.length?Math.min(...o):0,averageWordsPerMinute:o.length?60/h(o):0,outlierCount:c.filter(e=>e.isOutlier).length,invalidTransitionCount:c.filter(e=>e.outlierDirection===`invalid`).length,structuralPauseCount:c.filter(e=>e.isStructuralPause).length,lowerOutlierThreshold:s.lower,upperOutlierThreshold:s.upper,cueSource:r,cueUpdatedAt:i}}function C(e){let t=e.flatMap(e=>e.intervals),n=e.reduce((e,t)=>e+t.cueCount,0),r=e.reduce((e,t)=>e+t.totalDuration,0);return{recordingCount:e.length,cueCount:n,intervalCount:t.length,totalDuration:r,averageGap:h(t),medianGap:g(t),averageWordsPerMinute:t.length?60/h(t):0,longestGap:t.length?Math.max(...t):0,outlierCount:e.reduce((e,t)=>e+t.outlierCount,0),invalidTransitionCount:e.reduce((e,t)=>e+t.invalidTransitionCount,0),structuralPauseCount:e.reduce((e,t)=>e+t.structuralPauseCount,0)}}function w(e){let t=[];for(let n=1;n<=7;n+=1){let r=e.filter(e=>e.recording.aliyah===n&&e.intervalCount>0),i=r.flatMap(e=>e.intervals);t.push({aliyah:n,recordingCount:r.length,cueCount:r.reduce((e,t)=>e+t.cueCount,0),averageDuration:h(r.map(e=>e.totalDuration)),averageGap:h(i),medianGap:g(i),averageWordsPerMinute:i.length?60/h(i):0,longestGap:i.length?Math.max(...i):0,outlierCount:r.reduce((e,t)=>e+t.outlierCount,0),structuralPauseCount:r.reduce((e,t)=>e+t.structuralPauseCount,0)})}return t}function T(e){return e.reduce((e,t)=>e+t,0)}function E(e){return e.length?T(e)/e.length:0}function D(e){if(!e.length)return 0;let t=[...e].sort((e,t)=>e-t),n=Math.floor(t.length/2);return t.length%2==0?(t[n-1]+t[n])/2:t[n]}async function O(t){let n=new Map(c().map(e=>[e.id,e.displayName]));return(await Promise.all(s().filter(e).filter(e=>e.status===`available`).map(async e=>{let r=t?.cueOverrides?.has(e.id)?t.cueOverrides.get(e.id)??[]:await l(e),i=t?.cueUpdatedAtByAudioId?.get(e.id)??await d(e);return S({recording:e,narratorName:n.get(e.narratorId)??e.narratorId,cues:r,cueSource:t?.cueSourceByAudioId?.get(e.id)??`published`,cueUpdatedAt:i})}))).sort((e,t)=>(e.recording.parshaNumber??2**53-1)-(t.recording.parshaNumber??2**53-1)||e.recording.aliyah-t.recording.aliyah||e.narratorName.localeCompare(t.narratorName))}function k(t){let n=new Map(t.map(e=>[e.recording.id,e])),r=new Map;for(let t of s().filter(e).filter(e=>e.status===`available`)){let e=r.get(t.parshaSlug)??{parshaSlug:t.parshaSlug,parshaName:t.parshaName,parshaNumber:t.parshaNumber,recordingCount:0,cueRecordingCount:0,availableAliyot:[],cueAliyot:[],missingCueAliyot:[],averageDuration:0,averageGap:0,medianGap:0,averageWordsPerMinute:0,longestGap:0,outlierCount:0,structuralPauseCount:0};e.recordingCount+=1,e.availableAliyot.push(t.aliyah);let i=n.get(t.id);i&&i.intervalCount>0?(e.cueRecordingCount+=1,e.cueAliyot.push(t.aliyah)):e.missingCueAliyot.push(t.aliyah),r.set(t.parshaSlug,e)}return[...r.values()].map(e=>{let n=t.filter(t=>t.recording.parshaSlug===e.parshaSlug&&t.intervalCount>0),r=n.flatMap(e=>e.intervals);return{...e,availableAliyot:[...new Set(e.availableAliyot)].sort((e,t)=>e-t),cueAliyot:[...new Set(e.cueAliyot)].sort((e,t)=>e-t),missingCueAliyot:[...new Set(e.missingCueAliyot)].sort((e,t)=>e-t),averageDuration:E(n.map(e=>e.totalDuration)),averageGap:E(r),medianGap:D(r),averageWordsPerMinute:r.length?60/E(r):0,longestGap:r.length?Math.max(...r):0,outlierCount:n.reduce((e,t)=>e+t.outlierCount,0),structuralPauseCount:n.reduce((e,t)=>e+t.structuralPauseCount,0)}}).sort((e,t)=>(e.parshaNumber??2**53-1)-(t.parshaNumber??2**53-1)||e.parshaName.localeCompare(t.parshaName))}var A=new Intl.NumberFormat(void 0,{maximumFractionDigits:0}),j=`<span class="inline-direction-arrow" role="img" aria-label="to">${t(`arrowRight`)}</span>`,M=new Intl.DateTimeFormat(void 0,{dateStyle:`medium`,timeStyle:`short`}),N=new n({ashkenazi:!0,includeModernHolidays:!1,israel:!1}),P=new Map;function F(e){return P.has(e)||P.set(e,r(N,e)),P.get(e)??null}function I(e,t){let n=F(e),r=n?.run.aliyot.find(e=>e.index===t)?.start;return i(n?.canonicalSlug??e,r)}function L(e){return!Number.isFinite(e)||e<=0?`0.00s`:`${e.toFixed(2)}s`}function R(e){return!Number.isFinite(e)||e===0?`0.00s`:`${e>0?`+`:`-`}${Math.abs(e).toFixed(2)}s`}function z(e){return!Number.isFinite(e)||e<=0?`0 wpm`:`${A.format(Math.round(e))} wpm`}function B(e){if(!Number.isFinite(e)||e<=0)return`0:00`;let t=Math.round(e),n=Math.floor(t/60),r=t%60;return`${n}:${String(r).padStart(2,`0`)}`}function V(e){return e?M.format(e):`Unknown save time`}function H(e,t){return e&&t?`${e}, aliyah ${u(t)}`:e?`${e}, all available aliyot`:t?`all parshiot, aliyah ${u(t)}`:`all playback timing data`}function U(e,t){return e.getAttribute(`data-${t}`)??``}function W(e){return e.outlierDirection===`invalid`?`Timing moved backward.`:!e.thresholdGap||!e.thresholdDirection?`No review threshold crossed.`:`Review threshold ${e.thresholdDirection===`above`?`>`:`<`} ${L(e.thresholdGap)}`}function G(e){return`${R(e.deviationSeconds)} vs median gap ${L(e.localMedianGap)}`}function K(e){for(let t of e.querySelectorAll(`[data-analytics-graph]`)){let e=t.querySelector(`.analytics-graph-stage`),n=t.querySelector(`[data-analytics-graph-svg]`),r=t.querySelector(`[data-analytics-graph-tooltip]`),i=t.querySelector(`[data-analytics-graph-focus-line]`),a=t.querySelector(`[data-analytics-graph-focus-point]`),o=Array.from(t.querySelectorAll(`[data-analytics-graph-point]`));if(!e||!n||!r||!i||!a||!o.length)continue;let s=Number(n.dataset.graphTop??`0`),c=Number(n.dataset.graphBottom??`0`),l=Number(n.dataset.graphLeft??`0`),u=Number(n.dataset.graphRight??`0`),d=null,f=()=>{d?.classList.remove(`is-active`),d=null,t.classList.remove(`is-active`),r.hidden=!0,i.setAttribute(`visibility`,`hidden`),a.setAttribute(`visibility`,`hidden`)},p=o=>{if(d===o)return;d?.classList.remove(`is-active`),d=o,d.classList.add(`is-active`),t.classList.add(`is-active`);let l=Number(U(o,`x`)),u=Number(U(o,`y`)),f=U(o,`cue-number`),p=U(o,`previous-cue-number`),m=U(o,`gap`),h=U(o,`pace`),g=U(o,`review-label`),_=U(o,`threshold`),v=U(o,`deviation`);i.setAttribute(`x1`,`${l}`),i.setAttribute(`x2`,`${l}`),i.setAttribute(`y1`,`${s}`),i.setAttribute(`y2`,`${c}`),i.setAttribute(`visibility`,`visible`),a.setAttribute(`cx`,`${l}`),a.setAttribute(`cy`,`${u}`),a.setAttribute(`visibility`,`visible`),r.innerHTML=`
        <strong>Word ${p} ${j} ${f}</strong>
        <span>${m}s gap · ${h} wpm</span>
        <span>${g||`Within expected range`}</span>
        <span>${_}</span>
        <span>${v}</span>
      `,r.hidden=!1;let y=e.getBoundingClientRect(),b=n.getBoundingClientRect(),x=n.viewBox.baseVal,S=b.left-y.left+(x.width?l/x.width*b.width:0),C=b.top-y.top+(x.height?u/x.height*b.height:0);r.style.setProperty(`--analytics-tooltip-x`,`${S}px`),r.style.setProperty(`--analytics-tooltip-y`,`${C}px`)};n.addEventListener(`pointermove`,e=>{let t=n.getBoundingClientRect(),r=n.viewBox.baseVal,i=(e.clientX-t.left)/Math.max(t.width,1)*r.width,a=(e.clientY-t.top)/Math.max(t.height,1)*r.height;if(i<l||i>u||a<s||a>c){f();return}let d=o.reduce((e,t)=>e?Math.abs(Number(U(t,`x`))-i)<Math.abs(Number(U(e,`x`))-i)?t:e:t,null);d&&p(d)}),n.addEventListener(`pointerleave`,f),e.addEventListener(`pointerleave`,f);for(let e of o)e.addEventListener(`mouseenter`,()=>p(e)),e.addEventListener(`focus`,()=>p(e)),e.addEventListener(`blur`,f)}}function q(e,t){if(!e.length)return``;let n=e.map(e=>e.wordsPerMinute),r=Math.min(...n,t),i=Math.max(...n,t),a=i-r||1,o=t=>54+(e.length===1?246:t/(e.length-1)*492),s=e=>160-(e-r)/a*142,c=e.map((e,t)=>({sample:e,x:o(t),y:s(e.wordsPerMinute)})),l=c.map((e,t)=>`${t===0?`M`:`L`} ${e.x.toFixed(2)} ${e.y.toFixed(2)}`).join(` `),u=`${l} L ${c[c.length-1].x.toFixed(2)} ${160 .toFixed(2)} L ${c[0].x.toFixed(2)} ${160 .toFixed(2)} Z`,d=s(t);return`
    <div class="analytics-graph" data-analytics-graph>
      <div class="analytics-graph-header">
        <div class="analytics-legend" aria-label="Chart legend">
          <span><i class="mod-line"></i>Pace trace</span>
          <span><i class="mod-average"></i>Average pace</span>
          <span><i class="mod-outlier"></i>Review outlier</span>
        </div>
      </div>
      <div class="analytics-graph-stage">
      <span class="analytics-axis-title analytics-axis-title-y">Pace (words per minute)</span>
      <svg
        viewBox="0 0 560 190"
        role="img"
        aria-label="Word speed graph with average pace and review markers"
        data-analytics-graph-svg
        data-graph-left="54"
        data-graph-right="546"
        data-graph-top="18"
        data-graph-bottom="160"
      >
        ${[i,(i+r)/2,r].map(e=>`
              <g>
                <line
                  x1="54"
                  y1="${s(e).toFixed(2)}"
                  x2="546"
                  y2="${s(e).toFixed(2)}"
                  class="analytics-graph-grid"
                />
                <text
                  x="46"
                  y="${(s(e)+4).toFixed(2)}"
                  text-anchor="end"
                  class="analytics-graph-tick"
                >${Math.round(e)}</text>
              </g>
            `).join(``)}
        <line
          x1="54"
          y1="${d.toFixed(2)}"
          x2="546"
          y2="${d.toFixed(2)}"
          class="analytics-graph-average"
        />
        <line
          x1="54"
          y1="18"
          x2="54"
          y2="160"
          class="analytics-graph-focus-line"
          data-analytics-graph-focus-line
          visibility="hidden"
        />
        <path d="${u}" class="analytics-graph-fill" />
        <path d="${l}" class="analytics-graph-line" />
        ${c.map(e=>{let t=e.sample.isOutlier?` analytics-graph-outlier`:``;return`
              <circle
                cx="${e.x.toFixed(2)}"
                cy="${e.y.toFixed(2)}"
                r="${e.sample.isOutlier?`4.5`:`3.4`}"
                class="analytics-graph-point${t}"
                data-analytics-graph-point
                data-x="${e.x.toFixed(2)}"
                data-y="${e.y.toFixed(2)}"
                data-cue-number="${e.sample.cueNumber}"
                data-previous-cue-number="${e.sample.previousCueNumber}"
                data-gap="${e.sample.gap.toFixed(2)}"
                data-pace="${Math.round(e.sample.wordsPerMinute)}"
                data-review-label="${e.sample.reviewLabel}"
                data-threshold="${W(e.sample)}"
                data-deviation="${G(e.sample)}"
                tabindex="0"
              />
            `}).join(``)}
        <circle
          cx="54"
          cy="160"
          r="6"
          class="analytics-graph-focus-point"
          data-analytics-graph-focus-point
          visibility="hidden"
        />
      </svg>
      <div class="analytics-graph-tooltip" data-analytics-graph-tooltip hidden></div>
      </div>
      <p class="analytics-graph-axis-caption">Word progression through the aliyah</p>
      <p class="analytics-graph-copy">
        Each point shows the pace between two saved Words. Review markers flag out-of-order timestamps and long pauses.
      </p>
    </div>
  `}function J(e){return`
    <div class="about-card-header">
      <h2>Loading playback analytics</h2>
      <p>${e}</p>
    </div>
  `}function Y(e,t){let n=C(e);return e.length?`
    <div class="about-card-header">
      <h2>Selection overview</h2>
      <p>Current view: ${t}.</p>
    </div>
    <div class="analytics-summary-grid">
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Authored recordings</span>
        <strong class="analytics-stat-value">${n.recordingCount}</strong>
      </div>
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Total Words</span>
        <strong class="analytics-stat-value">${A.format(n.cueCount)}</strong>
      </div>
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Average pace</span>
        <strong class="analytics-stat-value">${z(n.averageWordsPerMinute)}</strong>
      </div>
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Median gap</span>
        <strong class="analytics-stat-value">${L(n.medianGap)}</strong>
      </div>
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Review transitions</span>
        <strong class="analytics-stat-value">${n.outlierCount}</strong>
      </div>
      <div class="analytics-summary-item">
        <span class="analytics-stat-label">Invalid transitions</span>
        <strong class="analytics-stat-value">${n.invalidTransitionCount}</strong>
      </div>
    </div>
  `:`
      <div class="about-card-header">
        <h2>Selection overview</h2>
        <p>No timing matches ${t} yet. Use the coverage view below to find recordings that still need timing.</p>
      </div>
    `}function X(e,t){let n=e.filter(e=>e.recordingCount>0);return n.length?`
    <div class="about-card-header">
      <h2>Average by aliyah</h2>
      <p>Averages within ${t}.</p>
    </div>
    <div class="analytics-aliyah-grid">
      ${n.map(e=>`
            <article class="analytics-aliyah-module">
              <h3>Aliyah ${u(e.aliyah)}</h3>
              <p>${e.recordingCount} recordings</p>
              <dl class="analytics-inline-stats">
                <div>
                  <dt>Average pace</dt>
                  <dd>${z(e.averageWordsPerMinute)}</dd>
                </div>
                <div>
                  <dt>Median gap</dt>
                  <dd>${L(e.medianGap)}</dd>
                </div>
                <div>
                  <dt>Review transitions</dt>
                  <dd>${e.outlierCount}</dd>
                </div>
                <div>
                  <dt>Longest gap</dt>
                  <dd>${L(e.longestGap)}</dd>
                </div>
              </dl>
            </article>
          `).join(``)}
    </div>
  `:`
      <div class="about-card-header">
        <h2>Average by aliyah</h2>
        <p>No timing is available for ${t} yet.</p>
      </div>
    `}function Z(e,t,n,r,i){return`
    <div class="about-card-header">
      <h2>Coverage by parsha</h2>
      <p>Every parsha with audio, which aliyot have timing, and which ones still need work.</p>
    </div>
    <div class="analytics-coverage-legend">
      <span><i class="mod-incomplete"></i>Published timing incomplete</span>
      <span><i class="mod-cued"></i>Completed timing</span>
      <span><i class="mod-missing"></i>Timing missing</span>
      <span><i class="mod-empty"></i>No audio in this slot</span>
    </div>
    <div class="analytics-coverage-list">
      ${e.filter(e=>!r||e.parshaSlug===r).map(e=>{let r=t.get(e.parshaSlug)??[],a=n.get(e.parshaSlug)??[],o=e.availableAliyot.filter(e=>!a.includes(e)&&!r.includes(e)),s=i<=0?``:e.availableAliyot.includes(i)?r.includes(i)?`Aliyah ${u(i)} has incomplete published timing.`:a.includes(i)?`Aliyah ${u(i)} already has timing.`:`Aliyah ${u(i)} has audio and still needs timing.`:`Aliyah ${u(i)} has no audio recording in this parsha.`;return`
            <article class="analytics-coverage-card">
              <div class="analytics-coverage-header">
                <div>
                  <h3>${e.parshaName}</h3>
                  <p>${a.length} complete · ${r.length} incomplete · ${o.length} missing${s?` · ${s}`:``}</p>
                </div>
                <dl class="analytics-coverage-stats">
                  <div>
                    <dt>Average pace</dt>
                    <dd>${z(e.averageWordsPerMinute)}</dd>
                  </div>
                  <div>
                    <dt>Median gap</dt>
                    <dd>${L(e.medianGap)}</dd>
                  </div>
                  <div>
                    <dt>Missing timing</dt>
                    <dd>${o.length?o.map(e=>u(e)).join(`, `):`None`}</dd>
                  </div>
                </dl>
              </div>
              <div class="analytics-coverage-strip">
                ${Array.from({length:7},(e,t)=>t+1).map(t=>`
                      <a
                        class="analytics-coverage-pill ${r.includes(t)?`mod-incomplete`:a.includes(t)?`mod-cued`:e.availableAliyot.includes(t)?`mod-missing`:`mod-empty`}${i===t?` is-selected`:``}"
                        href="${I(e.parshaSlug,t)}"
                        aria-label="Open ${e.parshaName}, aliyah ${u(t)}"
                      >
                        ${u(t)}
                      </a>
                    `).join(``)}
              </div>
            </article>
          `}).join(``)}
    </div>
  `}function Q(e,t){let n=e.flatMap(e=>e.intervalSamples.filter(e=>e.isOutlier).map(t=>({record:e,sample:t}))).sort((e,t)=>t.sample.severity-e.sample.severity).slice(0,12);return n.length?`
    <div class="about-card-header">
      <h2>Transition review</h2>
      <p>Transitions worth checking in ${t}. This list only shows out-of-order Words and very long pauses.</p>
    </div>
    <div class="analytics-outlier-list">
      ${n.map(({record:e,sample:t})=>`
            <article class="analytics-outlier-row">
              <div>
                <p class="analytics-outlier-title">${e.recording.parshaName} · Aliyah ${u(e.recording.aliyah)}</p>
                <p class="analytics-outlier-copy">Word ${t.previousCueNumber} ${j} ${t.cueNumber} · ${e.narratorName} · Published timing</p>
                <p class="analytics-outlier-copy">${W(t)} · ${G(t)}</p>
              </div>
              <div class="analytics-outlier-metrics">
                <strong>${L(t.gap)}</strong>
                <span>${z(t.wordsPerMinute)}</span>
                <span>${t.reviewLabel}</span>
              </div>
            </article>
          `).join(``)}
    </div>
  `:`
      <div class="about-card-header">
        <h2>Transition review</h2>
        <p>No review transitions were detected in ${t}. Only clear issues are shown here, so the Word spacing looks stable.</p>
      </div>
    `}function $(e){return`
    <article class="about-card analytics-module stack small">
      <div class="analytics-module-header">
        <div>
          <p class="about-eyebrow">Aliyah ${u(e.recording.aliyah)}</p>
          <h2>${e.recording.parshaName} · ${e.recording.title}</h2>
          <p class="about-copy analytics-meta">${e.narratorName} · Published timing · ${e.cueCount} Words · ${B(e.totalDuration)} timed span · ${V(e.cueUpdatedAt)}</p>
        </div>
        <div class="analytics-module-callout">
          <span class="analytics-stat-label">Review transitions</span>
          <strong class="analytics-stat-value">${e.outlierCount}</strong>
        </div>
      </div>
      <div class="analytics-stat-grid">
        <div class="analytics-stat">
          <span class="analytics-stat-label">Average pace</span>
          <strong class="analytics-stat-value">${z(e.averageWordsPerMinute)}</strong>
        </div>
        <div class="analytics-stat">
          <span class="analytics-stat-label">Median gap</span>
          <strong class="analytics-stat-value">${L(e.medianGap)}</strong>
        </div>
        <div class="analytics-stat">
          <span class="analytics-stat-label">Longest gap</span>
          <strong class="analytics-stat-value">${L(e.longestGap)}</strong>
        </div>
        <div class="analytics-stat">
          <span class="analytics-stat-label">Invalid transitions</span>
          <strong class="analytics-stat-value">${e.invalidTransitionCount}</strong>
        </div>
      </div>
      ${q(e.intervalSamples,e.averageWordsPerMinute)}
    </article>
  `}function ee(){return`
    <section class="about-view analytics-view stack large" data-analytics-root="true">
      <div class="about-hero analytics-hero stack small">
        <div class="analytics-toolbar">
          <a class="analytics-back-link" href="${a()}">Back to About</a>
          <span class="about-eyebrow">Playback Analytics</span>
        </div>
        <h1 class="about-title analytics-title">A clear view of pacing across each aliyah.</h1>
        <p class="about-copy">
          This page reads published playback timing. It shows pace,
          timing issues worth checking, and recordings that still need work.
        </p>
        <section class="about-card analytics-filter-card">
          <div class="analytics-filter-grid">
            <label class="analytics-filter-field">
              <span>Parsha</span>
              <select data-analytics-filter="parsha" disabled>
                <option value="">Loading parshiot…</option>
              </select>
            </label>
            <label class="analytics-filter-field">
              <span>Aliyah</span>
              <select data-analytics-filter="aliyah">
                <option value="">All aliyot</option>
                ${Array.from({length:7},(e,t)=>t+1).map(e=>`
                      <option value="${e}">Aliyah ${u(e)}</option>
                    `).join(``)}
              </select>
            </label>
          </div>
        </section>
      </div>

      <section class="about-card analytics-summary-card stack small" data-analytics-section="overview">
        ${J(`Loading published timing…`)}
      </section>
      <section class="about-card stack small" data-analytics-section="coverage">
        ${J(`Building the coverage view…`)}
      </section>
      <details class="analytics-details about-catalog-details stack small">
        <summary class="about-card about-catalog-summary analytics-details-summary">
          <span class="about-catalog-chevron" aria-hidden="true">${t(`arrowRight`)}</span>
          <span class="about-card-header">
            <span>
              <span class="about-catalog-title">Detailed playback breakdown</span>
              <span class="about-catalog-copy">Average by aliyah, transition review, and individual recording graphs.</span>
            </span>
          </span>
        </summary>
        <div class="analytics-details-content stack medium">
          <section class="about-card stack small" data-analytics-section="aliyah-averages">
            ${J(`Calculating aliyah-level averages…`)}
          </section>
          <section class="about-card stack small" data-analytics-section="outliers">
            ${J(`Reviewing timing transitions…`)}
          </section>
          <section class="analytics-modules stack medium" data-analytics-section="records"></section>
        </div>
      </details>
    </section>
  `}async function te(t,{signal:n}={}){let r=t.querySelector(`[data-analytics-root="true"]`);if(!r)return;let i=()=>!n?.aborted&&r.isConnected,a=r.querySelector(`[data-analytics-filter="parsha"]`),c=r.querySelector(`[data-analytics-filter="aliyah"]`),l=r.querySelector(`[data-analytics-section="overview"]`),u=r.querySelector(`[data-analytics-section="coverage"]`),d=r.querySelector(`[data-analytics-section="aliyah-averages"]`),f=r.querySelector(`[data-analytics-section="outliers"]`),p=r.querySelector(`[data-analytics-section="records"]`);if(!a||!c||!l||!u||!d||!f||!p)return;let m=s().filter(e).filter(e=>e.status===`available`),h=new Map,g=new Map;for(let e of m){if(!i())return;let t=await o(e);if(!i())return;if(t.isUnfinished){let t=h.get(e.parshaSlug)??[];t.push(e.aliyah),h.set(e.parshaSlug,t);continue}if(t.isComplete){let t=g.get(e.parshaSlug)??[];t.push(e.aliyah),g.set(e.parshaSlug,t)}}let _=await O();if(!i())return;let v=k(_);a.innerHTML=`
    <option value="">All parshiot with audio</option>
    ${v.map(e=>`
          <option value="${e.parshaSlug}">${e.parshaName}</option>
        `).join(``)}
  `,a.disabled=!1;let y=()=>{if(!i())return;let e=a.value,t=Number(c.value)||0,n=v.find(t=>t.parshaSlug===e)?.parshaName??null,r=_.filter(n=>(!e||n.recording.parshaSlug===e)&&(!t||n.recording.aliyah===t)).filter(e=>e.transitionCount>0),o=H(n,t||null);l.innerHTML=Y(r,o),u.innerHTML=Z(v,h,g,e,t),d.innerHTML=X(w(r),o),f.innerHTML=Q(r,o),p.innerHTML=r.length?r.map($).join(``):`
          <section class="about-card stack small analytics-empty-state">
            <div class="about-card-header">
              <h2>No timing transitions in this slice</h2>
              <p>Change the filter or use the coverage section above to find recordings that still need timing.</p>
            </div>
          </section>
        `,K(p)};a.addEventListener(`change`,y),c.addEventListener(`change`,y),y()}export{ee as default,te as mountCueAnalyticsPage};