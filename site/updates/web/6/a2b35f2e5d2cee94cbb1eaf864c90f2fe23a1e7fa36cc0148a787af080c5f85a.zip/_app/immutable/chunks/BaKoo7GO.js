const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./QVwXKNrD.js","./CJLdMZ-j.js","./xihTtKlq.js","./B8TkWqIn.js","./DT_-59oX.js","./D0-WBVqK.js","./HclGiUj8.js","./CEOk3ryL.js","./E4fb1cLD.js","./DEKaBRFm.js","./CT4bspt6.js","./CkaUEpHg.js","./DEgdE029.js","./D0YNzAQW.js","./B55wJRDZ.js","./ci9GFOaz.js","./C_sG4J_C.js","./OxwK-EO_.js","./qZcP8U3E.js","./yVxVdJXI.js","./CN4PYbqv.js","../assets/SupportDiagnosticsActions.DJCwcTri.css","./IghfWv07.js","../assets/reader-settings.CDE9aU7P.css","./Cwy8DojY.js","./bbTYFZJo.js","../assets/CueAnalyticsPage.BQ5Mq9ep.css","./CQFeuete.js","./CT1B6T-W.js","../assets/ParshaPicker.CPqXIDg4.css","./CkbWkhlf.js","./CfgJk93m.js","../assets/cue-authoring.DYcNihHZ.css","./eHf_RGi8.js","./Cx3jA1EZ.js","../assets/media-panel.Be1OF_ev.css","./BVZf8LWP.js","./CJ7KFjv4.js"])))=>i.map(i=>d[i]);
import{B as e,F as t,I as n,L as r,M as i,N as a,O as o,P as s,Tt as c,U as l,V as u,Z as d,a as f,c as p,ct as m,d as h,dt as g,et as _,f as v,it as y,j as b,kt as x,lt as S,m as C,mt as w,n as T,nt as E,ot as D,pt as O,r as k,rt as A,tt as j,v as M,vt as N,wt as P,y as F,yt as ee,z as I}from"./CJLdMZ-j.js";import{t as L}from"./HclGiUj8.js";import"./xihTtKlq.js";import{a as R,n as te,o as ne}from"./CWDDJxup.js";import{i as z,n as re,t as B}from"./DEKaBRFm.js";import{a as V,i as ie,n as ae,o as oe,s as se,t as H}from"./CLTos5mD.js";import{a as U,i as W,n as G,o as K,r as q,s as J,t as ce}from"./CT4bspt6.js";import{a as le,i as Y,n as ue,o as de,r as fe}from"./bbTYFZJo.js";import{A as pe,B as me,D as he,H as ge,O as _e,P as ve,U as ye,V as X,_ as be,d as xe,g as Se,h as Ce,j as we,k as Te,m as Ee,o as De,s as Oe}from"./CEOk3ryL.js";import{t as ke}from"./B5OcMZss.js";import{l as Ae,n as je,r as Me}from"./CkaUEpHg.js";import{i as Ne,r as Pe}from"./CfgJk93m.js";import{n as Fe,t as Z}from"./D0YNzAQW.js";import{A as Ie,C as Le,E as Re,S as Q,T as $,_ as ze,a as Be,b as Ve,c as He,f as Ue,h as We,i as Ge,j as Ke,l as qe,m as Je,n as Ye,o as Xe,p as Ze,r as Qe,s as $e,u as et,v as tt,w as nt,y as rt}from"./D0-WBVqK.js";import{n as it,t as at}from"./IghfWv07.js";import{i as ot,r as st,t as ct}from"./ci9GFOaz.js";import{c as lt,i as ut,n as dt,o as ft,r as pt,t as mt}from"./C_sG4J_C.js";function ht(e){if(!e.length)return e;let[t,...n]=e;return t.timeStart===0?e:[{...t,timeStart:0},...n]}var gt=new Set(fe.filter(le).map(e=>e.parshaSlug)),_t={kind:`range`,id:`rosh-chodesh`,name:`Rosh Chodesh`};function vt(e){if(!e.leining.isParsha)return null;let t=Ae(e.leining.date.title.en.replace(/^Parshat\s+/i,``)),n=je(t);return n&&gt.has(n)?n:gt.has(t)?t:n??t}function yt({narratorId:e,run:t,aliyahIndex:n,recordings:r=fe}){if(!n)return null;let i=t.aliyot.find(e=>e.index===n);if(!i)return null;let a=xt(t,i);if(a)return r.find(t=>de(t)&&t.status===`available`&&t.narratorId===e&&t.reading.id===a.id&&St(t.range,i))??null;let o=vt(t);if(!o)return null;let s=n===`Maftir`?7:Math.max(1,Math.min(n,7));return r.find(t=>le(t)&&t.narratorId===e&&t.parshaSlug===o&&t.aliyah===s&&t.status===`available`)??null}function bt({narratorId:e,run:t,aliyahIndex:n,recordings:r=fe}){if(!n)return null;let i=t.aliyot.find(e=>e.index===n);if(!i)return null;let a=yt({narratorId:e,run:t,aliyahIndex:n,recordings:r});if(a)return a;let o=n===`Maftir`?7:Math.max(1,Math.min(n,7)),s=xt(t,i);if(s){let t=r.find(t=>de(t)&&t.narratorId===e&&t.reading.id===s.id&&St(t.range,i));if(t)return t;let n=`/audio/${e}/${s.id}/${o}.m4a`;return{id:`${s.id}-${o}`,narratorId:e,reading:s,range:{start:i.start,end:i.end},aliyah:o,title:`${s.name} Aliyah ${o}`,playSrc:n,downloadSrc:n,format:`m4a`,status:`missing`}}let c=vt(t);if(!c)return null;let l=r.find(t=>le(t)&&t.narratorId===e&&t.parshaSlug===c&&t.aliyah===o);if(l)return l;let u=r.find(t=>le(t)&&t.narratorId===e&&t.parshaSlug===c),d=u?.parshaName??(t.leining.date.title.en.replace(/^Parshat\s+/i,``).trim()||c),f=`/audio/${e}/${c}/${o}.m4a`;return{id:`${c}-${o}`,narratorId:e,reading:{kind:`parsha`,id:c,name:d,...u?.parshaNumber?{order:u.parshaNumber}:{}},parshaSlug:c,parshaName:d,...u?.parshaNumber?{parshaNumber:u.parshaNumber}:{},aliyah:o,title:`${d} Aliyah ${o}`,playSrc:f,downloadSrc:f,format:`m4a`,status:`missing`}}function xt(e,t){let n=new Ke(e.leining.date.date),r=n.getDate()===1||n.getDate()===30,i=t.start.scroll===`torah`&&t.start.b===4&&t.start.c===28&&t.start.v>=1&&t.end.b===4&&t.end.c===28&&t.end.v<=15;return r&&i?_t:null}function St(e,t){return e.start.scroll===t.start.scroll&&e.end.scroll===t.end.scroll&&$(e.start,t.start)===0&&$(e.end,t.end)===0}function Ct(){return Y}function wt(){return fe}async function Tt(e){return ct(e)}function Et(e){return st(e)}function Dt(e){return ot(e)}async function Ot(e){return ht((await Tt(e))?.cues??[])}async function kt(e){let t=await Tt(e);return t?t.tokenizationVersion===`v2`?t.cues:(console.warn(`Ignoring outdated passage timings for ${e.id}`),[]):[]}async function At(e,t){let n=await Tt(e);return he(n?.issues,e.id,t)}async function jt(e){let t=(await Tt(e))?.savedAt;if(typeof t!=`string`)return null;let n=Date.parse(t);return Number.isFinite(n)?n:null}async function Mt(e){let t=await Tt(e),n=t?.cueCount??t?.cues.length??0,r=t?.tokenCount??0;return{cueCount:n,tokenCount:r,isUnfinished:n>0&&r>0&&n<r,isComplete:n>0&&r>0&&n>=r}}function Nt({cueIndex:e,cueCount:t,tokenCount:n}){let r=n||t,i=t>0?Math.max(0,Math.min(r,Math.max(e+1,1))):0,a=r>0?Math.max(0,Math.min(1,i/r)):0;return{current:i,total:r,label:`${i} / ${r}`,ratio:a}}function Pt({cueIndex:e,cueCount:t}){let n=Math.max(0,t),r=n>0?Math.max(1,Math.min(n,e+1)):0;return{current:r,total:n,label:`Cue ${r} / ${n}`}}var Ft=e=>`${e.pageNumber}:${e.lineIndex}:${e.fragmentIndex}:${e.wordIndex}`;function It(e,t){let n=Math.min(e.length,t.length);for(let r=n;r>0;r--){let n=e.slice(-r),i=t.slice(0,r);if(n.every((e,t)=>e===i[t]))return i}return[]}function Lt(e,t){let n=new Set(t);return e.filter(e=>n.has(Ft(e)))}function Rt(e,t){if(!t.length)return!0;let n=new Set(e.map(Ft));return t.every(e=>n.has(e))}function zt(e,t,n){let r=Lt(e.cues,t),i=r[0];if(!i)return e.cues.length||n===`cue-boundary`?null:{recording:e.recording,tokenKeys:[...t],cues:[],startTime:0,endTime:null};let a=r[r.length-1],o=e.cues.indexOf(a),s=e.cues[o+1],c=n===`media-end`?null:a.timeEnd??s?.timeStart??a.timeStart+.75;return{recording:e.recording,tokenKeys:t.filter(e=>r.some(t=>Ft(t)===e)),cues:r,startTime:i.timeStart,endTime:c}}function Bt({target:e,tokenKeys:t,current:n,previous:r,previousTokenKeys:i=[]}){if(!t.length)return null;let a=It(i,t),o=!!(n&&Rt(n.cues,a));if(n&&o){let r=zt(n,t,`media-end`);if(!r)return null;let i=r.tokenKeys[0]===t[0];return{target:e,tokenKeys:t,segments:[r],status:i?`current-only`:`partial-start`}}let s=!!(a.length&&r&&(!n||r.recording.narratorId===n.recording.narratorId)&&Rt(r.cues,a));if(r&&s){let i=zt(r,a,`cue-boundary`),o=t.slice(a.length),s=n?zt(n,o,`media-end`):null,c=[i,s].filter(e=>!!e);return c.length?{target:e,tokenKeys:t,segments:c,status:s?`previous-opening`:`overlap-only`}:null}if(!n)return null;let c=zt(n,t,`media-end`);return c?{target:e,tokenKeys:t,segments:[c],status:`partial-start`}:null}function Vt(e){return{timeStart:e.timeStart,timeEnd:e.timeEnd,pageNumber:e.pageNumber,lineIndex:e.lineIndex,fragmentIndex:e.fragmentIndex,wordIndex:e.wordIndex,review:e.review}}function Ht(e,t){return e.length===t.length&&e.every((e,n)=>JSON.stringify(Vt(e))===JSON.stringify(Vt(t[n])))}var Ut=`tikkun-admin-draft:`,Wt=new Map(fe.map(e=>[e.id,e])),Gt=new WeakMap,Kt=0;function qt(){let e=globalThis.crypto;return typeof e?.randomUUID==`function`?e.randomUUID():typeof e?.getRandomValues==`function`?[...e.getRandomValues(new Uint32Array(4))].map(e=>e.toString(16).padStart(8,`0`)).join(``):(Kt+=1,`${Date.now().toString(36)}-${Kt.toString(36)}-${Math.random().toString(36).slice(2)}`)}function Jt(e){return typeof e==`string`&&e.length>0&&e.length<=128}function Yt(){return qt()}function Xt(e){return`${Ut}${e}`}function Zt(e){return typeof e==`string`?Wt.get(e)??null:e}function Qt(e){return typeof e==`number`?{tokenCount:e}:{tokenCount:e.length,tokenKeys:e}}function $t(e,t){let n=Zt(e),r=typeof e==`string`?e:e.id,i=q(`local`),a=Xt(r),o;try{o=U(i,a)}catch(e){return console.error(`Failed to read admin draft for ${r}`,e),{status:`unavailable`,revision:null}}if(o===null)return{status:`missing`,revision:null};let s;try{s=JSON.parse(o)}catch(e){return console.error(`Failed to parse admin draft for ${r}`,e),{status:`invalid`,reason:`invalid-json`,revision:o}}let c=n?ue(s,{recording:n,...Qt(t)}):null;return c?{status:`ready`,draft:c,revision:o}:{status:`invalid`,reason:`invalid-draft`,revision:o}}function en(e,t){let n=$t(e,t);return n.status===`ready`?n.draft:null}function tn(e){let t=Gt.get(e);return t||(t=new Map,Gt.set(e,t)),t}function nn(e,t,n,r){if(!Jt(r.writerToken))throw TypeError(`Cannot persist an admin draft without a writer token`);let i=ue(e,{recording:t,tokenCount:e.tokenCount,tokenKeys:n});if(!i)throw TypeError(`Cannot persist an invalid admin draft`);let a=q(`local`);if(!a)throw new an(i.audioId);let o=Xt(i.audioId),s=JSON.stringify(i);try{let e=U(a,o);if(e===s)return{revision:s};let c=null;if(e!==null)try{c=ue(JSON.parse(e),{recording:t,tokenCount:i.tokenCount,tokenKeys:n})}catch{c=null}let l=tn(a).get(o),u=l?.rawValue===e&&l.writerToken===r.writerToken;if(r.expectedRevision!==e&&!u)throw new on(i.audioId,c?.updatedAt??null,i.updatedAt);if(c&&(c.updatedAt>i.updatedAt||c.updatedAt===i.updatedAt&&e!==s))throw new on(i.audioId,c.updatedAt,i.updatedAt);if(U(a,o)!==e)throw new on(i.audioId,null,i.updatedAt);if(J(a,o,s),U(a,o)!==s)throw Error(`Admin draft write could not be verified`);return tn(a).set(o,{rawValue:s,writerToken:r.writerToken}),{revision:s}}catch(e){throw e instanceof on?e:new an(i.audioId,e)}}async function rn(e,t,n,r){let i=globalThis.navigator?.locks;if(!i)throw new an(e.audioId,Error(`Web Locks are unavailable; refusing an unsafe draft write`));return i.request(`tikkun-admin-draft:${e.audioId}`,{mode:`exclusive`},()=>nn(e,t,n,r))}var an=class extends Error{constructor(e,t){super(`Failed to access admin draft storage for ${e}`),this.name=`AdminDraftStorageError`,this.cause=t}},on=class extends Error{constructor(e,t,n){super(`Refusing to overwrite conflicting admin draft for ${e} (${t??`missing`} vs ${n})`),this.name=`AdminDraftConflictError`}},sn=[{glyph:`א`,value:1},{glyph:`ב`,value:2},{glyph:`ג`,value:3},{glyph:`ד`,value:4},{glyph:`ה`,value:5},{glyph:`ו`,value:6},{glyph:`ז`,value:7},{glyph:`ח`,value:8},{glyph:`ט`,value:9},{glyph:`י`,value:10},{glyph:`כ`,value:20},{glyph:`ל`,value:30},{glyph:`מ`,value:40},{glyph:`נ`,value:50},{glyph:`ס`,value:60},{glyph:`ע`,value:70},{glyph:`פ`,value:80},{glyph:`צ`,value:90},{glyph:`ק`,value:100},{glyph:`ר`,value:200},{glyph:`ש`,value:300},{glyph:`ת`,value:400}].reverse(),cn=e=>{if(e<=0)return``;if(e===15)return`טו`;if(e===16)return`טז`;let t=0;for(;e<sn[t].value;)++t;let n=sn[t];return`${n.glyph}${cn(e-n.value)}`};function ln(e,t){return t===1?`ראשון`:e}function un(e=new URL(window.location.href)){let t=e.searchParams.get(`recording`)===`1`;return{enabled:t,audioId:t?e.searchParams.get(`audioId`):null}}function dn({contentRect:e,viewport:t,margin:n}){let r=e=>Math.max(2,Math.floor(e/2)*2),i=()=>({x:0,y:0,width:r(t.width),height:r(t.height)});if(!e)return i();let a=e.x+e.width,o=e.y+e.height;if(a<=0||e.x>=t.width||o<=0||e.y>=t.height)return i();let s=e.x+e.width/2,c=Math.max(0,Math.floor(e.x-n)),l=Math.min(t.width,Math.ceil(a+n)),u=Math.min(t.width,l-c);return{x:Math.max(0,Math.min(t.width-u,Math.floor(s-u/2))),y:0,width:r(u),height:r(t.height)}}function fn(e){return{...e,playbackRate:1,autoScrollWithPlayback:!0,focalPointMode:`reader`,disableShiftNekudotHide:!1,themeMode:`light`}}function pn(e,r){ee(r,!0);let i=()=>w(Oe,`$nativeUpdateState`,o),a=()=>w(De,`$nativeUpdatePromptDismissed`,o),[o,s]=O(),c=g(()=>i().web.pending||i().content.pending),u=g(()=>xe(i()));T(it);var d=n(),f=E(d),p=e=>{{let t=g(()=>i().applying?`Applying update…`:i().applyError??`Update available`),n=g(()=>!!i().applyError),a=g(()=>i().applying?`Cancel`:`Apply`),o=g(()=>i().applying?!i().canCancel:l(u));H(e,{get message(){return l(t)},get applying(){return i().applying},get error(){return l(n)},get actionLabel(){return l(a)},get actionDisabled(){return l(o)},onaction:()=>i().applying?it():void at(r.prepare),ondismiss:()=>De.set(!0)})}};b(f,e=>{l(c)&&!a()&&e(p)}),t(e,d),N(),s()}function mn(e,t,n){let r=t.createElement(`div`);t.body.append(r);let a=i(pn,{target:r,props:{prepare:n}});e.own(()=>{s(a).catch(e=>console.error(`Could not close the native update prompt`,e)),r.remove()})}function hn(e){return e.at(-1)?.annotatedText.trim().endsWith(`׃`)??!1}function gn(e,t=0){let n=e.findIndex((e,n)=>n>=t&&e.annotatedText.includes(`׃`));return n<0?e.length:n+1}function _n({currentLineWords:e,previousLineWords:t,verseOrdinal:n}){let r=t.length&&!hn(t)?gn(e):0;for(let t=0;t<n;t+=1)r=gn(e,r);return r}function vn({wordsByLine:e,startLineIndex:t,startVerseOrdinal:n,endLineIndex:r,endVerseOrdinal:i}){if(t<0||r<t||n<0||i<0)return[];let a=e[t],o=e[r];if(!a||!o)return[];let s=_n({currentLineWords:a,previousLineWords:e[t-1]??[],verseOrdinal:n}),c=_n({currentLineWords:o,previousLineWords:e[r-1]??[],verseOrdinal:i}),l=e.flat(),u=e.reduce((t,n,r)=>(t[r]=r?t[r-1]+e[r-1].length:0,t),[]),d=u[t]+s,f=u[r]+c,p=l.findIndex((e,t)=>t>=f&&e.annotatedText.includes(`׃`)),m=p<0?l.length:p+1;return l.slice(d,m).map(e=>e.tokenKey).filter(Boolean)}async function yn({start:e,end:t}){if(e.scroll!==t.scroll)throw Error(`Passage audio requires references in the same scroll`);let n=await Ve(e.scroll),r=n.physicalLocationFromRef(e),i=n.physicalLocationFromRef(t),a=Array.from({length:Math.min(n.getPageCount(),i.pageNumber+1)-Math.max(1,r.pageNumber-1)+1},(e,t)=>Math.max(1,r.pageNumber-1)+t),o=(await Promise.all(a.map(async t=>(await Ue(e.scroll,t)).map((e,n)=>({pageNumber:t,lineIndex:n,line:e}))))).flat(),s=(e,t)=>o[e]?.line.verses.findIndex(e=>e.book===t.b&&e.chapter===t.c&&e.verse===t.v)??-1,c=o.findIndex((t,n)=>s(n,e)>=0),l=o.findIndex((e,n)=>s(n,t)>=0),u=vn({wordsByLine:o.map(e=>Ee(e.pageNumber,e.lineIndex,e.line)),startLineIndex:c,startVerseOrdinal:s(c,e),endLineIndex:l,endVerseOrdinal:s(l,t)});if(!u.length)throw Error(`Could not resolve passage audio words`);return u}function bn({state:e,available:t,cueIncomplete:n=!1,adminMissing:r=!1,playing:i=!1}){let a=e?.problem,o=r||!e?.recording&&(!t||a===`missing-audio`),s=!o&&(e?.canPlay??(t&&![`checking`,`timing-needed`,`load-failed`,`missing-audio`].includes(a??``))),c=o?`empty`:a===`load-failed`?`audio`:e?.issue??(a===`timing-needed`||a===`incomplete-cues`||n?`cue`:a===`partial-audio`||a===`missing-audio`?`audio`:`normal`),l=i?`Pause this aliyah`:`Play this aliyah`;return o?l=r?`No recording yet. Select this aliyah to record.`:`No recording available for this aliyah.`:a===`checking`?l=`Checking available audio and timing cues.`:a===`load-failed`?l=e?.message||`The recording could not load. Try again.`:a===`timing-needed`?l=`Audio exists, but timing cues are needed to play this excerpt.`:a===`partial-audio`?l=`${(e?.message||`Part of this aliyah is available`).replace(/[.!?]$/,``)}. Select for an available portion to play.`:c===`cue`?l=`Full audio available. Some word highlighting is missing.`:a===`missing-audio`&&(l=e?.message||`No playable audio available for this aliyah.`),{tone:c,dimmed:!s,tooltip:l,actionDisabled:!r&&(o||a===`checking`)}}function xn(){let e=new Le({ashkenazi:!0,israel:!1,includeModernHolidays:!1}),t=new Map;return n=>{if(!le(n))return n.range;t.has(n.parshaSlug)||t.set(n.parshaSlug,He(e,n.parshaSlug,new Date));let r=t.get(n.parshaSlug)?.run.aliyot.find(e=>e.index===n.aliyah);return r?{start:r.start,end:r.end}:null}}var Sn=({start:e,end:t})=>`${e.c}:${e.v}-${t.c}:${t.v}`,Cn=(e,t)=>e.scroll===t.scroll&&$(e,t)===0,wn=(e,t)=>Cn(e.start,t.start)&&Cn(e.end,t.end),Tn=e=>`${e.start.scroll}:${e.start.b}:${Sn(e)}`;function En(e){let t=[];if(e.start.scroll!==`torah`||e.start.b!==e.end.b)return t;for(let n=e.start.c;n<=e.end.c;n++)for(let r of Q(e.start.b,n)){let i={...e.start,c:n,v:r};$(i,e.start)>=0&&$(i,e.end)<=0&&t.push(i)}return t}var Dn=class{constructor(e){this.options=e,this.cache=new Map,this.states=new Map,this.sources=e.recordings.flatMap(t=>{let n=e.rangeForRecording(t);return t.status===`available`&&n?[{recording:t,range:n}]:[]})}key(e,t){return`${t}:${Tn(e)}`}candidates(e,t){return this.sources.filter(n=>n.recording.narratorId===t&&n.range.start.scroll===e.start.scroll&&n.range.start.b===e.start.b&&$(n.range.start,e.end)<=0&&$(n.range.end,e.start)>=0).sort((t,n)=>Number(wn(n.range,e))-Number(wn(t.range,e))||$(t.range.start,n.range.start)||$(n.range.end,t.range.end)||t.recording.id.localeCompare(n.recording.id))}peek(e,t){let n=this.states.get(this.key(e,t));if(n)return n;let r=this.candidates(e,t);return{problem:r.length?`checking`:`missing-audio`,message:r.length?`Checking audio coverage`:`Audio not available`,recording:r[0]?.recording??null}}resolve(e,t){let n=this.key(e,t),r=this.cache.get(n);if(r)return r;let i=this.build(e,t).then(e=>(this.states.set(n,e),e),r=>{throw this.cache.delete(n),this.states.set(n,{problem:`load-failed`,message:`Audio details could not be loaded. Retry playback.`,recording:this.candidates(e,t)[0]?.recording??null}),r});return this.cache.set(n,i),i}async build(e,t){let n=En(e),r=new Map,i=e=>{let t=Tn(e),n=r.get(t);return n||(n=this.options.loadTokens(e),r.set(t,n)),n},a=await i(e),o=await Promise.all(this.candidates(e,t).map(async e=>({...e,tokens:await i(e.range),cues:new Map((await this.options.loadCues(e.recording)).map(e=>[X(e),e]))}))),s=new Map,c=!1,l=(e,t)=>{if(e>=n.length)return Promise.resolve({covered:0,cues:0,count:0,steps:[]});let r=`${e}:${t}`,a=s.get(r);if(a)return a;let u=(async()=>{let r=await l(e+1,!0),a={...r,steps:[{startIndex:e,endIndex:e,segment:null},...r.steps]};for(let r of o){if($(r.range.start,n[e])>0||$(r.range.end,n[e])<0||t&&$(r.range.start,n[e])<0)continue;let s=e;for(;s+1<n.length&&$(n[s+1],r.range.end)<=0;)s++;let u=new Set([s]);for(let t of o){let r=n.findIndex(e=>Cn(e,t.range.start));r>e&&r<=s&&u.add(r-1)}for(let t of u){let o={start:n[e],end:n[t]},s=await i(o),u=r.tokens.indexOf(s[0]);if(u<0||!s.every((e,t)=>r.tokens[u+t]===e))continue;let d=Cn(o.start,r.range.start)?0:r.cues.get(s[0])?.timeStart,f=s[s.length-1],p=r.tokens[u+s.length],m=Cn(o.end,r.range.end)?null:r.cues.get(f)?.timeEnd??(p?r.cues.get(p)?.timeStart:void 0);if(d===void 0||m===void 0||m!==null&&m<=d){c=!0;continue}let h=s.flatMap((e,t)=>{let n=r.cues.get(e);if(!n)return[];let i=r.cues.get(s[t+1]),a=n.timeEnd??i?.timeStart??(t===s.length-1?m??void 0:n.timeStart);return[{...n,...a===void 0?{}:{timeEnd:m===null?a:Math.min(a,m)}}]}),g={recording:r.recording,tokenKeys:s,cues:h,startTime:d,endTime:m},_=await l(t+1,!1),v={covered:_.covered+t-e+1,cues:_.cues+h.length,count:_.count+1,steps:[{startIndex:e,endIndex:t,segment:g},..._.steps]};(v.covered>a.covered||v.covered===a.covered&&(v.count<a.count||v.count===a.count&&v.cues>a.cues))&&(a=v)}}return a})();return s.set(r,u),u},u=[],d=[],f=null;for(let e of(await l(0,!1)).steps)if(e.segment)f||(f={range:{start:n[e.startIndex],end:n[e.endIndex]},tokenKeys:[],segments:[]},u.push(f)),f.range.end=n[e.endIndex],f.tokenKeys.push(...e.segment.tokenKeys),f.segments.push(e.segment);else{let t=d[d.length-1];!f&&t?t.end=n[e.endIndex]:d.push({start:n[e.startIndex],end:n[e.endIndex]}),f=null}let p=u.length===1&&wn(u[0].range,e),m=p&&u[0].segments.every(e=>e.cues.length===e.tokenKeys.length);c=d.some(e=>o.some(t=>$(t.range.start,e.end)<=0&&$(t.range.end,e.start)>=0))&&c;let h=p?m?null:`incomplete-cues`:u.length?`partial-audio`:c?`timing-needed`:`missing-audio`,g=n.filter(e=>!o.some(t=>$(t.range.start,e)<=0&&$(t.range.end,e)>=0)),_=g.length?`audio`:p&&m?void 0:`cue`,v=d.map(e=>[ze().find(t=>t.number===e.start.b)?.label,Sn(e)].filter(Boolean).join(` `)),y=g.length?`Audio unavailable for ${v.join(`, `)} ${d.length===1?`portion`:`portions`}`:`Excerpt timing needed: ${v.join(`, `)}`;return{problem:h,message:p?m?``:`Full audio available. Some word highlighting is missing.`:`${y}${g.length&&c?`. Some excerpts also need timing cues.`:``}`,recording:u[0]?.segments[0]?.recording??o[0]?.recording??null,portions:u,missing:d,tokenKeys:a,range:e,cueComplete:m,issue:_,canPlay:u.length>0}}};function On(e,t,n,r){return{target:n,readingLabel:r,tokenKeys:t.tokenKeys,segments:t.segments,status:e.problem===`partial-audio`?`partial-passage`:`passage`,passage:{range:t.range,requestedRange:e.range,cueComplete:t.segments.every(e=>e.cues.length===e.tokenKeys.length)}}}var kn=e=>{let t=document.createElement(`template`);if(e=e.trim(),t.innerHTML=e,t.content.childElementCount!==1)throw Error(`Should render exactly one node`);return t.content.firstElementChild},An=e=>typeof e==`string`?{key:e,ctrl:!1}:e,jn={htmlToElement:kn,whenKey:(e,t)=>n=>{let{key:r,ctrl:i}=An(e);n.ctrlKey===i&&n.key===r&&!n.repeat&&t(n)},purgeNode:e=>{for(;e.firstChild;)e.removeChild(e.firstChild)}},Mn=`.word[data-annotations-mode][data-annotations-alternate]`;function Nn(e,t){e.querySelectorAll(Mn).forEach(e=>{let n=e.closest(`[data-reader-annotations]`)?.dataset.readerAnnotations,r=n===`on`||n!==`off`&&t,i=r?`on`:`off`,a=(r?e.dataset.annotationsOnPresent:e.dataset.annotationsOffPresent)!==`false`,o=(r?e.dataset.annotationsOnKri:e.dataset.annotationsOffKri)===`true`;if(e.hidden=!a,e.classList.toggle(`ktiv-kri`,a&&o),e.dataset.annotationsMode===i)return;let s=e.innerHTML,c=e.dataset.annotationsAlternate??``;e.dataset.annotationsAlternate=s,e.innerHTML=a?c:``,e.dataset.annotationsMode=i})}var Pn=`.special-letter.mod-small`,Fn=`--special-letter-baseline-shift`,In=/[א-ת]/u,Ln=/[א-ת]/gu,Rn=e=>`${e.fontStyle} ${e.fontWeight} ${e.fontSize} ${e.fontFamily}`,zn=(e,t,n)=>{e.direction=n.direction===`rtl`?`rtl`:`ltr`,e.font=Rn(n),e.textBaseline=`alphabetic`;let r=e.measureText(t).actualBoundingBoxAscent;if(!Number.isFinite(r)||r<=0)throw Error(`Could not measure the visible top of special letter ${t}`);return r},Bn=(e,t)=>{let n=t.textContent?.match(In)?.[0],r=Number(t.dataset.specialLetterPosition),i=e.textContent?.match(Ln)??[];if(!n||!Number.isSafeInteger(r)||r<1||i[r-1]!==n)throw Error(`Small special letter has invalid word-position metadata`);let a=[i[r-2],i[r]].filter(e=>!!e);if(!a.length)throw Error(`Small special letter requires a neighboring Hebrew letter`);return{targetLetter:n,neighbors:a}},Vn=e=>{let t=e instanceof Document?e:e.ownerDocument,n=t.defaultView;if(!n)throw Error(`Special-letter alignment requires a window`);let r=t.createElement(`canvas`).getContext(`2d`);if(!r)throw Error(`Special-letter alignment requires Canvas 2D`);let i=e.querySelectorAll(Pn);return i.forEach(e=>{let t=e.closest(`.word`),i=e.textContent;if(!t||!i)throw Error(`Small special letter must remain inside a non-empty word`);let{targetLetter:a,neighbors:o}=Bn(t,e),s=n.getComputedStyle(t),c=Math.min(...o.map(e=>zn(r,e,s)))-zn(r,a,n.getComputedStyle(e));if(!Number.isFinite(c))throw Error(`Invalid special-letter baseline shift for ${i}`);e.style.setProperty(Fn,`${c}px`)}),i.length},Hn=async(e,t)=>{let n=e instanceof Document?e:e.ownerDocument;return n.fonts.status!==`loaded`&&await n.fonts.ready,t?.aborted||e instanceof Element&&!e.isConnected?0:Vn(e)},Un=`(max-width: 550px)`;function Wn(e,t){let n=t.matchMedia(Un),r=new Set,i=n.matches?`compact`:`wide`;return n.addEventListener(`change`,e=>{let t=e.matches?`compact`:`wide`;if(t!==i){i=t;for(let e of[...r])e(i)}},{signal:e.signal}),{get mode(){return i},isCompact:()=>i===`compact`,onChange(t){return r.add(t),e.own(()=>r.delete(t))}}}var Gn=class{constructor(){this.currentInfo={aliyahRange:[],currentRun:null,previousLink:null,nextLink:null,relatedRuns:[]},this.firstAliyah=null,this.lastAliyah=null}get info(){return this.currentInfo}setLine(e,t){let n={...this.currentInfo},r=t.first?.aliyot[0]??t.center?.aliyot[0],i=t.last?.aliyot[0]??t.center?.aliyot[0],a=t.center?.run??t.last?.run??t.first?.run;if(!a)return this.currentInfo;if(n.currentRun=a,n.currentRun!==this.currentInfo.currentRun&&n.currentRun){n.relatedRuns=n.currentRun.leining.runs.filter(e=>rt(e.scroll)).map(e=>({label:Ze(e.aliyot[0].index,e)||e.type,targetRun:e}));let t=n.currentRun.leining.date,r=e.generator.aroundDate(t.date).filter(e=>e.id===t.id||!nt(e,t)).flatMap(e=>e.leinings).filter(e=>e.runs.some(e=>rt(e.scroll))),i=r.findIndex(e=>e.date.id===t.id&&e.id===n.currentRun?.leining.id);n.previousLink=Kn(r[i-1],n.currentRun),n.nextLink=Kn(r[i+1],n.currentRun)}if(n.currentRun?.scroll!==`torah`)n.aliyahRange=[];else if(r!==this.firstAliyah?.aliyah||i!==this.lastAliyah?.aliyah||n.currentRun!==this.currentInfo.currentRun){this.firstAliyah=e(r),this.lastAliyah=e(i),(r||i)&&(n.aliyahRange=this.generateAliyahRange(n.currentRun));function e(e){return e?{aliyah:e,run:Object.values(t).find(t=>t?.aliyot.includes(e)).run}:null}}return this.currentInfo=n,this.currentInfo}generateAliyahRange(e){return(this.firstAliyah?.aliyah===this.lastAliyah?.aliyah?[this.firstAliyah]:[this.firstAliyah,this.lastAliyah]).filter(e=>e!=null).map(t=>{let n=Ze(t.aliyah.index,t.run,{isEnd:!0});return t.run===e?n:`${t.run.leining.date.title.he} ${n}`})}};function Kn(e,t){let n=e?.runs.find(e=>rt(e.scroll));return!e||!n?null:{targetRun:n,label:[e.date.id===t.leining.date.id?``:e.date.title.he,e.id].join(` `).trim()}}var qn=`tikkun.last-reading`;function Jn(e,t){return qe(e.leining,t)??Ge(e,t)}function Yn(e,t){if(!e||typeof e!=`object`)return!1;let n=e;return typeof n.hash==`string`&&R(n.hash)&&typeof n.parshaName==`string`&&n.parshaName.trim().length>0&&(n.aliyahLabel===void 0||typeof n.aliyahLabel==`string`)&&W(n.savedAt,{now:t})}function Xn(e,t,n=R){return G({storage:e,key:qn,validate:e=>Yn(e,t)&&n(e.hash)})}function Zn(e,t,n=Date.now()){if(!R(t.hash))return;let r=t.parshaName.trim();if(!r)return;let i={hash:t.hash,parshaName:r,aliyahLabel:t.aliyahLabel?.trim()||void 0,savedAt:n};try{let t=Xn(e,n),r=t.read();if(r.status===`unavailable`)throw r.error;K(t.write(i,r.revision)),se({reading:i})}catch(e){throw new er(e)}}function Qn(e,t=Date.now(),n=R){let r=Xn(e,t,n),i=r.read();return i.status===`unavailable`?(console.error(`Failed to read the last-reading checkpoint`,i.error),null):i.status===`invalid`?(i.reason===`invalid-json`?console.error(`Failed to parse the last-reading checkpoint`,i.error):console.error(`Invalid last-reading checkpoint`),null):i.status===`missing`?null:t-i.value.savedAt>1728e5?($n(r,i.revision),null):i.value}function $n(e,t){try{let n=e.remove(t);if(n.status===`unavailable`)throw n.error}catch(e){console.error(`Failed to remove an expired last-reading checkpoint`,e)}}var er=class extends Error{constructor(e){super(`Failed to save the last-reading checkpoint`),this.name=`LastReadingStorageError`,this.cause=e}};function tr(e){let t=e.showWhenEmpty??!0,n=e.dedupeKey??e.label;return{...e,aliases:e.aliases??[],keywords:e.keywords??[],available:e.available??!0,showWhenEmpty:t,emptyPriority:t?e.emptyPriority??0:null,dedupeKey:n,destinationId:e.destinationId??n}}function nr(e){return e===`Maftir`?`Maftir`:`Aliyah ${e}`}function rr(e){return e===`Maftir`?[`m`,`maftir`]:[`${e}`,`aliyah ${e}`]}function ir({run:e,displayTitle:t,navigate:n,showWhenEmpty:r=!0,emptyPriority:i,dedupeKeyPrefix:a}){let o=t.trim(),s=[o,...$e(e.leining),...e.leining.isParsha?[]:Je(e.leining.date.title,`${e.leining.id}`)];return e.aliyot.flatMap(t=>{let c=t.index;if(!c)return[];let l=Jn(e,t.start);return[tr({id:`reading.${e.id}.${c}`,group:`reading`,label:`${o} ${nr(c)}`,dedupeKey:`${a??`reading.${e.id}`}.${c}`,destinationId:l,searchConstraint:{kind:`aliyah`,aliyah:c,allowTerms:rr(c)},href:l,aliases:s.flatMap(e=>[`${e} ${c}`,`${e} ${nr(c)}`]),keywords:[...s,...rr(c)],showWhenEmpty:r,emptyPriority:i,run:()=>n(l)})]})}function ar({navigateToPage:e}){let t=[];for(let n=1;n<=tt(`torah`);n+=1)t.push(tr({id:`page.torah.${n}`,group:`page`,label:`Torah page ${n}`,aliases:[`${n}`,`page ${n}`,`torah ${n}`,`torah page ${n}`,`chumash page ${n}`],keywords:[`page`,`torah`,`chumash`],showWhenEmpty:!1,run:()=>e(`torah`,n)}));for(let n=1;n<=tt(`esther`);n+=1)t.push(tr({id:`page.esther.${n}`,group:`page`,label:`Esther page ${n}`,aliases:[`esther ${n}`,`esther page ${n}`,`megillah ${n}`,`megillah page ${n}`,`megillat esther page ${n}`],keywords:[`page`,`esther`,`megillah`],showWhenEmpty:!1,run:()=>e(`esther`,n)}));return t}function or(e,t){let{load:n=()=>L(()=>import(`./QVwXKNrD.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13]),import.meta.url),onLoadError:r,...i}=t,a=null,o=null,s=null,c=0,l=!1,u=()=>{if(a)return Promise.resolve(a);if(s)return s;o??=n();let t=o.then(t=>e.signal.aborted?null:(a=t.createCommandPalette(e,i),a)).catch(t=>(o=null,e.signal.aborted||r(t),null)).finally(()=>{s===t&&(s=null)});return s=t,t},d=()=>{if(e.signal.aborted)return;if(a){a.open();return}l=!0;let t=++c;u().then(n=>{e.signal.aborted||t!==c||!l||(l=!1,n?.open())})},f=()=>{l=!1,c+=1,a?.close()},p={open:d,close:f,toggle:()=>{if(l||a?.isOpen()){f();return}d()},isOpen:()=>l||(a?.isOpen()??!1),refresh:()=>a?.refresh()};return e.own(()=>{l=!1,c+=1,a=null,s=null,o=null}),p}var sr=[!0,!1].flatMap(e=>[!0,!1].flatMap(t=>[!0,!1].map(n=>({israel:e,ashkenazi:t,includeModernHolidays:n})))).map(e=>new Le(e));function cr(e){if(!R(e))return!1;let t=e.replace(/^#/,``);return sr.some(e=>Be(e,t)?.view===`reader`)}function lr(e){let t=e.split(`?`)[0];if(!R(t))throw Error(`Open a reading before sharing it.`);return`https://tikkunreader.com/reader/${t}`}async function ur(e,t){let n={title:`Tikkun Reader`,url:lr(e)};try{if(t.nativeShare)return await t.nativeShare(n),`shared`;let e=t.navigator;if(e.share&&(!e.canShare||e.canShare(n)))return await e.share(n),`shared`;if(!e.clipboard?.writeText)throw Error(`Sharing and clipboard access are unavailable.`);return await e.clipboard.writeText(n.url),`copied`}catch(e){if(e instanceof Error&&(t.nativeShare?e.message===`Share canceled`:e.name===`AbortError`))return`cancelled`;throw e}}var dr=`reader`;function fr(e){dr=e}function pr(e){let t=e.getBoundingClientRect(),n=dr===`browser`?document.documentElement.clientHeight/2:t.top+e.clientHeight/2;return Math.max(t.top,Math.min(t.bottom-1,n))}function mr(e){let t=e.getBoundingClientRect();return e.scrollTop+(pr(e)-t.top)}function hr(e,t){let n=t.getBoundingClientRect(),r=n.top+n.height/2;return Math.max(0,e.scrollTop+r-pr(e))}function gr(e,t,n={}){let r=hr(e,t),{minimumScrollDistance:i=0,...a}=n;return Math.abs(r-e.scrollTop)<=Math.max(0,i)?!1:a.behavior?(e.scrollTo({...a,top:r}),!0):(e.scrollTop=r,!0)}var _r=[`reading`,`match`],vr=[`one`,`two`],yr=[`tikkun-right`,`torah-right`],br={layout:`match`,sides:`one`},xr=e=>typeof e==`string`&&_r.some(t=>t===e),Sr=e=>typeof e==`string`&&vr.some(t=>t===e),Cr=e=>typeof e==`string`&&yr.some(t=>t===e);function wr(e,t){return e===`two`&&!t?`two`:`one`}var Tr=`tikkun.reader-preferences`,Er=[`automatic`,`light`,`sepia`,`dark`,`custom`],Dr=[`browser`,`reader`],Or={background:`#eee6d6`,text:`#3b3026`},kr={playbackRate:{min:.5,max:3},highlightOpacity:{min:.05,max:.45},outlineWidth:{min:1,max:6},outlineOffset:{min:0,max:10},radius:{min:0,max:16},glow:{min:0,max:8}},Ar={reducedMotion:`automatic`,narratorId:`yoni-davidov`,playbackRate:1,highlightFill:`#ffd700`,highlightOpacity:.15,outlineColor:`#ffd700`,outlineWidth:2,outlineOffset:3.5,radius:10,glow:3.5,autoScrollWithPlayback:!0,focalPointMode:`reader`,disableShiftNekudotHide:!1,themeMode:`automatic`,customBackgroundColor:Or.background,customTextColor:Or.text,readerTextLayout:`match`,readerSideMode:`one`,readerSideOrder:`tikkun-right`};function jr(){return typeof window>`u`||typeof window.matchMedia!=`function`?Ar.readerTextLayout:window.matchMedia(`(max-width: 550px)`).matches?`reading`:`match`}function Mr(e){return typeof document>`u`||typeof getComputedStyle>`u`?``:getComputedStyle(document.documentElement).getPropertyValue(e).trim()}function Nr(e,t){let n=Number.parseFloat(Mr(e));return Number.isFinite(n)?n:t}function Pr(e,t){return Mr(e)||t}function Fr(){return{...Ar,readerTextLayout:jr(),highlightFill:Pr(`--reader-highlight-fill`,Ar.highlightFill),outlineColor:Pr(`--reader-highlight-outline-color`,Ar.outlineColor),outlineWidth:Nr(`--reader-highlight-outline-width`,Ar.outlineWidth),outlineOffset:Nr(`--reader-highlight-outline-offset`,Ar.outlineOffset),radius:Nr(`--reader-highlight-border-radius`,Nr(`--reader-highlight-radius`,Ar.radius)),glow:Nr(`--reader-highlight-glow`,Ar.glow)}}function Ir(){return{highlightFill:Ar.highlightFill,highlightOpacity:Ar.highlightOpacity,outlineColor:Ar.outlineColor,outlineWidth:Ar.outlineWidth,outlineOffset:Ar.outlineOffset,radius:Ar.radius,glow:Ar.glow}}function Lr(e){return typeof e==`string`&&Er.some(t=>t===e)}function Rr(e){return typeof e==`string`&&Dr.some(t=>t===e)}function zr(e){return!!e&&typeof e==`object`&&!Array.isArray(e)}function Br(e,t,{min:n,max:r}){return typeof e==`number`&&Number.isFinite(e)?Math.max(n,Math.min(r,e)):t}function Vr(e,t){return typeof e==`string`&&/^#[0-9a-f]{6}$/i.test(e)?e:t}function Hr(e,t){let n=zr(e)?e:{};return{reducedMotion:n.reducedMotion===`on`||n.reducedMotion===`off`||n.reducedMotion===`automatic`?n.reducedMotion:t.reducedMotion,narratorId:typeof n.narratorId==`string`&&n.narratorId.trim()?n.narratorId.trim():t.narratorId,playbackRate:Br(n.playbackRate,t.playbackRate,kr.playbackRate),highlightFill:Vr(n.highlightFill,t.highlightFill),highlightOpacity:Br(n.highlightOpacity,t.highlightOpacity,kr.highlightOpacity),outlineColor:Vr(n.outlineColor,t.outlineColor),outlineWidth:Br(n.outlineWidth,t.outlineWidth,kr.outlineWidth),outlineOffset:Br(n.outlineOffset,t.outlineOffset,kr.outlineOffset),radius:Br(n.radius,t.radius,kr.radius),glow:Br(n.glow,t.glow,kr.glow),autoScrollWithPlayback:typeof n.autoScrollWithPlayback==`boolean`?n.autoScrollWithPlayback:t.autoScrollWithPlayback,focalPointMode:Rr(n.focalPointMode)?n.focalPointMode:t.focalPointMode,disableShiftNekudotHide:typeof n.disableShiftNekudotHide==`boolean`?n.disableShiftNekudotHide:t.disableShiftNekudotHide,themeMode:Lr(n.themeMode)?n.themeMode:t.themeMode,customBackgroundColor:Vr(n.customBackgroundColor,t.customBackgroundColor),customTextColor:Vr(n.customTextColor,t.customTextColor),readerTextLayout:xr(n.readerTextLayout)?n.readerTextLayout:t.readerTextLayout,readerSideMode:Sr(n.readerSideMode)?n.readerSideMode:t.readerSideMode,readerSideOrder:Cr(n.readerSideOrder)?n.readerSideOrder:t.readerSideOrder}}function Ur(){return G({storage:q(`local`),key:Tr,validate:zr})}function Wr(){let e=Fr(),t=Ur().read();return t.status===`unavailable`?(console.error(`Failed to read reader preferences`,t.error),{preferences:{...e},revision:null}):t.status===`invalid`?(t.reason===`invalid-json`?console.error(`Failed to parse reader preferences`,t.error):console.error(`Invalid reader preferences`),{preferences:{...e},revision:t.revision}):t.status===`missing`?{preferences:{...e},revision:t.revision}:{preferences:{...Hr(t.value,e),playbackRate:e.playbackRate},revision:t.revision}}function Gr(e,t){let n=Hr(e,Fr());try{let e=Ur(),r={...n,playbackRate:Ar.playbackRate},i=t;if(!i){let t=e.read();if(t.status===`unavailable`)throw t.error;i=t.revision}return K(e.write(r,i))}catch(e){throw new Kr(e)}}var Kr=class extends Error{constructor(e){super(`Failed to save reader preferences`),this.name=`ReaderPreferencesStorageError`,this.cause=e}};function qr(e,t){return Hr({...e,...t},e)}function Jr(e){let t=document.documentElement;t.dataset.readerReducedMotion=e.reducedMotion;let n=$r(e.highlightFill,e.highlightOpacity),r=`${e.highlightOpacity*100}%`,i=`${(1-e.highlightOpacity)*100}%`;t.dataset.readerTheme=e.themeMode,t.dataset.readerTextLayout=e.readerTextLayout,t.dataset.readerSideMode=e.readerSideMode,t.dataset.readerSideOrder=e.readerSideOrder,t.style.setProperty(`--reader-custom-background-color`,e.customBackgroundColor),t.style.setProperty(`--reader-custom-text-color`,e.customTextColor),t.style.colorScheme=e.themeMode===`custom`?Zr(e.customBackgroundColor)<.32?`dark`:`light`:``,t.dataset.readerCustomScheme=t.style.colorScheme,fr(e.focalPointMode),t.style.setProperty(`--reader-highlight-fill`,e.highlightFill),t.style.setProperty(`--reader-highlight-fill-tint`,n),t.style.setProperty(`--reader-highlight-fill-alpha`,`${e.highlightOpacity}`),t.style.setProperty(`--reader-highlight-fill-alpha-percent`,r),t.style.setProperty(`--reader-highlight-fill-alpha-inverse-percent`,i),t.style.setProperty(`--reader-highlight-outline-color`,e.outlineColor),t.style.setProperty(`--reader-highlight-outline-width`,`${e.outlineWidth}px`),t.style.setProperty(`--reader-highlight-border-radius`,`${e.radius}px`),t.style.setProperty(`--reader-highlight-glow`,`${e.glow}px`),t.style.setProperty(`--reader-highlight-outline-offset`,`${e.outlineOffset}px`)}function Yr(e,t){let n=Math.max(Zr(e),Zr(t)),r=Math.min(Zr(e),Zr(t));return(n+.05)/(r+.05)}function Xr(e){let t=`#191c22`,n=`#f8f7f3`;return Yr(e,t)>=Yr(e,n)?t:n}function Zr(e){let[t,n,r]=Qr(e).map(e=>{let t=e/255;return t<=.04045?t/12.92:((t+.055)/1.055)**2.4});return .2126*t+.7152*n+.0722*r}function Qr(e){let t=/^#([0-9a-f]{6})$/i.exec(e.trim());return t?[0,2,4].map(e=>Number.parseInt(t[1].slice(e,e+2),16)):[0,0,0]}function $r(e,t){let n=e.trim();if(!n.startsWith(`#`))return n;let r=n.slice(1);if(r.length!==6&&r.length!==3)return n;let[i,a,o]=(r.length===3?r.split(``).map(e=>e+e):[r.slice(0,2),r.slice(2,4),r.slice(4,6)]).map(e=>Number.parseInt(e,16));return`rgba(${i}, ${a}, ${o}, ${t})`}var ei=1600,ti=new WeakMap,ni=new WeakSet;function ri(e){e.dataset.copyState=`copied`,e.querySelector(`[data-aliyah-link-icon="link"]`)?.setAttribute(`hidden`,``),e.querySelector(`[data-aliyah-link-icon="check"]`)?.removeAttribute(`hidden`);let t=ti.get(e);t&&window.clearTimeout(t),ti.set(e,window.setTimeout(()=>ii(e),ei))}function ii(e){let t=ti.get(e);t!==void 0&&window.clearTimeout(t),delete e.dataset.copyState,e.querySelector(`[data-aliyah-link-icon="link"]`)?.removeAttribute(`hidden`),e.querySelector(`[data-aliyah-link-icon="check"]`)?.setAttribute(`hidden`,``),ti.delete(e)}function ai(e){if(e instanceof HTMLAnchorElement)return e.href;let t=e.dataset.aliyahUrl;return t?new URL(t,window.location.href).href:null}async function oi(e,t={}){let n=(e.target instanceof Element?e.target:null)?.closest(`[data-aliyah-link="true"]`);if(!n)return!1;if(e.preventDefault(),ni.has(n))return!0;ni.add(n),ii(n);try{let e=ai(n);if(!e)throw Error(`Missing permalink URL.`);if(t.nativeWriteText)await t.nativeWriteText(lr(new URL(e).hash));else{if(!navigator.clipboard?.writeText)throw Error(`Clipboard API is unavailable.`);await navigator.clipboard.writeText(e)}}catch(e){return console.warn(`Aliyah permalink copy failed.`,e),t.onError?.(),!0}finally{ni.delete(n)}return n.isConnected&&ri(n),!0}var si=new Set([Ie.Main,Ie.LastAliyah,Ie.Maftir]);function ci(e){return e===`Maftir`?`מפטיר`:[`ראשון`,`שני`,`שלישי`,`רביעי`,`חמישי`,`ששי`,`שביעי`][e-1]}function li(e,t){return!!(e&&t&&e.runId===t.runId&&e.aliyahIndex===t.aliyahIndex)}function ui({run:e,aliyah:t}){return`${e.id}:${t.index}`}function di(e){return`${e.key}:${e.audioKey??``}:${e.recordingKey??``}:${e.audioState?`passage`:`recording`}:${e.audioState?.problem??``}:${e.audioState?.issue??``}:${e.audioState?.canPlay??``}`}function fi(e){return e.leining.runs.filter(t=>t.scroll===e.scroll&&si.has(t.type)).flatMap(e=>e.aliyot.flatMap(t=>t.index?[{run:e,aliyah:{...t,index:t.index}}]:[]))}function pi({entries:e,active:t,playback:n,signaturePrefix:r,getAudio:i}){let a=e.map(e=>{let{run:t,aliyah:n}=e,r={runId:t.id,aliyahIndex:n.index},a=i(e);return{key:ui(e),target:r,label:ci(n.index),compactLabel:n.index===`Maftir`?`M`:`${n.index}`,audioKey:a.playbackKey,recordingKey:a.recordingKey,audioState:a.audioState}});return{signature:`${r}:${a.map(di).join(`|`)}`,items:a,active:t,playback:n}}function mi({runId:e,current:t,playback:n,first:r}){return n.playing&&n.target?.runId===e?n.target:t?.runId===e?t:r}var hi=r(`<button type="button"></button>`),gi=r(`<button type="button"> </button>`),_i=r(`<span class="aliyah-rail-caption" aria-hidden="true">Aliyah</span> <!>`,1),vi=r(`<button type="button"><!></button>`),yi=r(`<article><button class="mobile-aliyah-card-main" type="button"><span class="mobile-aliyah-card-label"> </span> <span class="mobile-aliyah-card-status"> </span></button> <!></article>`),bi=r(`<nav data-target-id="mobile-aliyah-segments" aria-label="Aliyah navigation"></nav> <nav data-target-id="aliyah-rail" aria-label="Aliyah navigation"><!></nav> <div data-target-id="mobile-aliyah-picker" id="mobile-aliyah-picker"><button class="mobile-aliyah-picker-backdrop" data-target-id="mobile-aliyah-picker-backdrop" type="button" aria-label="Close aliyah picker" tabindex="-1"></button> <div class="mobile-aliyah-sheet" role="dialog" aria-modal="true" aria-labelledby="mobile-aliyah-picker-title"><button class="mobile-aliyah-sheet-handle" data-target-id="mobile-aliyah-sheet-handle" type="button" aria-label="Close aliyah picker"></button> <header class="mobile-aliyah-sheet-header"><div class="mobile-aliyah-sheet-copy"><h2 id="mobile-aliyah-picker-title">Choose an aliyah</h2> <p>Tap a name to navigate, or play its recording.</p></div> <button class="mobile-aliyah-sheet-close" data-target-id="mobile-aliyah-picker-close" type="button" aria-label="Close aliyah picker"><!></button></header> <div class="mobile-aliyah-grid" data-target-id="mobile-aliyah-grid"></div></div></div>`,1);function xi(n,r){ee(r,!0);let i=f(r,`document`,7);function s(){let e=i().defaultView;if(!e)throw Error(`Aliyah Navigation requires an attached browser document`);return e}let h=s(),_={target:null,playing:!1,progressLabel:``},x=m(null),C=m(null),w=m(`hidden`),T=m(!1),O=m(!1),M=m(!1),P=m(!1),I=m(0),L=m(y({})),R=m(y({})),te,ne,z,re=null,B=null,V=null,ie=0,ae=null,oe=!1,se=!1,H=!1,U=0,W=new ke,G=new ke;function K(e){return e?{...e,items:[...e.items],playback:{...e.playback}}:null}function q(e,t=l(I)){return`${t}:${l(O)}:${di(e)}`}function J(e,t=!1){return(t?[l(C)]:[l(x),l(C)]).some(t=>t?.items.some(t=>q(t)===e))}function ce(e,t=l(I)){for(let n of e.items){let e=q(n,t);l(L)[e]!==void 0||W.has(e)||(W.add(e),r.loadCueStatus(n).then(t=>{W.delete(e),!(H||r.signal.aborted||!J(e))&&(S(()=>{D(L,{...l(L),[e]:t},!0)}),r.onCueStatusChange(n,t))}).catch(t=>{W.delete(e),!(H||r.signal.aborted||!J(e))&&r.onCueStatusError(t,n)}))}}function le(e,t=l(I)){for(let n of e.items){if(!n.audioKey)continue;let e=q(n,t);l(R)[e]!==void 0||G.has(e)||(G.add(e),r.loadDurationLabel(n).then(t=>{G.delete(e),!(H||r.signal.aborted||!J(e,!0))&&S(()=>{D(R,{...l(R),[e]:t},!0)})}).catch(t=>{G.delete(e),!(H||r.signal.aborted||!J(e,!0))&&(r.onDurationError(t,n),S(()=>{D(R,{...l(R),[e]:`Available`},!0)}))}))}}function Y(){i().documentElement.style.setProperty(`--aliyah-rail-top`,`${r.toolbar.getBoundingClientRect().bottom}px`)}function ue(){let e=l(w)===`hidden`;i().documentElement.dataset.aliyahRailVisibility=l(w),e&&r.onWideHidden()}function de(){re!==null&&(h.clearTimeout(re),re=null)}function fe(e){S(()=>{D(w,e,!0)}),ue()}function pe(){de(),fe(`hidden`)}function me(e=Ti){de(),re=h.setTimeout(()=>{re=null,!(oe||se)&&pe()},e)}function he(e=`peek`,{autoHideMs:t=Ti}={}){l(x)&&(Y(),fe(e),e===`expanded`?de():me(t))}function ge(e){S(()=>{D(x,K(e.desktop),!0),D(C,K(e.compact),!0),D(O,e.authoringEnabled,!0)}),l(x)?(Y(),ue(),ce(l(x))):pe(),l(C)?(ce(l(C)),le(l(C))):we()}function _e(){U+=1,we(),S(()=>{D(x,null),D(C,null),D(O,!1),D(I,l(I)+1),D(L,{},!0),D(R,{},!0)}),W.clear(),G.clear(),pe()}function ve(){S(()=>{D(I,l(I)+1),D(L,{},!0),D(R,{},!0)}),W.clear(),G.clear(),l(x)&&ce(l(x)),l(C)&&(ce(l(C)),le(l(C)))}function ye(e){S(()=>{l(x)&&D(x,{...l(x),active:e},!0),l(C)&&D(C,{...l(C),active:e},!0)})}function X(e){S(()=>{l(C)&&D(C,{...l(C),playback:{...e}},!0)})}function be(e){S(()=>{D(T,e,!0)}),e||we()}function xe(){return l(M)&&!l(P)}function Se(){ie&&=(h.cancelAnimationFrame(ie),0)}function Ce(){V!==null&&h.clearTimeout(V),V=null,S(()=>{D(P,!1)})}function we({focusTarget:e,restoreFocus:t=!0}={}){if(!l(M)||l(P))return;Se();let n=e??(t?ae:null);ae=null;let i=h.matchMedia(`(prefers-reduced-motion: reduce)`).matches;if(S(()=>{D(M,!1),D(P,!i)}),r.onCompactOpenChange(!1),n&&r.restoreFocus(n),i){Ce();return}V=h.setTimeout(Ce,180)}function Te(e){if(!l(T)||!l(C))return;X(r.onBeforeCompactOpen()),V!==null&&h.clearTimeout(V),V=null,Se();let t=i().activeElement,n=t instanceof h.HTMLElement&&t!==i().body?t:null;ae=e??n??r.getCompactToggle()??z,S(()=>{D(P,!1),D(M,!0)}),r.onCompactOpenChange(!0),ie=h.requestAnimationFrame(()=>{ie=0,!(H||r.signal.aborted||!l(M))&&(ne.querySelector(`.mobile-aliyah-card.is-current .mobile-aliyah-card-main`)??z).focus()})}function Ee(e){return l(L)[q(e)]??`none`}function De(e){let t=q(e);return Object.prototype.hasOwnProperty.call(l(L),t)?l(L)[t]??null:null}function Oe(e){if(e.audioState)return e.audioState.problem===`incomplete-cues`;let t=De(e);return!!(e.recordingKey&&t&&Oi(t))}function Ae(e){return bn({state:e.audioState,available:!!e.audioKey,cueIncomplete:Oe(e),adminMissing:l(O)&&!e.recordingKey,playing:Ne(Pe(),e.target)})}function je(e){if(e.audioState?.message&&!l(O)){if(!e.audioState.canPlay){if(e.audioState.problem===`missing-audio`)return`Audio unavailable`;if(e.audioState.problem===`timing-needed`)return`Timing cues needed`}return e.audioState.message}return l(O)&&!e.recordingKey?`Record audio + cues`:e.audioKey?l(R)[q(e)]??`Loading…`:`Audio unavailable`}function Me(e,t){return li(e.target,t)}function Ne(e,t){return e.playing&&Me(e,t)}function Pe(){return l(C)?.playback??_}function Fe(e,t){return Ne(t,e.target)?`Playing · ${t.progressLabel}`:Me(t,e.target)?`Paused · ${t.progressLabel}`:je(e)}function Ie(e,t){if(l(O)&&!e.recordingKey)return`Select ${e.label} for audio and cue recording`;let n=De(e);return l(O)&&Oe(e)&&n?ki({label:e.label,status:n,playing:Ne(t,e.target)}):`${Ne(t,e.target)?`Pause`:`Play`} ${e.label}${e.audioState?.message?` — ${e.audioState.message}`:``}`}function Le(e,t){return Ne(t,e.target)?`${e.label} is playing. Go to aliyah.`:`Go to ${e.label}`}function Re(e){r.onSelect(e),he(`expanded`),me()}function Q(e){ye(e),r.onSelect(e),r.onAfterNavigate()}function $(e){we(),ye(e),r.onSelect(e),r.onAfterNavigate()}async function ze(e){let t=l(C)?.items.find(t=>li(t.target,e));if(!t||Ae(t).actionDisabled)return;ye(e),we({focusTarget:r.getReaderFocusTarget()});let n=++U,i=await r.onPlayCompact(e);H||r.signal.aborted||n!==U||X(i)}function Be(){oe=!0,he(`expanded`)}function Ve(){oe=!1,me()}function He(){se=!0,he(`expanded`)}function Ue(){B!==null&&h.clearTimeout(B),B=h.setTimeout(()=>{B=null,se=i().activeElement?te.contains(i().activeElement):!1,se||me()},0)}function We(e){if(e.key===`Escape`){e.preventDefault(),we();return}if(e.key!==`Tab`)return;let t=[...ne.querySelectorAll(`button:not(:disabled), input:not(:disabled), [tabindex]:not([tabindex="-1"])`)].filter(e=>e.offsetParent!==null),n=t[0],r=t[t.length-1];!n||!r||(e.shiftKey&&i().activeElement===n?(e.preventDefault(),r.focus()):!e.shiftKey&&i().activeElement===r&&(e.preventDefault(),n.focus()))}let Ge={syncContent:ge,clearContent:_e,invalidate:ve,setActive:ye,syncPlayback:X,setCompactAvailable:be,revealWide:he,revealWideForMovement:()=>he(`peek`),scheduleWideHide:me,openCompact:Te,closeCompact:we,isCompactOpen:xe};k(()=>(r.connect(Ge),h.addEventListener(`resize`,Y),h.visualViewport?.addEventListener(`resize`,Y),()=>{H=!0,U+=1,de(),B!==null&&h.clearTimeout(B),V!==null&&h.clearTimeout(V),B=null,V=null,Se(),ae=null,oe=!1,se=!1,W.clear(),G.clear(),r.onCompactOpenChange(!1),r.onWideHidden(),i().documentElement.style.removeProperty(`--aliyah-rail-top`),delete i().documentElement.dataset.aliyahRailVisibility,h.removeEventListener(`resize`,Y),h.visualViewport?.removeEventListener(`resize`,Y)}));var Ke=bi(),qe=E(Ke);let Je;o(qe,21,()=>l(C)?.items.slice(0,7)??[],e=>e.key,(n,r)=>{var i=hi();let a;d((e,t,n,o)=>{a=F(i,1,`mobile-aliyah-segment`,null,a,e),v(i,`data-run-id`,l(r).target.runId),v(i,`data-aliyah-index`,l(r).target.aliyahIndex),v(i,`data-aliyah-label`,l(r).label),v(i,`title`,t),v(i,`aria-label`,n),v(i,`aria-current`,o)},[()=>({"is-current":li(l(C)?.active,l(r).target),"is-playing":Ne(Pe(),l(r).target)}),()=>Le(l(r),Pe()),()=>Le(l(r),Pe()),()=>li(l(C)?.active,l(r).target)?`location`:void 0]),e(`click`,i,()=>Q(l(r).target)),t(n,i)}),c(qe);var Ye=A(qe,2);let Xe;var Ze=j(Ye),Qe=n=>{var r=_i(),i=A(E(r),2);o(i,17,()=>l(x).items,e=>e.key,(n,r)=>{var i=gi();let o;var s=j(i,!0);c(i),d((e,t,n,c)=>{o=F(i,1,`aliyah-rail-button`,null,o,e),v(i,`data-run-id`,l(r).target.runId),v(i,`data-aliyah-index`,l(r).target.aliyahIndex),v(i,`data-navigation-key`,l(r).key),v(i,`data-cue-status`,t),v(i,`title`,n),v(i,`aria-current`,c),a(s,l(r).compactLabel)},[()=>({"is-active":li(l(x).active,l(r).target)}),()=>Ee(l(r)),()=>`${l(r).label} · ${Di(Ee(l(r)))}`,()=>li(l(x).active,l(r).target)?`location`:void 0]),e(`click`,i,()=>Re(l(r).target)),t(n,i)}),t(n,r)};b(Ze,e=>{l(x)&&e(Qe)}),c(Ye),p(Ye,e=>te=e,()=>te);var $e=A(Ye,2);let et;var tt=j($e),nt=A(tt,2),rt=j(nt),it=A(rt,2),at=A(j(it),2),ot=j(at);Z(ot,{name:`x`}),c(at),p(at,e=>z=e,()=>z),c(it);var st=A(it,2);o(st,21,()=>l(C)?.items??[],e=>e.key,(n,r)=>{var i=yi();let o;var s=j(i),u=j(s),f=j(u,!0);c(u);var p=A(u,2),m=j(p,!0);c(p),c(s);var h=A(s,2),_=n=>{var i=vi();let a;var o=j(i);{let e=g(()=>Ne(Pe(),l(r).target)?`pause`:`play`);Z(o,{get name(){return l(e)}})}c(i),d((e,t,n,o,s,c,u)=>{a=F(i,1,`mobile-aliyah-play`,null,a,e),v(i,`data-audio-problem`,l(r).audioState?.problem??``),v(i,`data-audio-tone`,t),v(i,`data-audio-dimmed`,n),v(i,`data-audio-tooltip`,o),v(i,`data-run-id`,l(r).target.runId),v(i,`data-aliyah-index`,l(r).target.aliyahIndex),v(i,`aria-disabled`,s),v(i,`aria-label`,c),v(i,`aria-pressed`,u)},[()=>({"is-missing-audio":l(O)&&!l(r).recordingKey,"is-cue-incomplete":Oe(l(r))}),()=>Ae(l(r)).tone,()=>Ae(l(r)).dimmed,()=>Ae(l(r)).tooltip,()=>Ae(l(r)).actionDisabled,()=>Ie(l(r),Pe()),()=>Ne(Pe(),l(r).target)]),e(`click`,i,()=>ze(l(r).target)),t(n,i)};b(h,e=>{l(r).target&&e(_)}),c(i),d((e,t,n,c,u)=>{o=F(i,1,`mobile-aliyah-card`,null,o,e),v(i,`data-run-id`,l(r).target.runId),v(i,`data-aliyah-index`,l(r).target.aliyahIndex),v(s,`data-run-id`,l(r).target.runId),v(s,`data-aliyah-index`,l(r).target.aliyahIndex),v(s,`aria-label`,`Go to ${l(r).label}`),v(s,`aria-current`,t),a(f,l(r).label),v(p,`data-audio-key`,l(r).audioKey??``),v(p,`data-duration-label`,n),v(p,`title`,c),a(m,u)},[()=>({"is-current":li(l(C)?.active,l(r).target),"is-unavailable":!l(r).audioKey&&!l(O),"is-authoring-missing":l(O)&&!l(r).recordingKey,"is-playing":Ne(Pe(),l(r).target)}),()=>li(l(C)?.active,l(r).target)?`location`:void 0,()=>je(l(r)),()=>Fe(l(r),Pe()),()=>Fe(l(r),Pe())]),e(`click`,s,()=>$(l(r).target)),t(n,i)}),c(st),c(nt),c($e),p($e,e=>ne=e,()=>ne),d(()=>{Je=F(qe,1,`mobile-aliyah-segments`,null,Je,{"u-hidden":!l(C)}),Xe=F(Ye,1,`aliyah-rail`,null,Xe,{"u-hidden":!l(x),"is-peeking":l(w)===`peek`,"is-expanded":l(w)===`expanded`}),v(Ye,`data-visibility`,l(w)),v(Ye,`aria-hidden`,l(w)===`hidden`),Ye.inert=l(w)===`hidden`,et=F($e,1,`mobile-aliyah-picker`,null,et,{"u-hidden":!l(M)&&!l(P),"is-closing":l(P)}),v($e,`aria-hidden`,!l(M)),$e.inert=!l(M)}),u(`pointerenter`,Ye,Be),u(`pointerleave`,Ye,Ve),e(`focusin`,Ye,He),e(`focusout`,Ye,Ue),e(`keydown`,$e,We),e(`click`,tt,()=>we()),e(`click`,rt,()=>we()),e(`click`,at,()=>we()),t(n,Ke),N()}I([`click`,`focusin`,`focusout`,`keydown`]);var Si=r(`<span class="mobile-aliyah-spinner"></span>`),Ci=r(`<div data-target-id="mobile-aliyah-capsule"><button data-target-id="mobile-aliyah-play-toggle" type="button"><span class="mobile-aliyah-play-icon" aria-hidden="true"><!></span> <span data-target-id="mobile-current-aliyah"> </span></button> <button class="mobile-aliyah-picker-toggle" data-target-id="mobile-aliyah-picker-toggle" type="button" title="Choose aliyah" aria-label="Choose aliyah" aria-haspopup="dialog" aria-controls="mobile-aliyah-picker"><span class="mobile-aliyah-picker-chevron" data-target-id="mobile-aliyah-picker-chevron" aria-hidden="true"><!></span></button></div> <span data-target-id="toolbar-current-aliyah-label"> </span> <button data-target-id="toolbar-current-aliyah-audio" type="button"><!></button>`,1);function wi(n,r){ee(r,!0);let i=m(y({current:{labelVisible:!1,label:`—`,target:null,audioAvailable:!1,authoringAvailable:!1,authoringEnabled:!1,cueStatus:null,playing:!1},compact:{visible:!1,target:null,label:`ראשון`,playbackState:`default`,audioAvailable:!1}})),o=m(!1),s,u=m(`idle`),f=g(()=>l(i).compact.audioAvailable??!1),h=g(()=>bn({state:l(i).current.audioState,available:l(i).current.audioAvailable,cueIncomplete:O(),adminMissing:l(i).current.authoringAvailable,playing:l(i).current.playing})),_=g(()=>bn({state:l(i).compact.audioState,available:l(f),adminMissing:l(i).compact.authoringMissing,cueIncomplete:l(i).compact.cueIncomplete,playing:l(i).compact.playbackState===`playing`}));function x(e){let t=!li(l(i).compact.target,e.compact.target);S(()=>{D(i,{current:{...e.current},compact:{...e.compact}},!0),(t||e.compact.playbackState!=="default")&&D(u,`idle`)})}function C(e){S(()=>{D(o,e,!0)})}function w(e,t){li(l(i).current.target,e)&&S(()=>{D(i,{...l(i),current:{...l(i).current,cueStatus:t}},!0)})}function T(){S(()=>{D(i,{...l(i),current:{...l(i).current,cueStatus:null}},!0)})}function O(){let e=l(i).current.cueStatus;return l(i).current.audioState?l(i).current.audioState.problem===`incomplete-cues`:!!(l(i).current.audioAvailable&&e&&Oi(e))}function M(){let e=l(i).current.cueStatus;return l(i).current.authoringEnabled&&O()&&e?ki({label:l(i).current.label,status:e,playing:l(i).current.playing}):`${l(i).current.playing?`Pause`:`Play`} ${l(i).current.label}${l(i).current.audioState?.message?` — ${l(i).current.audioState.message}`:``}`}function P(){r.onToggleCompact(s)}async function I(){l(h).actionDisabled||!l(i).current.target||!l(i).current.audioAvailable&&!l(i).current.authoringAvailable||await r.onPlayCurrent(l(i).current.target)}async function L(){let e=l(i).compact.target;if(!(!e||l(_).actionDisabled||l(u)===`loading`)){D(u,l(i).compact.playbackState==="default"?`loading`:`idle`,!0);try{await r.onPlayCurrent(e),D(u,`idle`)}catch(e){console.error(`Failed to play the current aliyah`,e),D(u,`error`)}}}function R(){return l(f)?l(u)===`loading`?`Loading ${l(i).compact.label}`:l(u)===`error`?`Retry ${l(i).compact.label}`:`${l(i).compact.playbackState===`playing`?`Pause`:`Play`} ${l(i).compact.label}${l(i).compact.audioState?.message?` — ${l(i).compact.audioState.message}`:``}`:`Recording unavailable for ${l(i).compact.label}`}let te={sync:x,setCueStatus:w,invalidateCueStatus:T,setCompactOpen:C,getCompactToggle:()=>s};k(()=>{r.connect(te)});var ne=Ci(),z=E(ne);let re;var B=j(z);let V;var ie=j(B),ae=j(ie),oe=e=>{var n=Si();t(e,n)},se=e=>{Z(e,{name:`replay`})},H=e=>{{let t=g(()=>l(i).compact.playbackState===`playing`?`pause`:`play`);Z(e,{get name(){return l(t)}})}};b(ae,e=>{l(u)===`loading`?e(oe):l(u)===`error`?e(se,1):e(H,-1)}),c(ie);var U=A(ie,2),W=j(U,!0);c(U),c(B);var G=A(B,2),K=j(G),q=j(K);{let e=g(()=>l(o)?`chevronUp`:`chevronDown`);Z(q,{get name(){return l(e)}})}c(K),c(G),p(G,e=>s=e,()=>s),c(z);var J=A(z,2);let ce;var le=j(J,!0);c(J);var Y=A(J,2);let ue;var de=j(Y);{let e=g(()=>l(i).current.playing?`pause`:`play`);Z(de,{get name(){return l(e)}})}c(Y),d((e,t,n)=>{re=F(z,1,`mobile-aliyah-capsule`,null,re,{"u-hidden":!l(i).compact.visible,"is-loaded":l(i).compact.playbackState===`loaded`,"is-playing":l(i).compact.playbackState===`playing`,"is-loading":l(u)===`loading`,"is-unavailable":!l(f)}),v(z,`data-audio-tone`,l(_).tone),v(z,`data-audio-dimmed`,l(_).dimmed),v(z,`data-run-id`,l(i).compact.target?.runId??``),v(z,`data-aliyah-index`,l(i).compact.target?`${l(i).compact.target.aliyahIndex}`:``),v(z,`data-playback-state`,l(i).compact.playbackState),V=F(B,1,`mobile-aliyah-play-toggle`,null,V,{"is-cue-incomplete":l(i).compact.audioState?.problem===`incomplete-cues`}),v(B,`data-audio-problem`,l(i).compact.audioState?.problem??``),v(B,`data-audio-tone`,l(_).tone),v(B,`data-audio-dimmed`,l(_).dimmed),v(B,`data-audio-tooltip`,l(u)===`loading`?`Preparing audio for this aliyah.`:l(_).tooltip),v(B,`aria-label`,e),v(B,`aria-disabled`,l(_).actionDisabled||l(u)===`loading`),a(W,l(i).compact.label),v(G,`aria-expanded`,l(o)),ce=F(J,1,`toolbar-current-aliyah-label`,null,ce,{"u-hidden":!l(i).current.labelVisible}),a(le,l(i).current.label),ue=F(Y,1,`aliyah-audio-button toolbar-current-aliyah-audio`,null,ue,t),v(Y,`data-audio-problem`,l(i).current.audioState?.problem??``),v(Y,`data-audio-tone`,l(h).tone),v(Y,`data-audio-dimmed`,l(h).dimmed),v(Y,`data-audio-tooltip`,l(h).tooltip),v(Y,`data-run-id`,l(i).current.target?.runId??``),v(Y,`data-aliyah-index`,l(i).current.target?`${l(i).current.target.aliyahIndex}`:``),v(Y,`aria-disabled`,l(h).actionDisabled),v(Y,`aria-label`,n)},[()=>R(),()=>({"u-hidden":!l(i).current.target||!l(i).current.labelVisible,"is-active":l(i).current.playing,"is-missing-audio":l(i).current.authoringAvailable,"is-cue-incomplete":O()}),()=>l(i).current.authoringAvailable?`Select ${l(i).current.label} for audio and cue recording`:l(i).current.audioAvailable?M():`Recording unavailable`]),e(`click`,B,()=>void L()),e(`click`,G,P),e(`click`,Y,I),t(n,ne),N()}I([`click`]);var Ti=4e3;function Ei({loaded:e,playing:t}){return e&&t?`playing`:e?`loaded`:`default`}function Di(e){return{none:`no cues`,pending:`partial published cues`,published:`complete published cues`,"local-draft":`local draft`,"generated-review":`generated draft needs review`}[e]}function Oi(e){return e!==`published`}function ki({label:e,status:t,playing:n=!1}){return n?`Pause ${e}`:t===`none`?`Start ${e} cue recording`:`Resume ${e} cue recording`}function Ai(e,t){let n=e.querySelector(`[data-target-id="${t}"]`);if(!n)throw Error(`Aliyah Navigation requires ${t}`);if(n.childNodes.length)throw Error(`Aliyah Navigation requires an empty ${t}`);return n}function ji(e,t){let n=e.querySelector(t);if(!n)throw Error(`Aliyah Navigation requires ${t}`);return n}function Mi(e,t){let n=Ai(t.document,`aliyah-toolbar-root`),r=Ai(t.document,`aliyah-navigation-layer-root`),a=ji(t.document,`.app-toolbar`),o=null,c=null,l=i(xi,{target:r,props:{document:t.document,signal:e.signal,toolbar:a,onSelect:t.onSelect,onPlayCompact:t.onPlayCompact,onBeforeCompactOpen:t.onBeforeCompactOpen,onAfterNavigate:t.onAfterNavigate,onWideHidden:t.onWideHidden,restoreFocus:t.restoreFocus,getReaderFocusTarget:t.getReaderFocusTarget,loadCueStatus:t.loadCueStatus,onCueStatusChange:(e,n)=>{o?.setCueStatus(e.target,n),t.onCueStatusChange(e,n)},loadDurationLabel:t.loadDurationLabel,onCueStatusError:t.onCueStatusError,onDurationError:t.onDurationError,getCompactToggle:()=>o?.getCompactToggle()??null,onCompactOpenChange:e=>{o?.setCompactOpen(e)},connect:e=>{c=e}}});S();let u=c;if(!u)throw s(l),Error(`Aliyah Navigation layer did not connect`);let d=i(wi,{target:n,props:{onToggleCompact:e=>{c?.isCompactOpen()?c.closeCompact():c?.openCompact(e)},onPlayCurrent:t.onPlayCurrent,connect:e=>{o=e}}});S();let f=o;if(!f)throw s(d),s(l),Error(`Aliyah Navigation toolbar did not connect`);return e.own(()=>{let e=s(d),t=s(l);Promise.all([e,t]).catch(e=>{console.error(`Failed to unmount Aliyah Navigation`,e)})}),{syncContent:e=>u.syncContent(e),clearContent:()=>u.clearContent(),invalidate:()=>{f.invalidateCueStatus(),u.invalidate()},setActive:e=>u.setActive(e),syncPlayback:e=>u.syncPlayback(e),syncToolbar:e=>{f.sync(e),u.setCompactAvailable(e.compact.visible)},revealWide:(e,t)=>u.revealWide(e,t),revealWideForMovement:()=>u.revealWideForMovement(),scheduleWideHide:e=>u.scheduleWideHide(e),openCompact:e=>u.openCompact(e),closeCompact:e=>u.closeCompact(e),isCompactOpen:()=>u.isCompactOpen()}}var Ni=e=>e?.dataset.annotationsOnText??e?.textContent??``;function Pi({currentLineWords:e,previousLineWords:t,verseOrdinal:n}){return _n({currentLineWords:e.map(Fi),previousLineWords:t.map(Fi),verseOrdinal:n})}var Fi=e=>({tokenKey:e.dataset.tokenKey??``,annotatedText:Ni(e)}),Ii=e=>{let t=[...e.querySelectorAll(`[data-reader-canonical="true"] .fragment .word`)];return(t.length?t:[...e.querySelectorAll(`.fragment .word`)]).filter(e=>e.dataset.annotationsOnPresent!==`false`&&!!e.dataset.tokenKey)};function Li({book:e,startLine:t,startVerseOrdinal:n}){let r=[...e.querySelectorAll(`[data-class="line"]`)],i=r.indexOf(t);if(i<0||n<0)return null;let a=r.map(Ii);return{lines:r,startLineIndex:i,startWordIndex:Pi({currentLineWords:a[i],previousLineWords:a[i-1]??[],verseOrdinal:n}),wordsByLine:a}}function Ri({book:e,startLine:t,startVerseOrdinal:n}){let r=Li({book:e,startLine:t,startVerseOrdinal:n});return r?.wordsByLine[r.startLineIndex][r.startWordIndex]?.dataset.tokenKey??null}function zi(e){let t=[...e.childNodes].find(e=>e.nodeType===Node.TEXT_NODE&&!!e.textContent),n=t?.data.match(/^.\p{Mark}*/u)?.[0];if(!t||!n)return null;let r=e.ownerDocument.createRange();r.setStart(t,0),r.setEnd(t,n.length);let i=r.getBoundingClientRect();return r.detach(),i.width>0&&i.height>0?i:null}function Bi(e,t){return{x:t.left-e.left+t.width/2,y:t.top-e.top}}function Vi({label:e,tokenKey:t}){let n=document.createElement(`button`);n.type=`button`,n.className=`aliyah-start-marker`,n.dataset.aliyahStartMarker=`true`,n.dataset.tokenKey=t,n.setAttribute(`aria-label`,`Aliyah ${e} begins here`),n.setAttribute(`aria-haspopup`,`dialog`),n.setAttribute(`aria-expanded`,`false`),n.setAttribute(`aria-controls`,`aliyah-start-popup`);let r=document.createElement(`span`);r.className=`aliyah-start-marker-rule`,r.setAttribute(`aria-hidden`,`true`);let i=document.createElement(`span`);i.className=`aliyah-start-marker-capsule`,i.textContent=e,i.setAttribute(`aria-hidden`,`true`);let a=document.createElement(`span`);return a.className=`aliyah-start-chevron`,a.innerHTML=Fe(`chevronDown`),a.setAttribute(`aria-hidden`,`true`),n.append(r,i,a),n}function Hi(e,t){let n=e?.aliyot.filter(e=>e.index)??[];return n[n.length-1]?.index===t}function Ui(e,t){return e?.aliyot.find(e=>e.index===t)??null}function Wi(e,t,n){let r=Ui(e,t);return r?n(r.start):null}async function Gi(e,t,n){let r=await e.resolver;return Wi(t,n,e=>r.physicalLocationFromRef(e))}var Ki=class{constructor(){this.locations=new Map}get size(){return this.locations.size}clear(){this.locations.clear()}async get(e,t,n){let r=t?`${t.id}:${n}`:`missing:${n}`;if(this.locations.has(r))return this.locations.get(r)??null;let i=await Gi(e,t,n);return this.locations.set(r,i),i}};function qi(e){return Math.max(0,e.lineNumber-1)}function Ji(e){return[...e.querySelectorAll(`[data-class="line"][data-page-number][data-line-index]`)]}function Yi(e,t){return e.querySelector(`[data-class="line"][data-line-index="${t}"]`)}function Xi(e,t){return{runId:e.id,index:t}}function Zi(e,t){return!!(e&&t&&e.runId===t.runId&&e.index===t.index)}function Qi(e){if(e===`Maftir`)return`Maftir`;let t=Number(e);return Number.isInteger(t)&&t>=1&&t<=7?t:null}function $i(e,t){return e.flatMap(e=>e.aliyot.flatMap(n=>n.index&&Re(n,t)?[Xi(e,n.index)]:[]))}function ea({runs:e,lineRun:t,focalRef:n,aliyot:r,aliyahStarts:i}){let a=e=>t?e.flatMap(e=>e.index?[Xi(t,e.index)]:[]):[],o=a(i);return o.length?o:n?$i(e,n):a(r)}function ta({memberships:e,playback:t,pending:n,explicit:r}){return t||n||(e.length?e.find(e=>Zi(e,r))||e[e.length-1]:null)}var na=[];function ra(e,t=na){return t.find(t=>t.audioId===e)??null}var ia=r(`<div data-target-id="floating-player" id="floating-player"><div class="floating-player-sheet-handle" aria-hidden="true"></div> <header class="floating-player-header"><button class="floating-player-drag-handle" data-target-id="floating-drag-handle" type="button" title="Drag to move the audio player" aria-label="Move audio player"><!></button> <div class="floating-player-heading"><strong class="floating-player-title mod-desktop" data-target-id="floating-player-title-desktop"> </strong> <strong class="floating-player-title mod-mobile" data-target-id="floating-player-title-mobile"> </strong> <span class="floating-player-subtitle mod-desktop" data-target-id="floating-player-subtitle"> </span> <span class="floating-player-subtitle mod-mobile" data-target-id="floating-player-parsha"> </span></div> <span class="floating-player-mode-group"><span class="floating-player-mode" data-target-id="floating-player-mode"> </span> <span data-target-id="floating-player-cue-progress"> </span></span> <button class="floating-player-button mod-expand" data-target-id="floating-expand-toggle" type="button"><!></button> <button class="floating-player-mobile-close" data-target-id="floating-mobile-close" type="button" aria-label="Close expanded player"><!></button></header> <div class="floating-player-controls"><button class="floating-player-button" data-target-id="floating-replay" type="button" title="Restart recording" aria-label="Restart recording"><span class="floating-player-tool-icon" data-target-id="floating-replay-icon"><!></span></button> <button class="floating-player-button" data-target-id="floating-prev" type="button"><!></button> <button class="floating-player-button" data-target-id="floating-play" type="button"><!></button> <button class="floating-player-minimized-summary" data-target-id="floating-minimized-summary" type="button"><strong> </strong> <span> </span></button> <button class="floating-player-button" data-target-id="floating-next" type="button"><!></button> <div class="floating-speed-control"><button class="floating-player-button mod-speed" data-target-id="floating-speed-toggle" type="button"><span class="floating-player-tool-icon" data-target-id="floating-speed-icon"><!></span> <span class="floating-player-tool-label" data-target-id="floating-speed-label"> </span> <span class="floating-player-tool-label mod-compact" data-target-id="floating-speed-compact-label" aria-hidden="true"> </span></button> <div data-target-id="floating-speed-popover"><input class="floating-speed-slider" data-target-id="floating-speed-slider" type="range" min="0.5" max="3" step="0.05" list="floating-speed-marks" aria-label="Playback speed"/> <datalist id="floating-speed-marks"><option label="0.5x"></option><option label="1x"></option><option label="1.5x"></option><option label="2x"></option><option label="3x"></option></datalist> <div class="floating-speed-ticks" aria-hidden="true"><span style="--speed-tick-position: 0%">0.5x</span> <span style="--speed-tick-position: 20%">1x</span> <span style="--speed-tick-position: 40%">1.5x</span> <span style="--speed-tick-position: 60%">2x</span> <span style="--speed-tick-position: 100%">3x</span></div></div></div></div> <div class="mobile-player-timeline"><span data-target-id="mobile-player-word-progress"> </span> <span class="mobile-player-time" data-target-id="mobile-player-current-time"> </span> <input class="mobile-player-seek" data-target-id="mobile-player-seek" type="range" min="0" max="1000" step="1" aria-label="Audio position"/> <span class="mobile-player-time" data-target-id="mobile-player-duration"> </span></div> <button class="floating-player-mobile-expand" data-target-id="floating-mobile-expand" type="button" aria-label="Expand audio player" aria-controls="floating-player"><!></button> <h3 class="floating-player-tools-heading">Playback controls</h3> <div class="floating-player-tools"><a data-target-id="floating-download" title="Save audio" aria-label="Save audio"><span class="floating-player-tool-icon" data-target-id="floating-download-icon"><!></span> <span class="floating-player-tool-label">Save</span></a> <a data-target-id="floating-video-download" title="Save aliyah video" aria-label="Save aliyah video"><span class="floating-player-tool-icon" data-target-id="floating-video-download-icon"><!></span> <span class="floating-player-tool-label">Video</span></a></div> <div class="floating-player-details" data-target-id="floating-player-details"><div class="floating-player-meta" data-target-id="floating-player-meta"><span data-target-id="floating-meta-status-wrap"><span class="floating-player-meta-label">Playback</span> <span class="floating-player-meta-value" data-target-id="floating-meta-status"> </span></span></div> <div class="floating-player-progress-list"><div class="floating-player-progress-item mod-word-progress"><div class="floating-player-progress-head"><span class="floating-player-progress-label">Word progress</span> <span class="floating-player-progress-value" data-target-id="floating-meta-cues"> </span></div></div></div></div> <span class="floating-player-minimized-progress" data-target-id="floating-minimized-progress" aria-hidden="true"></span></div> <button class="floating-player-backdrop" data-target-id="floating-player-backdrop" type="button" aria-label="Close expanded player" tabindex="-1"></button>`,1);function aa(n,r){ee(r,!0);let i=m(y({visible:!1,untimed:!0,playing:!1,expanded:!1,compact:!1,desktopTitle:`—`,mobileTitle:`—`,subtitle:`Audio`,mobileReading:`—`,mode:`No cues`,status:``,playbackRate:1,audioDownload:null,videoDownload:null})),o=m(y({audioRatio:0,cueRatio:0,seekValue:0,seekDisabled:!0,seekValueText:`0:00 of --:--`,currentTime:`0:00`,duration:`--:--`,wordProgress:`0 / 0`,cueProgress:`Cue 0 / 0`,cueProgressVisible:!1,mobileWordProgress:`Word 0 of 0`,mobileWordProgressVisible:!1})),s=m(null),f=m(!1),_=m(!1),b=m(!1),x=null,w=null,T=null,O=null,I=null,L=null,R=null,te=null,ne=null,z=null,re=null,B=null,V=g(()=>Le(l(i).playbackRate)),ie=g(()=>l(i).playing?`Pause`:`Play`),ae=g(()=>l(i).untimed?`Back 10 seconds`:`Previous Word`),oe=g(()=>l(i).untimed?`Forward 10 seconds`:`Next Word`),se=g(()=>l(i).expanded?`Collapse player`:`Expand player`);function H(e,t){if(!e)throw Error(`Floating Player is missing ${t}`);return e}function U(e){let t=e.getBoundingClientRect();return{left:t.left,top:t.top,width:t.width,height:t.height}}function W(){B!==null&&(r.view.clearTimeout(B),B=null)}function G(e){l(b)!==e&&(S(()=>{D(b,e,!0)}),r.document.documentElement.toggleAttribute(`data-mobile-player-minimized`,e))}function K(){let e=r.document.activeElement;return!!(e instanceof HTMLElement&&x?.contains(e)&&e.matches(`:focus-visible`))}function q(){return!!(l(i).visible&&l(i).compact&&!l(i).expanded&&!l(_)&&z===null&&re===null&&!K())}function J(){l(b)||B!==null||!q()||(B=r.view.setTimeout(()=>{B=null,q()&&G(!0)},4e3))}function ce(){W(),G(!1)}function le(){ce(),J()}function Y(e){ce(),e?H(I,`its play button`).focus({preventScroll:!0}):O?.blur(),J()}function ue(){W()}function de(e){let t=e.relatedTarget;t instanceof Node&&x?.contains(t)||J()}function fe(e){S(()=>{D(i,{...l(i),...e},!0)}),r.document.documentElement.toggleAttribute(`data-mobile-player-expanded`,l(i).expanded&&l(i).compact),!l(i).visible||!l(i).compact||l(i).expanded?(W(),G(!1)):J()}function pe(e){S(()=>{D(o,{...l(o),...e},!0)})}function me(e){S(()=>{D(s,e,!0)})}function he(e){S(()=>{D(f,e,!0)})}function ge(){l(_)&&(S(()=>{D(_,!1)}),J())}function _e(){H(w,`its mobile close button`).focus({preventScroll:!0})}function ve(){return U(H(x,`its player element`))}let ye={sync:fe,syncProgress:pe,setPosition:me,setDragging:he,closeSpeedPopover:ge,focusMobileClose:_e,measure:ve};function X(e){e.type!==`layout`&&!(l(b)&&e.type===`toggle-playback`)&&le(),r.action(e)}function be(e,t,n=null){X({type:`set-expanded`,expanded:e,source:t,returnFocus:n})}function xe(){ce(),S(()=>{D(_,!l(_))}),l(_)?(W(),H(te,`its speed slider`).focus({preventScroll:!0})):J()}function Se(e){let t=H(L,`its seek control`).getBoundingClientRect();return t.width<=0?null:Math.max(0,Math.min(1,(e-t.left)/t.width))}function Ce(e){l(o).seekValue=Math.round(e*1e3)}function we(e){let t=Number.parseFloat(e.currentTarget.value)/1e3;Ce(t),z===null&&X({type:`seek-commit`,ratio:t})}function Te(e){if(e.button!==0||l(o).seekDisabled||z!==null)return;let t=Se(e.clientX);if(t===null)return;e.preventDefault(),z=e.pointerId;let n=H(L,`its seek control`);n.focus({preventScroll:!0}),n.setPointerCapture(e.pointerId),Ce(t),X({type:`seek-preview`,phase:`start`,pointerId:e.pointerId,ratio:t})}function Ee(e){if(e.pointerId!==z)return;let t=Se(e.clientX);t!==null&&(Ce(t),X({type:`seek-preview`,phase:`move`,pointerId:e.pointerId,ratio:t}))}function De(e,t){if(e.pointerId!==z)return;let n=H(L,`its seek control`),r=(t?Se(e.clientX):null)??l(o).seekValue/1e3;Ce(r),X({type:`seek-finish`,pointerId:e.pointerId,ratio:r}),z=null,n.hasPointerCapture(e.pointerId)&&n.releasePointerCapture(e.pointerId)}function Oe(){if(z===null)return;let e=z;z=null,X({type:`seek-finish`,pointerId:e,ratio:l(o).seekValue/1e3})}function ke(e){let t=H(te,`its speed slider`).getBoundingClientRect();return .5+Math.max(0,Math.min(1,(e-t.left)/Math.max(t.width,1)))*2.5}function Ae(e){re===null&&X({type:`set-rate`,rate:Number.parseFloat(e.currentTarget.value),snap:!0})}function je(e){e.preventDefault(),re=e.pointerId,H(te,`its speed slider`).setPointerCapture(e.pointerId),X({type:`set-rate`,rate:ke(e.clientX),snap:!0})}function Me(e){e.pointerId===re&&X({type:`set-rate`,rate:ke(e.clientX),snap:!0})}function Ne(e,t){if(e.pointerId!==re)return;let n=H(te,`its speed slider`);t&&X({type:`set-rate`,rate:ke(e.clientX),snap:!0}),re=null,n.hasPointerCapture(e.pointerId)&&n.releasePointerCapture(e.pointerId)}function Pe(e){l(i).compact||e.button!==0||(e.preventDefault(),ne=e.pointerId,X({type:`drag-start`,pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY,playerRect:ve()}))}function Fe(e){if(l(i).compact)return;if(e.key===`Home`){e.preventDefault(),X({type:`drag-reset`});return}let t={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];t&&(e.preventDefault(),X({type:`drag-key`,direction:t,shiftKey:e.shiftKey,playerRect:ve()}))}function Ie(e){if(!l(i).compact||!l(i).expanded)return;if(e.key===`Escape`){e.preventDefault(),be(!1,`close`);return}if(e.key!==`Tab`)return;let t=[...H(x,`its player element`).querySelectorAll(`button:not(:disabled), input:not(:disabled), a[href]:not([aria-disabled="true"]), [tabindex]:not([tabindex="-1"])`)].filter(e=>e.offsetParent!==null&&!e.closest(`.u-hidden`)),n=t[0],a=t[t.length-1];!n||!a||(e.shiftKey&&r.document.activeElement===n?(e.preventDefault(),a.focus()):!e.shiftKey&&r.document.activeElement===a&&(e.preventDefault(),n.focus()))}function Le(e){return`${(Math.round(e*100)/100).toFixed(2).replace(/\.?0+$/,``)}x`}k(()=>{r.connect(ye);let e=e=>{e.pointerId===ne&&X({type:`drag-move`,pointerId:e.pointerId,clientX:e.clientX,clientY:e.clientY})},t=e=>{e.pointerId===ne&&(ne=null,X({type:`drag-finish`,pointerId:e.pointerId}))},n=()=>{ne!==null&&(ne=null,X({type:`drag-cancel`}))},i=e=>{if(!l(_))return;let t=e.target;t instanceof Node&&R?.contains(t)||ge()},a=()=>X({type:`layout`});r.view.addEventListener(`pointermove`,e),r.view.addEventListener(`pointerup`,t),r.view.addEventListener(`pointercancel`,t),r.view.addEventListener(`blur`,n),r.view.addEventListener(`resize`,a),r.document.addEventListener(`pointerdown`,i);let o=new ResizeObserver(a);return o.observe(H(x,`its player element`)),()=>{W(),o.disconnect(),r.document.removeEventListener(`pointerdown`,i),r.view.removeEventListener(`resize`,a),r.view.removeEventListener(`blur`,n),r.view.removeEventListener(`pointercancel`,t),r.view.removeEventListener(`pointerup`,t),r.view.removeEventListener(`pointermove`,e),r.document.documentElement.removeAttribute(`data-mobile-player-expanded`),r.document.documentElement.removeAttribute(`data-mobile-player-minimized`)}});var Re=ia(),Q=E(Re);let $,ze;var Be=A(j(Q),2),Ve=j(Be),He=j(Ve);Z(He,{name:`grip`}),c(Ve);var Ue=A(Ve,2),We=j(Ue),Ge=j(We,!0);c(We);var Ke=A(We,2),qe=j(Ke,!0);c(Ke);var Je=A(Ke,2),Ye=j(Je,!0);c(Je);var Xe=A(Je,2),Ze=j(Xe,!0);c(Xe),c(Ue);var Qe=A(Ue,2),$e=j(Qe),et=j($e,!0);c($e);var tt=A($e,2);let nt;var rt=j(tt,!0);c(tt),c(Qe);var it=A(Qe,2),at=j(it);{let e=g(()=>l(i).expanded?`minimize2`:`expand`);Z(at,{get name(){return l(e)}})}c(it);var ot=A(it,2),st=j(ot);Z(st,{name:`x`}),c(ot),p(ot,e=>w=e,()=>w),c(Be);var ct=A(Be,2),lt=j(ct),ut=j(lt),dt=j(ut);Z(dt,{name:`replay`}),c(ut),c(lt);var ft=A(lt,2),pt=j(ft);{let e=g(()=>l(i).untimed?`rewind10`:`arrowRight`);Z(pt,{get name(){return l(e)}})}c(ft);var mt=A(ft,2),ht=j(mt);{let e=g(()=>l(i).playing?`pause`:`play`);Z(ht,{get name(){return l(e)}})}c(mt),p(mt,e=>I=e,()=>I);var gt=A(mt,2),_t=j(gt),vt=j(_t,!0);c(_t);var yt=A(_t,2),bt=j(yt,!0);c(yt),c(gt),p(gt,e=>O=e,()=>O);var xt=A(gt,2),St=j(xt);{let e=g(()=>l(i).untimed?`forward10`:`arrowLeft`);Z(St,{get name(){return l(e)}})}c(xt);var Ct=A(xt,2),wt=j(Ct),Tt=j(wt),Et=j(Tt);Z(Et,{name:`gauge`}),c(Tt);var Dt=A(Tt,2),Ot=j(Dt);c(Dt);var kt=A(Dt,2),At=j(kt,!0);c(kt),c(wt);var jt=A(wt,2);let Mt;var Nt=j(jt);h(Nt),p(Nt,e=>te=e,()=>te);var Pt=A(Nt,2),Ft=j(Pt);Ft.value=Ft.__value=`0.5`;var It=A(Ft);It.value=It.__value=`1`;var Lt=A(It);Lt.value=Lt.__value=`1.5`;var Rt=A(Lt);Rt.value=Rt.__value=`2`;var zt=A(Rt);zt.value=zt.__value=`3`,c(Pt),P(2),c(jt),c(Ct),p(Ct,e=>R=e,()=>R),c(ct);var Bt=A(ct,2),Vt=j(Bt);let Ht;var Ut=j(Vt,!0);c(Vt);var Wt=A(Vt,2),Gt=j(Wt,!0);c(Wt);var Kt=A(Wt,2);h(Kt),p(Kt,e=>L=e,()=>L);var qt=A(Kt,2),Jt=j(qt,!0);c(qt),c(Bt);var Yt=A(Bt,2),Xt=j(Yt);Z(Xt,{name:`chevronUp`}),c(Yt),p(Yt,e=>T=e,()=>T);var Zt=A(Yt,4),Qt=j(Zt);let $t;var en=j(Qt),tn=j(en);Z(tn,{name:`download`}),c(en),P(2),c(Qt);var nn=A(Qt,2);let rn;var an=j(nn),on=j(an);Z(on,{name:`download`}),c(an),P(2),c(nn),c(Zt);var sn=A(Zt,2),cn=j(sn),ln=j(cn);let un;var dn=A(j(ln),2),fn=j(dn,!0);c(dn),c(ln),c(cn);var pn=A(cn,2),mn=j(pn),hn=j(mn),gn=A(j(hn),2),_n=j(gn,!0);c(gn),c(hn),c(mn),c(pn),c(sn),P(2),c(Q),p(Q,e=>x=e,()=>x);var vn=A(Q,2);d(()=>{$=F(Q,1,`floating-player`,null,$,{"u-hidden":!l(i).visible,"mod-untimed":l(i).untimed,"is-playing":l(i).playing,"is-expanded":l(i).expanded,"is-minimized":l(b),"mod-expandable":l(i).visible,"is-dragging":l(f)}),v(Q,`data-cue-mode`,l(i).untimed?`untimed`:`timed`),v(Q,`role`,l(i).expanded&&l(i).compact?`dialog`:`region`),v(Q,`aria-modal`,l(i).expanded&&l(i).compact?`true`:void 0),v(Q,`aria-label`,l(i).expanded&&l(i).compact?`Expanded audio player`:l(b)?`Compact audio player`:`Audio player`),ze=M(Q,``,ze,{"--audio-progress-ratio":`${l(o).audioRatio}`,"--cue-progress-ratio":`${l(o).cueRatio}`,left:l(s)?`${l(s).left}px`:void 0,top:l(s)?`${l(s).top}px`:void 0}),a(Ge,l(i).desktopTitle),a(qe,l(i).mobileTitle),a(Ye,l(i).subtitle),a(Ze,l(i).mobileReading),a(et,l(i).mode),nt=F(tt,1,`floating-player-cue-progress`,null,nt,{"u-hidden":!l(o).cueProgressVisible}),a(rt,l(o).cueProgress),v(it,`title`,l(se)),v(it,`aria-label`,l(se)),v(it,`aria-expanded`,l(i).expanded),it.disabled=!l(i).visible,lt.disabled=!l(i).visible,v(ft,`title`,l(ae)),v(ft,`aria-label`,l(ae)),ft.disabled=!l(i).visible,v(mt,`data-audio-tooltip`,l(i).status||`${l(ie)} this aliyah`),v(mt,`aria-label`,l(ie)),mt.disabled=!l(i).visible,v(gt,`aria-label`,`Show audio controls for ${l(i).mobileTitle}`),v(gt,`aria-hidden`,!l(b)),v(gt,`tabindex`,l(b)?0:-1),a(vt,l(i).mobileTitle),a(bt,l(i).mobileReading),v(xt,`title`,l(oe)),v(xt,`aria-label`,l(oe)),xt.disabled=!l(i).visible,v(wt,`title`,`Playback speed, ${l(V)}`),v(wt,`aria-label`,`Playback speed, ${l(V)}`),v(wt,`aria-expanded`,l(_)),a(Ot,`${l(V)??``} speed`),a(At,l(V)),Mt=F(jt,1,`floating-speed-popover`,null,Mt,{"u-hidden":!l(_)}),C(Nt,l(i).playbackRate),Ht=F(Vt,1,`mobile-player-word-progress`,null,Ht,{"u-hidden":!l(o).mobileWordProgressVisible}),a(Ut,l(o).mobileWordProgress),a(Gt,l(o).currentTime),C(Kt,l(o).seekValue),Kt.disabled=l(o).seekDisabled,v(Kt,`aria-valuetext`,l(o).seekValueText),a(Jt,l(o).duration),v(Yt,`aria-expanded`,l(i).expanded),Yt.disabled=!l(i).visible,$t=F(Qt,1,`floating-player-button mod-tool mod-save`,null,$t,{"u-hidden":!l(i).audioDownload}),v(Qt,`href`,l(i).audioDownload?.href??`#`),v(Qt,`download`,l(i).audioDownload?.fileName),v(Qt,`aria-disabled`,l(i).audioDownload?`false`:`true`),v(Qt,`tabindex`,l(i).audioDownload?0:-1),rn=F(nn,1,`floating-player-button mod-tool mod-video`,null,rn,{"u-hidden":!l(i).videoDownload}),v(nn,`href`,l(i).videoDownload?.href??`#`),v(nn,`download`,l(i).videoDownload?.fileName),v(nn,`aria-disabled`,l(i).videoDownload?`false`:`true`),v(nn,`tabindex`,l(i).videoDownload?0:-1),un=F(ln,1,`floating-player-meta-item`,null,un,{"u-hidden":!l(i).status}),a(fn,l(i).status),a(_n,l(o).wordProgress),v(vn,`aria-hidden`,!l(i).expanded||!l(i).compact)}),e(`keydown`,Q,Ie),e(`focusin`,Q,ue),e(`focusout`,Q,de),e(`pointerdown`,Ve,Pe),e(`dblclick`,Ve,()=>X({type:`drag-reset`})),e(`keydown`,Ve,Fe),e(`click`,it,()=>be(!l(i).expanded,`desktop`,r.document.activeElement)),e(`click`,ot,()=>be(!1,`close`)),e(`click`,lt,()=>X({type:`restart`})),e(`click`,ft,()=>X({type:`step`,delta:-1})),e(`click`,mt,()=>X({type:`toggle-playback`})),e(`click`,gt,e=>Y(e.detail===0)),e(`click`,xt,()=>X({type:`step`,delta:1})),e(`click`,wt,xe),e(`input`,Nt,Ae),e(`pointerdown`,Nt,je),e(`pointermove`,Nt,Me),e(`pointerup`,Nt,e=>Ne(e,!0)),u(`pointercancel`,Nt,e=>Ne(e,!1)),e(`change`,Nt,Ae),e(`input`,Kt,we),e(`pointerdown`,Kt,Te),e(`pointermove`,Kt,Ee),e(`pointerup`,Kt,e=>De(e,!0)),u(`pointercancel`,Kt,e=>De(e,!1)),u(`lostpointercapture`,Kt,Oe),e(`click`,Yt,()=>be(!0,`mobile`,H(T,`its mobile expand button`))),e(`click`,vn,()=>be(!1,`close`)),t(n,Re),N()}I([`keydown`,`focusin`,`focusout`,`pointerdown`,`dblclick`,`click`,`input`,`pointermove`,`pointerup`,`change`]);function oa(e,t){let n=t.document.querySelector(`[data-target-id="floating-player-root"]`);if(!n)throw Error(`Floating Player requires its mount root`);if(n.childNodes.length)throw Error(`Floating Player requires an empty mount root`);let r=null,a=i(aa,{target:n,props:{document:t.document,view:t.view,action:t.action,connect:e=>{r=e}}});S();let o=r;if(!o)throw s(a),Error(`Floating Player did not connect its interface`);return e.own(()=>{s(a).catch(e=>{console.error(`Failed to unmount Floating Player`,e)})}),o}var sa=`is-active-word`,ca=400,la=.5,ua=class{constructor(e){this.book=e,this.activeTokenKey=null,this.activeSequenceIndex=-1,this.activeElements=[],this.pendingActivation=null,this.pendingTokenKey=null,this.activationGeneration=0,this.sequence=[],this.sequenceIndexByTokenKey=new Map,this.display=null,this.tokenElementsByKey=new Map,this.activeTokenListeners=new Set}setDisplay(e){this.clear(),this.tokenElementsByKey.clear(),this.display=e}setSequence(e){this.sequence=e,this.sequenceIndexByTokenKey=new Map(e.map((e,t)=>[e,t])),this.activeSequenceIndex=this.activeTokenKey?this.sequenceIndexByTokenKey.get(this.activeTokenKey)??-1:-1}getSequence(){return[...this.sequence]}getActiveTokenKey(){return this.activeTokenKey}getActiveIndex(){return this.activeSequenceIndex}onActiveTokenChanged(e){return this.activeTokenListeners.add(e),()=>this.activeTokenListeners.delete(e)}clear(){this.activationGeneration+=1;let e=this.activeTokenKey!==null;this.activeElements.forEach(e=>e.classList.remove(sa)),this.activeElements=[],this.activeTokenKey=null,this.activeSequenceIndex=-1,this.pendingActivation=null,this.pendingTokenKey=null,e&&this.emitActiveTokenChanged(null)}async activateCue(e,t){let n=X(e);if(this.activeTokenKey===n)return this.getVisibleTokenElement(n)??this.getPrimaryTokenElement(n);if(this.pendingTokenKey===n&&this.pendingActivation)return this.pendingActivation;let r=++this.activationGeneration,i=this.display,a=(async()=>(await i?.ensurePageMounted(e.pageNumber),r!==this.activationGeneration||i!==this.display?null:this.applyTokenKey(n,t,r)))();return this.pendingTokenKey=n,this.pendingActivation=a,a.finally(()=>{this.pendingActivation===a&&(this.pendingTokenKey=null,this.pendingActivation=null)})}async activateTokenKey(e,{scroll:t=!0,scrollBehavior:n=`smooth`}={}){let r=++this.activationGeneration;return this.applyTokenKey(e,{scroll:t,scrollBehavior:n},r)}applyTokenKey(e,{scroll:t=!0,scrollBehavior:n=`smooth`}={},r=this.activationGeneration){if(r!==this.activationGeneration)return null;if(this.activeTokenKey===e)return this.getPrimaryTokenElement(e);this.activeElements.forEach(e=>e.classList.remove(sa));let i=this.getTokenElements(e);i.forEach(e=>e.classList.add(sa)),this.activeElements=i,this.activeTokenKey=e,this.activeSequenceIndex=this.sequenceIndexByTokenKey.get(e)??-1,this.emitActiveTokenChanged(e);let a=t?this.getVisibleTokenElement(e)??i[0]??null:i[0]??null;return a&&t&&this.scrollTokenIntoView(a,n),a}step(e,t){let n=this.getActiveIndex(),r=n<0?0:n+e;return r<0||r>=this.sequence.length?null:this.activateTokenKey(this.sequence[r],t)}getCueIndex(e,t){let n=0,r=e.length-1,i=-1;for(;n<=r;){let a=Math.floor((n+r)/2);t>=e[a].timeStart?(i=a,n=a+1):r=a-1}return i}getTokenKeyFromElement(e){return e.dataset.tokenKey??null}getTokenElements(e){let t=this.tokenElementsByKey.get(e);if(t){let n=t.filter(e=>e.isConnected);if(n.length)return this.rememberTokenElements(e,n),n;this.tokenElementsByKey.delete(e)}let n=[...this.book.querySelectorAll(`[data-token-key="${e}"]`)];return this.rememberTokenElements(e,n),n}getPrimaryTokenElement(e){return this.getTokenElements(e)[0]??null}getVisibleTokenElement(e){let t=this.book.getBoundingClientRect();return this.getTokenElements(e).find(e=>{let n=e.getBoundingClientRect();return n.width>0&&n.height>0&&n.top<t.bottom&&n.bottom>t.top})}scrollTokenIntoView(e,t){gr(this.book,e,{behavior:t,minimumScrollDistance:la})}rememberTokenElements(e,t){this.tokenElementsByKey.delete(e),this.tokenElementsByKey.set(e,t),this.pruneTokenElementCache()}pruneTokenElementCache(){for(;this.tokenElementsByKey.size>ca;){let e=this.tokenElementsByKey.keys().next().value;if(!e)return;if(e===this.activeTokenKey){let t=this.tokenElementsByKey.get(e);this.tokenElementsByKey.delete(e),t&&this.tokenElementsByKey.set(e,t);continue}this.tokenElementsByKey.delete(e)}}emitActiveTokenChanged(e){for(let t of this.activeTokenListeners)t(e)}};function da(e){return X(e)}var fa=.5,pa=3,ma=.09,ha=[.5,1,1.5,2,3],ga=10,_a=8,va=56;function ya(e){if(!Number.isFinite(e))return`--:--`;if(e<0)return`0:00`;let t=Math.floor(e),n=Math.floor(t/3600),r=Math.floor(t%3600/60),i=t%60;return n>0?`${n}:${String(r).padStart(2,`0`)}:${String(i).padStart(2,`0`)}`:`${r}:${String(i).padStart(2,`0`)}`}function ba(e,t){let n=e?.cues[t],r=e?.passage?n?e.tokenKeys.indexOf(da(n)):-1:t;return Nt({cueIndex:r,cueCount:e?.passage&&r<0?0:e?.cues.length??0,tokenCount:e?.tokenKeys.length??0})}function xa(e,t){let{audioController:n,highlightController:r,document:i,view:a}=t,o=()=>{throw Error(`Floating Player action arrived before playback was ready`)},s=oa(e,{document:i,view:a,action:e=>o(e)}),c=i.querySelector(`.reader-corner-controls`),l=null,u=!1,d=null,f=null,p=!1,m=null,h=null,g=0,_=t=>{g&&a.cancelAnimationFrame(g),g=a.requestAnimationFrame(()=>{g=0,e.signal.aborted||t()})},v=()=>{s.closeSpeedPopover()},y=()=>p&&m!==null?m:n.currentTime,b=()=>{let{duration:e}=n;return n.session&&Number.isFinite(e)&&e>0?Math.max(0,Math.min(1,y()/e)):0},x=(e,t)=>{let n=-1;for(let r=0;r<e.cues.length&&e.cues[r].timeStart<=t;r+=1)n=r;return n},S=(e=b())=>{let t=y(),{duration:r}=n;s.syncProgress({audioRatio:e,...p?{}:{seekValue:Math.round(e*1e3)},seekDisabled:!n.session||!Number.isFinite(r),seekValueText:`${ya(t)} of ${ya(r)}`,currentTime:ya(t),duration:ya(r)})},C=(e=n.session?x(n.session,y()):-1)=>{let t=n.session,r=ba(t,e),i=Pt({cueIndex:e,cueCount:t?.cues.length??0});s.syncProgress({cueRatio:r.ratio,wordProgress:r.label,cueProgress:i.label,cueProgressVisible:i.total>0,mobileWordProgress:`Word ${r.current} of ${r.total}`,mobileWordProgressVisible:!!t?.cues.length&&r.total>0})},w=()=>{S(),C(),t.onChange({type:`aliyah-playback`})},T=e=>e===`Maftir`?ci(7):e>1?ci(e-1):`previous aliyah`,E=()=>{let e=n.session;if(!e){s.sync({desktopTitle:`—`,mobileTitle:`—`,subtitle:`Audio`,mobileReading:`—`,mode:`No cues`,status:``}),s.syncProgress({wordProgress:`0 / 0`});return}let t=ba(e,x(e,y())),r=n.error?`Recording unavailable`:{"current-only":``,"previous-opening":`Opening from ${T(e.aliyahIndex)}`,"partial-start":`Starts at first available cue`,"overlap-only":`Partial: shared opening only`,passage:e.passage?.cueComplete?``:`Audio available; word highlighting incomplete`,"partial-passage":`Available portion: ${e.passage?Sn(e.passage.range):``}${e.passage?.cueComplete?``:` · Word highlighting incomplete`}`}[e.status],i=e.readingLabel??e.recording.reading.name,a=ci(e.aliyahIndex);s.sync({desktopTitle:`${i} · ${a}${e.status===`partial-passage`?` · available portion`:``}`,mobileTitle:`${a}${e.status===`partial-passage`?` · available portion`:``}`,subtitle:`Audio`,mobileReading:i,mode:e.cues.length?`Word cues`:`No cues`,status:r}),s.syncProgress({wordProgress:t.label})},D=e=>{let n=t.getPlaybackRate();return Number.isFinite(e)?Math.max(fa,Math.min(pa,e)):n},O=(e,t=ma)=>{let n=D(e),r=ha.reduce((e,t)=>Math.abs(t-n)<Math.abs(e-n)?t:e);return Math.abs(r-n)<=t?r:n},k=()=>{let e=D(t.getPlaybackRate());s.sync({playbackRate:e}),n.playbackRate=e},A=(e,r=!1)=>{let i=r?O(e):D(e);t.onPlaybackRateChange(i),n.playbackRate=i,k()},j=(e,{returnFocus:r,restoreFocus:a=!0}={})=>{let o=t.viewport.isCompact(),c=u,l=e&&!!n.session;if(l&&o&&!c){let e=i.activeElement instanceof HTMLElement&&i.activeElement!==i.body?i.activeElement:null;d=r??e}if(u=l,!l&&c&&!o&&f?.(),s.sync({expanded:l,compact:o}),l&&o&&!c){_(()=>s.focusMobileClose());return}if(!l&&c){v();let e=a?d:null;d=null,e&&_(()=>t.restoreFocus(e))}},M=(e=`all`)=>{if(e===`progress`){w(),E();return}let r=n.session,i=r&&!r.passage?ra(r.recording.id):null,a=!!(r&&r.status!==`overlap-only`&&(!r.passage||r.segments.length===1&&r.segments[0].startTime===0&&r.segments[0].endTime===null)),o=!!r?.cues.length,l=n.paused;r||j(!1,{restoreFocus:!1}),c?.classList.toggle(`mod-raised`,!!r),s.sync({visible:!!r,untimed:!!(r&&!o),playing:!!(r&&!l),compact:t.viewport.isCompact(),audioDownload:r&&a?{href:r.recording.downloadSrc,fileName:`${r.recording.id}.${r.recording.format}`}:null,videoDownload:i?{href:i.downloadSrc,fileName:`${i.audioId}_${i.quality}.mp4`}:null}),k(),w(),E(),t.onChange({type:`reader-chrome`})},N=async(e={})=>{let i=n.session;if(!i)return;let a=e.scroll??t.getAutoScroll();if(i.passage){let t=e.currentTime??n.currentTime,a=r.getCueIndex(i.cues,t),o=i.cues[a],s=i.segments.find(e=>t>=e.logicalStart&&t<e.logicalEnd);if(!o||!s||!s.tokenKeys.includes(da(o))||o.timeEnd!==void 0&&t>=o.timeEnd){r.clear();return}}if(i.cues.length){let t=r.getCueIndex(i.cues,e.currentTime??n.currentTime);t>=0&&(l=t,await r.activateCue(i.cues[t],{scroll:a,scrollBehavior:e.scrollBehavior}));return}!r.getActiveTokenKey()&&i.tokenKeys[0]&&await r.activateTokenKey(i.tokenKeys[0],{scroll:a,scrollBehavior:e.scrollBehavior})},P=e=>{let i=n.session;if(i){if(i.cues.length){let a=l??r.getCueIndex(i.cues,n.currentTime),o=i.cues[Math.max(0,a+e)];if(!o)return;l=i.cues.indexOf(o),n.seek(o.timeStart),r.activateCue(o,{scroll:t.getAutoScroll()});return}n.seek(n.currentTime+e*ga),M(`progress`)}},F=async e=>{if(!n.paused){n.pause(),M();return}await t.attemptPlayback(e)&&M()},ee=async(e=!0)=>{let i=n.session;if(!i)return;let a=e?t.attemptReplayFromStart(()=>ee(e)):null;i.cues.length&&(!i.passage||i.cues[0].timeStart===0)?(l=0,await r.activateCue(i.cues[0],{scroll:!0})):i.tokenKeys[0]&&await r.activateTokenKey(i.tokenKeys[0],{scroll:!0}),a&&await a},I=async e=>{switch(e.type){case`toggle`:await F(e.retry);return;case`step`:P(e.delta);return;case`set-rate`:A(e.rate,e.snap);return;case`set-cue-index`:l=e.index}},L=()=>{u&&t.viewport.isCompact()||t.focusReader()},R=e=>{let{duration:t}=n;return!n.session||!Number.isFinite(t)||t<=0?null:Math.max(0,Math.min(1,e))*t},te=e=>{let t=R(e);t!==null&&(m=t,M(`progress`),N({currentTime:t,scrollBehavior:`auto`}))},ne=e=>{let t=R(e);return t!==null&&(n.seek(t),M(`progress`),N({currentTime:t}),!0)},z=()=>{if(!p)return;let e=m;p=!1,m=null,h=null,e!==null&&(n.seek(e),M(`progress`),N({currentTime:e}),t.saveReadingPosition())},re=()=>{let n=null,r=null,i=null,o=()=>{s.setPosition(null)},c=(e,t)=>{let r=s.measure(),i=Math.max(_a,a.innerWidth-r.width-_a),o=Math.max(_a,a.innerHeight-r.height-_a);n={left:Math.max(_a,Math.min(e,i)),top:Math.max(_a,Math.min(t,o))},s.setPosition(n)},l=()=>{if(t.viewport.isCompact()){o();return}n&&c(n.left,n.top)},u=()=>{n=null,o()};return f=u,e.own(t.viewport.onChange(l)),e.own(()=>{i=null,s.setDragging(!1),o(),f===u&&(f=null)}),e=>{switch(e.type){case`drag-start`:{if(t.viewport.isCompact())return;let a=e.playerRect;!r&&!n&&(r={left:a.left,top:a.top}),i={pointerId:e.pointerId,pointerX:e.clientX,pointerY:e.clientY,playerLeft:a.left,playerTop:a.top},s.setDragging(!0);return}case`drag-move`:if(!i||i.pointerId!==e.pointerId)return;c(i.playerLeft+e.clientX-i.pointerX,i.playerTop+e.clientY-i.pointerY);return;case`drag-finish`:if(!i||i.pointerId!==e.pointerId)return;i=null,s.setDragging(!1),n&&r&&Math.hypot(n.left-r.left,n.top-r.top)<=va&&u();return;case`drag-cancel`:i=null,s.setDragging(!1);return;case`drag-reset`:u();return;case`drag-key`:{if(t.viewport.isCompact())return;let i=e.playerRect;!r&&!n&&(r={left:i.left,top:i.top});let a=e.shiftKey?40:12;c(i.left+e.direction[0]*a,i.top+e.direction[1]*a);return}case`layout`:l()}}},B=()=>{e.own(t.viewport.onChange(()=>{j(!1,{restoreFocus:!1})}))},V=re();return B(),o=e=>{switch(e.type){case`toggle-playback`:(async()=>{await F(async()=>{await t.attemptPlayback()}),t.saveReadingPosition(),L()})();return;case`step`:P(e.delta),t.saveReadingPosition(),L();return;case`restart`:(async()=>{await ee(),t.saveReadingPosition(),L()})();return;case`seek-commit`:!p&&ne(e.ratio)&&t.saveReadingPosition();return;case`seek-preview`:if(e.phase===`start`){if(h!==null)return;p=!0,h=e.pointerId}if(e.pointerId!==h)return;te(e.ratio);return;case`seek-finish`:if(e.pointerId!==h)return;te(e.ratio),z();return;case`set-rate`:A(e.rate,e.snap);return;case`set-expanded`:if(!n.session&&e.expanded||e.source===`desktop`&&t.viewport.isCompact()||e.source===`mobile`&&!t.viewport.isCompact())return;j(e.expanded,{returnFocus:e.returnFocus});return;case`drag-start`:case`drag-move`:case`drag-finish`:case`drag-cancel`:case`drag-reset`:case`drag-key`:case`layout`:V(e)}},e.own(n.on(`playback-updated`,()=>{M()})),e.own(n.on(`session-loaded`,e=>{l=e.cues.length?0:null,r.setSequence(e.tokenKeys),t.onChange({type:`session-loaded`,session:e}),M()})),e.own(n.on(`segment-updated`,()=>{t.onChange({type:`segment-updated`}),M()})),e.own(n.on(`time-updated`,()=>{M(`progress`)})),e.own(n.on(`duration-updated`,()=>{M(`progress`)})),e.own(n.on(`playback-error`,({error:e,recording:n})=>{t.onChange({type:`playback-error`,error:e,recording:n}),M()})),e.own(n.on(`frame-updated`,({currentTime:e})=>{if(S(),t.isCueAuthoringRecording()||p)return;let i=n.session;if(i?.passage){N({currentTime:e}),C();return}if(!i?.cues.length)return;let a=r.getCueIndex(i.cues,e);if(a<0)return;l=a;let o=i.cues[a];C(a),r.getActiveTokenKey()!==X(o)&&r.activateCue(o,{scroll:t.getAutoScroll()})})),e.own(n.on(`metadata-updated`,()=>M(`progress`))),e.own(()=>{g&&a.cancelAnimationFrame(g),g=0,p=!1,m=null,h=null,u=!1,d=null,v(),s.sync({expanded:!1,compact:!1}),s.setDragging(!1),i.documentElement.removeAttribute(`data-mobile-player-expanded`)}),M(),{get displayTime(){return y()},command:I,refresh:M,syncHighlight:N,closeOverlay(){return u?(j(!1),!0):(v(),!1)}}}var Sa=class{constructor(){this.current=0}start(){return this.current+=1,this.current}isCurrent(e){return e===this.current}cancel(){this.current+=1}};function Ca(e){return e===`ready`||e===`audio-only`}var wa=e=>e instanceof Error?e.message:`Download operation failed.`;function Ta({assets:e,backend:t,intent:n,dependencies:r,inUse:i=()=>!1}){let a=new Map;for(let t of e){let e=dt(t);a.has(e)||a.set(e,Object.freeze({key:e,asset:Object.freeze({...t}),phase:`idle`,downloadedBytes:0,error:null,readiness:`unchecked`}))}let o=new Map,s=`idle`,c=null,l=null,u=[],d=!1,f=!1,p=0,m=null,h=Promise.resolve(),g=new Map,_=new Map,v=new Map,y=async e=>{let t=[_.get(e),v.get(e)];_.delete(e),v.delete(e);for(let e of t)try{await e?.()}catch(e){l=wa(e),console.error(`Download reservation cleanup failed`,e),C()}},b=new Set,x=new AbortController,S=()=>Object.freeze({supported:t.supported,location:t.location??`browser`,phase:s,entries:Object.freeze([...a.values()]),inventory:Object.freeze([...o.values()]),error:c,persistenceError:l,unavailableIntent:Object.freeze([...u])}),C=()=>{f||b.forEach(e=>e(S()))},w=(e,t)=>{let n=a.get(e);n&&a.set(e,Object.freeze({...n,...t})),C()},T=async(e,t)=>{try{await n.update(e,t),l=null}catch(e){throw l=wa(e),C(),e}},E=e=>{let t=h.then(async()=>{if(f)throw Error(`Download library was destroyed.`);await e()});return h=t.catch(()=>{}),t},D=e=>[...new Set(e)].map(e=>{let t=a.get(e);if(!t)throw Error(`Recording is not in the current download catalog.`);return t}),O=()=>{if(f)return Promise.reject(Error(`Download library was destroyed.`));if(m)return m;let e=p;s=`checking`,c=null,C();let i=(async()=>{try{let i=d?null:await n.read(),c=await t.inventory(),l=new Map;if(r)for(let e of c){let t=dt(e);if(!g.has(t))try{l.set(t,{readiness:await r.check({...e,title:a.get(t)?.asset.title??e.audioId}),error:null})}catch(e){l.set(t,{readiness:`error`,error:wa(e)})}}if(f)return;if(e===p){o=new Map(c.map(e=>[dt(e),Object.freeze({...e})]));for(let[e,t]of o)a.has(e)||a.set(e,Object.freeze({key:e,asset:Object.freeze({...t,title:t.audioId}),phase:`stored`,downloadedBytes:t.byteLength,error:null,readiness:`unchecked`}));for(let[e,t]of a)if(!(g.has(e)||[`queued`,`removing`,`removal-pending`].includes(t.phase))){if(o.has(e)){let n=l.get(e)??{readiness:`unchecked`,error:null};w(e,{...n,phase:n.readiness===`error`?`error`:n.readiness===`missing`?`paused`:`stored`,downloadedBytes:t.asset.byteLength})}else t.phase===`stored`&&w(e,{phase:`idle`,downloadedBytes:0,readiness:`unchecked`})}}if(i){u=i.filter(e=>!a.has(e));for(let e of i)a.has(e)&&!o.has(e)&&w(e,{phase:`paused`})}d=!0,s=`ready`}catch(e){throw s=`error`,c=wa(e),e}finally{C()}})().finally(()=>{m===i&&(m=null)});return m=i,i},k=()=>{if(!f)for(let[e,n]of a){if(g.size>=2)break;if(n.phase!==`queued`)continue;let i=new AbortController,s=Promise.resolve().then(async()=>{w(e,{phase:r?`verifying`:`downloading`,downloadedBytes:o.get(e)?.byteLength??0,error:null});try{let a=r?await r.prepare(n.asset,i.signal):`unchecked`;i.signal.throwIfAborted(),w(e,{readiness:a});let s=o.get(e)??await t.download(n.asset,i.signal,t=>{if(!(i.signal.aborted||f)){if(!Number.isSafeInteger(t)||t<0||t>n.asset.byteLength)throw Error(`Invalid download progress.`);w(e,{phase:t===n.asset.byteLength?`verifying`:`downloading`,downloadedBytes:t})}});if(dt(s)!==e)throw Error(`Stored recording identity does not match the request.`);o.set(e,Object.freeze({...s})),p+=1,w(e,{phase:`stored`,downloadedBytes:s.byteLength,error:null}),await T([],[e])}catch(t){a.get(e)?.phase!==`stored`&&w(e,{phase:i.signal.aborted?`paused`:`error`,error:i.signal.aborted?null:wa(t),downloadedBytes:o.get(e)?.byteLength??0,readiness:i.signal.aborted?`unchecked`:`error`})}}).finally(async()=>{await y(e),g.delete(e),C(),k()});g.set(e,{controller:i,done:s}),w(e,{phase:`downloading`})}},A=async e=>{let n=a.get(e);if(i(n.asset)){w(e,{phase:`removal-pending`});return}w(e,{phase:`removing`,error:null});try{await t.remove(n.asset),o.delete(e),p+=1,w(e,{phase:`idle`,downloadedBytes:0,readiness:`unchecked`}),await T([],[e])}catch(t){throw w(e,{phase:`error`,error:wa(t)}),t}};return{snapshot:S,subscribe(e){return b.add(e),e(S()),()=>{b.delete(e)}},refresh:O,enqueue:e=>E(async()=>{d||await O(),await Promise.all(D(e).filter(e=>[`stored`,`paused`,`error`].includes(e.phase)).map(e=>g.get(e.key)?.done));let n=D(e).filter(e=>(!o.has(e.key)||r&&!Ca(e.readiness))&&!g.has(e.key)&&e.phase!==`queued`&&e.phase!==`removal-pending`);if(n.length){try{if(t.preflight||r?.preflight||r?.reserve){let e=new Map([...a.values()].filter(e=>g.has(e.key)||e.phase===`queued`).map(e=>[e.key,e]));for(let t of n)e.set(t.key,t);let i=[...e.values()].map(e=>e.asset);if(r?.reserve){let e=await r.reserve(i,x.signal),t=n.length;for(let r of n)v.set(r.key,async()=>{--t===0&&await e()})}else await r?.preflight?.(i,x.signal);let s=[...e.values()].filter(e=>!o.has(e.key)).map(e=>e.asset);s.length&&await t.preflight?.(s)}if(f)throw Error(`Download library was destroyed.`);if(t.protectQueued)for(let e of n)_.set(e.key,await t.protectQueued(e.asset,x.signal));if(f||(await T(n.map(e=>e.key),[]),f))throw Error(`Download library was destroyed.`)}catch(e){throw await Promise.all(n.map(e=>y(e.key))),e}for(let e of n)w(e.key,{phase:`queued`,error:null});k()}}),cancel:e=>E(async()=>{let t=D(e);for(let e of t)e.phase===`queued`&&w(e.key,{phase:`paused`}),g.get(e.key)?.controller.abort();await Promise.all(t.map(e=>g.get(e.key)?.done)),await Promise.all(t.map(e=>y(e.key))),await O()}),remove:e=>E(async()=>{d||await O();let t=D(e);for(let e of t)e.phase===`queued`&&w(e.key,{phase:`paused`}),g.get(e.key)?.controller.abort();await Promise.all(t.map(e=>g.get(e.key)?.done)),await Promise.all(t.map(e=>y(e.key)));let n=[];for(let e of t)try{await A(e.key)}catch(e){n.push(e)}if(n.length)throw AggregateError(n,`Some recording downloads could not be removed.`)}),releasePlayback:()=>E(async()=>{for(let[e,t]of a)t.phase===`removal-pending`&&!i(t.asset)&&await A(e)}),destroy(){if(!f){f=!0,x.abort(),b.clear();for(let e of g.values())e.controller.abort();Promise.allSettled([h,...[...g.values()].map(({done:e})=>e)]).then(()=>Promise.all([...new Set([..._.keys(),...v.keys()])].map(y))).then(()=>{r?.destroy?.(),t.destroy()})}}}}var Ea=`tikkun.download-intent`;function Da(e,t){let n=G({storage:e,key:Ea,validate:e=>Array.isArray(e)&&e.every(e=>typeof e==`string`&&e.length>0)&&new Set(e).size===e.length}),r=()=>{let e=n.read();if(e.status===`unavailable`)throw e.error;if(e.status===`invalid`)throw Error(`Saved download queue is invalid; existing data was not overwritten.`);return{keys:e.status===`ready`?e.value:[],revision:e.revision}};return{read:async()=>r().keys,async update(e,i){if(!t)throw Error(`Persistent download queue coordination is unavailable in this browser.`);await t.request(Ea,()=>{let t=r(),a=new Set(t.keys);i.forEach(e=>a.delete(e)),e.forEach(e=>a.add(e)),K(n.write([...a],t.revision))})}}}var Oa;function ka(){return Oa??=z(`TikkunMedia`)}function Aa(e=ka()){let t=!1;return{supported:!0,location:`device`,preflight:t=>e.preflight({assets:t}),async inventory(){let t=await e.inventory();if(!t||typeof t!=`object`||!(`recordings`in t))throw Error(`Invalid native media inventory.`);return lt({type:`RECORDING_LIBRARY`,state:`ready`,recordings:t.recordings})},async download(n,r,i){if(r.throwIfAborted(),t)throw Error(`Native media storage was destroyed.`);let a=crypto.randomUUID(),o,s,c=()=>{s??=e.cancelDownload({requestId:a}).catch(e=>{o=e})},l=await e.addListener(`progress`,e=>{if(!(!e||typeof e!=`object`||!(`requestId`in e)||e.requestId!==a||r.aborted)){if(!(`bytes`in e)||typeof e.bytes!=`number`||!Number.isSafeInteger(e.bytes)||e.bytes<0||e.bytes>n.byteLength){o=Error(`Native media returned invalid progress.`),c();return}i(e.bytes)}});try{r.throwIfAborted();let t=e.download({requestId:a,asset:n});r.addEventListener(`abort`,c,{once:!0}),r.aborted&&c();let i=await t;if(await s,o)throw o;r.throwIfAborted();let l=lt({type:`RECORDING_LIBRARY`,state:`ready`,recordings:[i]})[0];if(dt(l)!==dt(n))throw Error(`Native recording identity changed during download.`);return l}catch(e){throw await s,o||e}finally{r.removeEventListener(`abort`,c),await l.remove()}},remove:t=>e.remove({asset:t}),destroy(){t=!0}}}function ja(e=ka()){return{async read(){let t=await e.readIntent();if(!t||typeof t!=`object`||!(`keys`in t)||!Array.isArray(t.keys)||!t.keys.every(e=>typeof e==`string`&&e.length>0)||new Set(t.keys).size!==t.keys.length)throw Error(`Invalid native download queue.`);return t.keys},update:(t,n)=>e.updateIntent({add:t,remove:n})}}async function Ma(e,t=ka()){let n=ft(e);if(!n)return e.playSrc;let r=await t.resolve({asset:n});if(!r||typeof r!=`object`||!(`url`in r))throw Error(`Invalid native recording location.`);if(r.url===null)return e.playSrc;if(typeof r.url!=`string`)throw Error(`Invalid native recording location.`);let i=new URL(r.url);if(i.protocol!==`file:`||i.host||i.search||i.hash)throw Error(`Native recording location is not a local file.`);return r.url}var Na=`tikkun.download-capacity.v1`,Pa=e=>`${Na}:${e}`,Fa=e=>typeof e==`number`&&Number.isSafeInteger(e)&&e>=0,Ia=e=>!!e&&typeof e==`object`&&`url`in e&&typeof e.url==`string`&&/^https?:\/\//.test(e.url)&&`byteLength`in e&&Fa(e.byteLength)&&e.byteLength>0;function La(e){let t=new Map;for(let n of e){if(!Ia(n))throw Error(`Invalid download capacity asset.`);t.set(n.url,Math.max(t.get(n.url)??0,n.byteLength))}let n=t.size?[...t.values()].reduce((e,t)=>e+t*2,0)+33554432:0;if(!Number.isSafeInteger(n))throw Error(`Download capacity reservation is too large.`);return n}function Ra(e,t){let n=G({storage:e,key:Na,validate:e=>Array.isArray(e)&&e.every(e=>!!e&&typeof e==`object`&&typeof e.owner==`string`&&/^[a-f0-9-]{36}$/.test(e.owner)&&Array.isArray(e.assets)&&e.assets.every(Ia))&&new Set(e.map(e=>e.owner)).size===e.length}),r=()=>{let e=n.read();if(e.status===`unavailable`)throw e.error;if(e.status===`invalid`)throw Error(`Saved download capacity data is invalid; existing data was kept.`);return{entries:e.status===`ready`?e.value:[],revision:e.revision}};return{async reserve(e,i){if(!t)throw Error(`Shared download capacity coordination is unavailable.`);let a=crypto.randomUUID(),o=await ut(t,[Pa(a)],i);try{await t.request(Na,{signal:i},async()=>{let o=r(),{held:s}=await t.query();if(!s)throw Error(`Shared download capacity ownership is unavailable.`);let c=new Set(s.map(e=>e.name)),l=o.entries.filter(e=>c.has(Pa(e.owner))),u=await e();if(i.throwIfAborted(),u.availableBytes!==null&&!Fa(u.availableBytes))throw Error(`Invalid download capacity estimate.`);let d=La([...l.flatMap(e=>e.assets),...u.assets]);if(u.availableBytes!==null&&d>u.availableBytes)throw Error(`Not enough browser storage including downloads queued in other tabs. Cancel a batch or remove downloads and try again.`);K(n.write([...l,{owner:a,assets:[...u.assets]}],o.revision))})}catch(e){throw await o(),e}let s;return()=>s??=t.request(Na,()=>{let e=r();K(n.write(e.entries.filter(e=>e.owner!==a),e.revision))}).finally(o)}}}function za({baseUrl:e,navigator:t,storage:n,inUse:r}){let i=wt(),a=B(t),o=re(),s,c=()=>s??=(o?L(async()=>{let{createBundledRecordingDependencies:e}=await import(`./B55wJRDZ.js`);return{createBundledRecordingDependencies:e}},__vite__mapDeps([14,15,6,7,1,8,9,10,16]),import.meta.url).then(({createBundledRecordingDependencies:t})=>t({recordings:i,baseUrl:e})):L(async()=>{let{createWebRecordingDependencies:e}=await import(`./OxwK-EO_.js`);return{createWebRecordingDependencies:e}},__vite__mapDeps([17,16,14,15,6,7,1,8,9,10]),import.meta.url).then(({createWebRecordingDependencies:r})=>r({recordings:i,baseUrl:e,serviceWorker:a,capacity:Ra(n,t.locks??null)}))).catch(e=>{throw s=void 0,e});return Ta({assets:i.flatMap(t=>{let n=ft(t);return n?[pt(n,e)]:[]}),backend:o?Aa():mt({serviceWorker:a,locks:t.locks??null}),intent:o?ja():Da(n,t.locks??null),dependencies:{reserve:o?void 0:async(e,t)=>{let n=await c();if(!n.reserve)throw Error(`Offline capacity reservations are unavailable.`);return n.reserve(e,t)},preflight:o?void 0:async(e,t)=>{let n=await c();if(!n.preflight)throw Error(`Offline download preflight is unavailable.`);await n.preflight(e,t)},check:async e=>(await c()).check(e),prepare:async(e,t)=>(await c()).prepare(e,t),destroy:()=>{s?.then(e=>e.destroy?.(),e=>console.error(`Offline content initialization failed`,e))}},inUse:r})}function Ba(e){let t=new Set,n=0,r=!1,i=()=>[...new Set([...t,...e.currentSources()])];return{sources:i,async sync(){if(r)return;t=new Set(i());let a=++n;await e.whenReleased(),!(r||a!==n)&&(t=new Set(e.currentSources()),await e.onReleased())},freeze(){return t=new Set(i()),r=!0,n+=1,[...t]}}}var Va=class{constructor(){this.listeners={}}emit(e,t){let n=this.listeners[e];if(n)for(let e of[...n])e(t)}on(e,t){let n=this.listeners[e]??[];return n.push(t),this.listeners[e]=n,()=>{let n=this.listeners[e];if(!n)return;let r=n.indexOf(t);r>=0&&n.splice(r,1),n.length||delete this.listeners[e]}}},Ha;function Ua(){return Ha??=z(`TikkunPlayback`)}function Wa(e){if(!e||typeof e!=`object`)throw Error(`Invalid native playback state`);let t=e;if(!Number.isSafeInteger(t.revision)||Number(t.revision)<0||t.sessionID!==null&&(typeof t.sessionID!=`string`||!t.sessionID)||!Number.isSafeInteger(t.segmentIndex)||Number(t.segmentIndex)<0||typeof t.currentTime!=`number`||!Number.isFinite(t.currentTime)||t.currentTime<0||t.duration!==null&&(typeof t.duration!=`number`||!Number.isFinite(t.duration)||t.duration<0)||typeof t.paused!=`boolean`||typeof t.ended!=`boolean`||typeof t.rate!=`number`||!Number.isFinite(t.rate)||t.rate<.25||t.rate>3||![`idle`,`loading`,`ready`,`error`].includes(t.phase??``)||t.error!==null&&typeof t.error!=`string`)throw Error(`Invalid native playback state`);return t}var Ga=15e3,Ka=Symbol(`playback-activation-cancelled`),qa=class extends Va{constructor(e,{signal:t,protectPlayback:n}={}){super(),this.audio=e,this.activeSession=null,this.activeSegmentIndex=0,this.playbackFrame=0,this.nextSourcePreload=null,this.nextSourcePreloadCleanup=null,this.nextSourcePreloadKey=null,this.segmentTransitioning=!1,this.activationGeneration=0,this.segmentReady=Promise.resolve({status:`ready`}),this.cancelPendingActivation=null,this.failPendingActivation=null,this.activationError=null,this.activationNeedsReload=!1,this.mediaDurationsBySource=new Map,this.lifetimeController=new AbortController,this.destroyed=!1,this.pendingProtection=null,this.releaseProtection=null,this.pumpPlaybackFrame=()=>{if(this.audio.paused||this.audio.ended){this.playbackFrame=0;return}let e=this.activeSession?.segments[this.activeSegmentIndex]?.endTime;if(typeof e==`number`&&this.audio.currentTime>=e){this.advanceSegment(!0)||(this.audio.pause(),this.audio.currentTime=e,this.emit(`frame-updated`,{currentTime:this.currentTime}));return}this.emit(`frame-updated`,{currentTime:this.currentTime}),this.playbackFrame=requestAnimationFrame(this.pumpPlaybackFrame)},this.protectPlayback=n;let r={signal:this.lifetimeController.signal};e.addEventListener(`play`,()=>{this.startPlaybackFrameLoop(),this.emit(`playback-updated`,{playing:!0})},r),e.addEventListener(`pause`,()=>{this.stopPlaybackFrameLoop(),this.emit(`playback-updated`,{playing:!1})},r),e.addEventListener(`ended`,()=>{this.stopPlaybackFrameLoop(),!this.advanceSegment(!0)&&this.emit(`frame-updated`,{currentTime:this.currentTime})},r),e.addEventListener(`seeked`,()=>this.emit(`frame-updated`,{currentTime:this.currentTime}),r),e.addEventListener(`timeupdate`,()=>this.emit(`time-updated`,{currentTime:this.currentTime}),r);let i=()=>this.rememberActiveMediaDuration();e.addEventListener(`loadedmetadata`,i,r),e.addEventListener(`durationchange`,i,r),e.addEventListener(`error`,()=>{if(!this.activeSession)return;let e=this.mediaError();if(this.failPendingActivation){this.failPendingActivation(e);return}this.reportPlaybackError(e,this.activationGeneration,!0)},r);for(let t of[`loadedmetadata`,`durationchange`,`emptied`])e.addEventListener(t,()=>this.emit(`metadata-updated`,void 0),r);t?.addEventListener(`abort`,()=>this.destroy(),{once:!0}),t?.aborted&&this.destroy()}destroy(){this.destroyed||(this.destroyed=!0,this.clearSession(),this.stopPlaybackFrameLoop(),this.lifetimeController.abort())}startPlaybackFrameLoop(){this.playbackFrame||=requestAnimationFrame(this.pumpPlaybackFrame)}stopPlaybackFrameLoop(){this.playbackFrame&&=(cancelAnimationFrame(this.playbackFrame),0)}get session(){return this.activeSession}get paused(){return this.audio.paused}get ended(){return this.audio.ended}get playbackRate(){return this.audio.playbackRate}set playbackRate(e){this.audio.playbackRate=e}get error(){return this.activationError}get activeSegment(){return this.activeSession?.segments[this.activeSegmentIndex]??null}get currentTime(){let e=this.activeSession?.segments[this.activeSegmentIndex];return e?e.recording.status===`missing`?e.logicalStart:Math.min(e.logicalEnd,e.logicalStart+Math.max(0,this.audio.currentTime-e.startTime)):this.audio.currentTime}get duration(){let e=this.activeSession?.segments,t=e?.[e.length-1];if(!t)return this.audio.duration;if(Number.isFinite(t.logicalEnd))return t.logicalEnd;let n=this.mediaDurationsBySource.get(this.sourceKey(t.recording.playSrc));return n===void 0?1/0:t.logicalStart+Math.max(0,n-t.startTime)}async loadSession(e){if(this.destroyed)throw Error(`Playback controller was destroyed`);this.pendingProtection?.abort();let t=new AbortController;this.pendingProtection=t;let n=null;try{this.protectPlayback&&(n=await this.protectPlayback(e.segments.filter(({recording:e})=>e.status!==`missing`).map(({recording:e})=>e.playSrc),t.signal)),t.signal.throwIfAborted()}catch(e){throw n?.(),e}finally{this.pendingProtection===t&&(this.pendingProtection=null)}let r=this.releaseProtection;this.releaseProtection=n,this.activeSession=e,this.activeSegmentIndex=0;try{this.activateSegment(0,e.segments[0]?.logicalStart??0,!1)}catch(e){throw this.clearSession(),e}finally{r?.()}return this.emit(`session-loaded`,e),e}waitForFiniteDuration({signal:e,timeoutMs:t=Ga}={}){let n=this.duration;return Number.isFinite(n)&&n>0?Promise.resolve(n):new Promise((n,r)=>{let i=!1,a=t=>{i||(i=!0,clearTimeout(l),this.audio.removeEventListener(`loadedmetadata`,o),this.audio.removeEventListener(`durationchange`,o),this.audio.removeEventListener(`error`,s),e?.removeEventListener(`abort`,c),`error`in t?r(t.error):n(t.duration))},o=()=>{let e=this.duration;Number.isFinite(e)&&e>0&&a({duration:e})},s=()=>a({error:this.mediaError()}),c=()=>a({error:new DOMException(`Audio duration wait cancelled`,`AbortError`)}),l=setTimeout(()=>a({error:Error(`Timed out waiting for a finite audio duration`)}),t);this.audio.addEventListener(`loadedmetadata`,o),this.audio.addEventListener(`durationchange`,o),this.audio.addEventListener(`error`,s),e?.addEventListener(`abort`,c,{once:!0}),e?.aborted?c():o()})}clearSession(){this.pendingProtection?.abort(),this.pendingProtection=null,this.audio.pause(),this.cancelPendingActivation?.(),this.activationGeneration+=1,this.activeSession=null,this.activeSegmentIndex=0,this.clearNextSourcePreload(),this.segmentTransitioning=!1,this.segmentReady=Promise.resolve({status:`cancelled`}),this.cancelPendingActivation=null,this.failPendingActivation=null,this.activationError=null,this.activationNeedsReload=!1,this.audio.removeAttribute(`src`),this.audio.load(),this.releaseProtection?.(),this.releaseProtection=null,this.emit(`playback-updated`,{playing:!1})}authorizePlayback(e){if(e.status===`missing`)return!1;let t=!this.isMediaSource(e.playSrc);return!t&&this.audio.readyState>=HTMLMediaElement.HAVE_METADATA||(t&&(this.activeSession?this.clearSession():(this.cancelPendingActivation?.(),this.audio.pause()),this.audio.src=e.playSrc),this.activationError=null,this.activationNeedsReload=!1,this.audio.load(),!0)}togglePlayback(){if(this.audio.paused)return this.play();this.audio.pause()}play(){if(!this.activeSession)return Promise.resolve();if(this.activeSegment?.recording.status===`missing`)return Promise.reject(Error(`No source recording is available; record microphone audio first`));this.activationNeedsReload&&this.activeSession?this.activateSegment(this.activeSegmentIndex,this.currentTime,!1,!0):this.activationError=null;let e=this.activationGeneration,t=this.segmentReady,n=this.startMediaPlayback(e);if(!this.segmentTransitioning)return n;let r=t.then(t=>{if(t.status===`cancelled`||e!==this.activationGeneration)throw Ka;if(t.status===`failed`)throw t.error});return Promise.all([r,n]).then(()=>void 0).catch(e=>{if(e!==Ka)throw e})}async startMediaPlayback(e){try{await this.audio.play()}catch(t){if(e!==this.activationGeneration)return;let n=this.asError(t,`Audio playback failed`);throw this.reportPlaybackError(n,e,!1),n}}pause(){this.audio.pause()}seek(e){if(!Number.isFinite(e))throw TypeError(`Seek time must be finite`);let t=this.activeSession?.segments;if(!t?.length){this.audio.currentTime=e;return}let n=this.duration,r=Number.isFinite(n)?Math.max(0,Math.min(e,n)):Math.max(0,e),i=Math.max(0,t.findIndex((e,n)=>r>=e.logicalStart&&(r<e.logicalEnd||n===t.length-1))),a=t[i];if(a.recording.status===`missing`){i!==this.activeSegmentIndex||this.segmentTransitioning?this.activateSegment(i,a.logicalStart,!1):this.emit(`frame-updated`,{currentTime:a.logicalStart});return}if(i===this.activeSegmentIndex&&!this.segmentTransitioning){this.audio.currentTime=a.startTime+Math.max(0,r-a.logicalStart),this.emit(`frame-updated`,{currentTime:this.currentTime});return}this.activateSegment(i,r,!this.audio.paused)}replayFromStart(){let e=this.activeSession?.passage?0:this.activeSession?.cues[0]?.timeStart??0;return this.seek(e),this.play()}replayCurrentCue(){if(!this.activeSession?.cues.length)return;let e=this.currentTime,t=-1;for(let n=this.activeSession.cues.length-1;n>=0;n--)if(this.activeSession.cues[n].timeStart<=e){t=n;break}let n=this.activeSession.cues[Math.max(t,0)];if(n)return this.seek(n.timeStart),this.play()}advanceSegment(e){let t=this.activeSegmentIndex+1;return!this.activeSession?.segments[t]||this.segmentTransitioning?!1:(this.activateSegment(t,this.activeSession.segments[t].logicalStart,e),!0)}activateSegment(e,t,n,r=!1){let i=this.activeSession?.segments[e];if(!i)return;this.cancelPendingActivation?.();let a=++this.activationGeneration;this.segmentTransitioning=!0,this.activationError=null,this.activationNeedsReload=!1,this.activeSegmentIndex=e,this.emit(`segment-updated`,{index:e,segment:i});let o=i.recording.status===`missing`,s=o?!!this.audio.src:r||!this.isMediaSource(i.recording.playSrc);o?(this.audio.pause(),s&&(this.audio.removeAttribute(`src`),this.audio.load())):s&&(this.audio.src=i.recording.playSrc,this.audio.load());let c=i.startTime+Math.max(0,t-i.logicalStart),l=()=>{};this.segmentReady=new Promise(e=>{l=e});let u=!1,d=null,f=()=>{d!==null&&clearTimeout(d),this.audio.removeEventListener(`loadedmetadata`,m)},p=e=>{if(!u&&(u=!0,f(),l(e),a===this.activationGeneration)){if(this.cancelPendingActivation=null,this.failPendingActivation=null,this.segmentTransitioning=!1,e.status===`failed`){this.reportPlaybackError(e.error,a,!0);return}e.status!==`cancelled`&&(o||(this.rememberMediaDuration(i,this.audio),this.audio.currentTime=c),this.emit(`frame-updated`,{currentTime:this.currentTime}),n&&this.play().catch(()=>{}))}},m=()=>p({status:`ready`});this.cancelPendingActivation=()=>p({status:`cancelled`}),this.failPendingActivation=e=>p({status:`failed`,error:e}),o?p({status:`ready`}):this.audio.readyState<HTMLMediaElement.HAVE_METADATA?(this.audio.addEventListener(`loadedmetadata`,m,{once:!0}),d=setTimeout(()=>{p({status:`failed`,error:Error(`Timed out loading audio metadata for ${i.recording.id}`)})},Ga)):p({status:`ready`}),this.preloadNextSegment()}preloadNextSegment(){let e=this.activeSession?.segments[this.activeSegmentIndex+1];if(e?.recording.status===`missing`){this.clearNextSourcePreload();return}let t=e?this.sourceKey(e.recording.playSrc):null;if(e&&t===this.nextSourcePreloadKey&&this.nextSourcePreload||(this.clearNextSourcePreload(),!e||!t))return;let n=new Audio;n.preload=`metadata`,n.src=e.recording.playSrc,this.nextSourcePreload=n,this.nextSourcePreloadKey=t;let r=()=>{this.rememberMediaDuration(e,n),a()},i=()=>a(),a=()=>{n.removeEventListener(`loadedmetadata`,r),n.removeEventListener(`error`,i),this.nextSourcePreloadCleanup===a&&(this.nextSourcePreloadCleanup=null)};this.nextSourcePreloadCleanup=a,n.addEventListener(`loadedmetadata`,r,{once:!0}),n.addEventListener(`error`,i,{once:!0}),n.readyState>=HTMLMediaElement.HAVE_METADATA&&r()}clearNextSourcePreload(){let e=this.nextSourcePreload;this.nextSourcePreloadCleanup?.(),this.nextSourcePreloadCleanup=null,this.nextSourcePreload=null,this.nextSourcePreloadKey=null,e&&(e.pause(),e.removeAttribute(`src`),e.load())}sourceKey(e){return new URL(e,window.location.href).href}isMediaSource(e){let t=this.audio.currentSrc||this.audio.src;return!!(t&&this.sourceKey(t)===this.sourceKey(e))}rememberActiveMediaDuration(){let e=this.activeSession?.segments[this.activeSegmentIndex];if(!e||e.recording.status===`missing`)return;let t=this.audio.currentSrc||this.audio.src;!t||this.sourceKey(t)!==this.sourceKey(e.recording.playSrc)||this.rememberMediaDuration(e,this.audio)}rememberMediaDuration(e,t){if(!Number.isFinite(t.duration)||t.duration<=0)return;let n=this.sourceKey(e.recording.playSrc);if(this.mediaDurationsBySource.get(n)===t.duration)return;this.mediaDurationsBySource.set(n,t.duration);let r=this.duration;Number.isFinite(r)&&this.emit(`duration-updated`,{duration:r})}reportPlaybackError(e,t,n){t!==this.activationGeneration||!this.activeSession||(this.activationError=e,this.audio.pause(),this.activationNeedsReload=n,this.emit(`playback-error`,{error:e,recording:this.activeSession.segments[this.activeSegmentIndex]?.recording??this.activeSession.recording}))}mediaError(){let e=this.audio.error?.code;return Error(e?`Audio media failed with code ${e}`:`Audio media failed to load`)}asError(e,t){return e instanceof Error?e:Error(t)}};function Ja(e){Ya(e);let t=0,n=e.segments.map(e=>{let n=e.endTime===null?1/0:Math.max(.001,e.endTime-e.startTime),r={...e,logicalStart:t,logicalEnd:t+n};return t=r.logicalEnd,r}),r=n.flatMap(e=>e.cues.map(t=>({...t,timeStart:e.logicalStart+(t.timeStart-e.startTime),timeEnd:t.timeEnd===void 0?void 0:e.logicalStart+(t.timeEnd-e.startTime)}))),i=n[n.length-1]?.recording;if(!i)throw Error(`Playback plan must contain at least one segment`);return{recording:i,cues:r,runId:e.target.runId,aliyahIndex:e.target.index,tokenKeys:e.tokenKeys,segments:n,status:e.status,readingLabel:e.readingLabel,passage:e.passage}}function Ya(e){if(!e.segments.length)throw TypeError(`Playback plan must contain at least one segment`);for(let[t,n]of e.segments.entries()){if(!Number.isFinite(n.startTime)||n.startTime<0)throw TypeError(`Playback segment ${t} has an invalid start time`);if(n.endTime===null){if(t!==e.segments.length-1)throw TypeError(`Only the final playback segment may be open-ended`)}else if(!Number.isFinite(n.endTime)||n.endTime<=n.startTime)throw TypeError(`Playback segment ${t} has an invalid end time`);let r=-1/0;for(let e of n.cues){if(!Number.isFinite(e.timeStart)||e.timeStart<n.startTime||n.endTime!==null&&e.timeStart>n.endTime||e.timeStart<r||e.timeEnd!==void 0&&(!Number.isFinite(e.timeEnd)||e.timeEnd<e.timeStart||n.endTime!==null&&e.timeEnd>n.endTime))throw TypeError(`Playback segment ${t} has invalid cue ordering`);r=e.timeStart}}}var Xa=class extends Va{constructor(e,t=Ua(),n=async e=>e.playSrc){super(),this.bridge=t,this.resolveSource=n,this.useWeb=!1,this.activeSession=null,this.id=null,this.installedID=null,this.state=null,this.failure=null,this.rate=1,this.destroyed=!1,this.tail=Promise.resolve(),this.clearing=null,this.web=new qa(e);let r=e=>{this.web.on(e,t=>{this.useWeb&&this.emit(e,t)})};r(`session-loaded`),r(`segment-updated`),r(`playback-updated`),r(`frame-updated`),r(`time-updated`),r(`duration-updated`),r(`metadata-updated`),r(`playback-error`),this.registrations=[t.addListener(`stateChanged`,e=>{try{this.accept(e)}catch(e){this.report(e)}}),t.addListener(`commandError`,e=>{e&&typeof e==`object`&&`sessionID`in e&&e.sessionID===this.id&&`message`in e&&typeof e.message==`string`&&this.report(Error(e.message))})],this.bridgeReady=Promise.all(this.registrations),this.bridgeReady.catch(e=>this.report(e))}get session(){return this.useWeb?this.web.session:this.activeSession}get error(){return this.useWeb?this.web.error:this.failure}get activeSegment(){return this.useWeb?this.web.activeSegment:this.activeSession?.segments[this.state?.segmentIndex??0]??null}get currentTime(){return this.useWeb?this.web.currentTime:this.state?.currentTime??0}get duration(){return this.useWeb?this.web.duration:this.state?.duration??this.activeSession?.segments.at(-1)?.logicalEnd??1/0}get paused(){return this.useWeb?this.web.paused:this.state?.paused??!0}get ended(){return this.useWeb?this.web.ended:this.state?.ended??!1}get playbackRate(){return this.rate}set playbackRate(e){if(!Number.isFinite(e)||e<.25||e>3)throw TypeError(`Invalid playback rate`);if(e===this.rate)return;this.rate=e,this.web.playbackRate=e;let t=this.id;t&&this.background(this.command(t,()=>this.bridge.setRate({sessionID:t,rate:e})))}async loadSession(e){if(this.destroyed)throw Error(`Playback controller was destroyed`);if(this.clearSession(),this.useWeb=e.segments.some(({recording:e})=>e.status===`missing`||e.playSrc.startsWith(`blob:`)),this.useWeb){if(await this.clearing,this.destroyed)throw Error(`Playback controller was destroyed`);return this.web.loadSession(e)}this.activeSession=e;let t=crypto.randomUUID();return this.id=t,this.emit(`session-loaded`,e),await this.command(t,async()=>{await this.bridgeReady;let n=await Promise.all(e.segments.map(async({recording:e,startTime:t,endTime:n})=>({url:await this.resolveSource(e),start:t,end:n})));if(this.destroyed||this.id!==t)throw new DOMException(`Playback session was replaced.`,`AbortError`);let r=await this.bridge.setSession({sessionID:t,title:e.readingLabel??e.recording.title,segments:n});return this.installedID=t,this.accept(r),this.bridge.setRate({sessionID:t,rate:this.rate})}),e}clearSession(){let e=this.id;if(this.id=null,this.activeSession=null,this.state=null,this.failure=null,this.web.clearSession(),this.useWeb=!1,e){let t=this.tail.then(async()=>{this.installedID===e&&(await this.bridge.clear({sessionID:e}),this.installedID=null)});this.clearing=t,this.tail=t.catch(e=>{console.error(`Could not clear native playback`,e),this.report(e)})}this.emit(`playback-updated`,{playing:!1}),this.emit(`metadata-updated`,void 0)}authorizePlayback(e){return e.status===`missing`||e.playSrc.startsWith(`blob:`)?this.web.authorizePlayback(e):!this.destroyed}play(){if(this.useWeb)return this.web.play();let e=this.id;return e?this.command(e,()=>this.bridge.play({sessionID:e})):Promise.resolve()}pause(){if(this.useWeb){this.web.pause();return}let e=this.id;e&&this.background(this.command(e,()=>this.bridge.pause({sessionID:e})))}togglePlayback(){if(this.paused)return this.play();this.pause()}seek(e){if(!Number.isFinite(e))throw TypeError(`Seek time must be finite`);if(this.useWeb){this.web.seek(e);return}let t=this.id;t&&this.background(this.command(t,()=>this.bridge.seek({sessionID:t,time:e})))}replayFromStart(){return this.seek(this.session?.passage?0:this.session?.cues[0]?.timeStart??0),this.play()}replayCurrentCue(){let e=this.session?.cues;if(!e?.length)return;let t=e.findLast(e=>e.timeStart<=this.currentTime)??e[0];return this.seek(t.timeStart),this.play()}waitForFiniteDuration({signal:e,timeoutMs:t=15e3}={}){if(this.useWeb)return this.web.waitForFiniteDuration({signal:e,timeoutMs:t});let n=this.id;return new Promise((r,i)=>{let a=[],o=e=>{a.forEach(e=>e()),e?i(e):r(this.duration)},s=()=>{this.destroyed||this.id!==n||e?.aborted?o(new DOMException(`Audio duration wait cancelled`,`AbortError`)):this.failure?o(this.failure):Number.isFinite(this.duration)&&this.duration>0&&o()};a.push(this.on(`metadata-updated`,s),this.on(`playback-error`,s));let c=setTimeout(()=>o(Error(`Timed out waiting for a finite audio duration`)),t);a.push(()=>clearTimeout(c)),e?.addEventListener(`abort`,s,{once:!0}),a.push(()=>e?.removeEventListener(`abort`,s)),s()})}whenCleared(){return this.clearing??Promise.resolve()}destroy(){if(!this.destroyed){this.destroyed=!0,this.clearSession(),this.web.destroy();for(let e of this.registrations)e.then(e=>e.remove()).catch(e=>console.error(`Could not release native playback listener`,e))}}command(e,t){let n=this.tail.then(async()=>{this.destroyed||this.id!==e||this.accept(await t())});return this.tail=n.catch(t=>{this.id===e&&this.report(t)}),n}background(e){e.catch(()=>{})}accept(e){let t=Wa(e);if(this.destroyed||!this.id||t.sessionID!==this.id||this.useWeb)return;if(!this.activeSession?.segments[t.segmentIndex])throw Error(`Native playback returned an invalid segment`);let n=this.state;n&&t.revision<n.revision||(this.state=t,t.error?this.failure?.message!==t.error&&this.report(Error(t.error)):this.failure=null,n?.segmentIndex!==t.segmentIndex&&this.emit(`segment-updated`,{index:t.segmentIndex,segment:this.activeSegment}),(n?.paused!==t.paused||n?.ended!==t.ended)&&this.emit(`playback-updated`,{playing:!t.paused&&!t.ended}),n?.duration!==t.duration&&(this.emit(`duration-updated`,{duration:this.duration}),this.emit(`metadata-updated`,void 0)),this.emit(`time-updated`,{currentTime:t.currentTime}),this.emit(`frame-updated`,{currentTime:t.currentTime}))}report(e){if(this.destroyed)return;let t=e instanceof Error?e:Error(`Native playback failed`);this.failure=t;let n=this.activeSegment?.recording??this.activeSession?.recording;n?this.emit(`playback-error`,{error:t,recording:n}):console.error(`Native playback is unavailable`,t)}},Za=e=>`tikkun-recording-playback:${e}`;function Qa(e,t){return async(n,r)=>{r.throwIfAborted();let i=[...new Set(n.map(e=>new URL(e,t)).filter(e=>e.protocol===`https:`||e.protocol===`http:`).map(e=>e.href))];return!e||i.length===0?()=>{}:ut(e,i.map(Za),r)}}function $a(e,t){return!!(e&&e.runId===t.runId&&e.aliyahIndex===t.aliyahIndex&&(t.recordingId===null||e.recording.id===t.recordingId))}function eo(e,t){if(e.status===`overlap-only`)return null;let n=e.segments.find(e=>e.recording.id===t);return n?{...e,status:n.tokenKeys[0]===e.tokenKeys[0]?`current-only`:`partial-start`,segments:[{...n,startTime:0,endTime:null}]}:null}function to(e){if(!e||e.status===`overlap-only`||e.passage||e.segments.length!==1)return null;let t=e.segments[0];return t&&t.recording.id===e.recording.id&&t.startTime===0&&t.endTime===null?t:null}function no(e){return to(e)!==null}function ro(e,t){let n=to(e);return n?(e.cues=t,n.cues=t,!0):!1}var io=class{constructor(){this.generation=0,this.checkpoint=null}begin(e,t){if(!Number.isFinite(t)||t<0)throw TypeError(`Reader playback checkpoint time must be finite and nonnegative`);return this.checkpoint??={session:e,currentTime:t},++this.generation}isCurrent(e){return e===this.generation}leave(){this.generation+=1;let e=this.checkpoint;return this.checkpoint=null,e}},ao=e=>e.map(e=>({...e}));function oo(e){let{audioController:t,highlightController:n,library:r,display:i,authoring:a,presentation:o}=e,s=new Map,c=new io,l=0,u=null,d=()=>(u?.abort(),u=new AbortController,{generation:++l,signal:u.signal}),f=e=>e.generation===l&&u?.signal===e.signal&&!e.signal.aborted,p=()=>{l+=1,u?.abort(),u=null},m=({runId:e,aliyahIndex:t})=>`${e}:${t}`,h=async(e,t)=>{let n=m(e),r=s.get(n);if(r)return[...r];let a=await i.collectTokenKeys(e);return f(t)?(a.length&&s.set(n,[...a]),[...a]):[]},g=(t,n)=>r.findRecording({narratorId:e.getNarratorId(),run:t,aliyahIndex:n}),_=(e,t)=>{let n=fi(e),r=n.findIndex(n=>n.run.id===e.id&&n.aliyah.index===t);return{target:r>=0?n[r]:null,previous:r>0?n[r-1]:null}},v=(e,t)=>{let{target:n,previous:r}=_(e,t);return!n||!r?.aliyah.index||n.aliyah.start.scroll!==r.aliyah.end.scroll||$(n.aliyah.start,r.aliyah.start)<0||$(n.aliyah.start,r.aliyah.end)>0?null:g(r.run,r.aliyah.index)},y=(t,n)=>{let r=g(t,n),i=v(t,n),o=t.aliyot.find(e=>e.index===n),s=!e.recordingMode&&!a.isActive()&&t.scroll===`torah`&&o?e.passages?.peek(o,e.getNarratorId()):void 0;return{recording:r,overlapRecording:i,available:s?!!s.recording:!!(r||i),passage:s}},b=async(s,{mode:c=`reader`,recordingOverride:l}={})=>{let u=d(),p=i.resolveRun(s.runId);if(!p)return null;let m=await h(s,u);if(!f(u)||!m.length)return null;let v=c===`authoring`||a.isActive(),y=null;if(e.passages&&p.scroll===`torah`&&!v&&!e.recordingMode&&l===void 0){let n=p.aliyot.find(e=>e.index===s.aliyahIndex);if(!n)return null;let r=await e.passages.resolve(n,e.getNarratorId());if(!f(u))return null;let i=r.problem===null||r.problem===`incomplete-cues`;i||t.pause();let a=i?r.portions[0]:await e.choosePassagePortion?.(r,u.signal,e=>{let n=e.segments[0]?.recording;n&&t.authorizePlayback(n)});if(!a||!f(u))return null;if(y=On(r,a,{runId:s.runId,index:s.aliyahIndex},p.leining.date.title.en.replace(/^Parshat\s+/i,``)),y.segments.length>1){let{loadRecordingDuration:e}=await L(async()=>{let{loadRecordingDuration:e}=await import(`./BfkxMN6I.js`);return{loadRecordingDuration:e}},[],import.meta.url);y.segments=await Promise.all(y.segments.map(async t=>({...t,endTime:t.endTime??await e(t.recording,u.signal)})))}if(!f(u))return null}let b=l===void 0?c===`authoring`?r.findAuthoringRecording({narratorId:e.getNarratorId(),run:p,aliyahIndex:s.aliyahIndex}):g(p,s.aliyahIndex):l,x=b&&!y?{recording:b,cues:ao(await r.loadCues(b))}:null;if(!f(u))return null;let S=null,C=[];if(!y&&!e.recordingMode&&!v){let e=_(p,s.aliyahIndex).previous;if(e?.aliyah.index){let t=g(e.run,e.aliyah.index);if(t){let n={runId:e.run.id,aliyahIndex:e.aliyah.index};if(C=await h(n,u),!f(u))return null;S={recording:t,cues:ao(await r.loadCues(t))}}}}if(!f(u))return null;let w=y??Bt({target:{runId:s.runId,index:s.aliyahIndex},tokenKeys:m,current:x,previous:S,previousTokenKeys:C});if(!w)return null;let T=v?b&&eo(w,b.id):w;if(!T||!f(u))return null;let E=Ja(T);if(await t.loadSession(E),!f(u))return null;n.setSequence(E.tokenKeys);let D=E.cues[0];if(D&&(!y||D.timeStart===0)){if(t.seek(D.timeStart),await o.setCueIndex(0),!f(u))return null;await n.activateCue(D,{scroll:!0})}else E.tokenKeys[0]&&await n.activateTokenKey(E.tokenKeys[0],{scroll:!0});if(!f(u))return null;if(no(E)){if(await a.bindSession(),!f(u))return null;await o.setCueIndex(E.cues.length&&t.currentTime?n.getCueIndex(E.cues,t.currentTime):E.cues.length?0:null)}else a.clearSession();return f(u)?(o.sessionLoaded(E),E):null};return{lookup:y,load:(e,{mode:t=`reader`}={})=>b(e,{mode:t}),loadByAudioId:async e=>{let n=r.listRecordings().find(t=>t.id===e)??null;if(!n||!le(n))return null;await i.waitUntilReady();let a=i.resolveRunForRecording(n);if(!a)return null;let o=await b({runId:a.id,aliyahIndex:n.aliyah},{recordingOverride:n});if(!o)return null;let s={generation:l,signal:u?.signal??AbortSignal.abort()};return await t.waitForFiniteDuration({signal:s.signal}),f(s)?o:null},enterAuthoring:async()=>{let e=t.session;if(!e||a.hasSession()||e.status===`overlap-only`)return;let n=e.segments[e.segments.length-1];if(!n||n.recording.id!==e.recording.id)return;if(e.passage){let t=i.resolveRun(e.runId);if(e.segments.length!==1||n.startTime!==0||n.endTime!==null||!t||g(t,e.aliyahIndex)?.id!==e.recording.id)return}let r=c.begin(e,t.currentTime);t.pause();let o=await b({runId:e.runId,aliyahIndex:e.aliyahIndex},{mode:`authoring`,recordingOverride:e.recording});if(!(!c.isCurrent(r)||!a.isVisible())&&(!o||!no(o)))throw Error(`Could not create an authoring session for ${e.recording.id}`)},leaveAuthoring:async()=>{let e=c.leave();e&&(p(),t.pause(),await t.loadSession(e.session),!(a.isVisible()||t.session!==e.session)&&(t.seek(e.currentTime),o.sessionLoaded(e.session)))},replaceAuthoringCues:e=>{let n=t.session;return n?ro(n,ao(e)):!1},reset:()=>{p(),s.clear(),c.leave()},tokenCacheSize:()=>s.size}}function so(e,t){let n=re()?new Xa(t.audioElement,void 0,Ma):new qa(t.audioElement,{signal:e.signal,protectPlayback:Qa(t.view.navigator.locks??null,t.document.baseURI)});e.own(()=>n.destroy()),n.playbackRate=t.initialPlaybackRate;let r=new ua(t.book);e.own(()=>r.clear());let i=new Set,a=new Set,o=0,s=0,c=null,l=null,u=null,d=new WeakMap,f=null,p=null,m=-1,h=null,g=null,_=-1,v=null,y=null,b=-1,x=Object.freeze([]),S=null,C=-1,w=-1,T=null,E=e=>{let t=d.get(e);if(t)return t;let n=`range`in e?Object.freeze({...e,reading:Object.freeze({...e.reading}),...e.mediaIdentity?{mediaIdentity:Object.freeze({...e.mediaIdentity})}:{},range:Object.freeze({start:Object.freeze({...e.range.start}),end:Object.freeze({...e.range.end})})}):Object.freeze({...e,reading:Object.freeze({...e.reading}),...e.mediaIdentity?{mediaIdentity:Object.freeze({...e.mediaIdentity})}:{}});return d.set(e,n),n},D=()=>{let e=n.session;if(!e)return null;let t=n.activeSegment?.recording??e.recording;return f===e&&p===t&&m===s&&h?h:(f=e,p=t,m=s,h=Object.freeze({recording:E(e.recording),activeRecording:E(t),mediaSources:Object.freeze([...new Set(e.segments.map(e=>e.recording.playSrc))]),runId:e.runId,aliyahIndex:e.aliyahIndex,status:e.status,cueCount:e.cues.length,tokenCount:e.tokenKeys.length,tokenKeys:Object.freeze([...e.tokenKeys])}),h)},O=()=>{let e=n.session;return e?g===e&&_===o&&v?v:(g=e,_=o,v=Object.freeze({sessionRevision:o,recording:E(e.recording),tokenKeys:Object.freeze([...e.tokenKeys])}),v):null},k=()=>{let e=n.session;return e?y===e&&b===s?x:(y=e,b=s,x=Object.freeze(e.cues.map(e=>Object.freeze({...e}))),x):Object.freeze([])},A=()=>{let e=n.session,t=n.currentTime;return Object.freeze({sessionRevision:o,hasSession:!!e,activeTokenKey:r.getActiveTokenKey(),activeTokenIndex:r.getActiveIndex(),currentCueIndex:e?.cues.length?r.getCueIndex(e.cues,t):-1,currentTime:t,displayTime:c?.displayTime??t,duration:n.duration,paused:n.paused,ended:n.ended,error:n.error})},j=()=>{let e=n.session;return e?S===e&&C===o&&w===s&&T?T:(S=e,C=o,w=s,T=Object.freeze({sessionRevision:o,recording:E(e.recording),runId:e.runId,aliyahIndex:e.aliyahIndex,status:e.status,cues:Object.freeze(e.cues.map(e=>Object.freeze({...e}))),tokenKeys:Object.freeze([...e.tokenKeys])}),T):null},M=()=>Object.freeze({session:j(),currentTime:n.currentTime,duration:n.duration,activeTokenKey:r.getActiveTokenKey()}),N=()=>{let e=n.session,t=e?.cues.length?r.getCueIndex(e.cues,n.currentTime):-1;return Object.freeze({sessionRevision:o,session:D(),activeTokenKey:r.getActiveTokenKey(),activeTokenIndex:r.getActiveIndex(),currentCueIndex:t,currentTime:n.currentTime,displayTime:c?.displayTime??n.currentTime,duration:n.duration,paused:n.paused,ended:n.ended,playing:!!(e&&!n.paused&&!n.ended),error:n.error,tokenCacheSize:l?.tokenCacheSize()??0})},P=e=>{if(!i.size)return;let t=N();for(let n of i)n(e,t)},F=e=>{if(!a.size)return;let t=A();for(let n of a)n(e,t)},ee=async()=>{try{return await n.play(),!0}catch{return!1}},I=async e=>(u=e??null,ee()),L=async e=>{u=e??null;try{return await n.replayFromStart(),!0}catch{return!1}};c=xa(e,{...t.timeline,document:t.document,view:t.view,viewport:t.viewport,audioController:n,highlightController:r,attemptPlayback:I,attemptReplayFromStart:L,onChange:e=>{if(e.type===`session-loaded`){o+=1,s+=1,P({type:`session-loaded`}),F({type:`session`});return}P(e),e.type===`reader-chrome`?F({type:`playback`}):e.type===`aliyah-playback`?F({type:`display-progress`}):e.type===`playback-error`&&(F({type:`error`}),!t.view.navigator.onLine&&n.session&&P({type:`offline-media-error`,retry:u??(async()=>{await I()})}))}}),l=oo({...t.recording,audioController:n,highlightController:r,presentation:{setCueIndex:e=>c?.command({type:`set-cue-index`,index:e}),sessionLoaded:()=>c?.refresh()}}),e.own(()=>l?.reset()),e.own(r.onActiveTokenChanged(e=>{P({type:`active-token-changed`,tokenKey:e})})),e.own(n.on(`frame-updated`,()=>{F({type:`media-progress`})})),e.own(()=>i.clear()),e.own(()=>a.clear());let R=async(e,t)=>(u=null,await l?.load(e,t)?D():null),te=(e,t)=>r.activateTokenKey(e,t),ne=async(e,{play:t=!1,seekToCue:i=!1,retry:a,...o}={})=>{let s=n.session,l=s?.cues.findIndex(t=>X(t)===e)??-1,d=l>=0?s?.cues[l]??null:null;return d&&i&&(await c?.command({type:`set-cue-index`,index:l}),n.seek(d.timeStart)),t&&d&&(u=a??null,await ee()),d?r.activateCue(d,o):r.activateTokenKey(e,o)},z=async(e={})=>{let t=n.session;if(!t)return null;let i=r.getActiveTokenKey(),a=t.cues.length?r.getCueIndex(t.cues,n.currentTime):-1;return t.cues.length&&a>=0?r.activateCue(t.cues[a],e):i?r.activateTokenKey(i,e):t.cues[0]?r.activateCue(t.cues[0],e):t.tokenKeys[0]?r.activateTokenKey(t.tokenKeys[0],e):null},B=Object.freeze({snapshot:A,session:O,readCues:k,subscribe(e){return a.add(e),()=>a.delete(e)},prepareAuthoringSession:()=>l.enterAuthoring(),restoreReaderSession:()=>l.leaveAuthoring(),play:I,pause:()=>n.pause(),seek:e=>n.seek(e),async activateToken(e,t){await r.activateTokenKey(e,t)},clearHighlight:()=>r.clear(),replaceCues(e){let t=l.replaceAuthoringCues(e);return t&&(s+=1),t},refresh:e=>c.refresh(e),setCueIndex:e=>c.command({type:`set-cue-index`,index:e})}),V=Object.freeze({snapshot:M,async loadByAudioId(e){let t=await l.loadByAudioId(e);return t&&n.session===t?j():null},seek:e=>n.seek(e),play:()=>n.play(),pause:()=>n.pause(),syncHighlight:()=>c.syncHighlight(),async activateHighlightAt(e,{scroll:t}){let i=n.session;if(!i?.cues.length)return await c.syncHighlight(),!!(i&&n.session===i);let a=r.getCueIndex(i.cues,e);return a<0?(await c.syncHighlight(),n.session===i):(r.clear(),await r.activateCue(i.cues[a],{scroll:t}),n.session===i)}});return{snapshot:N,whenAudioReleased:()=>n instanceof Xa?n.whenCleared():Promise.resolve(),subscribe(e){return i.add(e),()=>i.delete(e)},setDisplay(e){r.setDisplay(e)},resetRoute(){n.clearSession(),r.clear(),l.reset(),c.refresh(),o+=1,P({type:`route-reset`})},resetRecordingCache:()=>l.reset(),lookupRecording:(e,t)=>l.lookup(e,t),loadRecording:R,isTargetActive:e=>$a(n.session,n.session?.passage?{...e,recordingId:null}:e),authorizePlayback(...e){let t=e.find(e=>!!(e&&e.status!==`missing`));return t?n.authorizePlayback(t):!1},pause:()=>n.pause(),play:I,async replayCurrentCue(){u=async()=>{await n.replayCurrentCue()},await n.replayCurrentCue()},toggle:e=>c.command({type:`toggle`,retry:e}),step:e=>c.command({type:`step`,delta:e}),seek(e){n.seek(e),c.refresh(`progress`)},setPlaybackRate:(e,t)=>c.command({type:`set-rate`,rate:e,snap:t}),syncHighlight:e=>c.syncHighlight(e),restoreActiveHighlight:z,activateToken:te,activateSessionToken:ne,cueForToken(e){let t=n.session?.cues.find(t=>X(t)===e);return t?Object.freeze({...t}):null},tokenIndex:e=>n.session?.tokenKeys.indexOf(e)??-1,protectedCuePageNumbers(e){let t=n.session;if(!t?.cues.length)return[];let i=Math.max(0,r.getCueIndex(t.cues,n.currentTime)),a=[];for(let n=i;n<t.cues.length&&a.length<=e;n+=1){let e=t.cues[n]?.pageNumber;Number.isInteger(e)&&e>0&&!a.includes(e)&&a.push(e)}return Object.freeze(a)},closeOverlay:()=>c.closeOverlay(),cueAuthoringAdapter:()=>B,recordingHarnessAdapter:()=>V}}var co=class extends Error{constructor(e,t){super(e),this.name=`MountCleanupError`,this.errors=t}};function lo(e){return e instanceof co?e.errors:[e]}function uo(e){return typeof e!=`object`&&typeof e!=`function`||e===null?!1:typeof e.then==`function`}function fo(){let e=null,t=!1,n=t=>{if(t.destroyed)return;t.destroyed=!0,e===t&&(e=null);let n=[];try{t.controller.abort()}catch(e){n.push(e)}let r=t.teardowns.splice(0);for(let e=r.length-1;e>=0;--e)try{r[e]()}catch(e){n.push(e)}if(n.length)throw new co(`Mount teardown failed`,n)};return r=>{if(t)throw Error(`Mount transitions cannot be nested`);t=!0;try{e&&n(e);let i={controller:new AbortController,teardowns:[],destroyed:!1};e=i;let a=e=>{if(typeof e!=`function`)throw TypeError(`Owned teardown must be a function`);let t=!0,n=()=>{if(!t)return;t=!1;let r=i.teardowns.indexOf(n);r>=0&&i.teardowns.splice(r,1),e()};return i.destroyed?n():i.teardowns.push(n),n};try{if(uo(r({signal:i.controller.signal,own:a})))throw TypeError(`Mount setup must be synchronous`)}catch(e){try{n(i)}catch(t){throw new co(`Mount setup and rollback failed`,[e,...lo(t)])}throw e}return()=>{if(!i.destroyed){if(t)throw Error(`Mount transitions cannot be nested`);t=!0;try{n(i)}finally{t=!1}}}}finally{t=!1}}}function po(e){return ye(e)}function mo({audioId:e,label:t,tokenKey:n,timeStart:r}){if(!ge(n))throw TypeError(`Invalid checkpoint token key: ${n}`);return{id:`cue:${e}:${n}`,kind:`cue`,source:`playback`,label:t,audioId:e,tokenKey:n,timeStart:r}}function ho(e){if(!ge(e.tokenKey))throw TypeError(`Invalid recording-issue token key: ${e.tokenKey}`);return{id:`issue:${e.id}`,kind:`recording-issue`,source:`recording-issue`,label:e.note?.trim()||e.kind,audioId:e.audioId,tokenKey:e.tokenKey,timeStart:e.timeStart,createdAt:e.createdAt}}function go(e,t){let n=po(e.tokenKey),r=po(t.tokenKey);return(n&&r?me(n,r):n?-1:r?1:e.tokenKey.localeCompare(t.tokenKey))||(e.timeStart??0)-(t.timeStart??0)}var _o=`tikkun.bookmarks`;function vo({hash:e,label:t,tokenKey:n,audioId:r,timeStart:i,createdAt:a=Date.now()}){return{id:`bookmark:${n}:${a}`,hash:e,label:t,tokenKey:n,...r?{audioId:r}:{},...i===void 0?{}:{timeStart:i},createdAt:a}}function yo(e,t=R){if(!e||typeof e!=`object`)return!1;let n=e;return typeof n.id==`string`&&n.id.length>0&&typeof n.hash==`string`&&R(n.hash)&&t(n.hash)&&typeof n.label==`string`&&n.label.trim().length>0&&typeof n.tokenKey==`string`&&ge(n.tokenKey)&&typeof n.createdAt==`number`&&Number.isSafeInteger(n.createdAt)&&n.createdAt>=0&&(n.audioId===void 0||typeof n.audioId==`string`&&n.audioId.length>0)&&(n.timeStart===void 0||typeof n.timeStart==`number`&&Number.isFinite(n.timeStart)&&n.timeStart>=0)}function bo(e){return G({storage:e,key:_o,validate:e=>Array.isArray(e)})}function xo(e,t=R){let n=bo(e).read();return n.status===`unavailable`?(console.error(`Failed to read reader bookmarks`,n.error),{bookmarks:[],revision:null}):n.status===`invalid`?(n.reason===`invalid-json`?console.error(`Failed to parse reader bookmarks`,n.error):console.error(`Invalid reader bookmarks`),{bookmarks:[],revision:n.revision}):n.status===`missing`?{bookmarks:[],revision:n.revision}:{bookmarks:n.value.filter(e=>yo(e,t)).sort((e,t)=>t.createdAt-e.createdAt),revision:n.revision}}function So(e,t,n){let r=new Set,i=new Set;if(t.some(e=>!yo(e)||r.has(e.id)||i.has(e.tokenKey)?!0:(r.add(e.id),i.add(e.tokenKey),!1)))throw TypeError(`Cannot persist invalid or duplicate reader bookmarks`);try{let r=bo(e),i=[...t].sort((e,t)=>t.createdAt-e.createdAt),a=n;if(!a){let e=r.read();if(e.status===`unavailable`)throw e.error;a=e.revision}return K(r.write(i,a))}catch(e){throw new Co(e)}}var Co=class extends Error{constructor(e){super(`Failed to save reader bookmarks`),this.name=`BookmarkStorageError`,this.cause=e}};function wo(e,t){let{load:n=()=>L(()=>import(`./qZcP8U3E.js`),__vite__mapDeps([18,1,2,9,7,8,10,19,20,21,13,22,6,16,23]),import.meta.url),onLoadError:r,...i}=t,a=i.document.querySelector(`[data-target-id="settings-toggle"]`);if(!a)throw Error(`Lazy Reader Settings requires [data-target-id="settings-toggle"]`);let o=null,s=null,c=null,l=null,u=0,d=e=>{e?a.setAttribute(`aria-busy`,`true`):a.removeAttribute(`aria-busy`)},f=()=>{if(o)return Promise.resolve(o);if(c)return c;s??=n();let t=s.then(t=>e.signal.aborted?null:(o=t.createReaderSettings(e,i),o)).catch(t=>(s=null,e.signal.aborted||r(t),null)).finally(()=>{c===t&&(c=null)});return c=t,t},p=(t={})=>{if(e.signal.aborted)return;if(o){o.open(t);return}l=t,d(!0);let n=++u;f().then(t=>{if(e.signal.aborted||n!==u||l===null)return;let r=l;l=null,d(!1),t?.open(r)})},m=e=>{let t=l!==null;return l=null,u+=1,d(!1),o?.close(e)??t},h={open:p,close:m,sync:()=>o?.sync()};return a.addEventListener(`click`,()=>{if(l!==null){m();return}o?.close()||p({returnFocus:a})},{signal:e.signal}),e.own(()=>{l=null,u+=1,d(!1),o=null,c=null,s=null}),h}var To=r(`<button class="toolbar-button mod-icon-label toolbar-share-current" data-target-id="share-current-reading" type="button" title="Share Reading" aria-label="Share Reading"><!></button>`),Eo=r(`<button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="media"><span>Media &amp; Storage</span><span class="toolbar-overflow-icon" aria-hidden="true"><!></span></button>`),Do=r(`<button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="share"><span>Share Reading</span><span class="toolbar-overflow-icon" aria-hidden="true"><!></span></button>`),Oo=r(`<button data-target-id="bookmark-current" type="button"><!></button> <!> <button class="toolbar-button mod-icon-label toolbar-overflow-toggle" data-target-id="toolbar-overflow-toggle" type="button" title="Reader controls" aria-label="Reader controls" aria-controls="toolbar-overflow-menu"><!></button> <div data-target-id="toolbar-overflow-menu" id="toolbar-overflow-menu" role="group" aria-label="Reader actions"><button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="bookmark"><span data-target-id="toolbar-overflow-bookmark-label"> </span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-bookmark-icon"><!></span></button> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="aliyah-rail"><span>Choose Aliyah</span></button> <button class="toolbar-overflow-item mod-aliyah-starts" type="button" data-toolbar-overflow-action="aliyah-starts"><span>Show Aliyah Starts</span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-aliyah-starts-icon" aria-hidden="true"><!></span></button> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="annotations"><span data-target-id="toolbar-overflow-annotations-label"> </span> <span class="toolbar-overflow-icon mod-annotations" data-target-id="toolbar-overflow-annotations-icon" aria-hidden="true"><span class="toggle mod-compact"><span class="annotations-toggle-icon"><span class="toggle-state mod-off">א</span> <span class="toggle-state mod-on">אֶ֨</span></span></span></span></button> <!> <!> <button class="toolbar-overflow-item" type="button" data-toolbar-overflow-action="settings"><span>Reader Settings</span> <span class="toolbar-overflow-icon" data-target-id="toolbar-overflow-settings-icon" aria-hidden="true"><!></span></button></div>`,1);function ko(n,r){ee(r,!0);function i(){return{...r.getState()}}let o=m(y(i())),s=m(!1),u=m(!1),f;function h(){S(()=>{D(o,i(),!0)})}function _({restoreFocus:e=!1}={}){return l(s)?(S(()=>{D(s,!1)}),e&&f.focus({preventScroll:!0}),!0):!1}function x(e){if(e.stopPropagation(),l(s)){_();return}h(),S(()=>{D(s,!0)})}function C(e){_(),e()}async function w(e=f){if(!(l(u)||!r.shareReading)){D(u,!0),_();try{await r.shareReading(e)}finally{S(()=>{D(u,!1)}),e.isConnected&&e.focus({preventScroll:!0})}}}function T(e){let t=r.document.defaultView?.Element;return!!(t&&e instanceof t)}let O={close:_,sync:h};k(()=>{let e=e=>{!l(s)||!T(e.target)||e.target.closest(`[data-target-id="toolbar-overflow-menu"]`)||e.target.closest(`[data-target-id="toolbar-overflow-toggle"]`)||_()},t=e=>{e.key!==`Escape`||!l(s)||(e.preventDefault(),_({restoreFocus:!0}))};return r.connect(O),r.document.addEventListener(`pointerdown`,e),r.document.addEventListener(`keydown`,t),()=>{r.document.removeEventListener(`pointerdown`,e),r.document.removeEventListener(`keydown`,t),_()}});var M=Oo(),I=E(M);let L;var R=j(I);{let e=g(()=>l(o).bookmarked?`bookmarkFilled`:`bookmark`);Z(R,{get name(){return l(e)}})}c(I);var te=A(I,2),ne=n=>{var r=To(),i=j(r);Z(i,{name:`link`}),c(r),d(()=>r.disabled=l(u)||!l(o).shareAvailable),e(`click`,r,e=>w(e.currentTarget)),t(n,r)};b(te,e=>{r.shareReading&&e(ne)});var z=A(te,2),re=j(z);Z(re,{name:`cog`}),c(z),p(z,e=>f=e,()=>f);var B=A(z,2);let V;var ie=j(B),ae=j(ie),oe=j(ae,!0);c(ae);var se=A(ae,2),H=j(se);{let e=g(()=>l(o).bookmarked?`bookmarkFilled`:`bookmark`);Z(H,{get name(){return l(e)}})}c(se),c(ie);var U=A(ie,2),W=A(U,2),G=A(j(W),2),K=j(G);Z(K,{name:`chevronDown`}),c(G),c(W);var q=A(W,2),J=j(q),ce=j(J,!0);c(J),P(2),c(q);var le=A(q,2),Y=n=>{var i=Eo(),a=A(j(i)),o=j(a);Z(o,{name:`download`}),c(a),c(i),e(`click`,i,()=>C(()=>r.openMedia?.(f))),t(n,i)};b(le,e=>{r.openMedia&&e(Y)});var ue=A(le,2),de=n=>{var r=Do(),i=A(j(r)),a=j(i);Z(a,{name:`link`}),c(i),c(r),d(()=>r.disabled=l(u)||!l(o).shareAvailable),e(`click`,r,()=>w()),t(n,r)};b(ue,e=>{r.shareReading&&e(de)});var fe=A(ue,2),pe=A(j(fe),2),me=j(pe);Z(me,{name:`settings2`}),c(pe),c(fe),c(B),d(()=>{L=F(I,1,`toolbar-button mod-icon-label`,null,L,{"is-active":l(o).bookmarked}),v(I,`title`,l(o).bookmarked?`Remove bookmark`:`Bookmark current word`),v(I,`aria-label`,l(o).bookmarked?`Remove bookmark`:`Bookmark current word`),v(I,`aria-pressed`,l(o).bookmarked),I.disabled=!l(o).bookmarkAvailable,v(z,`aria-expanded`,l(s)),V=F(B,1,`toolbar-overflow-menu`,null,V,{"u-hidden":!l(s)}),v(B,`aria-hidden`,!l(s)),ie.disabled=!l(o).bookmarkAvailable,a(oe,l(o).bookmarked?`Remove Bookmark`:`Bookmark Word`),U.disabled=!l(o).aliyahNavigationAvailable,W.disabled=!l(o).aliyahNavigationAvailable,v(q,`aria-pressed`,l(o).annotationsEnabled),a(ce,l(o).annotationsEnabled?`Hide Nekudot`:`Show Nekudot`)}),e(`click`,I,function(...e){r.toggleBookmark?.apply(this,e)}),e(`click`,z,x),e(`click`,ie,()=>C(r.toggleBookmark)),e(`click`,U,()=>C(()=>r.openAliyahNavigation(f))),e(`click`,W,()=>C(r.showAliyahStarts)),e(`click`,q,()=>C(r.toggleAnnotations)),e(`click`,fe,()=>C(()=>r.openSettings(f))),t(n,M),N()}I([`click`]);function Ao(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Controls requires ${t}`);return n}function jo(e,t){let n=Ao(t.document,`[data-target-id="reader-controls-root"]`);if(n.childNodes.length)throw Error(`Reader Controls requires an empty controls root`);let r=null,a=()=>r,o=i(ko,{target:n,props:{...t,connect:e=>{r=e}}});S();let c=a();if(!c)throw s(o),Error(`Reader Controls did not connect its component API`);return e.own(()=>{c.close(),s(o).catch(e=>{console.error(`Failed to unmount Reader Controls`,e)})}),c}var Mo=r(`<header class="app-toolbar" data-reader-shell-owner="true"><div class="toolbar-content u-page-wrap"><div class="toolbar-wrapper mod-left"><div class="toolbar-item"><button data-target-id="about-link" type="button">About</button> <button class="mobile-library-button" data-target-id="mobile-library" type="button" title="Home" aria-label="Open main page"><span class="mobile-library-icon" data-target-id="mobile-library-icon"><!></span></button></div></div> <div class="toolbar-wrapper mod-center"><div class="toolbar-item"><button class="parsha-title" data-target-id="parsha-title" data-tooltip="Tip: Press Cmd/Ctrl+K to search"> </button></div></div> <div class="toolbar-wrapper mod-right"><div class="toolbar-item"><div class="aliyah-navigation-root" data-target-id="aliyah-toolbar-root"></div> <div class="reader-controls-root" data-target-id="reader-controls-root"></div> <button data-target-id="settings-toggle" type="button" title="Reader settings" aria-label="Reader settings" aria-haspopup="dialog" aria-expanded="false" aria-controls="reader-settings-pane"><!></button></div></div></div></header> <div class="aliyah-navigation-root" data-target-id="aliyah-navigation-layer-root"></div> <div class="last-reading-prompt u-hidden" data-target-id="last-reading-prompt" role="status" aria-live="polite"><span data-target-id="last-reading-copy">Resume reading?</span> <button class="last-reading-button" data-target-id="last-reading-resume" type="button">Resume</button> <button class="last-reading-dismiss" data-target-id="last-reading-dismiss" type="button" aria-label="Dismiss reading prompt"></button></div> <div data-target-id="reader-progress-mobile" aria-hidden="true"><div class="reader-progress-mobile-fill" data-target-id="reader-progress-mobile-fill"></div></div> <div id="js-app" class="app-body"><main data-target-id="reader-shell" aria-label="Torah reader"><div><div data-target-id="floating-player-root"></div></div> <div class="reader-main" style="direction: rtl"><div class="reader-text-forehead" data-target-id="reader-text-forehead" aria-label="Torah and Tikkun sides"><div class="reader-side-heading mod-left" lang="he" dir="rtl"><span data-reader-heading-form="torah">תורה</span> <span data-reader-heading-form="tikkun">תיקון</span></div> <button class="reader-side-swap" data-target-id="reader-side-swap" data-reader-no-form-toggle="true" type="button" title="Swap Torah and Tikkun sides" aria-label="Swap Torah and Tikkun sides"><!></button> <div class="reader-side-heading mod-right" lang="he" dir="rtl"><span data-reader-heading-form="torah">תורה</span> <span data-reader-heading-form="tikkun">תיקון</span></div></div> <div data-target-id="tikkun-book" tabindex="-1"></div></div> <div><div data-target-id="reader-progress" role="progressbar" aria-label="Reading progress" aria-valuemin="0" aria-valuemax="100"><div class="reader-progress-label" data-target-id="reader-progress-label"> </div> <div class="reader-progress-rail"><div class="reader-progress-fill" data-target-id="reader-progress-fill"></div></div> <div class="reader-progress-percent" data-target-id="reader-progress-percent"> </div></div></div></main> <section data-target-id="about-view"></section></div> <div><button data-test-id="annotations-toggle" data-target-id="annotations-toggle" data-tooltip="Tip: Hold &quot;Shift&quot; to toggle quickly" data-tooltip-position="top-left" type="button"><span class="toggle" aria-hidden="true"><span class="shadowed-circle"><span class="toggle-state mod-off">א</span> <span class="toggle-state mod-on">אֶ֨</span></span></span></button></div> <div data-target-id="settings-root"></div>`,1);function No(n,r){ee(r,!0);let i=f(r,`onSwapSides`,3,()=>{});function o(){return r.initialTitle}function s(){return r.initialAnnotationsEnabled}let h=m(`reader`),b=m(!1),x=m(y(o())),C=m(y({label:`—`,percent:0})),w=m(y(s())),T,O=m(!1),I=`--mobile-parsha-title-font-size`,L=g(()=>l(h)===`reader`&&!l(b));function R(e){S(()=>{D(h,e,!0)})}function te(e){S(()=>{D(b,e,!0)})}function ne(e){S(()=>{D(x,e,!0)}),z()}function z(){T.style.removeProperty(I);let e=T.ownerDocument.defaultView;if(!e)throw Error(`Reader Shell title requires a browser window`);if(!e.matchMedia(`(max-width: 550px)`).matches)return;let t=e.getComputedStyle(T),n=Number.parseFloat(t.paddingInlineStart)+Number.parseFloat(t.paddingInlineEnd),r=T.clientWidth-n,i=T.ownerDocument.createRange();i.selectNodeContents(T);let a=i.getBoundingClientRect().width;if(r<=0||a<=r+.5)return;let o=Number.parseFloat(t.fontSize),s=Math.max(9,Math.floor(o*(r-1)*100/a)/100);T.style.setProperty(I,`${s}px`)}function re(e){if(e.percent!==void 0&&!Number.isFinite(e.percent))throw TypeError(`Reader Shell progress must be finite`);S(()=>{D(C,{label:e.label??l(C).label,percent:e.percent===void 0?l(C).percent:Math.max(0,Math.min(100,Math.round(e.percent)))},!0)})}function B(e){S(()=>{D(w,e,!0)})}function V(){T.focus({preventScroll:!0})}let ie={setView:R,setPickerOpen:te,setTitle:ne,setProgress:re,setAnnotationsEnabled:B,focusTitle:V,isReaderVisible:()=>l(h)===`reader`};k(()=>{let e=T.closest(`.toolbar-content`);if(!e)throw Error(`Reader Shell toolbar is missing`);let t=T.ownerDocument,n=t.defaultView;if(!n)throw Error(`Reader Shell toolbar requires a browser window`);let i=new n.ResizeObserver(z);i.observe(e);let a=!0;return z(),t.fonts.ready.then(()=>{a&&z()}),r.connect(ie),()=>{a=!1,i.disconnect()}});var ae=Mo();u(`pointerdown`,_,()=>{D(O,!0)}),u(`keydown`,_,()=>{D(O,!1)});var oe=E(ae),se=j(oe),H=j(se),U=j(H),W=j(U);let G;var K=A(W,2),q=j(K),J=j(q);Z(J,{name:`houseFilled`}),c(q),c(K),c(U),c(H);var ce=A(H,2),le=j(ce),Y=j(le),ue=j(Y,!0);c(Y),p(Y,e=>T=e,()=>T),c(le),c(ce);var de=A(ce,2),fe=j(de),pe=A(j(fe),4);let me;var he=j(pe);Z(he,{name:`settings2`}),c(pe),c(fe),c(de),c(se),c(oe);var ge=A(oe,6);let _e;var ve=j(ge);let ye;c(ge);var X=A(ge,2),be=j(X);let xe;var Se=j(be);let Ce;var we=A(Se,2),Te=j(we),Ee=j(Te),De=A(Ee,2),Oe=j(De);Z(Oe,{name:`arrowLeftRight`}),c(De);var ke=A(De,2);c(Te);var Ae=A(Te,2);let je;c(we);var Me=A(we,2);let Ne;var Pe=j(Me);let Fe;var Ie=j(Pe),Le=j(Ie,!0);c(Ie);var Re=A(Ie,2),Q=j(Re);let $;c(Re);var ze=A(Re,2),Be=j(ze);c(ze),c(Pe),c(Me),c(be);var Ve=A(be,2);let He;c(X);var Ue=A(X,2);let We;var Ge=j(Ue);let Ke;c(Ue),P(2),d(()=>{v(oe,`data-header-pointer`,l(O)||void 0),G=F(W,1,`toolbar-button`,null,G,{"u-hidden":l(b),"mod-animated":l(b)}),a(ue,l(x)),me=F(pe,1,`toolbar-button`,null,me,{"u-hidden":l(b),"mod-animated":l(b)}),_e=F(ge,1,`reader-progress-mobile`,null,_e,{"u-hidden":!l(L),"mod-animated":!l(L)}),ye=M(ve,``,ye,{"--reader-progress-ratio":`${l(C).percent/100}`}),xe=F(be,1,`reader-shell`,null,xe,{"u-hidden":l(h)!==`reader`}),Ce=F(Se,1,`reader-side mod-left`,null,Ce,{"u-hidden":!l(L),"mod-animated":!l(L)}),Ee.dir=Ee.dir,ke.dir=ke.dir,je=F(Ae,1,`tikkun-book`,null,je,{"mod-annotations-on":l(w),"mod-annotations-off":!l(w),"u-hidden":l(b),"mod-animated":l(b)}),Ne=F(Me,1,`reader-side mod-right`,null,Ne,{"u-hidden":!l(L),"mod-animated":!l(L)}),Fe=F(Pe,1,`reader-progress`,null,Fe,{"u-hidden":!l(L),"mod-animated":!l(L)}),v(Pe,`aria-valuenow`,l(C).percent),v(Pe,`aria-valuetext`,`${l(C).label}, ${l(C).percent}%`),a(Le,l(C).label),$=M(Q,``,$,{"--reader-progress-ratio":`${l(C).percent/100}`}),a(Be,`${l(C).percent??``}%`),He=F(Ve,1,`about-route`,null,He,{"u-hidden":l(h)!==`optional`}),We=F(Ue,1,`reader-corner-controls`,null,We,{"u-hidden":!l(L),"mod-animated":!l(L)}),Ke=F(Ge,1,`annotations-toggle`,null,Ke,{"u-hidden":l(b),"mod-animated":l(b)}),v(Ge,`title`,l(w)?`Hide nekudot`:`Show nekudot`),v(Ge,`aria-label`,l(w)?`Hide nekudot and cantillation marks`:`Show nekudot and cantillation marks`),v(Ge,`aria-pressed`,l(w))}),e(`click`,W,function(...e){r.onAboutClick?.apply(this,e)}),e(`click`,K,function(...e){r.onAboutClick?.apply(this,e)}),e(`click`,Y,function(...e){r.onTitleClick?.apply(this,e)}),e(`click`,De,function(...e){i()?.apply(this,e)}),e(`click`,Ge,()=>r.onAnnotationsChange(!l(w))),t(n,ae),N()}I([`click`]);function Po(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Shell requires ${t}`);return n}function Fo(e,t){let n=Po(t.document,`[data-target-id="app-root"]`),r=Po(t.document,`[data-target-id="reader-shell-anchor"]`);if(r.parentElement!==n)throw Error(`Reader Shell anchor must be a direct child of the app root`);if(n.querySelector(`[data-reader-shell-owner="true"]`))throw Error(`Reader Shell is already mounted`);let a=null,o=()=>a,c=i(No,{target:n,anchor:r,props:{initialTitle:t.initialTitle,initialAnnotationsEnabled:t.initialAnnotationsEnabled,onTitleClick:t.onTitleClick,onAboutClick:t.onAboutClick,onAnnotationsChange:t.onAnnotationsChange,onSwapSides:t.onSwapSides,connect:e=>{a=e}}});S();let l=o();if(!l)throw s(c),Error(`Reader Shell did not connect its component interface`);return e.own(()=>{s(c).catch(e=>{console.error(`Failed to unmount Reader Shell`,e)})}),l}var Io=e=>e.length?e.length===1?e[0]:[e[0],e[e.length-1]].join(`-`):``,Lo={asVersesRange:e=>Io(e.map(e=>{let t=[];return e.v===1&&t.push(e.c),t.push(e.v),t.map(e=>cn(e)).join(`:`)}))},Ro={schemaVersion:1,tradition:`contemporary-ashkenazi-sephardi`,entries:[{id:`genesis-2-4-small-he`,verse:{book:1,chapter:2,verse:4},word:{text:`בהבראם`,occurrence:1},letter:{text:`ה`,position:2},form:{type:`small`}},{id:`genesis-23-2-small-kaf`,verse:{book:1,chapter:23,verse:2},word:{text:`ולבכתה`,occurrence:1},letter:{text:`כ`,position:4},form:{type:`small`}},{id:`genesis-27-46-small-qof`,verse:{book:1,chapter:27,verse:46},word:{text:`קצתי`,occurrence:1},letter:{text:`ק`,position:1},form:{type:`small`}},{id:`leviticus-1-1-small-alef`,verse:{book:3,chapter:1,verse:1},word:{text:`ויקרא`,occurrence:1},letter:{text:`א`,position:5},form:{type:`small`}},{id:`leviticus-6-2-small-mem`,verse:{book:3,chapter:6,verse:2},word:{text:`מוקדה`,occurrence:1},letter:{text:`מ`,position:1},form:{type:`small`}},{id:`numbers-10-35-inverted-nun`,verse:{book:4,chapter:10,verse:35},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-10-36-inverted-nun`,verse:{book:4,chapter:10,verse:36},word:{text:`׆`,occurrence:1},letter:{text:`׆`,position:1},form:{type:`inverted`}},{id:`numbers-25-11-small-yod`,verse:{book:4,chapter:25,verse:11},word:{text:`פינחס`,occurrence:1},letter:{text:`י`,position:2},form:{type:`small`}},{id:`deuteronomy-32-18-small-yod`,verse:{book:5,chapter:32,verse:18},word:{text:`תשי`,occurrence:1},letter:{text:`י`,position:3},form:{type:`small`}}]},zo=e=>!!e&&typeof e==`object`&&!Array.isArray(e),Bo=e=>Number.isSafeInteger(e)&&Number(e)>0,Vo=e=>typeof e==`string`&&/^[א-ת]$/u.test(e),Ho=e=>e.match(/[א-ת\u05c6]/gu)?.join(``)??``,Uo=(e,t)=>{let n=`Special-letter entry ${t+1}`;if(!zo(e))throw Error(`${n} must be an object`);let{id:r,verse:i,word:a,letter:o,form:s}=e;if(typeof r!=`string`||!/^[a-z0-9-]+$/.test(r))throw Error(`${n} has an invalid id`);if(!zo(i)||!Bo(i.book)||!Bo(i.chapter)||!Bo(i.verse))throw Error(`${n} has an invalid verse`);if(!zo(a)||typeof a.text!=`string`||Ho(a.text)!==a.text||!Bo(a.occurrence))throw Error(`${n} has an invalid word target`);if(!zo(o)||!(Vo(o.text)||o.text===`׆`)||!Bo(o.position)||Array.from(a.text)[o.position-1]!==o.text)throw Error(`${n} has an invalid letter target`);if(!zo(s)||s.type!==`small`&&s.type!==`inverted`)throw Error(`${n} has an unsupported form`);if(s.type===`inverted`?a.text!==`׆`||o.text!==`׆`:!Vo(o.text))throw Error(`${n} has an invalid target for its form`);return{id:r,verse:{book:i.book,chapter:i.chapter,verse:i.verse},word:{text:a.text,occurrence:a.occurrence},letter:{text:o.text,position:o.position},form:{type:s.type}}},Wo=(e=>{if(!zo(e)||e.schemaVersion!==1)throw Error(`Special-letter catalog has an unsupported schema version`);if(typeof e.tradition!=`string`||!e.tradition.trim())throw Error(`Special-letter catalog must name its tradition`);if(!Array.isArray(e.entries))throw Error(`Special-letter catalog entries must be an array`);let t=e.entries.map(Uo),n=new Set,r=new Set;for(let e of t){if(n.has(e.id))throw Error(`Duplicate special-letter id: ${e.id}`);n.add(e.id);let t=[e.verse.book,e.verse.chapter,e.verse.verse,e.word.text,e.word.occurrence,e.letter.position].join(`:`);if(r.has(t))throw Error(`Duplicate special-letter target: ${t}`);r.add(t)}return{schemaVersion:1,tradition:e.tradition,entries:t}})(Ro),Go=({b:e,c:t,v:n})=>`${e}:${t}:${n}`,Ko=({verse:e})=>`${e.book}:${e.chapter}:${e.verse}`,qo=Wo.entries.reduce((e,t)=>{let n=Ko(t);return e.set(n,[...e.get(n)??[],t]),e},new Map),Jo=(e,t)=>`<span
  class="special-letter mod-${t.form.type}"
  data-special-letter-id="${t.id}"
  data-special-letter-form="${t.form.type}"
  data-special-letter-position="${t.letter.position}"
>${e}</span>`,Yo=(e,t)=>{let n=new Map(t.map(e=>[e.letter.position,e])),r=0;return(e.match(/.\p{Mark}*/gu)??[]).map(e=>{let t=e.match(/[א-ת\u05c6]/u)?.[0];if(!t)return e;r+=1;let i=n.get(r);return!i||i.letter.text!==t?e:Jo(e,i)}).join(``)},Xo=e=>{let t=[...new Set(e.filter(e=>!!e).map(Go))].flatMap(e=>qo.get(e)??[]),n=new Map;return e=>{let r=Ho(e),i=t.filter(e=>e.word.text===r);if(!i.length)return e;let a=(n.get(r)??0)+1;n.set(r,a);let o=i.filter(e=>e.word.occurrence===a);return o.length?Yo(e,o):e}};function Zo(e,t){let n=(t,n)=>e[t]?.[n]??0,r=Math.max(n(`fragments-3`,0),n(`fragments-3`,2),n(`closing`,0)),i=n(`fragments-3`,1),a=Math.max(...e[`fragments-2`]??[],n(`extended-left`,0),n(`penultimate`,1)),o=n(`extended-left`,1),s=n(`penultimate`,0);return{required:Math.max(n(`opening`,0),2*r+i+2*t,2*a+t,a+o+t,s+a+t,r+n(`closing`,1)+t),outer:r,middle:i,half:a,extendedLeft:o,penultimateRight:s}}var Qo=`opening.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.extended-left.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.fragments-2.fragments-3.penultimate.closing`.split(`.`);function $o(e,t){if(e!==78)return null;let n=Qo[t-5];return n?{pattern:n}:null}var es=e=>e?`mod-petucha`:``,ts=e=>e.length>1?`mod-setuma`:``,ns=e=>e.replace(/&/g,`&amp;`).replace(/"/g,`&quot;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),rs=e=>e.normalize(`NFD`).replace(/\p{M}/gu,``),is=({annotatedText:e,unannotatedText:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,fragmentIndex:a,renderAnnotatedSpecialLetters:o,renderUnannotatedSpecialLetters:s,readingLayout:c})=>{let l=be(e),u=be(t),d=Math.max(l.length,u.length);return Array.from({length:d},(e,t)=>{let d=l[t],f=u[t],p=d?o(d.text):``,m=f?s(f.text):``,h=n?d:f,g=n?p:m,_=n?m:p,v=`${r}:${i}:${a}:${t}`,y=!!d?.text.includes(`׃`);return`<span
        class="word ${h?.isKri?`ktiv-kri`:``}${y?` mod-sof-pasuk`:``}"
        ${Se(d?.text??``)?``:`data-token-key="${v}"`}
        data-page-number="${r}"
        data-line-index="${i}"
        data-fragment-index="${a}"
        data-word-index="${t}"
        data-annotations-mode="${n?`on`:`off`}"
        data-annotations-alternate="${ns(_)}"
        data-annotations-on-text="${ns(d?.text??``)}"
        data-annotations-on-present="${!!d}"
        data-annotations-off-present="${!!f}"
        data-annotations-on-kri="${!!d?.isKri}"
        data-annotations-off-kri="${!!f?.isKri}"
        ${h?``:`hidden`}
      >${g}</span>${c&&y?`<br class="reader-pasuk-break" aria-hidden="true">`:``}`}).join(` `)},as=e=>e.replace(/([־-])/g,`$1<wbr>`),os=e=>e?.leining.date.title.he.replace(/^פרשת /,``)??e?.leining.date.title.en.replace(/^Parshat\s+/i,``)??``,ss=new Map([[1,`ראשון`],[2,`שני`],[3,`שלישי`],[4,`רביעי`],[5,`חמישי`],[6,`ששי`],[7,`שביעי`],[`Maftir`,`מפטיר`]]),cs=e=>e.map(e=>ss.get(e.index)).filter(Boolean).join(`, `),ls=({c:e,v:t})=>`${cn(e)}:${cn(t)}`,us=e=>e.map(e=>{let t=ls(e.start),n=e.start.c===e.end.c?cn(e.end.v):ls(e.end);return t===n?t:`${t}-${n}`}).join(`, `),ds=(e,t,n,r)=>`
  <span
    class="aliyah-badge${n?.index?` mod-with-audio`:``}"
    ${n?.index?`data-aliyah-marker="true"`:``}
    ${t?`data-run-id="${t}"`:``}
    ${n?.index?`data-aliyah-index="${n.index}"`:``}
  >
    ${n?.index?`<button
            type="button"
            class="aliyah-audio-button"
            data-audio-button="true"
            data-run-id="${t}"
            data-aliyah-index="${n.index}"
            aria-label="Play ${e}"
          >${Fe(`play`)}</button>`:``}
    <span class="aliyah-label-text">${as(e)}</span>
    ${fs(e,r,n)}
  </span>
`,fs=(e,t,n)=>!t||!n?.start?``:`
    <button
      type="button"
      class="aliyah-link"
      data-aliyah-link="true"
      data-aliyah-url="${ns(Jn(t,n.start))}"
      aria-label="Copy link to ${ns(e)}"
      title="Copy link to ${ns(e)}"
    ><span data-aliyah-link-icon="link">${Fe(`link`)}</span><span data-aliyah-link-icon="check" hidden>${Fe(`check`)}</span></button>
  `,ps=(e,t,n,r)=>{let i=t?.b===2&&$o(n,r);return i?{kind:`sea`,pattern:i.pattern}:t&&t.b===5&&t.c===32&&t.v>=1&&t.v<=43&&e.length===2?{kind:`haazinu`,pattern:`columns-2`}:null},ms=({text:e,references:t,annotationsEnabled:n,pageNumber:r,lineIndex:i,presentation:a,surface:o})=>{let s=o===`tikkun`||o!==`torah`&&null,c=s??n,l=Xo(t),u=Xo(t);return`<div
    class="reader-text-side mod-${o}"
    data-reader-canonical="${o!==`torah`}"
    ${s===null?``:`data-reader-annotations="${c?`on`:`off`}"`}
    ${o===`torah`?`aria-hidden="true"`:``}
  >
    <div class="reader-text-flow">
      ${e.map((e,t)=>`
        <div class="column">
          ${e.map((n,o)=>{let s=Ce({text:n,annotated:!0}),d=a.layout===`reading`&&a.sides===`two`?rs(s):Ce({text:n,annotated:!1});return`
            <span class="fragment ${ts(e)}">${is({annotatedText:s,unannotatedText:d,annotationsEnabled:c,pageNumber:r,lineIndex:i,fragmentIndex:t*100+o,renderAnnotatedSpecialLetters:l,renderUnannotatedSpecialLetters:u,readingLayout:a.layout===`reading`})}</span>
          `}).join(``)}
        </div>
      `).join(``)}
    </div>
  </div>`},hs=({pageNumber:e,lineIndex:t,run:n,aliyahStarts:r,startTitle:i,startLabel:a,startVerse:o,mirror:s})=>`
    data-line-index="${t}"
    data-page-number="${e}"
    ${s?`data-reader-mirror="true"`:`data-class="line"`}
    ${n?`data-run-id="${n.id}"`:``}
    ${!s&&r.length?`data-aliyah-starts="${r.map(e=>e.index).join(`,`)}"`:``}
    ${!s&&r.length&&i?`data-aliyah-start-title="${ns(i)}"`:``}
    ${!s&&r.length&&a?`data-aliyah-start-label="${ns(a)}"`:``}
    ${!s&&r.length&&o?`data-aliyah-start-verse="${ns(o)}"`:``}
  `,gs=({pageNumber:e,text:t,verses:n,focalRef:r,isPetucha:i,labels:a,aliyahStarts:o,run:s,lineIndex:c,annotationsEnabled:l=!0,presentation:u=br,surface:d=`single`,mirror:f=!1,renderVerseGutter:p=!0,pageReference:m})=>{let h=cs(o),g=os(s),_=us(o),v=[r,...n],y=n[0]??r??m,b=u.layout===`match`?ps(t,y,e,c):null,x=u.layout===`match`?t.length>1||b!==null:!1,S=hs({pageNumber:e,lineIndex:c,run:s,aliyahStarts:o,startTitle:g,startLabel:h,startVerse:_,mirror:f}),C=u.sides===`two`&&d===`single`?[`tikkun`,`torah`].map(n=>ms({text:t,references:v,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:n})).join(``):ms({text:t,references:v,annotationsEnabled:l,pageNumber:e,lineIndex:c,presentation:u,surface:d});return u.layout===`reading`?`
      <div
        class="${f?`reader-mirror-line`:`line`} mod-reading-line${x?` mod-shirah`:``}"
        ${S}
      >
        <div class="line-content">${C}</div>
        ${p?`<div class="line-gutter mod-verses">
                <span class="location-indicator mod-verses">${Lo.asVersesRange(n)}</span>
              </div>`:``}
        ${f?``:`<div class="line-gutter mod-aliyot">
                <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>ds(e,s?.id,o[t],s)).join(``)}</span>
              </div>`}
      </div>
    `:`
  <tr
    class="${x?`mod-shirah`:``}"
    ${S}
    ${b?`data-shirah-kind="${b.kind}" data-shirah-pattern="${b.pattern}"`:``}
  >
    <td class="line ${es(i)}">
      <div class="line-content">${C}</div>
      <div class="line-gutter mod-verses">
        <span class="location-indicator mod-verses">${Lo.asVersesRange(n)}</span>
      </div>
      <div class="line-gutter mod-aliyot">
        <span class="location-indicator mod-aliyot" data-target-id="aliyot-range">${a.map((e,t)=>ds(e,s?.id,o[t],s)).join(``)}</span>
      </div>
    </td>
  </tr>
`},_s=(e,{annotationsEnabled:t=!0,presentation:n=br}={})=>{let r=e.lines.find(e=>e.verses.length)?.verses[0];if(n.layout===`reading`){let r=({surface:r=`single`,mirror:i=!1}={})=>e.lines.map((a,o)=>gs({pageNumber:e.pageNumber,lineIndex:o,annotationsEnabled:t,presentation:n,surface:r,mirror:i,...a})).join(``);return`
      <div
        class="reader-reading-page mod-${n.sides}-side"
        data-page-number="${e.pageNumber}"
      >
        <span class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</span>
        ${n.sides===`two`?`<div class="reader-reading-page-side mod-tikkun">${r({surface:`tikkun`})}</div>
               <div class="reader-reading-page-side mod-torah" aria-hidden="true">${r({surface:`torah`,mirror:!0})}</div>`:`<div class="reader-reading-page-side mod-single">${r()}</div>`}
      </div>
    `}return`
  <table data-page-number="${e.pageNumber}" data-reader-sides="${n.sides}">
    <caption class="tikkun-page-number" aria-hidden="true">${e.pageNumber}</caption>
    ${e.lines.map((i,a)=>gs({pageNumber:e.pageNumber,lineIndex:a,annotationsEnabled:t,presentation:n,pageReference:r,...i})).join(``)}
  </table>
`};function vs(e){return e.getBoundingClientRect().height||e.offsetHeight||null}function ys(e){let t=[...e].sort((e,t)=>e.pageNumber-t.pageNumber);return{mountedPageCount:t.filter(e=>e.state===`mounted`).length,pages:t}}var bs=`[
  {
    "text": [
      [
        "הַבָּאִ֥ים אַחֲרֵיהֶ֖ם בַּיָּ֑ם לֹֽא־נִשְׁאַ֥ר בָּהֶ֖ם עַד־אֶחָֽד׃ וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בַיַּבָּשָׁ֖ה בְּת֣וֹךְ הַיָּ֑ם וְהַמַּ֤יִם לָהֶם֙ חֹמָ֔ה מִֽימִינָ֖ם וּמִשְּׂמֹאלָֽם׃ וַיּ֨וֹשַׁע"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֜ה בַּיּ֥וֹם הַה֛וּא אֶת־יִשְׂרָאֵ֖ל מִיַּ֣ד מִצְרָ֑יִם וַיַּ֤רְא יִשְׂרָאֵל֙ אֶת־מִצְרַ֔יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מֵ֖ת עַל־שְׂפַ֥ת הַיָּֽם׃ וַיַּ֨רְא יִשְׂרָאֵ֜ל אֶת־הַיָּ֣ד הַגְּדֹלָ֗ה אֲשֶׁ֨ר עָשָׂ֤ה יְהֹוָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 14,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּמִצְרַ֔יִם וַיִּֽירְא֥וּ הָעָ֖ם אֶת־יְהֹוָ֑ה וַיַּֽאֲמִ֙ינוּ֙ בַּֽיהֹוָ֔ה וּבְמֹשֶׁ֖ה עַבְדּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        "אָ֣ז יָשִֽׁיר־מֹשֶׁה֩ וּבְנֵ֨י יִשְׂרָאֵ֜ל אֶת־הַשִּׁירָ֤ה הַזֹּאת֙ לַֽיהֹוָ֔ה וַיֹּאמְר֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 1
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֵאמֹ֑ר",
        " אָשִׁ֤ירָה לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה",
        " ס֥וּס"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " עָזִּ֤י וְזִמְרָת֙ יָ֔הּ וַֽיְהִי־לִ֖י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לִֽישׁוּעָ֑ה",
        " זֶ֤ה אֵלִי֙ וְאַנְוֵ֔הוּ",
        " אֱלֹהֵ֥י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָבִ֖י וַאֲרֹמְמֶֽנְהוּ׃",
        " יְהֹוָ֖ה אִ֣ישׁ מִלְחָמָ֑ה יְהֹוָ֖ה"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁמֽוֹ׃",
        " מַרְכְּבֹ֥ת פַּרְעֹ֛ה וְחֵיל֖וֹ יָרָ֣ה בַיָּ֑ם",
        " וּמִבְחַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָֽׁלִשָׁ֖יו טֻבְּע֥וּ בְיַם־סֽוּף׃",
        " תְּהֹמֹ֖ת יְכַסְיֻ֑מוּ יָרְד֥וּ בִמְצוֹלֹ֖ת כְּמוֹ־"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָֽבֶן׃",
        " יְמִֽינְךָ֣ יְהֹוָ֔ה נֶאְדָּרִ֖י בַּכֹּ֑חַ",
        " יְמִֽינְךָ֥"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה תִּרְעַ֥ץ אוֹיֵֽב׃",
        " וּבְרֹ֥ב גְּאוֹנְךָ֖ תַּהֲרֹ֣ס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 7
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָמֶ֑יךָ",
        " תְּשַׁלַּח֙ חֲרֹ֣נְךָ֔ יֹאכְלֵ֖מוֹ כַּקַּֽשׁ׃",
        " וּבְר֤וּחַ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַפֶּ֙יךָ֙ נֶ֣עֶרְמוּ מַ֔יִם",
        " נִצְּב֥וּ כְמוֹ־נֵ֖ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נֹזְלִ֑ים",
        " קָֽפְא֥וּ תְהֹמֹ֖ת בְּלֶב־יָֽם׃",
        " אָמַ֥ר"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אוֹיֵ֛ב אֶרְדֹּ֥ף אַשִּׂ֖יג",
        " אֲחַלֵּ֣ק שָׁלָ֑ל תִּמְלָאֵ֣מוֹ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "נַפְשִׁ֔י",
        " אָרִ֣יק חַרְבִּ֔י תּוֹרִישֵׁ֖מוֹ יָדִֽי׃",
        " נָשַׁ֥פְתָּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְרוּחֲךָ֖ כִּסָּ֣מוֹ יָ֑ם",
        " צָֽלְלוּ֙ כַּֽעוֹפֶ֔רֶת בְּמַ֖יִם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַדִּירִֽים׃",
        " מִֽי־כָמֹ֤כָה בָּֽאֵלִם֙ יְהֹוָ֔ה",
        " מִ֥י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כָּמֹ֖כָה נֶאְדָּ֣ר בַּקֹּ֑דֶשׁ",
        " נוֹרָ֥א תְהִלֹּ֖ת עֹ֥שֵׂה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶֽלֶא׃",
        " נָטִ֙יתָ֙ יְמִ֣ינְךָ֔ תִּבְלָעֵ֖מוֹ אָֽרֶץ׃",
        " נָחִ֥יתָ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 12
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 13
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְחַסְדְּךָ֖ עַם־ז֣וּ גָּאָ֑לְתָּ",
        " נֵהַ֥לְתָּ בְעׇזְּךָ֖ אֶל־נְוֵ֥ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קׇדְשֶֽׁךָ׃",
        " שָֽׁמְע֥וּ עַמִּ֖ים יִרְגָּז֑וּן",
        " חִ֣יל"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָחַ֔ז יֹשְׁבֵ֖י פְּלָֽשֶׁת׃",
        " אָ֤ז נִבְהֲלוּ֙ אַלּוּפֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱד֔וֹם",
        " אֵילֵ֣י מוֹאָ֔ב יֹֽאחֲזֵ֖מוֹ רָ֑עַד",
        " נָמֹ֕גוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כֹּ֖ל יֹשְׁבֵ֥י כְנָֽעַן׃",
        " תִּפֹּ֨ל עֲלֵיהֶ֤ם אֵימָ֙תָה֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וָפַ֔חַד",
        " בִּגְדֹ֥ל זְרוֹעֲךָ֖ יִדְּמ֣וּ כָּאָ֑בֶן",
        " עַד־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲבֹ֤ר עַמְּךָ֙ יְהֹוָ֔ה",
        " עַֽד־יַעֲבֹ֖ר עַם־ז֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קָנִֽיתָ׃",
        " תְּבִאֵ֗מוֹ וְתִטָּעֵ֙מוֹ֙ בְּהַ֣ר נַחֲלָֽתְךָ֔",
        " מָכ֧וֹן"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְשִׁבְתְּךָ֛ פָּעַ֖לְתָּ יְהֹוָ֑ה",
        " מִקְּדָ֕שׁ אֲדֹנָ֖י כּוֹנְנ֥וּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָדֶֽיךָ׃",
        " יְהֹוָ֥ה ׀ יִמְלֹ֖ךְ לְעֹלָ֥ם וָעֶֽד׃",
        " כִּ֣י"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 18
      },
      {
        "book": 2,
        "chapter": 15,
        "verse": 19
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָא֩ ס֨וּס פַּרְעֹ֜ה בְּרִכְבּ֤וֹ וּבְפָרָשָׁיו֙ בַּיָּ֔ם",
        " וַיָּ֧שֶׁב יְהֹוָ֛ה עֲלֵהֶ֖ם אֶת־מֵ֣י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַיָּ֑ם",
        " וּבְנֵ֧י יִשְׂרָאֵ֛ל הָלְכ֥וּ בַיַּבָּשָׁ֖ה בְּת֥וֹךְ הַיָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּקַּח֩ מִרְיָ֨ם הַנְּבִיאָ֜ה אֲח֧וֹת אַהֲרֹ֛ן אֶת־הַתֹּ֖ף בְּיָדָ֑הּ וַתֵּצֶ֤אןָ כׇֽל־הַנָּשִׁים֙"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֶ֔יהָ בְּתֻפִּ֖ים וּבִמְחֹלֹֽת׃ וַתַּ֥עַן לָהֶ֖ם מִרְיָ֑ם שִׁ֤ירוּ לַֽיהֹוָה֙ כִּֽי־גָאֹ֣ה גָּאָ֔ה ס֥וּס"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹכְב֖וֹ רָמָ֥ה בַיָּֽם׃",
        " וַיַּסַּ֨ע מֹשֶׁ֤ה אֶת־יִשְׂרָאֵל֙ מִיַּם־ס֔וּף וַיֵּצְא֖וּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶל־מִדְבַּר־שׁ֑וּר וַיֵּלְכ֧וּ שְׁלֹֽשֶׁת־יָמִ֛ים בַּמִּדְבָּ֖ר וְלֹא־מָ֥צְאוּ מָֽיִם׃ וַיָּבֹ֣אוּ"
      ]
    ],
    "verses": [
      {
        "book": 2,
        "chapter": 15,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָרָ֔תָה וְלֹ֣א יָֽכְל֗וּ לִשְׁתֹּ֥ת מַ֙יִם֙ מִמָּרָ֔ה כִּ֥י מָרִ֖ים הֵ֑ם עַל־כֵּ֥ן קָרָֽא־שְׁמָ֖הּ מָרָֽה׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  }
]`,xs=`[
  {
    "text": [
      [
        "וְאָעִ֣ידָה בָּ֔ם אֶת־הַשָּׁמַ֖יִם וְאֶת־הָאָֽרֶץ׃ כִּ֣י יָדַ֗עְתִּי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 29
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַחֲרֵ֤י מוֹתִי֙ כִּֽי־הַשְׁחֵ֣ת תַּשְׁחִת֔וּן וְסַרְתֶּ֣ם מִן־"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדֶּ֔רֶךְ אֲשֶׁ֥ר צִוִּ֖יתִי אֶתְכֶ֑ם וְקָרָ֨את אֶתְכֶ֤ם הָרָעָה֙"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּאַחֲרִ֣ית הַיָּמִ֔ים כִּֽי־תַעֲשׂ֤וּ אֶת־הָרַע֙ בְּעֵינֵ֣י יְהֹוָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְהַכְעִיס֖וֹ בְּמַעֲשֵׂ֥ה יְדֵיכֶֽם׃ וַיְדַבֵּ֣ר מֹשֶׁ֗ה בְּאׇזְנֵי֙ כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 31,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "קְהַ֣ל יִשְׂרָאֵ֔ל אֶת־דִּבְרֵ֥י הַשִּׁירָ֖ה הַזֹּ֑את עַ֖ד תֻּמָּֽם׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": true
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַאֲזִ֥ינוּ הַשָּׁמַ֖יִם וַאֲדַבֵּ֑רָה"
      ],
      [
        "וְתִשְׁמַ֥ע הָאָ֖רֶץ אִמְרֵי־פִֽי׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 1
      }
    ],
    "aliyot": [
      {
        "standard": 1
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַעֲרֹ֤ף כַּמָּטָר֙ לִקְחִ֔י"
      ],
      [
        "תִּזַּ֥ל כַּטַּ֖ל אִמְרָתִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 2
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּשְׂעִירִ֣ם עֲלֵי־דֶ֔שֶׁא"
      ],
      [
        "וְכִרְבִיבִ֖ים עֲלֵי־עֵֽשֶׂב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י שֵׁ֥ם יְהֹוָ֖ה אֶקְרָ֑א"
      ],
      [
        "הָב֥וּ גֹ֖דֶל לֵאלֹהֵֽינוּ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 3
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַצּוּר֙ תָּמִ֣ים פׇּֽעֳל֔וֹ"
      ],
      [
        "כִּ֥י כׇל־דְּרָכָ֖יו מִשְׁפָּ֑ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 4
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֵ֤ל אֱמוּנָה֙ וְאֵ֣ין עָ֔וֶל"
      ],
      [
        "צַדִּ֥יק וְיָשָׁ֖ר הֽוּא׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שִׁחֵ֥ת ל֛וֹ לֹ֖א בָּנָ֣יו מוּמָ֑ם"
      ],
      [
        "דּ֥וֹר עִקֵּ֖שׁ וּפְתַלְתֹּֽל׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 5
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַ לְיְהֹוָה֙ תִּגְמְלוּ־זֹ֔את"
      ],
      [
        "עַ֥ם נָבָ֖ל וְלֹ֣א חָכָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 6
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הֲלוֹא־הוּא֙ אָבִ֣יךָ קָּנֶ֔ךָ"
      ],
      [
        "ה֥וּא עָשְׂךָ֖ וַֽיְכֹנְנֶֽךָ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "זְכֹר֙ יְמ֣וֹת עוֹלָ֔ם"
      ],
      [
        "בִּ֖ינוּ שְׁנ֣וֹת דֹּר־וָדֹ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 7
      }
    ],
    "aliyot": [
      {
        "standard": 2
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שְׁאַ֤ל אָבִ֙יךָ֙ וְיַגֵּ֔דְךָ"
      ],
      [
        "זְקֵנֶ֖יךָ וְיֹ֥אמְרוּ לָֽךְ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּהַנְחֵ֤ל עֶלְיוֹן֙ גּוֹיִ֔ם"
      ],
      [
        "בְּהַפְרִיד֖וֹ בְּנֵ֣י אָדָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 8
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַצֵּב֙ גְּבֻלֹ֣ת עַמִּ֔ים"
      ],
      [
        "לְמִסְפַּ֖ר בְּנֵ֥י יִשְׂרָאֵֽל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּ֛י חֵ֥לֶק יְהֹוָ֖ה עַמּ֑וֹ"
      ],
      [
        "יַעֲקֹ֖ב חֶ֥בֶל נַחֲלָתֽוֹ׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 9
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִמְצָאֵ֙הוּ֙ בְּאֶ֣רֶץ מִדְבָּ֔ר"
      ],
      [
        "וּבְתֹ֖הוּ יְלֵ֣ל יְשִׁמֹ֑ן"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 10
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְסֹבְבֶ֙נְהוּ֙ יְב֣וֹנְנֵ֔הוּ"
      ],
      [
        "יִצְּרֶ֖נְהוּ כְּאִישׁ֥וֹן עֵינֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כְּנֶ֙שֶׁר֙ יָעִ֣יר קִנּ֔וֹ"
      ],
      [
        "עַל־גּוֹזָלָ֖יו יְרַחֵ֑ף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 11
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִפְרֹ֤שׂ כְּנָפָיו֙ יִקָּחֵ֔הוּ"
      ],
      [
        "יִשָּׂאֵ֖הוּ עַל־אֶבְרָתֽוֹ׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהֹוָ֖ה בָּדָ֣ד יַנְחֶ֑נּוּ"
      ],
      [
        "וְאֵ֥ין עִמּ֖וֹ אֵ֥ל נֵכָֽר׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 12
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יַרְכִּבֵ֙הוּ֙ עַל־במותי#[בָּ֣מֳתֵי] אָ֔רֶץ"
      ],
      [
        "וַיֹּאכַ֖ל תְּנוּבֹ֣ת שָׂדָ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 13
      }
    ],
    "aliyot": [
      {
        "standard": 3
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיֵּנִקֵ֤הֽוּ דְבַשׁ֙ מִסֶּ֔לַע"
      ],
      [
        "וְשֶׁ֖מֶן מֵחַלְמִ֥ישׁ צֽוּר׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חֶמְאַ֨ת בָּקָ֜ר וַחֲלֵ֣ב צֹ֗אן"
      ],
      [
        "עִם־חֵ֨לֶב כָּרִ֜ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 14
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵילִ֤ים בְּנֵֽי־בָשָׁן֙ וְעַתּוּדִ֔ים"
      ],
      [
        "עִם־חֵ֖לֶב כִּלְי֣וֹת חִטָּ֑ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְדַם־עֵנָ֖ב תִּשְׁתֶּה־חָֽמֶר׃"
      ],
      [
        "וַיִּשְׁמַ֤ן יְשֻׁרוּן֙ וַיִּבְעָ֔ט"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 15
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "שָׁמַ֖נְתָּ עָבִ֣יתָ כָּשִׂ֑יתָ"
      ],
      [
        "וַיִּטֹּשׁ֙ אֱל֣וֹהַּ עָשָׂ֔הוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיְנַבֵּ֖ל צ֥וּר יְשֻׁעָתֽוֹ׃"
      ],
      [
        "יַקְנִאֻ֖הוּ בְּזָרִ֑ים"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 16
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּתוֹעֵבֹ֖ת יַכְעִיסֻֽהוּ׃"
      ],
      [
        "יִזְבְּח֗וּ לַשֵּׁדִים֙ לֹ֣א אֱלֹ֔הַּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 17
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֱלֹהִ֖ים לֹ֣א יְדָע֑וּם"
      ],
      [
        "חֲדָשִׁים֙ מִקָּרֹ֣ב בָּ֔אוּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לֹ֥א שְׂעָר֖וּם אֲבֹתֵיכֶֽם׃"
      ],
      [
        "צ֥וּר יְלָדְךָ֖ תֶּ֑שִׁי"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 18
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתִּשְׁכַּ֖ח אֵ֥ל מְחֹלְלֶֽךָ׃"
      ],
      [
        "וַיַּ֥רְא יְהֹוָ֖ה וַיִּנְאָ֑ץ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 19
      }
    ],
    "aliyot": [
      {
        "standard": 4
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִכַּ֥עַס בָּנָ֖יו וּבְנֹתָֽיו׃"
      ],
      [
        "וַיֹּ֗אמֶר אַסְתִּ֤ירָה פָנַי֙ מֵהֶ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 20
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֶרְאֶ֖ה מָ֣ה אַחֲרִיתָ֑ם"
      ],
      [
        "כִּ֣י ד֤וֹר תַּהְפֻּכֹת֙ הֵ֔מָּה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בָּנִ֖ים לֹא־אֵמֻ֥ן בָּֽם׃"
      ],
      [
        "הֵ֚ם קִנְא֣וּנִי בְלֹא־אֵ֔ל"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 21
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּעֲס֖וּנִי בְּהַבְלֵיהֶ֑ם"
      ],
      [
        "וַאֲנִי֙ אַקְנִיאֵ֣ם בְּלֹא־עָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "בְּג֥וֹי נָבָ֖ל אַכְעִיסֵֽם׃"
      ],
      [
        "כִּי־אֵשׁ֙ קָדְחָ֣ה בְאַפִּ֔י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 22
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,Ss=`[
  {
    "text": [
      [
        "וַתִּיקַ֖ד עַד־שְׁא֣וֹל תַּחְתִּ֑ית"
      ],
      [
        "וַתֹּ֤אכַל אֶ֙רֶץ֙ וִֽיבֻלָ֔הּ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַתְּלַהֵ֖ט מוֹסְדֵ֥י הָרִֽים׃"
      ],
      [
        "אַסְפֶּ֥ה עָלֵ֖ימוֹ רָע֑וֹת"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 23
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חִצַּ֖י אֲכַלֶּה־בָּֽם׃"
      ],
      [
        "מְזֵ֥י רָעָ֛ב וּלְחֻ֥מֵי רֶ֖שֶׁף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 24
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְקֶ֣טֶב מְרִירִ֑י"
      ],
      [
        "וְשֶׁן־בְּהֵמֹת֙ אֲשַׁלַּח־בָּ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "עִם־חֲמַ֖ת זֹחֲלֵ֥י עָפָֽר׃"
      ],
      [
        "מִחוּץ֙ תְּשַׁכֶּל־חֶ֔רֶב"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 25
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמֵחֲדָרִ֖ים אֵימָ֑ה"
      ],
      [
        "גַּם־בָּחוּר֙ גַּם־בְּתוּלָ֔ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יוֹנֵ֖ק עִם־אִ֥ישׁ שֵׂיבָֽה׃"
      ],
      [
        "אָמַ֖רְתִּי אַפְאֵיהֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 26
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁבִּ֥יתָה מֵאֱנ֖וֹשׁ זִכְרָֽם׃"
      ],
      [
        "לוּלֵ֗י כַּ֤עַס אוֹיֵב֙ אָג֔וּר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 27
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "פֶּֽן־יְנַכְּר֖וּ צָרֵ֑ימוֹ"
      ],
      [
        "פֶּן־יֹֽאמְרוּ֙ יָדֵ֣נוּ רָ֔מָה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְלֹ֥א יְהֹוָ֖ה פָּעַ֥ל כׇּל־זֹֽאת׃"
      ],
      [
        "כִּי־ג֛וֹי אֹבַ֥ד עֵצ֖וֹת הֵ֑מָּה"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 28
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין בָּהֶ֖ם תְּבוּנָֽה׃"
      ],
      [
        "ל֥וּ חָכְמ֖וּ יַשְׂכִּ֣ילוּ זֹ֑את"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 29
      }
    ],
    "aliyot": [
      {
        "standard": 5
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יָבִ֖ינוּ לְאַחֲרִיתָֽם׃"
      ],
      [
        "אֵיכָ֞ה יִרְדֹּ֤ף אֶחָד֙ אֶ֔לֶף"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 30
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּשְׁנַ֖יִם יָנִ֣יסוּ רְבָבָ֑ה"
      ],
      [
        "אִם־לֹא֙ כִּי־צוּרָ֣ם מְכָרָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַֽיהֹוָ֖ה הִסְגִּירָֽם׃"
      ],
      [
        "כִּ֛י לֹ֥א כְצוּרֵ֖נוּ צוּרָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 31
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֹיְבֵ֖ינוּ פְּלִילִֽים׃"
      ],
      [
        "כִּֽי־מִגֶּ֤פֶן סְדֹם֙ גַּפְנָ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 32
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וּמִשַּׁדְמֹ֖ת עֲמֹרָ֑ה"
      ],
      [
        "עֲנָבֵ֙מוֹ֙ עִנְּבֵי־ר֔וֹשׁ"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכְּלֹ֥ת מְרֹרֹ֖ת לָֽמוֹ׃"
      ],
      [
        "חֲמַ֥ת תַּנִּינִ֖ם יֵינָ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 33
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְרֹ֥אשׁ פְּתָנִ֖ים אַכְזָֽר׃"
      ],
      [
        "הֲלֹא־ה֖וּא כָּמֻ֣ס עִמָּדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 34
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "חָת֖וּם בְּאוֹצְרֹתָֽי׃"
      ],
      [
        "לִ֤י נָקָם֙ וְשִׁלֵּ֔ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 35
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְעֵ֖ת תָּמ֣וּט רַגְלָ֑ם"
      ],
      [
        "כִּ֤י קָרוֹב֙ י֣וֹם אֵידָ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְחָ֖שׁ עֲתִדֹ֥ת לָֽמוֹ׃"
      ],
      [
        "כִּֽי־יָדִ֤ין יְהֹוָה֙ עַמּ֔וֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 36
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְעַל־עֲבָדָ֖יו יִתְנֶחָ֑ם"
      ],
      [
        "כִּ֤י יִרְאֶה֙ כִּֽי־אָ֣זְלַת יָ֔ד"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֶ֖פֶס עָצ֥וּר וְעָזֽוּב׃"
      ],
      [
        "וְאָמַ֖ר אֵ֣י אֱלֹהֵ֑ימוֹ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 37
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "צ֖וּר חָסָ֥יוּ בֽוֹ׃"
      ],
      [
        "אֲשֶׁ֨ר חֵ֤לֶב זְבָחֵ֙ימוֹ֙ יֹאכֵ֔לוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 38
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יִשְׁתּ֖וּ יֵ֣ין נְסִיכָ֑ם"
      ],
      [
        "יָק֙וּמוּ֙ וְיַעְזְרֻכֶ֔ם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "יְהִ֥י עֲלֵיכֶ֖ם סִתְרָֽה׃"
      ],
      [
        "רְא֣וּ ׀ עַתָּ֗ה כִּ֣י אֲנִ֤י אֲנִי֙ ה֔וּא"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 39
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְאֵ֥ין אֱלֹהִ֖ים עִמָּדִ֑י"
      ],
      [
        "אֲנִ֧י אָמִ֣ית וַאֲחַיֶּ֗ה"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מָחַ֙צְתִּי֙ וַאֲנִ֣י אֶרְפָּ֔א"
      ],
      [
        "וְאֵ֥ין מִיָּדִ֖י מַצִּֽיל׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "כִּֽי־אֶשָּׂ֥א אֶל־שָׁמַ֖יִם יָדִ֑י"
      ],
      [
        "וְאָמַ֕רְתִּי חַ֥י אָנֹכִ֖י לְעֹלָֽם׃"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 40
      }
    ],
    "aliyot": [
      {
        "standard": 6
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אִם־שַׁנּוֹתִי֙ בְּרַ֣ק חַרְבִּ֔י"
      ],
      [
        "וְתֹאחֵ֥ז בְּמִשְׁפָּ֖ט יָדִ֑י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 41
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אָשִׁ֤יב נָקָם֙ לְצָרָ֔י"
      ],
      [
        "וְלִמְשַׂנְאַ֖י אֲשַׁלֵּֽם׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אַשְׁכִּ֤יר חִצַּי֙ מִדָּ֔ם"
      ],
      [
        "וְחַרְבִּ֖י תֹּאכַ֣ל בָּשָׂ֑ר"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 42
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "מִדַּ֤ם חָלָל֙ וְשִׁבְיָ֔ה"
      ],
      [
        "מֵרֹ֖אשׁ פַּרְע֥וֹת אוֹיֵֽב׃"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַרְנִ֤ינוּ גוֹיִם֙ עַמּ֔וֹ"
      ],
      [
        "כִּ֥י דַם־עֲבָדָ֖יו יִקּ֑וֹם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 43
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וְנָקָם֙ יָשִׁ֣יב לְצָרָ֔יו"
      ],
      [
        "וְכִפֶּ֥ר אַדְמָת֖וֹ עַמּֽוֹ׃#(פ)"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        ""
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "וַיָּבֹ֣א מֹשֶׁ֗ה וַיְדַבֵּ֛ר אֶת־כׇּל־דִּבְרֵ֥י הַשִּׁירָֽה־הַזֹּ֖את בְּאׇזְנֵ֣י"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 44
      }
    ],
    "aliyot": [
      {
        "standard": 7
      }
    ],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הָעָ֑ם ה֖וּא וְהוֹשֵׁ֥עַ בִּן־נֽוּן׃ וַיְכַ֣ל מֹשֶׁ֗ה לְדַבֵּ֛ר אֶת־כׇּל־"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 45
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַדְּבָרִ֥ים הָאֵ֖לֶּה אֶל־כׇּל־יִשְׂרָאֵֽל׃ וַיֹּ֤אמֶר אֲלֵהֶם֙ שִׂ֣ימוּ"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 46
      }
    ],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "לְבַבְכֶ֔ם לְכׇ֨ל־הַדְּבָרִ֔ים אֲשֶׁ֧ר אָנֹכִ֛י מֵעִ֥יד בָּכֶ֖ם הַיּ֑וֹם"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "אֲשֶׁ֤ר תְּצַוֻּם֙ אֶת־בְּנֵיכֶ֔ם לִשְׁמֹ֣ר לַעֲשׂ֔וֹת אֶת־כׇּל־דִּבְרֵ֖י"
      ]
    ],
    "verses": [],
    "aliyot": [],
    "isPetucha": false
  },
  {
    "text": [
      [
        "הַתּוֹרָ֥ה הַזֹּֽאת׃ כִּ֠י לֹֽא־דָבָ֨ר רֵ֥ק הוּא֙ מִכֶּ֔ם כִּי־ה֖וּא חַיֵּיכֶ֑ם"
      ]
    ],
    "verses": [
      {
        "book": 5,
        "chapter": 32,
        "verse": 47
      }
    ],
    "aliyot": [],
    "isPetucha": false
  }
]`,Cs=JSON.parse(bs),ws=JSON.parse(xs),Ts=JSON.parse(Ss);function Es(e){return(e===`sea`?[{pageNumber:78,lines:Cs}]:[{pageNumber:242,lines:ws},{pageNumber:243,lines:Ts}]).flatMap(({pageNumber:t,lines:n})=>{let r,i=n.find(e=>e.verses.length)?.verses[0],a=i?{b:i.book,c:i.chapter,v:i.verse}:void 0;return n.flatMap((n,i)=>{let o=n.verses.map(({book:e,chapter:t,verse:n})=>({b:e,c:t,v:n})),s=r??o[0];return r=o.at(-1)??r,ps(n.text,o[0]??s??a,t,i)?.kind===e?[{pageNumber:t,lineIndex:i,markup:ms({text:n.text,references:[s,...o],annotationsEnabled:!0,pageNumber:t,lineIndex:i,presentation:{layout:`match`,sides:`one`},surface:`single`})}]:[]})})}var Ds=(e,t)=>[...e.querySelectorAll(t)].filter(e=>!e.hidden&&e.getClientRects().length>0);function Os(e){e.querySelectorAll(`.word[data-token-key]`).forEach(e=>e.style.removeProperty(`--reader-paired-word-width`))}var ks=new WeakMap,As=new WeakMap;function js(e){let t=getComputedStyle(e);return`${t.fontStyle} ${t.fontWeight} ${t.fontSize}/${t.lineHeight} ${t.fontFamily}`}function Ms(e){let t=[...e.querySelectorAll(`tr:not([data-shirah-kind]) [data-reader-canonical="true"] .reader-text-flow`)];if(!t.length)return[];let n=js(e),r=As.get(t[0]);if(r?.font===n&&document.fonts.check(n,`אשר`))return r.widths;let i=document.createElement(`div`);i.className=`match-shirah-measure`,i.style.font=n,i.setAttribute(`aria-hidden`,`true`);let a=t.map(e=>e.cloneNode(!0));i.append(...a),document.body.append(i);let o=[];for(let e of[!0,!1]){Nn(i,e);for(let e of a){let t=[...e.querySelectorAll(`.ktiv-kri:not([hidden])`)].reduce((e,t)=>{let n=getComputedStyle(t);return e+Number.parseFloat(n.paddingLeft)+Number.parseFloat(n.paddingRight)+Number.parseFloat(n.borderLeftWidth)+Number.parseFloat(n.borderRightWidth)},0);o.push({width:e.getBoundingClientRect().width,fixedInsets:t})}}return i.remove(),document.fonts.check(n,`אשר`)&&As.set(t[0],{font:n,widths:o}),o}function Ns(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind])`),r=e.closest(`.tikkun-book`),i=e.querySelector(`table`);if(!n||!r||!i||r.clientWidth===0)return;let a=Ms(e),o=Math.max(...a.map(e=>e.width))+2,s=n.querySelector(`.line-content`),c=s.getBoundingClientRect(),l=t===`two`?1+2*Number.parseFloat(getComputedStyle(s).columnGap):0,u=t===`two`?2:1,d=u*o+l;if(d<=c.width)return;let f=r.getBoundingClientRect(),p=getComputedStyle(n.querySelector(`.line`)).gridTemplateColumns.split(` `).map(Number.parseFloat),m=p[2]+p[3],h=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),g=(c.left+c.right)/2,_=t===`two`?2*Math.min(g-f.left-h,f.right-m-h-g):f.width-m-2*h,v=Math.max(c.width,Math.min(d,_)),y=t===`two`?g+v/2:Math.min(g+v/2,f.right-m-h);i.style.width=getComputedStyle(i).width,e.classList.add(`mod-match-fitted`),e.style.setProperty(`--match-ordinary-inline-size`,`${v}px`),e.style.setProperty(`--match-ordinary-inline-offset`,`${y-c.right}px`);let b=(v-l)/u,x=Math.min(1,...a.map(e=>(b-e.fixedInsets)/(e.width-e.fixedInsets+2)));e.style.setProperty(`--match-text-scale`,`${x}em`)}function Ps(e){e.classList.remove(`mod-match-song-frame`);for(let t of[`inline-size`,`inline-offset`,`gutter-inline-offset`,`ordinary-flow-size`,`shirah-flow-size`])e.style.removeProperty(`--match-page-${t}`)}function Fs(e,t){if(t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let n=e.querySelector(`tr:not([data-shirah-kind]) .line-content`),r=e.querySelector(`tr[data-shirah-kind] .line-content`),i=e.closest(`.tikkun-book`);if(!n||!r||!i)return;let a=n.getBoundingClientRect(),o=r.getBoundingClientRect(),s=a.width>o.width?a:o,c=getComputedStyle(r).transform,l=o.right-(c===`none`?0:new DOMMatrixReadOnly(c).m41),u=e.querySelector(`table`);u.style.width=getComputedStyle(u).width,e.style.setProperty(`--match-page-ordinary-flow-size`,`${n.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-shirah-flow-size`,`${r.querySelector(`.reader-text-flow`).getBoundingClientRect().width}px`),e.style.setProperty(`--match-page-inline-size`,`${s.width}px`),e.style.setProperty(`--match-page-inline-offset`,`${s.right-l}px`),e.classList.add(`mod-match-song-frame`);let d=i.getBoundingClientRect().right,f=[...e.querySelectorAll(`.location-indicator.mod-verses`)],p=Math.max(0,...f.map(e=>e.getBoundingClientRect().right-d+1));e.style.setProperty(`--match-page-gutter-inline-offset`,`${s.right-l-p}px`)}function Is(e,t){let n=e.closest(`.tikkun-book`);if(!n||n.clientWidth===0)return;let r=e.querySelector(`tr[data-shirah-kind]`)?.dataset.shirahKind;if(r!==`sea`&&r!==`haazinu`||r!==`haazinu`&&t===`one`&&!window.matchMedia(`(min-width: 551px)`).matches)return;let i=[...n.querySelectorAll(`tr[data-shirah-kind="${r}"]`)],a=[...new Set(i.map(e=>e.closest(`.tikkun-page`)))];for(let e of a)Ps(e),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-haazinu-gap`);let o=js(e),s=ks.get(n)??new Map;ks.set(n,s);let c=`${r}:${o}`,l=s.get(c)??{half:0,gap:0,trailingSpace:0,sea:{},pageFirstSpanWidths:new Map},u=document.createElement(`div`);u.className=`match-shirah-measure`,u.style.font=o,u.setAttribute(`aria-hidden`,`true`);let d=document.createElement(`span`);d.className=`fragment`,d.textContent=`אשר אשר אשר`;let f=document.createElement(`span`);f.textContent=`\xA0`,u.append(d,f);let p=l.gap?[]:Es(r).map(({pageNumber:e,lineIndex:t,markup:n})=>{let r=document.createElement(`div`);r.innerHTML=n;let i=[...r.querySelectorAll(`.fragment`)];return u.append(...i),{pageNumber:e,seaLayout:$o(e,t),fragments:i}});(p.length||!l.gap)&&document.body.append(u),l.gap||(l.gap=d.getBoundingClientRect().width,l.trailingSpace=f.getBoundingClientRect().width);for(let e of[!0,!1]){Nn(u,e);for(let{pageNumber:e,seaLayout:t,fragments:n}of p){let r=n.map(e=>e.getBoundingClientRect().width);if(t){let e=l.sea[t.pattern]??[];r.forEach((t,n)=>{e[n]=Math.max(e[n]??0,t+1)}),l.sea[t.pattern]=e}else l.half=Math.max(l.half,...r),l.pageFirstSpanWidths.set(e,Math.max(l.pageFirstSpanWidths.get(e)??0,r[0]))}}u.remove(),document.fonts.check(o,`אשר`)&&s.set(c,l);let m=r===`sea`?Zo(l.sea,l.gap):null;if(m){let t=Number.parseFloat(getComputedStyle(e).fontSize);a.forEach(e=>{e.style.setProperty(`--match-sea-outer`,`${m.outer/t}em`),e.style.setProperty(`--match-sea-middle`,`${m.middle/t}em`),e.style.setProperty(`--match-sea-half`,`${m.half/t}em`),e.style.setProperty(`--match-sea-extended-left`,`${m.extendedLeft/t}em`),e.style.setProperty(`--match-sea-penultimate-right`,`${m.penultimateRight/t}em`),e.style.setProperty(`--match-sea-gap`,`${l.gap/t}em`)})}r===`haazinu`&&t===`one`&&a.forEach(e=>e.style.setProperty(`--match-haazinu-page-first-span-width`,`${(l.pageFirstSpanWidths.get(Number(e.querySelector(`table`)?.dataset.pageNumber))??0)+l.trailingSpace}px`));let h=a.map(e=>e.querySelector(`tr[data-shirah-kind="${r}"] .line-content`).getBoundingClientRect()),g=i[0].querySelector(r===`haazinu`?`.reader-text-flow`:`.column`),_=r===`haazinu`?l.gap:Number.parseFloat(getComputedStyle(g).columnGap),v=n.getBoundingClientRect(),y=Number.parseFloat(getComputedStyle(document.documentElement).fontSize),b=m?.required??2*l.half+_,x=r===`haazinu`||i.some(e=>e.querySelector(`.line-gutter.mod-aliyot`)?.textContent?.trim()),S=i[0].querySelector(`.line`),C=getComputedStyle(S).gridTemplateColumns.split(` `).map(Number.parseFloat),w=x&&(C[3]??0)>0,T=C[2]+(w?C[3]:0);if(r===`haazinu`||t===`two`){T=Math.max(T,...i.map(e=>{let t=e.querySelector(`.location-indicator.mod-verses`),n=e.querySelector(`.line-content`);return t?t.getBoundingClientRect().right-n.getBoundingClientRect().right:0}));let n=t===`two`?2:1,r=i[0].querySelector(`.line-content`),o=t===`two`?1+2*Number.parseFloat(getComputedStyle(r).columnGap):0,s=n*(b+2),c=Math.ceil(s+o),l=Math.min(y,Math.max(2,(v.width-T-c)/2)),u=t===`two`?(h[0].left+h[0].right)/2:(v.left+v.right)/2,d=t===`two`?2*Math.min(u-v.left-l,v.right-T-l-u):v.width-T-2*l,f=Math.min(1,(d-o)/s),p=t===`two`?s*f+o:Math.min(c,d),m=t===`two`?u+p/2:Math.min(u+p/2,v.right-T-l),g=Number.parseFloat(getComputedStyle(e).fontSize);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${p}px`),e.style.setProperty(`--match-shirah-inline-offset`,`${m-h[t].right}px`),e.style.setProperty(`--match-shirah-text-scale`,`${f}em`),e.style.setProperty(`--match-haazinu-gap`,`${_/g}em`),e.style.setProperty(`--match-shirah-aliyah-display`,w?`flex`:`none`)}),a}let E=Math.ceil(b+1),D=y,O=Math.min(y,Math.max(2,v.width-T-D-E)),k=Math.min(E,v.width-T-D-O),A=Math.min((v.left+v.right+k)/2,v.right-T-O);return a.forEach((e,t)=>{e.style.setProperty(`--match-shirah-inline-size`,`${k}px`),e.style.setProperty(`--match-shirah-text-scale`,`${Math.min(1,k/E)}em`),e.style.setProperty(`--match-shirah-inline-offset`,`${A-h[t].right}px`),e.style.setProperty(`--match-shirah-aliyah-display`,x?`flex`:`none`)}),a}function Ls(e){Os(e);let t=new Map,n=[];for(let n of Ds(e,`.reader-reading-page-side.mod-torah .word[data-token-key]`)){let e=n.dataset.tokenKey;e&&t.set(e,n)}for(let r of Ds(e,`.reader-reading-page-side.mod-tikkun .word[data-token-key]`)){let e=r.dataset.tokenKey,i=e?t.get(e):void 0;if(!i)continue;let a=Number.parseFloat(getComputedStyle(r).fontSize),o=Number.parseFloat(getComputedStyle(i).fontSize),s=Math.max(a,o);if(!Number.isFinite(s)||s<=0)continue;let c=`${(Math.max(r.getBoundingClientRect().width,i.getBoundingClientRect().width)/s).toFixed(4)}em`;n.push({torah:i,tikkun:r,width:c})}for(let{torah:e,tikkun:t,width:r}of n)t.style.setProperty(`--reader-paired-word-width`,r),e.style.setProperty(`--reader-paired-word-width`,r)}function Rs(e){let t=e.querySelector(`.reader-reading-page`),n=e.closest(`.tikkun-book`);if(!t||!n)return;let r=t.getBoundingClientRect();for(let t of e.querySelectorAll(`.reader-reading-page-side`)){let e=t.classList.contains(`mod-torah`)?`mod-torah`:`mod-tikkun`,i=[...n.querySelectorAll(`.reader-reading-page-side.${e} .mod-reading-line`)];for(let e of t.querySelectorAll(`.mod-reading-line`)){let t=e.querySelector(`.line-gutter.mod-verses`);if(!t?.textContent?.trim())continue;let n=i.indexOf(e),a=Ds(e,`.word[data-token-key]`),o=a[Pi({currentLineWords:a,previousLineWords:n>0?Ds(i[n-1],`.word[data-token-key]`):[],verseOrdinal:0})]??a[0];o&&t.style.setProperty(`--reading-verse-gutter-top`,`${o.getBoundingClientRect().top-r.top}px`)}}}function zs(e){let t=e.closest(`.tikkun-book`);if(!t)return;let n=t.getBoundingClientRect(),r=[...t.querySelectorAll(`.mod-reading-line[data-class="line"]`)];for(let i of e.querySelectorAll(`.mod-reading-line[data-class="line"]`)){let e=i.querySelector(`.line-gutter.mod-verses`);if(!e?.textContent?.trim())continue;let a=r.indexOf(i),o=Ds(i,`[data-reader-canonical="true"] .word[data-token-key]`),s=o[Pi({currentLineWords:o,previousLineWords:a>0?Ds(r[a-1],`[data-reader-canonical="true"] .word[data-token-key]`):[],verseOrdinal:0})]??o[0];s&&e.style.setProperty(`--reading-verse-gutter-top`,`${s.getBoundingClientRect().top-n.top+t.scrollTop}px`)}}function Bs(e,t){if(Ps(e),e.style.removeProperty(`--reading-shirah-inline-size`),e.style.removeProperty(`--match-shirah-inline-expansion`),e.style.removeProperty(`--match-shirah-inline-offset`),e.style.removeProperty(`--match-shirah-inline-size`),e.style.removeProperty(`--match-shirah-aliyah-display`),e.style.removeProperty(`--match-shirah-text-scale`),e.style.removeProperty(`--match-text-scale`),e.style.removeProperty(`--match-haazinu-gap`),e.style.removeProperty(`--match-ordinary-inline-size`),e.style.removeProperty(`--match-ordinary-inline-offset`),e.classList.remove(`mod-match-fitted`),e.querySelector(`table`)?.style.removeProperty(`width`),Os(e),t.layout===`match`){let n=Is(e,t.sides);Ns(e,t.sides),n?.forEach(e=>Fs(e,t.sides));return}t.sides===`two`?(Ls(e),Rs(e)):zs(e)}var{htmlToElement:Vs,purgeNode:Hs}=jn,Us=.5,Ws=class{constructor(e,t){this.viewModel=e,this.root=t,this.renderPrevious=this.generateRender(`afterbegin`),this.renderNext=this.generateRender(`beforeend`),this.renderedPages=new Map,this.pageMounts=new Map,this.renderedEntries=new Map,this.pageNumberMountPromises=new Map,this.contentMountPromises=new Map,this.disposed=!1,this.accessCounter=0,this.edgeLoadingReady=!1,this.pendingInitialCenterScrollTop=null,this.edgeLoadPromise=null,this.pageLayoutFrame=0,this.presentationAnchor=null,this.handleEdgeScroll=()=>{if(this.disposed||!this.edgeLoadingReady||this.consumePendingInitialCenterScroll()||this.edgeLoadPromise)return;let e=this.getEdgeLoadDirection();if(!e)return;let t=this.loadAdjacentPage(e);this.edgeLoadPromise=t,t.catch(t=>{console.error(`Failed to load ${e} reader page`,t)}).finally(()=>{this.edgeLoadPromise===t&&(this.edgeLoadPromise=null)})},this.presentation=nc(t),rc(t,this.presentation),this.pageLayoutObserver=typeof ResizeObserver>`u`?null:new ResizeObserver(()=>this.schedulePageLayoutRefresh()),this.pageLayoutObserver?.observe(t),t.scrollTop=0,Hs(t),t.addEventListener(`scroll`,this.handleEdgeScroll,{passive:!0}),this.rendered=e.startingLocation.then(async({page:t,lineNumber:n})=>{let r=[...this.renderNext(t,{preserveViewport:!1}).querySelectorAll(`.line`)],i=n-1;if(i<r.length/2){let t=await e.fetchPreviousPage();t&&this.renderPrevious(t,{preserveViewport:!1})}else{let t=await e.fetchNextPage();t&&this.renderNext(t,{preserveViewport:!1})}return r[i]}),this.scrolled=this.rendered.then(async e=>{await tc(this.root),await new Promise(requestAnimationFrame),this.refreshMountedPageLayouts(),this.scrollTo({element:e}),this.edgeLoadingReady=!0})}destroy(){this.disposed=!0,this.edgeLoadingReady=!1,this.pendingInitialCenterScrollTop=null,this.root.removeEventListener(`scroll`,this.handleEdgeScroll),this.pageLayoutObserver?.disconnect(),this.pageLayoutFrame&&cancelAnimationFrame(this.pageLayoutFrame),this.pageLayoutFrame=0}setPresentation(e,t){if(this.presentation.layout===e.layout&&this.presentation.sides===e.sides)return!1;let n=this.getPresentationAnchor(),r=[];return this.mutatePreservingViewport(null,()=>{t?.(),this.presentation={...e},rc(this.root,this.presentation);for(let e of this.pageMounts.values()){let t=e.node,n=t?.tikkunPage;!t||!n||e.state!==`mounted`||(t.replaceChildren(Vs(_s(n,{annotationsEnabled:this.annotationsEnabled(),presentation:this.presentation}))),Bs(t,this.presentation),e.measuredHeight=vs(t),this.touchPageRecord(e),r.push({page:n,node:t}))}for(let{page:e,node:t}of r)this.dispatchPageRendered(e,t)},n),this.presentationAnchor=n,this.presentation.layout===`reading`&&this.schedulePageLayoutRefresh(),!0}updateAnnotations(e){let t=this.getPresentationAnchor();this.mutatePreservingViewport(null,()=>{e(),this.refreshMountedPageLayouts()},t),this.presentationAnchor=t}getPresentationAnchor(){let e=this.presentationAnchor,t=e&&Qs(this.root,e);return t&&Math.abs(ec(this.root,t,e.alignment)-e.viewportOffset)<1?e:Xs(this.root)}usesPresentation(e){return this.presentation.layout===e.layout&&this.presentation.sides===e.sides}schedulePageLayoutRefresh(){this.disposed||this.pageLayoutFrame||(this.pageLayoutFrame=requestAnimationFrame(()=>{this.pageLayoutFrame=0,this.refreshMountedPageLayouts()}))}refreshMountedPageLayouts(){for(let e of this.pageMounts.values())e.state!==`mounted`||!e.node?.isConnected||(Bs(e.node,this.presentation),e.measuredHeight=vs(e.node))}scrollTo({element:e}){if(this.disposed)return;let t=Ys(e)??e,n=gr(this.root,t);this.pendingInitialCenterScrollTop=n?this.root.scrollTop:null,this.root.dispatchEvent(new Event(`scroll`))}generateRender(e){return(t,{preserveViewport:n=!0}={})=>{let r=t.type===`page`&&this.pageMounts.get(t.contentIndex)?.state===`evicted`,i=()=>{let n;return n=t.type===`message`?this.mountMessageEntry(t,e):this.mountPageEntry(t,e),n},a=n?this.mutatePreservingViewport(t.contentIndex,i):i();return this.disposed?a:(t.type===`page`&&r&&this.dispatchPageRemounted(t.pageNumber,a),this.dispatchPageRendered(t,a),this.presentation.layout===`reading`&&this.schedulePageLayoutRefresh(),a)}}consumePendingInitialCenterScroll(){let e=this.pendingInitialCenterScrollTop;return e!==null&&(this.pendingInitialCenterScrollTop=null,Math.abs(this.root.scrollTop-e)<=.5)}getEdgeLoadDirection(){let e=this.root.clientHeight;return this.root.scrollTop<Us*e?`previous`:this.root.scrollHeight-(e+this.root.scrollTop)<Us*e?`next`:null}async loadAdjacentPage(e){let t=e===`previous`?await this.viewModel.fetchPreviousPage():await this.viewModel.fetchNextPage();return!t||this.disposed?null:e===`previous`?this.renderPrevious(t):this.renderNext(t)}ensureNextContentMounted(){return this.loadAdjacentPage(`next`)}dispatchPageRendered(e,t){this.root.dispatchEvent(new CustomEvent(`page-rendered`,{detail:{entry:e,node:t}}))}dispatchPageRemounted(e,t){this.root.dispatchEvent(new CustomEvent(`page-remounted`,{detail:{pageNumber:e,node:t}}))}mutatePreservingViewport(e,t,n=Xs(this.root)){let r=this.root.scrollHeight,i=this.root.scrollTop,a=t();return Zs(this.root,n,{affectedContentIndex:e,previousScrollHeight:r,previousScrollTop:i}),a}getMountedPageNode(e){let t=this.getNearestMountedPageRecord(e);return t?.node?(this.touchPageRecord(t),t.node):null}getMountedPageNumbers(){return[...this.renderedPages.entries()].sort(([e],[t])=>e-t).flatMap(([,e])=>e.tikkunPage?[e.tikkunPage.pageNumber]:[])}getKnownPageNumbers(){return[...this.pageMounts.values()].sort((e,t)=>e.contentIndex-t.contentIndex).map(e=>e.pageNumber)}getViewportAnchorPageRecord(){let e=[...this.pageMounts.values()].filter(e=>e.state===`mounted`&&e.node?.isConnected);if(!e.length)return null;let t=this.root.getBoundingClientRect(),n=t.top+t.height/2,r=null,i=1/0;for(let t of e){let e=t.node;if(!e)continue;let a=Ks(e,n);a<i&&(i=a,r=t)}return r??e[0]??null}getViewportAnchorPageNumber(){return this.getViewportAnchorPageRecord()?.pageNumber??null}isPageMounted(e){return this.getPageRecords(e).some(e=>e.state===`mounted`&&e.node?.isConnected)}async ensurePageMounted(e,t){if(this.disposed)return null;if(t){let n=await this.viewModel.fetchPageByPageNumber(e,t);return this.disposed||!n||n.type!==`page`?null:this.mountPageByContentIndex(n.contentIndex)}return this.mountPageByNumber(e)}async ensurePageMountedForNavigation(e,t){if(this.disposed)return null;let n=await this.viewModel.fetchPageByPageNumber(e,t);if(this.disposed||!n||n.type!==`page`)return null;let r=n.contentIndex,i=this.getViewportAnchorPageRecord()?.contentIndex;if(i===void 0)return this.mountPageByContentIndex(r);let a=r>=i?1:-1,o=r===i?r:i+a,s=r+a,c=null;for(let e=o;a>0?e<=s:e>=s;e+=a){let t=e===r?n:await this.viewModel.fetchPageByContentIndex(e);if(this.disposed)return null;if(!t){if(e===s)break;return null}let i=await this.ensureRenderedEntryMounted(t);if(this.disposed)return null;e===r&&i instanceof HTMLElement&&(c=i)}return c??this.renderedPages.get(r)??null}async ensureRenderedEntryMounted(e){if(e.type===`page`)return this.mountPageByContentIndex(e.contentIndex);let t=this.renderedEntries.get(e.contentIndex);if(t?.isConnected)return t;let n=this.mutatePreservingViewport(e.contentIndex,()=>this.mountMessageEntry(e));return this.disposed||this.dispatchPageRendered(e,n),n}async mountPageByNumber(e){if(this.disposed)return null;let t=this.getNearestMountedPageRecord(e);if(t?.node)return this.touchPageRecord(t),t.node;let n=this.getPageRecords(e).find(e=>e.state===`evicted`);if(n)return this.mountPageByContentIndex(n.contentIndex);let r=this.pageNumberMountPromises.get(e);if(r)return r;let i=(async()=>{let t=await this.viewModel.fetchPageByPageNumber(e);return this.disposed||!t||t.type!==`page`?null:this.mountFetchedPage(t)})();return this.pageNumberMountPromises.set(e,i),i.then(()=>this.clearPageNumberMount(e,i),()=>this.clearPageNumberMount(e,i)),i}async mountPageByContentIndex(e){if(this.disposed)return null;let t=this.pageMounts.get(e);if(t?.state===`mounted`&&t.node?.isConnected)return this.touchPageRecord(t),t.node;let n=this.contentMountPromises.get(e);if(n)return n;let r=(async()=>{let t=await this.viewModel.fetchPageByContentIndex(e);return this.disposed||!t||t.type!==`page`?null:this.mountFetchedPage(t)})();return this.contentMountPromises.set(e,r),t&&(t.mountPromise=r),r.then(()=>this.clearContentMount(e,r),()=>this.clearContentMount(e,r)),r}clearPageNumberMount(e,t){this.pageNumberMountPromises.get(e)===t&&this.pageNumberMountPromises.delete(e)}clearContentMount(e,t){this.contentMountPromises.get(e)===t&&this.contentMountPromises.delete(e);let n=this.pageMounts.get(e);n?.mountPromise===t&&(n.mountPromise=null)}mountFetchedPage(e){let t=this.pageMounts.get(e.contentIndex);if(t?.state===`mounted`&&t.node?.isConnected)return this.touchPageRecord(t),t.node;let n=t?.state===`evicted`,r=this.mutatePreservingViewport(e.contentIndex,()=>n&&t.placeholderNode?this.mountEvictedPage(e,t):this.mountPageEntry(e,`beforeend`));return n&&this.dispatchPageRemounted(e.pageNumber,r),this.dispatchPageRendered(e,r),r}getPageRecords(e){return[...this.pageMounts.values()].filter(t=>t.pageNumber===e).sort((e,t)=>e.contentIndex-t.contentIndex)}getNearestMountedPageRecord(e){let t=this.getPageRecords(e).filter(e=>e.state===`mounted`&&e.node?.isConnected);if(t.length<=1)return t[0]??null;let n=this.root.getBoundingClientRect(),r=n.top+n.height/2;return t.reduce((e,t)=>!e.node||!t.node?e:Ks(t.node,r)<Ks(e.node,r)?t:e)}evictPage(e){if(this.disposed)return!1;let t=this.getPageRecords(e),n=!1;for(let e of t)this.evictPageRecord(e)&&(n=!0);return n}evictPageRecord(e){if(!e||e.state!==`mounted`||!e.node||e.mountPromise)return!1;let t=e.node,n=vs(t)??e.measuredHeight??0,r=qs(e.pageNumber,e.contentIndex,n);return this.mutatePreservingViewport(e.contentIndex,()=>{t.replaceWith(r),this.renderedPages.delete(e.contentIndex),this.renderedEntries.set(e.contentIndex,r),e.state=`evicted`,e.node=null,e.placeholderNode=r,e.measuredHeight=n,e.mountPromise=null,this.touchPageRecord(e)}),this.root.dispatchEvent(new CustomEvent(`page-evicted`,{detail:{pageNumber:e.pageNumber,node:t}})),!0}evictPages(e){return e.filter(e=>this.evictPage(e))}getEvictedPageNumbersNearViewport({marginPx:e=this.root.clientHeight}={}){return this.getEvictedPageRecordsNearViewport({marginPx:e}).map(e=>e.pageNumber)}getEvictedPageRecordsNearViewport({marginPx:e=this.root.clientHeight}={}){let t=this.root.getBoundingClientRect(),n=t.top-Math.max(0,e),r=t.bottom+Math.max(0,e),i=[];for(let e of this.pageMounts.values()){if(e.state!==`evicted`||!e.placeholderNode?.isConnected)continue;let t=e.placeholderNode.getBoundingClientRect();t.bottom>=n&&t.top<=r&&i.push(e)}return i.sort((e,t)=>e.contentIndex-t.contentIndex)}async ensureEvictedPagesMountedNearViewport(e){let t=this.getEvictedPageRecordsNearViewport(e),n=[];for(let e of t)await this.mountPageByContentIndex(e.contentIndex)&&n.push(e.pageNumber);return n}getPageLifecycleSnapshot(){return ys([...this.pageMounts.values()].map(e=>({pageNumber:e.pageNumber,state:e.state,measuredHeight:e.measuredHeight,lastAccessedAt:e.lastAccessedAt})))}markPageMounted(e,t){let n=this.setPageRecord(e.contentIndex,e.pageNumber,`mounted`);n.node=t,n.placeholderNode=null,n.measuredHeight=vs(t),n.mountPromise=null,this.touchPageRecord(n)}setPageRecord(e,t,n){let r=this.pageMounts.get(e);if(r)return r.pageNumber=t,r.state=n,r.lastAccessedAt=this.nextAccessToken(),n!==`mounted`&&(r.node=null,n!==`evicted`&&(r.placeholderNode=null,r.measuredHeight=null)),n!==`mounting`&&(r.mountPromise=null),r;let i={contentIndex:e,pageNumber:t,state:n,node:null,placeholderNode:null,measuredHeight:null,lastAccessedAt:this.nextAccessToken(),mountPromise:null};return this.pageMounts.set(e,i),i}touchPageRecord(e){e.lastAccessedAt=this.nextAccessToken(),e.node&&(e.measuredHeight=vs(e.node))}nextAccessToken(){return this.accessCounter+=1,this.accessCounter}mountPageEntry(e,t){if(this.disposed)return Gs(e,this.annotationsEnabled(),this.presentation);let n=this.pageMounts.get(e.contentIndex);if(n?.state===`mounted`&&n.node?.isConnected)return this.touchPageRecord(n),n.node;if(n?.state===`evicted`&&n.placeholderNode?.isConnected)return this.mountEvictedPage(e,n);let r=Gs(e,this.annotationsEnabled(),this.presentation);return this.insertEntryNodeInOrder(e.contentIndex,r,t),Bs(r,this.presentation),this.renderedPages.set(e.contentIndex,r),this.renderedEntries.set(e.contentIndex,r),this.markPageMounted(e,r),r}mountMessageEntry(e,t=`beforeend`){let n=this.renderedEntries.get(e.contentIndex);if(n?.isConnected)return n;let r=Js(e);return this.disposed?r:(this.insertEntryNodeInOrder(e.contentIndex,r,t),this.renderedEntries.set(e.contentIndex,r),r)}insertEntryNodeInOrder(e,t,n=`beforeend`){let r=this.getNextKnownEntryDomNode(e);r?this.root.insertBefore(t,r):this.root.insertAdjacentElement(n,t)}getNextKnownEntryDomNode(e){let t=1/0,n=null;for(let[r,i]of this.renderedEntries)r<=e||r>=t||!i.isConnected||(t=r,n=i);return n}mountEvictedPage(e,t){let n=Gs(e,this.annotationsEnabled(),this.presentation);return this.disposed?n:(t.placeholderNode?.replaceWith(n),Bs(n,this.presentation),this.renderedPages.set(e.contentIndex,n),this.renderedEntries.set(e.contentIndex,n),this.markPageMounted(e,n),n)}annotationsEnabled(){return this.root.classList.contains(`mod-annotations-on`)}};function Gs(e,t,n){let r=document.createElement(`div`);return r.classList.add(`tikkun-page`),r.dataset.contentIndex=`${e.contentIndex}`,r.tikkunPage=e,r.appendChild(Vs(_s(e,{annotationsEnabled:t,presentation:n}))),r}function Ks(e,t){let n=e.getBoundingClientRect();return n.top<=t&&n.bottom>=t?0:Math.min(Math.abs(n.top-t),Math.abs(n.bottom-t))}function qs(e,t,n){let r=document.createElement(`div`);return r.className=`tikkun-page-placeholder`,r.dataset.pagePlaceholder=`${e}`,r.dataset.contentIndex=`${t}`,r.setAttribute(`aria-hidden`,`true`),r.style.minHeight=`${Math.max(0,n)}px`,r.style.height=`${Math.max(0,n)}px`,r}function Js(e){let t=document.createElement(`div`);t.classList.add(`tikkun-message`),t.dataset.contentIndex=`${e.contentIndex}`;let n=document.createElement(`span`);return n.classList.add(`tikkun-message-text`),n.textContent=e.text,t.appendChild(n),t}function Ys(e){return[...e.querySelectorAll(`.word`)].find(e=>{let t=e.getBoundingClientRect();return t.width>0&&t.height>0})??null}function Xs(e){let t=pr(e),n=null,r=1/0,i=[...e.querySelectorAll(`[data-reader-canonical="true"] .word:not([hidden])`)].filter($s),a=i.length?i:e.querySelectorAll(`[data-class="line"]`);for(let e of a){let i=e.getBoundingClientRect(),a=Math.abs((i.top+i.bottom)/2-t);a>=r||(n=e,r=a)}if(!n)return null;let o=Number(n.closest(`[data-content-index]`)?.dataset.contentIndex),s=Number(n.dataset.pageNumber),c=Number(n.dataset.lineIndex);if(!Number.isInteger(o)||!Number.isInteger(s)||!Number.isInteger(c))return null;let l=Ys(n)??n,u=l.matches(`.word`)?`center`:`top`;return{contentIndex:o,pageNumber:s,lineIndex:c,tokenKey:l.dataset.tokenKey??null,alignment:u,viewportOffset:ec(e,l,u)}}function Zs(e,t,{affectedContentIndex:n,previousScrollHeight:r,previousScrollTop:i}){if(!t)return;let a=e.querySelector(`[data-content-index="${t.contentIndex}"]`),o=Qs(e,t),s=a?.querySelector(`[data-page-number="${t.pageNumber}"][data-line-index="${t.lineIndex}"]`),c=o??s;if(c){let n=o?t.alignment:`top`;for(let r=0;r<2;r+=1){let r=ec(e,c,n)-t.viewportOffset;if(Math.abs(r)<=.5)break;e.scrollTop+=r}return}n!==null&&n<t.contentIndex&&(e.scrollTop=i+(e.scrollHeight-r))}function Qs(e,t){return t.tokenKey?[...e.querySelector(`[data-content-index="${t.contentIndex}"]`)?.querySelectorAll(`[data-reader-canonical="true"] .word`)??[]].find(e=>e.dataset.tokenKey===t.tokenKey&&$s(e))??null:null}function $s(e){let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function ec(e,t,n){let r=t.getBoundingClientRect();return(n===`center`?(r.top+r.bottom)/2:r.top)-pr(e)}async function tc(e){let t=document.fonts;if(!t)return;let n=e.querySelector(`.tikkun-page`);n&&await t.load(js(n),`אשר`),await t.ready}function nc(e){return{layout:xr(e.dataset.readerLayout)?e.dataset.readerLayout:br.layout,sides:Sr(e.dataset.readerSides)?e.dataset.readerSides:br.sides}}function rc(e,t){e.dataset.readerLayout=t.layout,e.dataset.readerSides=t.sides}var ic=class{constructor(){this.generation=0,this.activeController=null}begin(){this.activeController?.abort();let e=++this.generation,t=new AbortController;return this.activeController=t,{generation:e,signal:t.signal,isCurrent:()=>this.generation===e&&this.activeController===t&&!t.signal.aborted}}cancel(){this.generation+=1,this.activeController?.abort(),this.activeController=null}},ac=class extends Va{constructor(e){super(),this.handleScroll=()=>this.scheduleUpdate(),this.destroyed=!1,this.updateFrame=0,this.book=e,this.lineTrackers={first:new lc(oc.Down,e),center:new lc(oc.Down,e),last:new lc(oc.Up,e)},this.update(),e.addEventListener(`scroll`,this.handleScroll)}refresh(){this.destroyed||(this.updateFrame&&=(cancelAnimationFrame(this.updateFrame),0),this.update(!0))}destroy(){this.destroyed||(this.destroyed=!0,this.book.removeEventListener(`scroll`,this.handleScroll),this.updateFrame&&=(cancelAnimationFrame(this.updateFrame),0))}scheduleUpdate(){this.destroyed||this.updateFrame||(this.updateFrame=requestAnimationFrame(()=>{this.updateFrame=0,!(this.destroyed||!this.book.isConnected)&&this.update()}))}update(e=!1){let t=!1,n=this.book.getBoundingClientRect(),r=parseFloat(getComputedStyle(this.book).paddingTop),i=document.documentElement.clientHeight-1,a=e=>Math.max(0,Math.min(i,e)),o=a(n.top+r),s=a(pr(this.book)),c=a(n.bottom-1);this.lineTrackers.first.update(o,e)&&(t=!0),this.lineTrackers.center.update(s,e)&&(t=!0),this.lineTrackers.last.update(c,e)&&(t=!0),(t||e)&&this.emit(`viewport-updated`,{first:this.lineTrackers.first.current,center:this.lineTrackers.center.current,last:this.lineTrackers.last.current})}},oc={Down:{coordinate:`top`,nextElement:`nextNode`},Up:{coordinate:`bottom`,nextElement:`previousNode`}},sc={[-1]:oc.Up,1:oc.Down},cc=Math.sign,lc=class{constructor(e,t){this.direction=e,this.root=t,this.walker=document.createTreeWalker(t,NodeFilter.SHOW_ELEMENT,e=>!(e instanceof HTMLElement)||e.tagName===`TD`?NodeFilter.FILTER_REJECT:e.dataset.lineIndex?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP)}get current(){return uc(this.walker.currentNode)}resetWalker(e){let t=document.elementFromPoint(document.documentElement.clientWidth/2,e)?.closest(`[data-line-index]`);this.walker.currentNode=t&&this.root.contains(t)?t:this.root,this.walker.currentNode===this.root&&this.walker.nextNode()}update(e,t=!1){let n=this.current;return t&&this.resetWalker(e),this.maybeUpdate(e),n!==this.current}maybeUpdate(e){if(this.walker.currentNode===this.root&&this.resetWalker(e),this.root.contains(this.walker.currentNode)||this.resetWalker(e),!(this.walker.currentNode instanceof Element))throw Error(`Not an element?`);let t=!0,n=cc(0);for(;;){let r=e-this.walker.currentNode.getBoundingClientRect()[this.direction.coordinate];if(Math.abs(r)<.8*this.walker.currentNode.clientHeight)break;if(t&&Math.abs(r)>100){this.resetWalker(e),t=!1;continue}if(t=!1,n&&n!==cc(r)||(n=cc(r),!n))break;let i=this.walker.currentNode;if(this.walker[sc[n].nextElement](),this.walker.currentNode===i)break}let r=0;for(;!uc(this.walker.currentNode)?.aliyot.length&&++r<40;)this.walker[this.direction.nextElement]()}};function uc(e){return e instanceof HTMLElement?e.closest(`.tikkun-page`)?.tikkunPage?.lines[Number(e.dataset.lineIndex)]??null:null}var dc={viewportRadius:2,playbackForwardPageCount:2},fc=[`viewport`,`rail-target`,`playback`,`initial-neighbor`];function pc({mountedPageNumbers:e,viewportPageNumber:t=null,railTargetPageNumber:n=null,playbackPageNumbers:r=[],initialNeighborPageNumbers:i=[],config:a={}}){let o=hc(a),s=gc(e),c=new Map;if(_c(t))for(let e=t-o.viewportRadius;e<=t+o.viewportRadius;e+=1)vc(c,e,`viewport`);_c(n)&&vc(c,n,`rail-target`),gc(r).slice(0,o.playbackForwardPageCount+1).forEach(e=>{vc(c,e,`playback`)}),gc(i).forEach(e=>{vc(c,e,`initial-neighbor`)});let l=[...c.keys()].sort((e,t)=>e-t),u=new Set(l);return{config:o,retainedPages:l,evictionCandidates:s.filter(e=>!u.has(e)),retainReasons:l.map(e=>({pageNumber:e,reasons:yc(c.get(e)??new Set)}))}}function mc({enabled:e,policy:t,evictPages:n}){return e?{enabled:e,evictedPages:n(t.evictionCandidates)}:{enabled:e,evictedPages:[]}}function hc(e){return{viewportRadius:Math.max(0,Math.floor(e.viewportRadius??dc.viewportRadius)),playbackForwardPageCount:Math.max(0,Math.floor(e.playbackForwardPageCount??dc.playbackForwardPageCount))}}function gc(e){return[...new Set(e.filter(_c))].sort((e,t)=>e-t)}function _c(e){return Number.isInteger(e)&&Number(e)>0}function vc(e,t,n){if(!_c(t))return;let r=e.get(t)??new Set;r.add(n),e.set(t,r)}function yc(e){return fc.filter(t=>e.has(t))}var bc={viewportRadius:2,playbackForwardPageCount:2},xc=2,Sc=1400;function Cc({search:e,frame:t,timer:n,getPlaybackProtectedPageNumbers:r,refreshViewport:i,invalidateReaderPosition:a,config:o=bc}){let s=new URLSearchParams(e).get(`virtualizePages`)===`1`,c=pc({mountedPageNumbers:[],config:o}).config,l=null,u=0,d=null,f=null,p=0,m=0,h=0,g=0,_=null,v=!1,y=new Set;function b(e,t){return!v&&l===e&&u===t}function x(){return!!(l&&d===l)}function S(){let e=l;return e?pc({mountedPageNumbers:e.getMountedPageNumbers(),viewportPageNumber:e.getViewportAnchorPageNumber(),railTargetPageNumber:f,playbackPageNumbers:[...r(c.playbackForwardPageCount)],config:c}):null}function C(){let e=l;if(!e||!x())return;let t=S();t&&mc({enabled:s&&p===0,policy:t,evictPages:t=>e.evictPages(t)})}function w(){if(v)return()=>!1;p+=1;let e=!1;return()=>!e&&(e=!0,p=Math.max(0,p-1),!0)}function T(){let e=w();return{release(){e()&&p===0&&_&&k()}}}function E(){let e=w(),t=!1,r=0,i=()=>{t||(t=!0,r&&(n.clear(r),y.delete(r)),e()&&p===0&&C())};return{release:i,releaseAfterNavigation(){let e=n.set(()=>{y.delete(e),i()},Sc);r=e,y.add(e)}}}function D(){m&&=(t.cancel(m),0)}function O({clearPending:e=!0}={}){e&&(_=null),h&&=(t.cancel(h),0)}function k(){let e=_;if(!e||!b(e.display,e.generation)||!x()){_=null;return}h||=t.request(()=>{h=0;let e=_;if(!e||e.scrollRevision!==g||!b(e.display,e.generation)||!x()){_=null;return}p>0||(_=null,C())})}function A(e,t){!b(e,t)||!x()||(_={display:e,generation:t,scrollRevision:g},k())}async function j(){let e=l,t=u;if(!e||!b(e,t))return[];let n=e.root.clientHeight*xc;if(!e.getEvictedPageNumbersNearViewport({marginPx:n}).length)return[];let r=T(),o=[];try{o=await e.ensureEvictedPagesMountedNearViewport({marginPx:n}),b(e,t)&&(i(),a())}finally{r.release()}return o.length>0&&A(e,t),o}return{replaceDisplay(e){v||(l=e,u+=1,f=null,d=null,D(),O(),g=0)},markReady(e){v||l!==e||(d=e)},setRailTarget(e){v||(f=e)},pauseEviction:T,holdNavigation:E,onReaderScroll(){v||!x()||(g+=1,_&&={..._,scrollRevision:g},O({clearPending:!1}),!m&&(m=t.request(()=>{m=0,j().catch(e=>{console.error(`Failed to remount pages near the reader viewport`,e)}).finally(k)})))},afterPageRendered(){C()},destroy(){v||(v=!0,D(),O(),y.forEach(e=>n.clear(e)),y.clear(),l=null,d=null,u+=1,p=0)}}}var wc=[`viewport-title`,`inline-audio`,`reader-position`,`playback-state`];function Tc({frame:e,present:t}){let n=new Set,r=new Set,i=null,a=!1,o=0,s=e=>wc.filter(t=>e.has(t)),c=()=>i===null&&(i=e.request(()=>{if(i=null,a)return;let e=Object.freeze(s(n));n.clear();try{e.length>0&&(o+=1,t(Object.freeze({revision:o,invalidations:e})))}finally{if(r.size>0){for(let e of r)n.add(e);r.clear()}n.size>0&&c()}}),!0);return{invalidate(...e){if(!(a||e.length===0)){for(let t of e)n.add(t);c()}},invalidateAfterLayout(...e){if(!(a||e.length===0)){for(let t of e)r.add(t);c()}},destroy(){a||(a=!0,n.clear(),r.clear(),i!==null&&e.cancel(i),i=null)}}}var Ec=`[data-line-index][data-aliyah-starts]:not([data-reader-mirror])`;function Dc(e,t){let n=!1,r=!0,i=0,a=null,o=new Map,s=()=>{if(n)throw Error(`Reader progress anchor index has been destroyed`)},c=(e,t)=>{if(e.length===0)return Object.freeze({index:-1,current:null,next:null});let n=0,r=e.length;for(;n<r;){let i=n+Math.floor((r-n)/2);e[i].position<=t?n=i+1:r=i}let i=Math.max(0,n-1);return Object.freeze({index:i,current:e[i]??null,next:e[i+1]??null})},l=e=>{let t=e.closest(`.tikkun-page`);return t?t.tikkunPage?.lines[Number(e.dataset.lineIndex)]??null:null},u=()=>{let n=t?.now(),s=e.getBoundingClientRect(),u=[...e.querySelectorAll(Ec)],d=new Map,f=u.map((t,n)=>{let r=t.getBoundingClientRect(),i=t.querySelector(`.aliyah-label-text`)?.textContent?.trim()??`—`,a=(t.dataset.aliyahStarts??``).split(`,`),o=Qi(a[a.length-1]),c=l(t);return{anchor:Object.freeze({line:t,label:a.includes(`1`)?`ראשון`:i,run:c?.run??null,aliyahIndex:o,position:e.scrollTop+(r.top-s.top)}),sourceIndex:n}}).sort((e,t)=>e.anchor.position-t.anchor.position||e.sourceIndex-t.sourceIndex).map(({anchor:e})=>e),p=Object.freeze(f),m=i+1,h=Object.freeze({revision:m,anchors:p,at:e=>c(p,e)});for(let e of p)e.line&&d.set(e.line,e);return i=m,o=d,a=h,r=!1,t&&n!==void 0&&t.measure(`tikkun:reader:progress-anchor-rebuild`,{start:n,end:t.now(),detail:{anchorCount:p.length}}),h},d=()=>(s(),!r&&a?a:u());return{snapshot:d,anchorForElement(t){s();let n=t.closest(`[data-line-index]`);if(!n)return null;let r=d(),i=o.get(n);if(i)return i;let a=e.getBoundingClientRect(),c=n.getBoundingClientRect(),l=e.scrollTop+(c.top-a.top);return r.at(l).current},invalidate(){n||(r=!0)},destroy(){n||(n=!0,r=!1,a=null,o.clear())}}}var Oc=900;function kc({document:e,view:t,root:n,search:r,frame:i,timer:a,background:o,effects:s,factories:c=Ac()}){let l=new URLSearchParams(r).get(`debugPerformance`)===`1`?t.performance:void 0,u=new ic,d=new Ki,f=new Map,p=new Map,m=Dc(n,l),h=null,g=null,_=null,v=null,y=0,b=null,x=null,S=!1,C=Tc({frame:i,present:({invalidations:e})=>{if(!l){s.present(e);return}let t=l.now();try{s.present(e)}finally{l.measure(`tikkun:reader:presentation`,{start:t,end:l.now(),detail:{invalidations:e}})}}}),w=null,T=Cc({search:r,frame:i,timer:a,getPlaybackProtectedPageNumbers:e=>s.getPlaybackProtectedPageNumbers(e),refreshViewport:()=>w?.refresh(),invalidateReaderPosition:()=>C.invalidate(`reader-position`)});w=c.viewport(n);let E=w.on(`viewport-updated`,e=>{!h||n.style.visibility===`hidden`||(_=e,C.invalidate(`viewport-title`,`reader-position`))});function D(e,t){return!S&&h===e&&g===t&&t.isCurrent()}function O(e,t){let n={generation:t.generation,signal:t.signal,viewModel:e.viewModel,rendered:e.rendered,scrolled:e.scrolled,isCurrent:()=>D(e,t),getMountedPageNode:t=>e.getMountedPageNode(t),ensurePageMounted:(t,n)=>e.ensurePageMounted(t,n),ensurePageMountedForNavigation:(t,n)=>e.ensurePageMountedForNavigation(t,n),ensureNextContentMounted:()=>e.ensureNextContentMounted()};return Object.freeze(n)}function k(){let e=h,t=g;return!e||!t||!D(e,t)?null:O(e,t)}function A(){x?.pause(),x?.removeAttribute(`src`),x?.load(),x=null}function j(){y&&=(o.cancel(y),0)}function M(){m.invalidate(`reader-model`),d=new Ki,f.clear(),p.clear(),s.resetDisplayResources(),j(),b=null,A(),v=null}function N(e){return new Promise(t=>{let n=e=>{if(e<=0){t();return}i.request(()=>n(e-1))};n(e)})}function P(e){h?.destroy(),_=null,s.beforeDisplayReplacement(),M(),s.afterDisplayReplacementReset();let t=u.begin();g=t,n.style.visibility=`hidden`,n.setAttribute(`aria-busy`,`true`);let r=c.display(e,n);h=r,T.replaceDisplay(r),s.displayCreated(r);let i=r.rendered,a=r.scrolled.then(async()=>{D(r,t)&&(T.markReady(r),await N(2),D(r,t)&&(n.style.visibility=``,n.removeAttribute(`aria-busy`),w?.refresh()))});return a.catch(e=>{h===r&&(n.style.visibility=``,n.removeAttribute(`aria-busy`)),s.reportError(``,e)}),{ready:i,complete:a,isCurrent:()=>D(r,t),getMountedPageNode:e=>r.getMountedPageNode(e)}}function F(){u.cancel(),g=null,s.displayDeactivating(),h?.destroy(),h=null,T.replaceDisplay(null),M()}function ee(e,t){return`${e}:${t}`}function I(e,t){return`${e}:${t}`}function L(e){let[t]=e.split(`:`).map(Number);return Number.isInteger(t)?t:null}function R(e){let t=e.closest(`[data-page-number]`),n=Number(t?.dataset.pageNumber);return Number.isInteger(n)&&n>0?n:null}function te(e,t){return`[data-aliyah-marker="true"][data-run-id="${e}"][data-aliyah-index="${t}"]`}function ne(e){Ji(e).forEach(e=>{let t=Number(e.dataset.pageNumber),n=Number(e.dataset.lineIndex);Number.isFinite(t)&&Number.isFinite(n)&&p.set(I(t,n),e)}),e.querySelectorAll(`[data-aliyah-marker="true"]`).forEach(e=>{let t=e.dataset.runId,n=Qi(e.dataset.aliyahIndex);!t||!n||f.set(ee(t,n),e)})}function z(e){for(let[t]of p)L(t)===e&&p.delete(t);for(let[t,n]of f)(R(n)===e||!n.isConnected)&&f.delete(t)}function re(e,t){return t.viewModel.relevantRuns.find(t=>t.id===e)??s.resolveRun(e)}async function B(e,t,n=k()){if(!n)return null;let r=re(e,n);return r?d.get(n.viewModel,r,t):null}function V(t,n){let r=ee(t,n),i=f.get(r);if(i?.isConnected)return i;let a=e.querySelector(te(t,n));return a?f.set(r,a):f.delete(r),a}function ie(e,t=k(),n){if(!t)return null;let r=qi(e);if(n)return Yi(n,r);let i=I(e.pageNumber,r),a=p.get(i);if(a?.isConnected)return a;let o=t.getMountedPageNode(e.pageNumber),s=o?Yi(o,r):null;return s&&p.set(i,s),s}async function ae(e,t){let n=k();if(!n)return null;let r=V(e,t);if(r)return T.setRailTarget(R(r)),{element:r,marker:r};let i=await B(e,t,n);if(!n.isCurrent())return null;if(i){T.setRailTarget(i.pageNumber);let a=await n.ensurePageMountedForNavigation(i.pageNumber,{runId:e});if(!n.isCurrent())return null;if(r=V(e,t),r)return{element:r,marker:r};let o=a?ie(i,n,a):null;if(o)return{element:o,marker:null}}for(;!r;){if(!n.isCurrent())return null;let i=await n.ensureNextContentMounted();if(!n.isCurrent()||!i)return null;r=V(e,t)}return{element:r,marker:r}}function oe(e){let t=k();if(!t)return Promise.resolve();if(v)return v;let n=(async()=>{let n=m.snapshot().anchors;for(;t.isCurrent()&&n.length<=e+1;){let e=await t.ensureNextContentMounted();if(!t.isCurrent()||!e)break;n=m.snapshot().anchors}})().finally(()=>{v===n&&(v=null)});return v=n,n}function se(e){let n=e?new URL(e,t.location.href).href:null;if(x?.src===n||(A(),!e))return;let r=c.audio();r.preload=`metadata`,r.src=e,r.load(),x=r}function H(e,t){let n=k();if(!n||t===b)return;b=t,j();let r=0,i=new Set,a=()=>{if(y=0,!n.isCurrent()||t!==b)return;if(s.isPlaybackActive()){y=o.delay(a,Oc);return}let c=e[r];c&&(r+=1,(async()=>{let e=await d.get(n.viewModel,c.run,c.aliyahIndex),t=e?`${c.run.id}:${e.pageNumber}`:null;e&&t&&!i.has(t)&&n.isCurrent()&&(i.add(t),await n.viewModel.fetchPageByPageNumber(e.pageNumber,{runId:c.run.id})),n.isCurrent()&&await s.prewarmCueData(c)})().catch(e=>{s.reportError(`Failed to prewarm aliyah resources`,e)}).finally(()=>{r<e.length&&n.isCurrent()&&t===b&&(y=o.request(a))}))};n.scrolled.then(()=>{!n.isCurrent()||t!==b||(y=o.request(a))})}return{render:P,deactivate:F,capture:k,isReaderReady:()=>k()!==null,async waitUntilReaderReady(){let e=k();e&&(await e.rendered,await e.scrolled)},viewportRange:()=>_,resetViewport(){_=null},refreshViewport(){w?.refresh()},setPagePresentation(e,t){return!h||h.usesPresentation(e)||(p.clear(),f.clear(),!h.setPresentation(e,t))?!1:(m.invalidate(`text-layout`),w?.refresh(),C.invalidateAfterLayout(`reader-position`),!0)},updateAnnotations(e){h?h.updateAnnotations(e):e(),m.invalidate(`annotations`),w?.refresh(),C.invalidateAfterLayout(`reader-position`)},progressSnapshot:()=>m.snapshot(),progressAnchorForElement:e=>m.anchorForElement(e),invalidateProgressAnchors:e=>m.invalidate(e),ensureNextProgressAnchorLoaded:oe,invalidatePresentation:(...e)=>C.invalidate(...e),invalidatePresentationAfterLayout:(...e)=>C.invalidateAfterLayout(...e),onReaderScroll(e){e(),C.invalidate(`reader-position`),T.onReaderScroll()},pageRendered(e,t){l?.mark(`tikkun:reader:page-rendered`,{detail:{generation:g?.generation??null}}),ne(e),t(),m.invalidate(`page-rendered`),T.afterPageRendered(),C.invalidateAfterLayout(`reader-position`)},pageEvicted(e){l?.mark(`tikkun:reader:page-evicted`,{detail:{generation:g?.generation??null,pageNumber:e}}),m.invalidate(`page-evicted`),C.invalidateAfterLayout(`reader-position`),e!==null&&z(e)},getRenderedLineForLocation:ie,ensureAliyahDomTargetRendered:ae,pauseEviction:()=>T.pauseEviction(),holdNavigation:()=>T.holdNavigation(),syncAudioPreload:se,scheduleResourcePrewarm:H,destroy(){S||(S=!0,u.cancel(),g=null,h?.destroy(),h=null,M(),E(),w?.destroy(),w=null,_=null,C.destroy(),m.destroy(),T.destroy())}}}function Ac(){return{display:(e,t)=>new Ws(e,t),viewport:e=>new ac(e),audio:()=>new Audio}}function jc({source:e,viewportPosition:t,getScrollHeight:n,rangeCurrent:r,isLastAnchor:i}){let a=e.anchors;if(a.length===0)return Object.freeze({kind:`empty`,current:null,label:`Loading`,progressIndex:-1,percent:0,requestNextAnchor:null});let{index:o,current:s}=e.at(t),c=r??s,l=c?.line!==null&&c?.line!==void 0?a.findIndex(e=>e.line===c.line):o,u=l>=0?l:o,d=a[u]??s,f={current:c,label:c?.label??`—`,progressIndex:u};if(!d)return Object.freeze({...f,kind:`ready`,percent:0,requestNextAnchor:null});let p=u+1;for(;a[p]?.position<=d.position;)p+=1;let m=a[p]?.position??(i(d)?Math.max(d.position+1,n()):null);if(m===null)return Object.freeze({...f,kind:`request-next-anchor`,percent:null,requestNextAnchor:Object.freeze({afterIndex:u})});let h=Math.max(0,Math.min(1,(t-d.position)/(m-d.position)));return Object.freeze({...f,kind:`ready`,percent:h*100,requestNextAnchor:null})}function Mc(){return`
    <main class="page-not-found">
      <p class="page-not-found-eyebrow">Reader</p>
      <h1>Page Not Found</h1>
      <p>This passage isn't available. Return to the Reading Index to choose another place.</p>
      <button class="page-not-found-action" data-target-id="open-reading-index" type="button">
        Open Reading Index
      </button>
    </main>
  `}async function Nc(e,{signal:t,load:n=()=>L(()=>import(`./Cwy8DojY.js`),__vite__mapDeps([24,25,8,1,10,7,9,13,2,5,6,11,26]),import.meta.url)}){let r=await n();t.aborted||(e.innerHTML=r.default(),!t.aborted&&await r.mountCueAnalyticsPage(e,{signal:t}))}var Pc=`תיקון קוראים`;function Fc(e){return e?.replace(/^פרשת /,``)??`תיקון קוראים`}var Ic=`#/next`,Lc=`תיקון קוראים`;function Rc(e,t){let n=e.querySelector(t);if(!n)throw Error(`Reader Route requires ${t}`);return n}function zc(e){if(!e)return null;let[,t]=e.match(/^#\/(?:torah|esther)\/page\/(\d+)$/)??[];if(!t)return null;let n=Number(t);return Number.isInteger(n)?n:null}function Bc(e,t){let{document:n,view:r,shell:i,host:a}=t,o=Rc(n,`[data-target-id="about-view"]`),s=Rc(n,`[data-target-id="reader-shell"]`),c=!1,l=null,u=()=>{l?.resolve(),l=null},d=null,f=null,p=!1,m=0,h=null,g=!1,_=null,v=null,y=null,b=Ic,x=Pc,S=!1,C=null,w=null,T=null,E=(e=r.location.hash)=>e.split(`?`,1)[0],D=e=>Be(t.createGenerator(),E(e).replace(/^#/,``)),O=()=>D(r.location.hash),k=e=>{x=e,i.setTitle(e)},A=()=>{d?.abort(),d=null},j=()=>{f?.destroy(),f=null},M=()=>{let e=!!f||p,t=T,r=_===`not-found`&&O()?.view===`not-found`;m+=1,p=!1,_=null,w=null,T=null,g=!1,j(),i.setPickerOpen(!1),a.pickerChanged(!1),r&&i.setView(`optional`),e&&(t?.focus({preventScroll:!0}),n.activeElement!==t&&i.focusTitle())},N=(e,t={})=>{if(C=t.offerReturnToPreviousReading?w??a.captureReadingPosition():null,t.saveReadingAfterRender&&(S=!0,a.dismissLastReadingPrompt()),(f||p)&&M(),r.location.hash===e){let t=D(e);t&&oe(t);return}r.location.hash=e},P=e=>{let t=E(e);if(!c||y===null||!i.isReaderVisible()||!t||t===y&&t===E())return!1;let n=D(t);if(n?.view!==`reader`)return!1;let a=ne(y,n.canonicalHash??t);if(!a)return!1;let o=new URL(r.location.href);o.hash=a;let s=o.href!==r.location.href;return s&&r.history.replaceState(r.history.state,``,o),y=a,b=a,s},F=()=>(h??=(t.loadParshaPicker??(()=>L(()=>import(`./CQFeuete.js`),__vite__mapDeps([27,1,2,13,5,6,7,8,9,10,11,28,3,4,12,29]),import.meta.url)))().catch(e=>{throw h=null,e}),h),ee=()=>{let e=_===`not-found`&&O()?.view===`not-found`;_=null,g=!1,i.setPickerOpen(!1),a.pickerChanged(!1),e&&i.setView(`optional`)},I=(r=null,{animate:o=!1,focusSearch:c=!o}={})=>{T=n.activeElement instanceof HTMLElement?n.activeElement:null,j();let l=o,u=++m;p=!0,g=c,_=r,w=a.captureReadingPosition(),a.preparePicker(),F().then(({default:n})=>{if(e.signal.aborted||u!==m||!p)return;let r=n(t.createGenerator(),{calendarSettings:t.getCalendarSettings(),animateOnOpen:l,onCalendarSettingsChange:e=>{if(t.updateCalendarSettings(e),!f)return;let n=_;M(),I(n)},navigate:e=>{N(e,{saveReadingAfterRender:!0,offerReturnToPreviousReading:!0})},getActions:t.getSearchActions,requestClose:M,isBookmarkAction:t.isBookmarkAction,formatBadge:t.formatSearchBadge});try{s.appendChild(r.node),r.onMount(),f=r,p=!1,_===`not-found`&&i.setView(`reader`),i.setPickerOpen(!0),a.pickerChanged(!0);let e=g;g=!1,e?r.focusSearch():r.node.focus({preventScroll:!0})}catch(e){if(r.destroy(),u!==m)return;p=!1,ee(),a.pickerLoadFailed(e)}}).catch(t=>{e.signal.aborted||u!==m||(p=!1,ee(),a.pickerLoadFailed(t))})},R=(e={})=>{let t=O(),n=!!(v?.isCurrent()&&i.isReaderVisible());if(t?.view!==`reader`&&!n){N(b);return}f||p?M():I(null,e)},te=()=>f?(f.focusSearch(),!0):p?(g=!0,!0):!1,z=()=>{f?.refreshSearch()},re=(e,t)=>{let n=zc(e);if(!n)return;let i=t.getMountedPageNode(n)?.querySelector(`.tikkun-page-number`);i&&(i.classList.remove(`mod-route-reveal`),i.offsetWidth,i.classList.add(`mod-route-reveal`),r.setTimeout(()=>{i.classList.remove(`mod-route-reveal`)},1900))},B=()=>{v=null,a.leaveReader(),A()},V=()=>{B(),M(),i.setView(`optional`),o.innerHTML=Mc(),Rc(n,`[data-target-id="open-reading-index"]`).addEventListener(`click`,()=>{I(`not-found`,{animate:!0})},{signal:e.signal}),k(Lc)},ie=e=>{if(B(),e.view===`about`){a.openAbout();return}i.setView(`optional`),o.innerHTML=`<section class="about-card" aria-busy="true"><h2>Loading Cue Analytics</h2></section>`;let t=new AbortController;d=t,Nc(o,{signal:t.signal}).catch(e=>{t.signal.aborted||(console.error(`Failed to load Cue Data analytics`,e),o.innerHTML=`<section class="about-card"><h2>Analytics unavailable</h2><p>Reload this page to try again.</p></section>`)}),k(Lc)},ae=(e,t)=>{A(),k(Fc(e.model.initialTitle)),i.setView(`reader`),o.innerHTML=``;let n=(e.canonicalHash??E())||b,s=new URL(r.location.href);s.hash=n,s.href!==r.location.href&&r.history.replaceState(null,``,s);let c=y!==null&&y!==n;c&&a.readerRouteChanged(n),c&&(f||p)&&M(),y=n,b=n;let d=a.renderReader(e.model);v=d;let m=S;S=!1;let h=()=>v===d&&d.isCurrent(),g=d.ready.then(()=>{h()&&(a.readerReady(),t&&t.hash!==n&&a.showReturnToPreviousReading(t))});Promise.all([g,d.complete]).then(()=>{h()&&(m&&a.saveReadingPosition(),re(n,d),u())}).catch(e=>{h()&&(console.error(`Failed to render reader route`,e),l?.reject(e),l=null)})};function oe(e){let t=C;if(C=null,e.view===`not-found`){V(),u();return}if(e.view===`about`||e.view===`cue-analytics`){ie(e),u();return}ae(e,t)}return e.own(()=>{A(),l=null,v=null,m+=1,p=!1,h=null,C=null,w=null,j()}),{start:n=>{if(c)throw Error(`Reader Route is already started`);c=!0;let i=new Promise((e,t)=>{l={resolve:e,reject:t}});r.addEventListener(`hashchange`,()=>{let e=O();e?oe(e):C=null},{signal:e.signal});let a=!r.location.hash&&n!==void 0,o=a?n.resumeHash:null,s=o?D(o):null,u=o&&s?.view===`reader`?{...s,canonicalHash:s.canonicalHash??E(o)}:null;return oe(u??O()??{view:`reader`,canonicalHash:Ic,model:et.forDate(t.createGenerator(),new Date)}),a&&!u&&I(null,{focusSearch:!1}),i},navigate:N,syncScrolledReading:P,toggleAbout:()=>{a.openAbout()},togglePicker:R,focusPickerSearch:te,refreshPickerSearch:z,closePicker:M,setTitle:k,snapshot:()=>({view:O()?.view??null,hashPath:E(),currentReaderHash:y,title:x,pickerOpen:!!f||p})}}function Vc(e,t){let n=t.document.querySelector(`[data-target-id="last-reading-prompt"]`),r=t.document.querySelector(`[data-target-id="last-reading-copy"]`),i=t.document.querySelector(`[data-target-id="last-reading-dismiss"]`),a=t.document.querySelector(`[data-target-id="last-reading-resume"]`),o=null,s=()=>{n?.classList.add(`u-hidden`)},c=()=>{o=null,s()};return i?.addEventListener(`click`,c,{signal:e.signal}),a?.addEventListener(`click`,()=>{if(!o)return;let e=o;c(),t.onResume(e)},{signal:e.signal}),e.own(()=>{o=null,s()}),{show:(e,s=`resume`)=>{if(t.disabled||!n||!r)return;let c=e.aliyahLabel?`${e.parshaName}, ${e.aliyahLabel}`:e.parshaName;r.textContent=`${s===`return`?`Return to`:`Resume`} ${c}?`,a&&(a.textContent=s===`return`?`Return`:`Resume`),i?.setAttribute(`aria-label`,s===`return`?`Dismiss return prompt`:`Dismiss resume prompt`),o=e,n.classList.remove(`u-hidden`)},hide:s,dismiss:c}}function Hc(e,t){let n=t.document.querySelector(`[data-target-id="app-offline-prompt"]`),r=t.document.querySelector(`[data-target-id="app-offline-dismiss"]`),i=!1,a=null,o=({force:e=!1}={})=>{e&&(i=!1),i||n?.classList.remove(`u-hidden`)},s=()=>{n?.classList.add(`u-hidden`)};return r?.addEventListener(`click`,()=>{i=!0,s()},{signal:e.signal}),t.view.addEventListener(`online`,()=>{i=!1,s();let e=a;a=null,!(!e||e.isCurrent?.()===!1)&&e.retry().catch(n=>{e.isCurrent?.()!==!1&&t.onRetryError(n)})},{signal:e.signal}),e.own(()=>{a=null,s()}),{recordPlaybackFailure:(e,t)=>{a={retry:e,isCurrent:t},o({force:!0})},clearPlaybackFailure:()=>{a=null,s()},hide:s}}function Uc({getValue:e,setValue:t,isDisabled:n}){let r=null,i=()=>{if(r===null)return;let e=r;r=null,t(e)};return{handleKeyDown(i){i.key!==`Shift`||i.repeat||i.metaKey||i.ctrlKey||i.altKey||Kc(i.target)||n()||r!==null||(r=e(),t(!r))},handleKeyUp(e){e.key===`Shift`&&i()},release:i}}function Wc(e){return{metaOrCtrl:!1,shift:!1,alt:!1,...e,key:e.key.toLocaleLowerCase()}}function Gc(e,t,n){let r=t.key.toLocaleLowerCase();return e.find(e=>e.modes.includes(n)&&e.key===r&&e.metaOrCtrl===(t.metaKey||t.ctrlKey)&&e.shift===t.shiftKey&&e.alt===t.altKey)??null}function Kc(e){if(!e||typeof e!=`object`)return!1;let t=e;return!!(t.isContentEditable||t.closest?.(`input, textarea, select, button, [contenteditable="true"]`))}function qc(e,t){let n=fo(),r=null,i=null,a=null,o=0,s=!1,c=()=>{if(r)return Promise.resolve(r);if(a)return a;i??=(t.load??(()=>L(()=>import(`./CkbWkhlf.js`),__vite__mapDeps([30,1,2,10,25,8,7,9,31,13,15,6,32]),import.meta.url)))();let o=i.then(i=>{if(e.signal.aborted)return null;let a=null,o=n(e=>{let n=t.mount(e,i);a=n,r=n,t.onMounted(n),e.own(()=>{t.onUnmounted(n),r===n&&(r=null)})});e.own(o);let c=a;return c?.restoreAccessState(),s&&c?.setVisible(!1),c}).catch(e=>(i=null,t.onLoadError(e),null)).finally(()=>{a===o&&(a=null)});return a=o,o},l=()=>{s=!0,o+=1,r?.setVisible(!1)},u=()=>{if(r)return r.isUnlocked();try{return Ne(t.sessionStorage).unlocked}catch(e){return t.onLoadError(e),!1}};return e.own(()=>{s=!0,o+=1,r=null,a=null,i=null}),{isUnlocked:u,open:()=>{if(!u())return;s=!1;let e=++o;c().then(t=>{!t||e!==o||s||t.setVisible(!0)})},restoreIfOpen:()=>{try{if(!Ne(t.sessionStorage).panelOpen)return}catch(e){t.onLoadError(e);return}s=!1,c()},handleShortcut:e=>{if(r)return r.handleKeydown(e);if(!Pe(e))return!1;e.preventDefault(),s=!1;let t=++o;return c().then(n=>{!n||t!==o||s||n.handleKeydown(e)}),!0},close:l}}function Jc({document:e,view:t,localStorage:n,sessionStorage:r,recordingMode:i,aboutHref:a,downloadOwner:o,openAbout:s}){let c=t,l=t.location,u=t.navigator,d=t.requestAnimationFrame.bind(t),f=t.cancelAnimationFrame.bind(t),{whenKey:p}=jn,m=ie(n),h=m.settings,g=m.revision,_=()=>new Le(oe(h)),v=fo(),y=null,b=null,x=Fr(),S=0,C=null,w=null,T=null,E=null,D=null,O=null,k=new Map,A=xn(),j=new Dn({recordings:wt(),rangeForRecording:A,loadTokens:yn,loadCues:kt}),M=new Set,N=new Map;function P(e,t){let n=`${e.id}:${t}:${x.narratorId}`,r=z?.snapshot();if(r?.error&&r.session?.runId===e.id&&r.session.aliyahIndex===t)return{problem:`load-failed`,issue:`audio`,canPlay:!1,recording:r.session.recording,message:`The recording could not load. Try again.`};if(N.has(n))return N.get(n);let a=e.aliyot.find(e=>e.index===t);if(!a||e.scroll!==`torah`||i.enabled||I?.isActive())return;let o=x.narratorId,s=j.peek(a,o),c=`${e.id}:${t}:${o}`;return s.problem===`checking`&&!M.has(c)&&(M.add(c),j.resolve(a,o).then(()=>{M.delete(c),z&&(Hr(),Br())},e=>{M.delete(c),console.error(`Could not resolve passage audio`,e),z&&(Hr(),Br())})),s}function F(e){if(!e)return;let t=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.runId)??_().parseId(e.runId);return t?P(t,e.aliyahIndex):void 0}let ee=null,I=null,ne=null,z=null,H=null,U=null,W=null,G=null,K=null,q=null,J=null,Y=null,ue=[],de=null,fe=null,me=[],he=[],ge=null,X=[],be=i.enabled?`recording`:`normal`,xe=!0,Se=!1,Ce=!1,Ee=null,De=!1;function Oe(){if(!y)throw Error(`Reader display session is not mounted`);return y}function ke(e,t,n){return`${e}:${t}:${n}`}function Ae(e,t,n){return k.get(ke(e,t,n))??null}function je(){k.clear(),O?.invalidate()}function Ne(e,t){Hn(e,t).then(()=>{t.aborted||!y||(y.invalidateProgressAnchors(`text-layout`),zr())}).catch(e=>{console.error(`Failed to align special Hebrew letters`,e)})}function Pe(){return new URLSearchParams(l.search).get(`debugActiveToken`)}function Z(e){return Oe().render(e)}function Ie(){y?.deactivate()}function Re(t,{assertive:n=!1}={}){let r=e.querySelector(`[data-target-id="persistence-toast"]`);r&&(b!==null&&c.clearTimeout(b),r.setAttribute(`role`,n?`alert`:`status`),r.setAttribute(`aria-live`,n?`assertive`:`polite`),r.textContent=t,r.classList.remove(`u-hidden`),b=c.setTimeout(()=>{r.classList.add(`u-hidden`),r.textContent=``,r.setAttribute(`role`,`status`),r.setAttribute(`aria-live`,`polite`),b=null},6e3))}let Q=e=>Re(e);function ze(e){if(!e?.run)return null;let t=e.run.aliyot.find(t=>t.index===e.aliyahIndex),n=t?.start?Jn(e.run,t.start):Jn(e.run);return!n||n===`#/next`?null:n}function Be(e){let t=y?.capture(),n=ze(e);return!t||!e?.run||!n?null:{hash:n,parshaName:t.viewModel.displayTitleForRun(e.run),aliyahLabel:e.label===`—`?void 0:e.label}}function Ve(e){if(i.enabled||K?.snapshot().view!==`reader`)return;let t=Be(e);if(t)try{Zn(n,t)}catch(e){console.error(`Failed to save the current reading position`,e),Q(`Your reading position could not be saved in this browser.`)}}function Ue(){let e=y;if(!e?.capture())return null;let t=ut();return e.progressSnapshot().at(mr(t)).current}function Ge(){let e=K?.snapshot();if(i.enabled||e?.view!==`reader`)return null;let t=Be(Ue()),n=Date.now();if(t)return{...t,savedAt:n};let r=y?.capture();if(r){let t=r.viewModel.relevantRuns.find(t=>Fc(r.viewModel.displayTitleForRun(t))===e.title);if(t)return{hash:Jn(t,t.aliyot[0]?.start),parshaName:r.viewModel.displayTitleForRun(t),savedAt:n}}let a=e.currentReaderHash===`#/next`?null:e.currentReaderHash;return a?{hash:a,parshaName:e.title,savedAt:n}:null}function qe(){Ve(Ue())}function Ze(){O?.closeCompact(),z?.resetRoute(),me=[],he=[],ge=null,X=[],I?.recordingIssuesChanged(),I?.clearSession(),Bn(),Ar(),jr(null)}function $e(e){try{g=V(e,n,g)}catch(t){if(console.error(`Failed to save calendar settings`,t),t instanceof ae&&t.cause instanceof ce&&t.cause.reason===`conflict`){let t=ie(n);try{g=V(e,n,t.revision)}catch(e){console.error(`Failed to save calendar settings after refreshing browser state`,e),Q(`Calendar settings changed in another tab. This choice applies now but could not be saved.`)}}else Q(`Calendar settings will apply now but could not be saved.`)}h=e}let et=e=>{let t=ut(),n=y,r=()=>{xe=e,pt().setAnnotationsEnabled(e),Nn(t,e)};n?n.updateAnnotations(r):r();let i=n?.capture();i&&Ne(t,i.signal),hr(t),n&&zr(),U?.sync()},tt=(e,t)=>{let n=null,r=()=>{n!==null&&clearTimeout(n),n=setTimeout(()=>{n=null,e()},t)};return r.cancel=()=>{n!==null&&clearTimeout(n),n=null},r},nt=()=>{e.documentElement.style.setProperty(`--app-height`,`${c.innerHeight}px`)},rt=0;function it(){rt&&=(f(rt),0),e.querySelectorAll(`.debug-focal-line, .debug-focal-measure`).forEach(e=>e.remove())}function at(){if(e.querySelector(`.debug-focal-line, .debug-focal-measure`)){it();return}let t=(t,n)=>{let r=e.createElement(`div`);return r.className=`debug-focal-line`,r.style.cssText=`
        position: fixed;
        left: 0;
        right: 0;
        height: 0;
        border-top: 2px solid ${t};
        z-index: 999999;
        pointer-events: none;
        font: 13px sans-serif;
        color: white;
        text-shadow: 0 1px 2px black;
      `,r.textContent=n,e.body.appendChild(r),r},n=(t,n,r)=>{let i=e.createElement(`div`),a=e.createElement(`div`);return i.className=`debug-focal-measure`,a.className=`debug-focal-measure`,i.style.cssText=`
        position: fixed;
        left: ${n}px;
        width: 0;
        border-left: 2px dashed ${t};
        z-index: 999999;
        pointer-events: none;
      `,a.style.cssText=`
        position: fixed;
        left: ${n+8}px;
        z-index: 999999;
        pointer-events: none;
        padding: 2px 6px;
        border-radius: 4px;
        background: rgba(0, 0, 0, 0.72);
        color: white;
        font: 13px sans-serif;
        white-space: nowrap;
      `,e.body.append(i,a),{update(e,t){let n=Math.min(e,t),o=Math.abs(t-e);i.style.top=`${n}px`,i.style.height=`${o}px`,a.style.top=`${n+o/2-12}px`,a.textContent=`${r}: ${Math.round(o)}px`}}},r=`lightskyblue`,i=t(`red`,`Browser center`),a=t(r,`Reader center`),o=n(`red`,24,`Browser top`),s=n(`red`,104,`Browser bottom`),c=n(r,220,`Reader top`),l=n(r,300,`Reader bottom`),u=()=>{let t=e.querySelector(`[data-target-id="tikkun-book"]`);if(!t||!i.isConnected){it();return}let n=t.getBoundingClientRect(),r=e.documentElement.clientHeight,f=r/2,p=n.top,m=n.top+t.clientHeight,h=p+t.clientHeight/2;i.style.top=`${f}px`,a.style.top=`${h}px`,o.update(0,f),s.update(f,r),c.update(p,h),l.update(h,m),rt=d(u)};u()}function ot(t){e.addEventListener(`click`,e=>{let t=e.target;t instanceof Element&&t.closest(`[data-target-id="debug-focal-measure-toggle"]`)&&at()},{signal:t.signal}),t.own(it)}function st(e,t){let n=()=>{t.classList.add(`mod-pull-releasing`),t.style.setProperty(`--pull-translation`,`0`)},r=0;t.addEventListener(`touchstart`,e=>{t.classList.remove(`mod-pull-releasing`),r=e.changedTouches[0].screenX},{signal:e.signal}),t.addEventListener(`touchmove`,e=>{let n=e.changedTouches[0].screenX,i=-Math.max(n-r,-100);i<30||t.style.setProperty(`--pull-translation`,`${30-i}px`)},{signal:e.signal}),t.addEventListener(`touchend`,n,{signal:e.signal}),t.addEventListener(`touchcancel`,n,{signal:e.signal}),e.own(()=>{t.classList.remove(`mod-pull-releasing`),t.style.removeProperty(`--pull-translation`)})}function ct(e){T=e,E=K?.snapshot().hashPath??l.hash.split(`?`,1)[0]}function lt(){T=null,E=null}function ut(){return e.querySelector(`[data-target-id="tikkun-book"]`)}function dt(){return{layout:x.readerTextLayout,sides:wr(x.readerSideMode,ht())}}function ft({rerender:e=!0,beforeLayout:t}={}){let n=ut(),r=dt(),i=e&&(y?.setPagePresentation(r,t)??!1);if(i||t?.(),n.dataset.readerLayout=r.layout,n.dataset.readerSides=r.sides,!i)return!1;y?.invalidateProgressAnchors(`text-layout`);let a=y?.capture()?.signal;return a&&Ne(n,a),hr(n),zr(),z?.syncHighlight({scroll:!1}),!0}function pt(){if(!G)throw Error(`Reader Shell is not mounted`);return G}function mt(){ut().focus({preventScroll:!0})}function ht(){return ee?.isCompact()??!1}function gt(e){return e instanceof HTMLElement?e.isContentEditable||!!e.closest(`input, textarea, select, button`):!1}function _t(){return i.enabled?`recording`:I?.isActive()?`admin-authoring`:be===`practice-focus`?`practice-focus`:`normal`}function xt(){ne?ne.close():I?.setVisible(!1)}function St(){let t=_t(),n=t!==be;be=t,e.documentElement.dataset.readerMode=be,n&&(z?Ur():Mn())}function Tt(){return z?.snapshot().activeTokenKey||Et()}function Et(){let e=Cr(ut());return e?e.dataset.tokenKey?e.dataset.tokenKey:Sr(e)?.dataset.tokenKey??e.querySelector(`.word[data-token-key]`)?.dataset.tokenKey??null:null}function Dt(t){return e.querySelector(`[data-token-key="${t}"]`)?.textContent?.trim().replace(/\s+/g,` `)||`Word ${t}`}async function jt(e,t={}){let n=ye(e);if(!n)throw TypeError(`Invalid token key: ${e}`);let r=Oe(),i=r.holdNavigation();try{await r.capture()?.ensurePageMountedForNavigation(n.pageNumber),i.releaseAfterNavigation();let a=await z?.activateToken(e,{scroll:!0});a||i.release(),t.audioTime!==void 0&&z?.snapshot().session&&z.seek(t.audioTime),a&&jr(r.progressAnchorForElement(a)),mt()}catch(e){throw i.release(),e}}function Nt(){let e=Et();if(!e)return;if(ue.find(t=>t.tokenKey===e)){let t=ue.filter(t=>t.tokenKey!==e);if(!Pt(t))return;ue=t,tn(),U?.sync();return}let t=z?.snapshot().session,n=z?.cueForToken(e),r=[vo({hash:It(e),label:Dt(e),tokenKey:e,audioId:t?.recording.id,timeStart:n?.timeStart}),...ue.filter(t=>t.tokenKey!==e)];Pt(r)&&(ue=r,tn(),U?.sync())}function Pt(e){try{return de=So(n,e,de),!0}catch(e){if(console.error(`Failed to save reader bookmarks`,e),e instanceof Co&&e.cause instanceof ce&&e.cause.reason===`conflict`){let e=xo(n,cr);return ue=e.bookmarks,de=e.revision,tn(),U?.sync(),Q(`Bookmarks changed in another tab. Review the latest list and try again.`),!1}return Q(`Bookmarks could not be saved in this browser.`),!1}}function Ft(e=Et()){let t=!!(e&&ue.some(t=>t.tokenKey===e));return{bookmarkAvailable:!!e,bookmarked:t,annotationsEnabled:xe,aliyahNavigationAvailable:On(),shareAvailable:R(Lt())}}function It(t){let n=e.querySelector(`[data-token-key="${t}"]`),r=n?Er(n):null,i=r?.verses[0],a=i&&r?.run?{...i,scroll:r.run.scroll}:r?.run?.aliyot[0]?.start;if(r?.run)return Jn(r.run,a);let o=K?.snapshot().currentReaderHash;return o&&o!==`#/next`?o:l.hash}function Lt(){let e=Et();return e?It(e):K?.snapshot().currentReaderHash??``}function Rt(e){return{id:e.id,kind:`bookmark`,source:`bookmark`,label:e.label,hash:e.hash,audioId:e.audioId,tokenKey:e.tokenKey,timeStart:e.timeStart,createdAt:e.createdAt}}function zt(e){let t=/^#\/run\/([^/]+)/.exec(e.hash)?.[1];if(t){let e=_().parseId(t);return e?qt(e):null}let n=/^#\/(?:torah|esther)\/parsha\/([^/]+)/.exec(e.hash)?.[1];return n?n.replace(/-/g,` `):null}function Bt(e){return/[A-Za-z]/.test(e)?e.replace(/\S+/g,e=>e.charAt(0).toLocaleUpperCase()+e.slice(1).toLocaleLowerCase()):e}function Vt(e){return e.id.startsWith(`checkpoint.bookmark:`)}function Ut(){let e=[...ue.map(Rt),...Te(X).map(ho)],t=z?.snapshot().session,n=Tt();if(t&&n){let r=z?.cueForToken(n);r&&e.push(mo({audioId:t.recording.id,label:`Current word`,tokenKey:n,timeStart:r.timeStart}))}return e.sort(go)}function Wt(e){if(e.hash&&e.hash!==l.hash){l.hash=e.hash,c.setTimeout(()=>{jt(e.tokenKey,{audioTime:e.timeStart})},0);return}jt(e.tokenKey,{audioTime:e.timeStart})}async function Gt(e,t,n=Xn.start()){let r=Oe(),i=r.holdNavigation(),a;try{a=await r.ensureAliyahDomTargetRendered(e,t)}catch(e){throw i.release(),e}if(!Xn.isCurrent(n)||!a){i.release();return}let o=a.element.closest(`[data-line-index]`);i.releaseAfterNavigation(),gr(ut(),o??a.element,{behavior:`smooth`}),jr(r.progressAnchorForElement(o??a.element)),r.refreshViewport(),Br(),c.setTimeout(()=>{r.refreshViewport(),Br()},500),mt()}function Kt(){let e=_(),t=new Date;t.setHours(0,0,0,0);let n=new Ke(t).getFullYear(),r=[],i=new Set;for(let a=n;a<=n+2;a+=1)for(let n of e.forHebrewYear(a))if(!(n.date<t))for(let e of n.leinings){let t=We(e);if(!t||i.has(t.id))continue;i.add(t.id);let a=`${n.title.en} / ${n.title.he}`;if(r.push(tr({id:`reading.holiday.${t.id}`,group:`reading`,label:a,aliases:[n.title.en,n.title.he],keywords:Je(n.title,`${e.id}`),showWhenEmpty:!1,destinationId:Jn(t),href:Jn(t),run:()=>K?.navigate(Jn(t))})),r.length>=16)return r}return r}function qt(e){return e.leining.date.title.he||e.leining.date.title.en}function Jt(){let e=_(),t=new Date;t.setHours(0,0,0,0);let n=new Ke(t).getFullYear(),r=[],i=new Set;for(let a=n;a<=n+2;a+=1)for(let n of e.forHebrewYear(a))if(!(n.date<t)){for(let e of n.leinings)if(e.isParsha)for(let t of e.runs){if(t.scroll!==`torah`||i.has(t.id))continue;i.add(t.id);let e=vt(t);r.push(...ir({run:t,displayTitle:qt(t),showWhenEmpty:!1,dedupeKeyPrefix:e?`reading.parsha.${e}`:void 0,navigate:e=>K?.navigate(e)}))}}return r}function Yt(e){let t=We(e);return t?[t]:[]}function Zt(){let e=_(),t=new Ke(new Date).getFullYear(),n=[],r=new Set;for(let i=t;i<=t+1;i+=1)for(let t of e.forHebrewYear(i))for(let e of t.leinings)if(!e.isParsha)for(let t of Yt(e))r.has(t.id)||(r.add(t.id),n.push(...ir({run:t,displayTitle:qt(t),showWhenEmpty:!1,navigate:e=>K?.navigate(e)})));return n}function Qt(e){let t=[e.parshaSlug,e.parshaName,...Me(e.parshaSlug)];return[...t,...t.flatMap(t=>[`${t} ${e.aliyah}`,`${t} Aliyah ${e.aliyah}`])]}function $t(){let e=[tr({id:`reading.current`,group:`reading`,label:`Today / Next Reading`,aliases:[`Today`,`Next Reading`,`Next Shabbat`],keywords:[`current reading`,`upcoming reading`],emptyPriority:100,destinationId:`#/next`,href:`#/next`,run:()=>K?.navigate(`#/next`)}),tr({id:`tools.analytics`,group:`tools`,label:`Cue Analytics`,aliases:[`Playback Analytics`,`Word Analytics`],keywords:[`timing`],emptyPriority:40,run:()=>K?.navigate(Ye())}),tr({id:`tools.media`,group:`tools`,label:`Media & Storage`,aliases:[`Downloads`,`Offline audio`],keywords:[`download`,`storage`,`recordings`],emptyPriority:38,run:()=>W?.()}),tr({id:`tools.settings`,group:`tools`,label:`Reader Settings`,aliases:[`Preferences`],keywords:[`theme`,`highlight`],emptyPriority:39,run:()=>H?.open()}),tr({id:`admin.open`,group:`admin`,label:`Cue Authoring`,keywords:[`timing`,`authoring`,`record cues`],available:ne?.isUnlocked()??!1,emptyPriority:30,run:()=>ne?.open()})];e.push(...Kt());let t=y?.capture();if(t){let n=Oe().progressSnapshot().anchors,r=br(y?.viewportRange()??null,n)?.run??n.find(e=>e.run)?.run??null;if(r){let n=r.leining.isParsha?vt(r):null;e.push(...ir({run:r,displayTitle:t.viewModel.displayTitleForRun(r),dedupeKeyPrefix:n?`reading.parsha.${n}`:void 0,emptyPriority:85,showWhenEmpty:!1,navigate:e=>K?.navigate(e)}))}}for(let t of wt()){if(t.status!==`available`||!le(t))continue;let n=He(_(),t.parshaSlug),r=n?.run.aliyot.find(e=>e.index===t.aliyah),i=n&&r?Jn(n.run,r.start):Xe(t.parshaSlug);e.push(tr({id:`reading.${t.id}`,group:`reading`,label:`${t.parshaName} Aliyah ${t.aliyah}`,dedupeKey:`reading.parsha.${t.parshaSlug}.${t.aliyah}`,destinationId:i,searchConstraint:{kind:`aliyah`,aliyah:t.aliyah,allowTerms:[`recording`,`audio`]},href:i,aliases:Qt(t),keywords:[`recording`,`audio`],showWhenEmpty:!1,run:()=>K?.navigate(i)}))}e.push(...Jt()),e.push(...Zt()),e.push(...ar({navigateToPage:(e,t)=>K?.navigate(Qe(e,t))}));let r=Qn(n,Date.now(),cr);r&&e.push(tr({id:`resume.last-reading`,group:`resume`,label:`Resume ${r.aliyahLabel?`${r.parshaName}, ${r.aliyahLabel}`:r.parshaName}`,aliases:[`Resume Reading`,`Last Reading`],keywords:[`resume`,`last reading`],emptyPriority:95,destinationId:r.hash,href:r.hash,run:()=>K?.navigate(r.hash)}));for(let t of Ut()){let n=t.kind===`bookmark`?ue.find(e=>e.id===t.id):null;e.push(tr({id:`checkpoint.${t.id}`,group:t.kind===`bookmark`?`resume`:`checkpoint`,label:t.label,badgeLabel:n?zt(n)??void 0:void 0,keywords:[`bookmark`,`checkpoint`,t.tokenKey],emptyPriority:t.kind===`bookmark`?90:88,run:()=>Wt(t)}))}return e}function tn(){J?.refresh(),K?.refreshPickerSearch()}function nn(){if(K?.focusPickerSearch()){J?.close();return}J?.open()}function rn(e){(e?.isConnected&&e.getClientRects().length>0?e:ut()).focus({preventScroll:!0})}let an=null,on=null,sn=null;function cn(){return an||(an=e.createElement(`div`),an.className=`aliyah-start-popup u-hidden`,an.id=`aliyah-start-popup`,an.setAttribute(`role`,`dialog`),an.setAttribute(`aria-label`,`Aliyah start`),e.body.appendChild(an),an)}function un(){an?.classList.add(`u-hidden`),sn?.setAttribute(`aria-expanded`,`false`),on=null,sn=null}function dn(e){let t=e.querySelector(`.aliyah-start-marker`);if(!t)return null;let n=t.getBoundingClientRect();return n.width>0&&n.height>0?t:null}function pn(e,t){let n=e.target?.closest(`.aliyah-start-marker`);return n&&t.contains(n)?n:null}function hn(e){return e.closest(`[data-line-index][data-aliyah-starts]`)}function gn(t,n,r){if(!r)return;let i=e.createElement(`div`);i.className=`aliyah-start-popup-row`;let a=e.createElement(`span`);a.className=`aliyah-start-popup-label`,a.textContent=n;let o=e.createElement(`span`);o.className=`aliyah-start-popup-value`,o.textContent=r,i.append(a,o),t.appendChild(i)}function _n(e,t,n=dn(t)){let r=t.querySelector(`.line-content`);if(!r)return;let i=(n??r).getBoundingClientRect(),a=e.getBoundingClientRect(),o=n?i.left+i.width/2:i.right-4,s=i.top,l=Math.max(8,Math.min(o-a.width/2,c.innerWidth-a.width-8)),u=s-a.height-8,d=u>=8?u:Math.min(s+24,c.innerHeight-a.height-8);e.style.left=`${l}px`,e.style.top=`${Math.max(8,d)}px`}function vn(e,t=dn(e)){if(on===e&&sn===t&&an&&!an.classList.contains(`u-hidden`))return;let n=cn();sn?.setAttribute(`aria-expanded`,`false`),on=e,sn=t,t?.setAttribute(`aria-expanded`,`true`),n.replaceChildren(),gn(n,`Parsha`,e.dataset.aliyahStartTitle??``),gn(n,`Aliyah`,t?.dataset.aliyahStartLabel??e.dataset.aliyahStartLabel??``),gn(n,`Verses:`,e.dataset.aliyahStartVerse??``),n.classList.remove(`u-hidden`),_n(n,e,t)}function Sn(t){let n=ut();n.addEventListener(`click`,e=>{if(!ht()){un();return}if(!(e instanceof MouseEvent))return;let t=pn(e,n),r=t?hn(t):null;if(!r||!t){un();return}e.preventDefault(),e.stopImmediatePropagation(),vn(r,t)},{signal:t.signal}),n.addEventListener(`pointerover`,e=>{if(!ht()||e.pointerType===`touch`)return;let t=pn(e,n),r=t?hn(t):null;!r||!t||vn(r,t)},{signal:t.signal}),n.addEventListener(`pointerout`,e=>{if(e.pointerType===`touch`)return;let t=pn(e,n);if(!t)return;let r=e.relatedTarget;r instanceof Node&&t.contains(r)||un()},{signal:t.signal}),n.addEventListener(`focusin`,e=>{if(!ht())return;let t=e.target?.closest(`.aliyah-start-marker`),n=t?hn(t):null;n&&t&&vn(n,t)},{signal:t.signal}),n.addEventListener(`scroll`,un,{passive:!0,signal:t.signal}),c.addEventListener(`resize`,()=>{un(),C!==null&&c.clearTimeout(C),C=c.setTimeout(()=>{C=null,t.signal.aborted||hr(n)},120)},{signal:t.signal});let r=()=>{t.signal.aborted||(y?.invalidateProgressAnchors(`text-layout`),hr(n),y&&zr())};e.fonts.ready.then(r),e.fonts.addEventListener(`loadingdone`,r,{signal:t.signal}),e.addEventListener(`pointerdown`,e=>{let t=e.target;!an||an.classList.contains(`u-hidden`)||t&&an.contains(t)||t?.closest(`.aliyah-start-marker`)||t?.closest(`[data-aliyah-starts]`)||un()},{signal:t.signal}),t.own(()=>{un(),an?.remove(),an=null,C!==null&&(c.clearTimeout(C),C=null),S&&=(f(S),0)})}function Cn(t){let n=[Wc({id:`palette.open`,key:`k`,metaOrCtrl:!0,modes:[`normal`,`practice-focus`,`admin-authoring`],run:nn}),Wc({id:`issue.mark`,key:`m`,modes:[`admin-authoring`],run:()=>I?.openIssue()}),Wc({id:`phrase.replay`,key:`r`,modes:[`admin-authoring`],run:()=>{z?.replayCurrentCue()}})];e.addEventListener(`keydown`,e=>{St();let t=Gc(n,e,be);if(!t||t.id===`palette.open`&&e.target instanceof Element&&e.target.closest(`[data-target-id="reader-search"]`))return;let r=t.id===`palette.open`&&((J?.isOpen()??!1)||(K?.snapshot().pickerOpen??!1));Kc(e.target)&&!r||(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),t.run())},{capture:!0,signal:t.signal})}function wn(e){let t=K?.snapshot(),n=t?.hashPath.match(/^#\/torah\/parsha\/([^/?]+)/)?.[1],r=y?.capture();if(!n||!r)return e;let i=He(_(),decodeURIComponent(n)),a=i?r.viewModel.relevantRuns.find(e=>e.id===i.run.id)??null:null;if(!a)return e;let o=Fc(r.viewModel.displayTitleForRun(a));return t?.title===o?a:e}function Tn(){let e=z?.snapshot(),t=e?.session;return{target:t?{runId:t.runId,aliyahIndex:t.aliyahIndex}:null,playing:e?.playing??!1,progressLabel:e&&t?`${ya(e.currentTime)}/${ya(e.duration)}`:``}}async function En(e){let t=kn(e.target,{includePreviousOverlap:!0}),n=F(e.target);if(n)return n.message||`Available`;if(!t)return`Available`;let r=await Ot(t),i=r[r.length-1],a=i?.timeEnd??i?.timeStart??0;return a>0?ya(a):`Available`}function On(){let e=K?.snapshot();return e?.view===`reader`&&!e.pickerOpen}function kn(e,{includePreviousOverlap:t=!1}={}){let n=(y?.capture())?.viewModel.relevantRuns.find(t=>t.id===e.runId)??_().parseId(e.runId);return n?yt({narratorId:x.narratorId,run:n,aliyahIndex:e.aliyahIndex})??P(n,e.aliyahIndex)?.recording??(t?Or(n,e.aliyahIndex):null):null}function An(e,t,n){return pi({entries:e,active:t,playback:n,signaturePrefix:x.narratorId,getAudio:({run:e,aliyah:t})=>{let n=yt({narratorId:x.narratorId,run:e,aliyahIndex:t.index}),r=P(e,t.index);return{audioState:r,playbackKey:(r?.recording??n??Or(e,t.index))?.id??null,recordingKey:n?.id??null}}})}function Mn(e=y?.viewportRange()??null,t){if(!On()){O?.clearContent(),y?.syncAudioPreload(null);return}let n=t??Oe().progressSnapshot(),r=n.anchors,i=br(e,r)??n.at(mr(ut())).current,a=i?.run??r.find(e=>e.run)?.run??null;if(!a){O?.clearContent(),y?.syncAudioPreload(null);return}let o=Tn(),s=i?.run&&i.aliyahIndex?{runId:i.run.id,aliyahIndex:i.aliyahIndex}:null,c=fi(a),l=An(c,s,o),u=wn(a)??a,d=fi(u),f=An(d,mi({runId:u.id,current:s,playback:o,first:d[0]?{runId:d[0].run.id,aliyahIndex:d[0].aliyah.index}:null}),o);sr(a,s?.aliyahIndex??null),Oe().scheduleResourcePrewarm(c.flatMap(({run:e,aliyah:t})=>t.index?[{run:e,aliyahIndex:t.index}]:[]),l.signature),O?.syncContent({desktop:l,compact:f,authoringEnabled:I?.isActive()??!1})}function Pn(e,t){let n=performance.now();w={runId:e,aliyahIndex:t,expiresAt:n+2500,maxExpiresAt:n+6e3},ct({runId:e,index:t}),O?.setActive({runId:e,aliyahIndex:t}),Gt(e,t,Xn.start())}function Fn(t){let r=Mi(t,{document:e,onSelect:e=>Pn(e.runId,e.aliyahIndex),onPlayCompact:async e=>(await Lr(e),t.signal.aborted||qe(),Tn()),onPlayCurrent:async e=>{await Lr(e),mt()},onBeforeCompactOpen:()=>{let e=z?.snapshot();return e?.session&&e.playing&&z?.pause(),Tn()},onAfterNavigate:mt,onWideHidden:un,restoreFocus:rn,getReaderFocusTarget:ut,loadCueStatus:async e=>{if(e.recordingKey||!e.audioState)return Ln(kn(e.target));let t=(y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.target.runId)??_().parseId(e.target.runId))?.aliyot.find(t=>t.index===e.target.aliyahIndex);if(!t)return`none`;let n=await j.resolve(t,x.narratorId);return n.cueComplete?`published`:n.portions.some(e=>e.segments.some(e=>e.cues.length>0))?`pending`:`none`},onCueStatusChange:(e,t)=>{e.recordingKey&&(k.set(ke(e.target.runId,e.target.aliyahIndex,e.recordingKey),t),Ar())},loadDurationLabel:En,onCueStatusError:(e,t)=>{console.error(`Failed to load Cue Data status for ${t.key}`,e)},onDurationError:(e,t)=>{console.error(`Failed to load duration for ${t.audioKey??t.key}`,e)}});O=r;let i=new Set(wt().map(e=>Xt(e.id)));c.addEventListener(`storage`,e=>{e.storageArea===n&&(e.key!==null&&!i.has(e.key)||(je(),Ar()))},{signal:t.signal}),t.own(()=>{O===r&&(O=null)})}function In(){w&&(w.expiresAt=Math.min(w.maxExpiresAt,performance.now()+500))}async function Ln(e){if(!e)return`none`;let t=A(e),[n,r]=await Promise.all([Mt(e),t?yn(t):null]);if(r){let t=en(e,r);if(t?.cues.length){let n=await Ot(e);if(!n.length||!Ht(t.cues,n))return`local-draft`}}return n?.isComplete?`published`:n?.isUnfinished?`pending`:`none`}async function Rn(){let e=z?.snapshot(),t=e?.session,r=I?.isVisible()&&I.getSession()?t?.recording??null:t?.activeRecording??t?.recording??null,i=e?.sessionRevision,a=er.start();if(me=[],he=[],ge=null,X=[],I?.recordingIssuesChanged(),zn(),Bn(),t&&r){let e=await At(r,`v2`),t=z?.snapshot(),o=I?.isVisible()&&I.getSession()?t?.session?.recording??null:t?.session?.activeRecording??null;if(!er.isCurrent(a)||t?.sessionRevision!==i||o?.id!==r.id)return;let s={issues:[],revision:null};try{s=pe(n,r.id,`v2`)}catch(e){console.error(`Recording issue storage is unavailable for ${r.id}`,e)}me=e,he=s.issues,ge=s.revision,X=we(me,he),I?.recordingIssuesChanged(),zn(),Bn()}tn()}function zn(e=ut()){e.querySelectorAll(`.word[data-recording-issue]`).forEach(e=>{e.removeAttribute(`data-recording-issue`),e.removeAttribute(`title`)});for(let t of _e(X))e.querySelectorAll(`[data-token-key="${t.tokenKey}"]`).forEach(e=>{e.dataset.recordingIssue=t.kind,e.title=ve(t)})}function Bn(){let t=e.querySelector(`[data-target-id="reader-issue-toast"]`);if(!t)return;let n=Tt(),r=n?_e(X).find(e=>e.tokenKey===n):null;if(!r){t.classList.add(`u-hidden`),t.textContent=``;return}t.textContent=ve(r),t.classList.remove(`u-hidden`)}function Vn(e){let t=z;if(!t)return;let n=y?.capture(),r=t.snapshot().sessionRevision;Y?.recordPlaybackFailure(e,()=>z===t&&t.snapshot().sessionRevision===r&&(n?.isCurrent()??!0))}function Un(e){return Qi(e)}function Kn({recording:e,runId:t,aliyahIndex:n}){return!!(t&&n&&z?.isTargetActive({recordingId:e?.id??null,runId:t,aliyahIndex:n}))}function qn(e,t){let n=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e);return Hi(n,t)}function Yn(e){return!!(e?.run?.id&&e.aliyahIndex&&qn(e.run.id,e.aliyahIndex))}let Xn=new Sa,$n=new Sa,er=new Sa;function nr(){z?.resetRecordingCache(),Xn.cancel(),$n.cancel()}function rr(){return z?.snapshot().playing??!1}function sr(e,t){let n=t?yt({narratorId:x.narratorId,run:e,aliyahIndex:t}):null,r=t?Or(e,t):null,i=n?.playSrc??r?.playSrc??null;y?.syncAudioPreload(i)}function lr(e){let t=c;return t.requestIdleCallback?t.requestIdleCallback(e):c.setTimeout(e,150)}function dr(e){c.cancelIdleCallback?.(e),c.clearTimeout(e)}function fr(e,t){e&&(e.innerHTML=Fe(t))}function pr(e){i.enabled&&e.querySelectorAll(`[data-aliyah-marker="true"]`).forEach(e=>{let t=e.querySelector(`.aliyah-label-text`);if(!t)return;let n=e.dataset.aliyahIndex?Number(e.dataset.aliyahIndex):null;t.textContent=ln(t.textContent??``,n)})}function hr(e){S||=d(()=>{S=0,_r(e)})}function _r(e,t=e){sn&&t instanceof Node&&t.contains(sn)&&un(),t.querySelectorAll(`.aliyah-start-marker`).forEach(e=>e.remove()),t.querySelectorAll(`[data-line-index][data-aliyah-starts]`).forEach(t=>{let n=Er(t);if(!n?.aliyahStarts.length)return;let r=t.querySelector(`.line-content`);if(!r)return;let i=new Map;n.aliyahStarts.forEach(r=>{let a=Ri({book:e,startLine:t,startVerseOrdinal:n.verses.findIndex(e=>$(e,r.start)===0)});if(!a)return;let o=i.get(a);o?o.push(r):i.set(a,[r])}),i.forEach((e,n)=>{let i=e.map(e=>Un(`${e.index??``}`)).filter(e=>!!e).map(ci).join(`, `);if(!i)return;let a=[...t.querySelectorAll(`.word[data-token-key="${n}"]`)].map(e=>zi(e)).find(e=>e!==null);if(!a)return;let o=Vi({label:i,tokenKey:n});o.dataset.aliyahStartLabel=i,r.append(o);let s=o.offsetParent instanceof HTMLElement?o.offsetParent:r,c=s.getBoundingClientRect(),l=Bi({left:c.left+s.clientLeft-s.scrollLeft,top:c.top+s.clientTop-s.scrollTop},a);o.style.setProperty(`--aliyah-start-anchor-x`,`${l.x}px`),o.style.setProperty(`--aliyah-start-anchor-y`,`${l.y}px`)})})}function vr(e){let t=e?.center,n=t?.run,r=y?.capture();return{centerRun:n,memberships:t?ea({runs:r?.viewModel.relevantRuns??(n?[n]:[]),lineRun:n,focalRef:t.focalRef,aliyot:t.aliyot,aliyahStarts:t.aliyahStarts}):[]}}function yr(e,t,n){if(!e)return null;let r=y?.capture()?.viewModel.relevantRuns.find(t=>t.id===e.runId)??(t?.id===e.runId?t:null);if(!r)return null;let i=n.find(t=>t.run?.id===e.runId&&t.aliyahIndex===e.index);return i?{...i,label:ci(e.index)}:{line:null,label:ci(e.index),run:r,aliyahIndex:e.index,position:mr(ut())}}function br(e,t){let{centerRun:n,memberships:r}=vr(e),i=w?{runId:w.runId,index:w.aliyahIndex}:null;if(w){let e=w.expiresAt<=performance.now(),t=r.some(e=>Zi(e,i));(e||t)&&(w=null,i=null)}let a=z?.snapshot().session,o=a&&rr()?{runId:a.runId,index:a.aliyahIndex}:null,s=ta({memberships:r,playback:o,pending:i,explicit:T});return T&&!i&&!o&&!r.some(e=>Zi(e,T))&&lt(),yr(s,n,t)}function xr(e,t,n){if(t===null||n===t)return null;if(n>t){for(let r=e.length-1;r>=0;--r){let i=e[r];if(!(i.position>n)){if(i.position<=t)break;return i}}return null}for(let r of e)if(!(r.position<n)){if(r.position>=t)break;return r}return null}function Sr(e){return[...e.querySelectorAll(`.word`)].find(e=>{let t=e.getBoundingClientRect();return t.width>0&&t.height>0})??null}function Cr(e){let t=e.querySelector(`.word.is-active-word`);if(t)return t;let n=y?.viewportRange()?.center;if(!n)return null;let r=[...e.querySelectorAll(`[data-line-index]`)].find(e=>Er(e)===n);return r?Sr(r)??r:null}function Tr(e,t={}){let n=ut();e?.isConnected&&gr(n,e,t),y?.refreshViewport(),Br()}function Er(e){let t=e.closest(`[data-line-index]`),n=t?.closest(`.tikkun-page`);return!t||!(n instanceof HTMLElement)?null:n.tikkunPage?.lines[Number(t.dataset.lineIndex)]??null}function Dr(e){let t=Er(e),n=Un(e.dataset.aliyahIndex);if(!t||!n)return null;let r=e.dataset.runId??t?.run?.id,i=(y?.capture())?.viewModel.relevantRuns.find(e=>e.id===r)??(t?.run?.id===r?t.run:null)??(r?_().parseId(r):null);if(!i)return null;let a=z?.lookupRecording(i,n),o=a?.recording??yt({narratorId:x.narratorId,run:i,aliyahIndex:n});return{lineInfo:t,run:i,aliyahIndex:n,recording:o,audioState:P(i,n),available:a?.available??!!(o||Or(i,n))}}function Or(e,t){return z?.lookupRecording(e,t).overlapRecording??null}function kr(...e){z?.authorizePlayback(...e)}function Ar(){let t=z?.snapshot();for(let n of e.querySelectorAll(`[data-audio-button="true"]`)){let e=Dr(n),r=!!e?.available,i=I?.isActive()??!1,a=!!(e&&i&&!e.recording),o=e?.recording?Ae(e.run.id,e.aliyahIndex,e.recording.id):null,s=e?.audioState?e.audioState.problem===`incomplete-cues`:!!(e?.recording&&o&&Oi(o)),c=!!(Kn({recording:e?.recording,runId:e?.run.id,aliyahIndex:e?.aliyahIndex})&&t?.playing),l=bn({state:e?.audioState,available:r,cueIncomplete:s,adminMissing:a,playing:c});n.disabled=!1,n.setAttribute(`aria-disabled`,String(l.actionDisabled)),n.dataset.audioTone=l.tone,n.dataset.audioDimmed=String(l.dimmed),n.dataset.audioTooltip=l.tooltip,fr(n,c?`pause`:`play`);let u=e?.lineInfo.labels[0]??`aliyah`;n.title=a?`Select ${u} for audio and cue recording`:i&&s&&o?ki({label:u,status:o,playing:c}):r?`${c?`Pause`:`Play`} ${u}`:`Recording unavailable`,!i&&e?.audioState?.message&&(n.title+=` — ${e.audioState.message}`),n.dataset.audioProblem=e?.audioState?.problem??``,n.setAttribute(`aria-label`,n.title),n.removeAttribute(`title`),o?n.dataset.cueStatus=o:delete n.dataset.cueStatus,n.classList.toggle(`is-active`,c),n.classList.toggle(`is-missing-audio`,a),n.classList.toggle(`is-cue-incomplete`,s)}}function jr(e){let t=z?.snapshot(),n=e?.run&&e.aliyahIndex?yt({narratorId:x.narratorId,run:e.run,aliyahIndex:e.aliyahIndex}):null,r=e?.run&&e.aliyahIndex?Or(e.run,e.aliyahIndex):null,i=I?.isActive()??!1,a=e?.run&&e.aliyahIndex&&n?Ae(e.run.id,e.aliyahIndex,n.id):null,o=K?.snapshot().pickerOpen??!1,s=e?.run&&e.aliyahIndex?P(e.run,e.aliyahIndex):void 0,c=!!(e?.run&&e.aliyahIndex&&(n||r||s?.recording)&&!o),l=!!(e?.run&&e.aliyahIndex&&!n&&i&&!o),u=!!(Kn({recording:n,runId:e?.run?.id,aliyahIndex:e?.aliyahIndex})&&t?.playing),d=wn(e?.run??null),f=d?fi(d):[],p=t?.session,m=!!(d&&p?.runId===d.id),h=!!(m&&rr()),g=h?p?.aliyahIndex??null:e?.run?.id===d?.id?e?.aliyahIndex??null:f[0]?.aliyah.index??null,_=h?p?.runId??``:e?.run?.id===d?.id?e?.run?.id??``:d?.id??``,v=!!(m&&p?.runId===_&&p?.aliyahIndex===g),y=_&&g?{runId:_,aliyahIndex:g}:null,b=!!(y&&(kn(y,{includePreviousOverlap:!0})||I?.isActive()));O?.syncToolbar({current:{labelVisible:!!(e&&!o),label:e?.label??`—`,target:e?.run&&e.aliyahIndex?{runId:e.run.id,aliyahIndex:e.aliyahIndex}:null,audioAvailable:c,audioState:s,authoringAvailable:l,authoringEnabled:i,cueStatus:a,playing:u},compact:{visible:!!(d&&g&&!o),target:y,label:g?ci(g):`—`,playbackState:Ei({loaded:v,playing:v&&h}),audioAvailable:b,audioState:F(y),authoringMissing:!!(i&&y&&!kn(y)),cueIncomplete:!!(a&&Oi(a)&&e?.run?.id===_&&e?.aliyahIndex===g)}})}async function Mr({runId:e,aliyahIndex:t}){let n=Oe().capture();if(!n)return[];let r=n.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e),i=Ui(r,t);if(!r||!i)return[];let a=await yn(i);return n.isCurrent()?[...a]:[]}async function Nr({runId:e,aliyahIndex:t},n){let r=z;if(!r)return;ct({runId:e,index:t});let i=await r.loadRecording({runId:e,aliyahIndex:t},{mode:`authoring`});if($n.isCurrent(n)){if(!i){console.error(`Could not prepare ${e}:${t} for audio authoring`);return}Hr()}}async function Pr(e,t){let n=`${t.runId}:${t.aliyahIndex}:${x.narratorId}`;N.delete(n);try{return await e.loadRecording(t)}catch(e){return e instanceof DOMException&&e.name===`AbortError`?null:(console.error(`Could not prepare aliyah playback`,e),N.set(n,{problem:`load-failed`,issue:`audio`,canPlay:!1,recording:kn(t),message:`The recording could not load. Try again.`}),Hr(),Br(),Re(e instanceof Error?e.message:`Audio could not be loaded. Retry playback.`),null)}}async function Ir(e){if(e.getAttribute(`aria-disabled`)===`true`)return;let t=z;if(!t)return;let n=Dr(e);if(!n)return;let r=$n.start();if(I?.isActive()&&!n.recording){await Nr({runId:n.run.id,aliyahIndex:n.aliyahIndex},r);return}if(!n.available||n.audioState?.problem===`checking`)return;if(ct({runId:n.run.id,index:n.aliyahIndex}),t.isTargetActive({recordingId:n.recording?.id??null,runId:n.run.id,aliyahIndex:n.aliyahIndex})){let n=t.snapshot().paused,r=t.toggle(()=>Ir(e));n&&await t.restoreActiveHighlight({scroll:!0}),await r;return}let i=t.lookupRecording(n.run,n.aliyahIndex);(!i.passage||![`partial-audio`,`timing-needed`].includes(i.passage.problem??``))&&kr(i.passage?.recording,i.recording,i.overlapRecording,n.recording),await Pr(t,{runId:n.run.id,aliyahIndex:n.aliyahIndex})&&$n.isCurrent(r)&&await t.play(()=>Ir(e))}async function Lr({runId:e,aliyahIndex:t}){let n=z;if(!n)return;let r=$n.start(),i=(y?.capture())?.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e);if(!i)return;let a=n.lookupRecording(i,t),o=!!(I?.isActive()&&!a.recording);if(!o&&(!a.available||a.passage?.problem===`checking`))return;if(n.isTargetActive({recordingId:a.recording?.id??null,runId:e,aliyahIndex:t})){ct({runId:e,index:t}),await n.toggle(()=>Lr({runId:e,aliyahIndex:t}));return}let s=()=>Lr({runId:e,aliyahIndex:t});!o&&(!a.passage||![`partial-audio`,`timing-needed`].includes(a.passage.problem??``))&&kr(a.passage?.recording,a.recording,a.overlapRecording);let c=await Oe().ensureAliyahDomTargetRendered(e,t);if($n.isCurrent(r)&&(c?.marker??c?.element)){if(o){await Nr({runId:e,aliyahIndex:t},r);return}ct({runId:e,index:t}),await Pr(n,{runId:e,aliyahIndex:t})&&$n.isCurrent(r)&&await n.play(s)}}function Rr(e=y?.viewportRange()??null){let t=ut(),n=Oe().progressSnapshot(),r=n.anchors,a=r.length?mr(t):0,o=De&&r.length?xr(r,Ee,a):null;Ce&&(Ee=a,De=!1);let s=jc({source:n,viewportPosition:a,getScrollHeight:()=>t.scrollHeight,rangeCurrent:r.length?br(e,r):null,isLastAnchor:Yn});if(Ce&&!i.enabled){let e=ze(o);e&&K?.syncScrolledReading(e)}if(s.kind===`empty`){pt().setProgress({label:s.label,percent:s.percent}),jr(null),U?.sync(),Mn(e,n);return}if(pt().setProgress({label:s.label}),jr(s.current),U?.sync(),Mn(e,n),s.kind===`request-next-anchor`){Oe().ensureNextProgressAnchorLoaded(s.requestNextAnchor.afterIndex).then(()=>zr()).catch(e=>{console.error(`Failed to load the next reader progress anchor`,e)});return}pt().setProgress({percent:s.percent})}function zr(){if(y){y.invalidatePresentationAfterLayout(`reader-position`);return}Rr()}function Br(){if(y){y.invalidatePresentation(`reader-position`);return}Rr()}function Vr(e=!1){if(!e){let e=Oe().progressSnapshot(),t=mr(ut());jr(e.at(t).current)}O?.syncPlayback(Tn())}function Hr(){if(y){y.invalidatePresentation(`inline-audio`,`playback-state`);return}Ar(),Vr()}function Ur(){if(y){y.invalidatePresentation(`inline-audio`,`reader-position`);return}Ar(),Rr()}function Yr(e){let t=e.focalPointMode!==void 0&&e.focalPointMode!==x.focalPointMode?Cr(ut()):null,n=e.readerTextLayout!==void 0&&e.readerTextLayout!==x.readerTextLayout||e.readerSideMode!==void 0&&e.readerSideMode!==x.readerSideMode,r=qr(x,e);try{fe=Gr(r,fe)}catch(t){if(console.error(`Failed to save reader preferences`,t),t instanceof Kr&&t.cause instanceof ce&&t.cause.reason===`conflict`){let t=Wr(),n=qr(t.preferences,e);try{fe=Gr(n,t.revision),r=n}catch(e){console.error(`Failed to save reader preferences after refreshing browser state`,e),Q(`Reader settings changed in another tab. This change applies now but could not be saved.`)}}else Q(`Reader settings will apply now but could not be saved.`)}x=r,n?ft({beforeLayout:()=>Jr(x)}):Jr(x),Tr(t,{behavior:`smooth`}),Ur()}function Xr(e,t){let n=null,r=0,i=()=>{y?.invalidateProgressAnchors(`viewport-resized`),n??=Cr(t),nt(),!r&&(r=d(()=>{r=0;let i=n;n=null,Ne(t,e.signal),Tr(i)}))};nt(),c.addEventListener(`resize`,i,{signal:e.signal}),c.visualViewport?.addEventListener(`resize`,i,{signal:e.signal}),e.own(()=>{n=null,r&&f(r),r=0})}let Zr=!l.hash,Qr=e.querySelector(`[data-target-id="reader-audio"]`);i.enabled&&(e.documentElement.dataset.recordingMode=`true`);let $r=Wr();fe=$r.revision,x=i.enabled?fn($r.preferences):$r.preferences,Jr(x);let ei=xo(n,cr);ue=ei.bookmarks,de=ei.revision;let ti,ni=v(m=>{let g=o??te();o||m.own(()=>g.destroy()),L(async()=>{let{mountAudioButtonTooltip:e}=await import(`./BfkxMN6I.js`);return{mountAudioButtonTooltip:e}},[],import.meta.url).then(({mountAudioButtonTooltip:t})=>{m.signal.aborted||t(m,e)}).catch(e=>console.error(`Could not load audio tooltips`,e));let v=Fo(m,{document:e,initialTitle:Pc,initialAnnotationsEnabled:xe,onTitleClick:()=>{J?.close(),K?.togglePicker({animate:!0})},onAboutClick:()=>{O?.closeCompact(),K?.toggleAbout()},onAnnotationsChange:et,onSwapSides:()=>{Yr({readerSideOrder:x.readerSideOrder===`tikkun-right`?`torah-right`:`tikkun-right`})}});G=v,m.own(()=>{G===v&&(G=null)});let S=ut(),C=Wn(m,c);ee=C,ft({rerender:!1}),C.onChange(()=>{ft(),H?.sync()}),m.own(()=>{ee===C&&(ee=null)});let w=new Gn,T=kc({document:e,view:c,root:S,search:l.search,frame:{request:d,cancel:f},timer:{set:(e,t)=>c.setTimeout(e,t),clear:e=>c.clearTimeout(e)},background:{request:lr,delay:(e,t)=>c.setTimeout(e,t),cancel:dr},effects:{beforeDisplayReplacement(){k.clear()},resetDisplayResources:nr,afterDisplayReplacementReset:Mn,displayCreated(e){z?.setDisplay(e)},displayDeactivating(){Y?.clearPlaybackFailure()},resolveRun:e=>_().parseId(e),getPlaybackProtectedPageNumbers:e=>z?.protectedCuePageNumbers(e)??[],isPlaybackActive:rr,async prewarmCueData({run:e,aliyahIndex:t}){let n=yt({narratorId:x.narratorId,run:e,aliyahIndex:t});n&&await Ot(n)},present(e){let t=e.includes(`viewport-title`),n=e.includes(`reader-position`),r=e.includes(`playback-state`),i=y?.capture(),a=y?.viewportRange()??null;if(t&&i&&a){w.setLine(i.viewModel,a);let e=w.info.currentRun;K?.setTitle(Fc(e?i.viewModel.displayTitleForRun(e):void 0))}e.includes(`inline-audio`)&&Ar(),n&&Rr(),r&&Vr(n)},reportError(e,t){e?console.error(e,t):console.error(t)}}});y=T,m.own(()=>{T.destroy(),y===T&&(y=null)});let A=null,M;m.own(()=>M?.());let N=so(m,{document:e,view:c,audioElement:Qr,book:S,viewport:C,initialPlaybackRate:x.playbackRate,timeline:{getAutoScroll:()=>x.autoScrollWithPlayback,getPlaybackRate:()=>x.playbackRate,onPlaybackRateChange:e=>{x=qr(x,{playbackRate:e}),Jr(x),H?.sync()},isCueAuthoringRecording:()=>I?.isRecording()??!1,saveReadingPosition:qe,focusReader:mt,restoreFocus:rn},recording:{passages:j,choosePassagePortion:async(t,n,r)=>{let{createPassageAudioDialog:i}=await L(async()=>{let{createPassageAudioDialog:e}=await import(`./BfkxMN6I.js`);return{createPassageAudioDialog:e}},[],import.meta.url);return n.aborted||m.signal.aborted?null:(A??=i(m,e),A(t,n,r))},library:{findRecording:yt,findAuthoringRecording:bt,listRecordings:wt,loadCues:Ot},display:{resolveRun:e=>T.capture()?.viewModel.relevantRuns.find(t=>t.id===e)??_().parseId(e),collectTokenKeys:Mr,waitUntilReady:()=>T.waitUntilReaderReady(),resolveRunForRecording:e=>le(e)?T.capture()?.viewModel.relevantRuns.find(t=>vt(t)===e.parshaSlug)??null:null},authoring:{isActive:()=>I?.isActive()??!1,isVisible:()=>I?.isVisible()??!1,hasSession:()=>!!I?.getSession(),bindSession:async()=>{await I?.bindSession()},clearSession:()=>I?.clearSession()},getNarratorId:()=>x.narratorId,recordingMode:i.enabled}});z=N;let P=e.baseURI,F=g.getLibrary(e=>za({baseUrl:P,navigator:u,storage:n,inUse:e}),{view:c,document:e,intentKey:Ea}),V=Ba({currentSources:()=>N.snapshot().session?.mediaSources??[],whenReleased:()=>N.whenAudioReleased(),onReleased:()=>F.releasePlayback()}),ie,ae=g.protectPlayback(e=>(ie??V.sources()).some(t=>new URL(t,P).href===e.url));m.signal.addEventListener(`abort`,()=>{ie=V.freeze()},{once:!0}),M=()=>{N.whenAudioReleased().then(ae).catch(e=>console.error(`Could not release recording download protection`,e))};let oe,ce,ue=t=>{if(H?.close({restoreFocus:!1}),oe){oe.open({returnFocus:t,narratorId:x.narratorId});return}ce||=L(async()=>{let{createMediaPanel:e}=await import(`./eHf_RGi8.js`);return{createMediaPanel:e}},__vite__mapDeps([33,1,8,2,34,11,13,5,6,7,9,10,16,35]),import.meta.url).then(({createMediaPanel:n})=>{m.signal.aborted||(oe=n(m,{document:e,generator:_(),library:F,recordings:wt(),narrators:Ct(),narratorId:x.narratorId}),oe.open({returnFocus:t,narratorId:x.narratorId}))}).catch(e=>{console.error(`Could not open Media`,e),m.signal.aborted||Q(`Media could not be opened. Try again.`)}).finally(()=>{ce=void 0})};W=ue,m.own(()=>{W===ue&&(W=null)}),m.own(N.subscribe((e,t)=>{(e.type===`session-loaded`||e.type===`route-reset`)&&V.sync().catch(e=>console.error(`Could not remove released recordings`,e)),e.type===`reader-chrome`?(t.playing&&Y?.clearPlaybackFailure(),Hr()):e.type===`aliyah-playback`?O?.syncPlayback(Tn()):e.type===`session-loaded`?(Y?.clearPlaybackFailure(),Ar(),Rn(),je(),Mn(),H?.sync()):e.type===`segment-updated`?(Rn(),H?.sync()):e.type===`active-token-changed`?Bn():e.type===`playback-error`?(Hr(),Br(),u.onLine&&(console.error(`Audio playback failed for ${e.recording.id}`,e.error),Re(`This recording could not play. Check your connection and try again.`,{assertive:!0}))):e.type===`offline-media-error`&&Vn(e.retry)})),m.own(()=>{Ie(),z===N&&(z=null)});let de=N.cueAuthoringAdapter(),fe=qc(m,{sessionStorage:r,mount:(t,i)=>i.createCueAuthoring(t,{document:e,view:c,playback:de,localStorage:n,sessionStorage:r,getAutoScroll:()=>x.autoScrollWithPlayback,getActiveTokenKey:Tt,getMergedRecordingIssues:()=>X,getLocalRecordingIssues:()=>he,getLocalRecordingIssueRevision:()=>ge,focusReader:mt,formatDuration:ya,onChange:e=>{e===`access`?tn():e===`cue-data`?(je(),Ar(),Rn()):e===`draft`?(je(),Ar()):e===`mode`?St():e===`playback`?de.refresh():e===`playback-progress`&&de.refresh(`progress`)},onCueNavigationChange:e=>{de.setCueIndex(e)},onLocalRecordingIssuesChanged:(e,t)=>{he=e,ge=t,X=we(me,he),zn(),Bn(),tn()},showPersistenceNotice:Q}),onMounted:e=>{I=e},onUnmounted:e=>{I===e&&(I=null)},onLoadError:e=>{console.error(`Failed to load Cue Authoring`,e)}});ne=fe,m.own(()=>{ne===fe&&(ne=null)});let pe=Vc(m,{document:e,disabled:i.enabled,onResume:e=>{K?.navigate(e.hash,{saveReadingAfterRender:!0})}});q=pe,m.own(()=>{q===pe&&(q=null)});let _e=or(m,{document:e,getActions:$t,createGenerator:_,restoreFocus:mt,isBookmarkAction:Vt,formatBadge:Bt,onLoadError:e=>{console.error(`Failed to load the search overlay`,e),Q(`Search could not be opened. Reload this page to try again.`)}});J=_e,m.own(()=>{J===_e&&(J=null)});let ve=Hc(m,{document:e,view:c,onRetryError:e=>{console.error(`Failed to retry recording after reconnecting`,e)}});Y=ve,m.own(()=>{Y===ve&&(Y=null)}),Fn(m);let ye=jo(m,{document:e,getState:Ft,toggleBookmark:()=>{Nt(),mt()},openAliyahNavigation:e=>{if(ht()){O?.openCompact(e);return}O?.revealWide(`expanded`),O?.scheduleWideHide(),mt()},showAliyahStarts:()=>{O?.revealWide(`peek`),mt()},toggleAnnotations:()=>{et(!xe),mt()},openSettings:e=>{H?.open({returnFocus:e})},openMedia:ue,shareReading:async()=>{try{let e=await ur(Lt(),{navigator:u,nativeShare:re()?async e=>{let{Share:t}=await L(async()=>{let{Share:e}=await import(`./BVZf8LWP.js`);return{Share:e}},__vite__mapDeps([36,6,9]),import.meta.url);return t.share(e)}:void 0});!m.signal.aborted&&e===`copied`&&Re(`Reading link copied.`)}catch(e){console.error(`Could not share reading`,e),m.signal.aborted||Re(`Reading could not be shared. Try again.`,{assertive:!0})}}});U=ye,m.own(()=>{U===ye&&(U=null)}),Cn(m);let be=Zr&&!i.enabled?Qn(n,Date.now(),cr):null;Sn(m),st(m,S),Xr(m,S),re()&&mn(m,e,()=>{if(!N.snapshot().paused)throw Error(`Pause audio before applying the update.`);if(I?.isActive()||i.enabled)throw Error(`Finish recording or editing before applying the update.`);if(F?.snapshot().entries.some(e=>[`queued`,`downloading`,`verifying`,`removing`].includes(e.phase)))throw Error(`Wait for downloads to finish, or pause them before applying the update.`);let e=Ge();if(!e)throw Error(`Wait for your reading to load before applying the update.`);Zn(n,e)});let Te=wo(m,{document:e,view:c,narrators:Ct(),getPreferences:()=>x,updatePreferences:e=>Yr(e),setPlaybackRate:e=>{N.setPlaybackRate(e),Ur()},restoreFocus:rn,animateThemeChanges:!i.enabled,serviceWorker:B(c.navigator),getCurrentRecording:()=>N.snapshot().session?.activeRecording??null,downloadLibrary:F,openMedia:()=>ue(e.querySelector(`[data-target-id="settings-toggle"]`)??void 0),onLoadError:e=>{console.error(`Failed to load Reader Settings`,e),Q(`Reader Settings could not be opened. Reload this page to try again.`)}});H=Te,m.own(()=>{H===Te&&(H=null)}),ot(m);let Oe=tt(()=>qe(),1e3);m.own(Oe.cancel);let ke=()=>{(!Ce||Ee===null)&&(Ee=mr(S)),Ce=!0},Ae=()=>{Se=!0,ke(),q?.dismiss()};S.addEventListener(`pointerdown`,ke,{passive:!0,signal:m.signal}),S.addEventListener(`keydown`,ke,{signal:m.signal}),S.addEventListener(`wheel`,Ae,{passive:!0,signal:m.signal}),S.addEventListener(`touchstart`,Ae,{passive:!0,signal:m.signal}),S.addEventListener(`keydown`,p(`ArrowDown`,Ae),{signal:m.signal}),S.addEventListener(`keydown`,p(`ArrowUp`,Ae),{signal:m.signal}),S.addEventListener(`keydown`,p(`PageDown`,e=>{Ae(e),O?.revealWideForMovement()}),{signal:m.signal}),S.addEventListener(`keydown`,p(`PageUp`,e=>{Ae(e),O?.revealWideForMovement()}),{signal:m.signal}),S.addEventListener(`scroll`,()=>{Ce&&(De=!0),T.onReaderScroll(()=>{let e=S.scrollTop,t=D;D=e,In(),t!==null&&Math.abs(e-t)>=28&&!N.snapshot().playing&&O?.revealWideForMovement()}),Se&&Oe()},{signal:m.signal}),S.addEventListener(`page-rendered`,e=>{let t=e instanceof CustomEvent?e.detail?.node:null,n=t instanceof Element?t:S;Nn(n,xe),Ne(n,m.signal),T.pageRendered(n,()=>{_r(S,S.dataset.readerLayout===`reading`?S:n),pr(n),zn(n)}),!rr()&&(Ur(),N.syncHighlight({scroll:!1}))},{signal:m.signal}),S.addEventListener(`page-evicted`,e=>{let t=e instanceof CustomEvent?e.detail?.pageNumber:null;T.pageEvicted(Number.isInteger(t)?t:null)},{signal:m.signal});let Me=null,Fe=[`button`,`a`,`input`,`select`,`textarea`,`[contenteditable="true"]`,`[data-reader-no-form-toggle="true"]`].join(`,`);S.addEventListener(`pointerdown`,e=>{let t=e.target;if(!ht()||!(t instanceof Element)||!S.contains(t)||t.closest(Fe)){Me=null;return}Me={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,startedAt:performance.now(),canceled:!1,readyAt:null}},{passive:!0,signal:m.signal}),S.addEventListener(`pointermove`,e=>{!Me||Me.pointerId!==e.pointerId||Math.hypot(e.clientX-Me.startX,e.clientY-Me.startY)>8&&(Me.canceled=!0)},{passive:!0,signal:m.signal}),S.addEventListener(`pointerup`,e=>{if(!Me||Me.pointerId!==e.pointerId)return;let t=performance.now()-Me.startedAt;Me.readyAt=!Me.canceled&&t<450?performance.now():null},{passive:!0,signal:m.signal}),S.addEventListener(`pointercancel`,()=>{Me=null},{passive:!0,signal:m.signal});function Le(e){let t=Me;if(Me=null,!t?.readyAt||performance.now()-t.readyAt>500||dt().sides!==`one`)return!1;let n=e.target;if(!(n instanceof Element)||!S.contains(n)||n.closest(Fe))return!1;let r=c.getSelection();return!r||r.isCollapsed}S.addEventListener(`click`,async t=>{let n=t.target,r=n.closest(`[data-audio-button="true"]`);if(r){t.preventDefault(),await Ir(r),Ve(T.progressAnchorForElement(r)),mt();return}if(await oi(t,{nativeWriteText:re()?async e=>{let{Clipboard:t}=await L(async()=>{let{Clipboard:e}=await import(`./CJ7KFjv4.js`);return{Clipboard:e}},__vite__mapDeps([37,9]),import.meta.url);await t.write({string:e})}:void 0,onError:()=>{m.signal.aborted||Re(`Reading link could not be copied. Try again.`,{assertive:!0})}}))return;let i=n.closest(`.word`),a=N.snapshot();if(Le(t)&&(!i||!a.session)){t.preventDefault(),et(!xe),mt();return}if(!i||!a.session)return;let o=i.dataset.tokenKey??null;if(!o)return;let s=N.tokenIndex(o),c=N.cueForToken(o),l=a.playing;if(I?.isActive()&&!I.isRecording()&&s>=0){t.preventDefault(),await I.selectReaderToken(s,{play:l&&!!c,preservePlayback:l,seekToCue:!!c,focusRow:!0}),jr(T.progressAnchorForElement(i));return}let u=await N.activateSessionToken(o,{play:!!c,seekToCue:!!c,retry:async()=>{e.body.contains(i)&&i.click()},scroll:x.autoScrollWithPlayback}),d=T.progressAnchorForElement(u??i);jr(d),Ve(d)},{signal:m.signal});let $=Uc({getValue:()=>xe,setValue:et,isDisabled:()=>x.disableShiftNekudotHide});e.addEventListener(`keydown`,$.handleKeyDown,{signal:m.signal}),e.addEventListener(`keyup`,$.handleKeyUp,{signal:m.signal}),c.addEventListener(`blur`,$.release,{signal:m.signal}),m.own($.release),e.addEventListener(`keydown`,p(`/`,e=>{gt(e.target)||(e.preventDefault(),J?.close(),K?.togglePicker())}),{signal:m.signal}),e.addEventListener(`keydown`,p(`Escape`,e=>{if(O?.isCompactOpen()&&(e.preventDefault(),O.closeCompact()),N.closeOverlay()){e.preventDefault();return}K?.snapshot().pickerOpen&&(e.preventDefault(),K.closePicker()),H?.close(),I?.closeOverlays(),J?.close(),un()}),{signal:m.signal}),e.addEventListener(`click`,e=>{if(e.defaultPrevented)return;let t=e.target.closest(`a[href^="#/"]`);if(!t)return;let n=t.getAttribute(`href`);(!n||n===l.hash)&&(e.preventDefault(),K?.navigate(n??l.hash))},{signal:m.signal}),e.addEventListener(`keydown`,e=>{if(!fe.handleShortcut(e)&&!e.defaultPrevented&&!gt(e.target)&&!(K?.snapshot().view!==`reader`||!N.snapshot().session)){if(e.code===`Space`){e.preventDefault(),N.toggle(async()=>{await N.play()});return}if(e.key===`ArrowRight`){e.preventDefault(),N.step(1);return}e.key===`ArrowLeft`&&(e.preventDefault(),N.step(-1))}},{signal:m.signal}),i.enabled&&L(async()=>{let{mountRecordingHarness:e}=await import(`./CzimoaS5.js`);return{mountRecordingHarness:e}},[],import.meta.url).then(({mountRecordingHarness:t})=>{if(m.signal.aborted)return;let n=N.recordingHarnessAdapter();t(m,{document:e,view:c,playback:n,isReaderReady:()=>T.isReaderReady(),waitUntilReaderReady:()=>T.waitUntilReaderReady(),getBook:ut})}).catch(e=>{m.signal.aborted||console.error(`Failed to load the Recording Harness`,e)}),fe.restoreIfOpen();let ze=Bc(m,{document:e,view:c,shell:v,createGenerator:_,getCalendarSettings:()=>h,updateCalendarSettings:$e,getSearchActions:$t,isBookmarkAction:Vt,formatSearchBadge:Bt,host:{renderReader:Z,leaveReader:()=>{N.pause(),Ie(),xt(),q?.hide()},openAbout:()=>{if(!s){t.location.assign(a);return}s().catch(e=>{console.error(`Could not open About`,e),m.signal.aborted||Re(`About could not be opened. Try again.`,{assertive:!0})})},readerRouteChanged:e=>{Ce=!1,Ee=null,De=!1,E!==e&&lt(),Ze(),T.resetViewport(),U?.close(),un(),O?.revealWide(`peek`)},readerReady:()=>{let e=T.capture();Ur();let t=K?.snapshot();!i.enabled&&t?.view===`reader`&&R(t.currentReaderHash)&&se({reading:{hash:t.currentReaderHash,parshaName:t.title}}),z===N&&N.syncHighlight({scroll:!1}).catch(t=>{e?.isCurrent()&&console.error(`Failed to restore reader highlight`,t)});let n=Pe();n&&z===N&&N.activateToken(n,{scroll:!1}).catch(t=>{e?.isCurrent()&&console.error(`Failed to activate debug token`,t)})},preparePicker:()=>{J?.close(),xt()},pickerChanged:e=>{Mn(),e?jr(null):Ur()},pickerLoadFailed:e=>{console.error(`Failed to load the Reading Index`,e),Q(`The Reading Index could not be opened. Reload this page to try again.`)},captureReadingPosition:Ge,showReturnToPreviousReading:e=>{q?.show(e,`return`)},dismissLastReadingPrompt:()=>q?.dismiss(),saveReadingPosition:qe}});K=ze,m.own(()=>{K===ze&&(K=null)});let Be=re()&&!i.enabled;ti=ze.start(Be?{resumeHash:be?.hash??null}:void 0),m.own(()=>{b!==null&&(c.clearTimeout(b),b=null);let t=e.querySelector(`[data-target-id="persistence-toast"]`);t&&(t.classList.add(`u-hidden`),t.textContent=``,t.setAttribute(`role`,`status`),t.setAttribute(`aria-live`,`polite`)),J?.close(),Y?.hide(),q?.hide()}),be&&!Be&&q?.show(be)});return{ready:ti,destroy:ni}}var Yc=x({startApp:()=>Zc,stopApp:()=>Qc}),Xc=null;function Zc(e={}){if(Xc)return Xc;let t=document.querySelector(`[data-target-id="app-root"]`)?.dataset.aboutHref;if(!t)throw Error(`Reader bootstrap requires an About page URL`);return Xc=Jc({document,view:window,localStorage:q(`local`),sessionStorage:q(`session`),recordingMode:un(new URL(window.location.href)),aboutHref:t,...e}),Xc}function Qc(){Xc?.destroy(),Xc=null}export{Mt as C,wt as D,Ct as E,Dt as O,Et as S,Ot as T,$t as _,Jr as a,Lt as b,qr as c,Sn as d,dn as f,Yt as g,an as h,Ca as i,ht as k,Xr as l,on as m,Ia as n,Yr as o,cn as p,ka as r,Ir as s,Zc as startApp,Qc as stopApp,Yc as t,Un as u,rn as v,jt as w,Nt as x,Ht as y};